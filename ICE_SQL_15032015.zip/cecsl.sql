-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Dim 15 Mars 2015 à 12:19
-- Version du serveur :  5.5.41-0ubuntu0.14.04.1
-- Version de PHP :  5.5.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `cecsl`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE IF NOT EXISTS `achat_presta` (
`idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Contenu de la table `achat_presta`
--

INSERT INTO `achat_presta` (`idachatpresta`, `date_achat`, `idprestation`, `qte`, `total_achat`) VALUES
(8, '28-01-2015', 71, '100', '760'),
(9, '28-01-2015', 80, '2', '78'),
(10, '30-01-2015', 81, '1', '37'),
(11, '30-01-2015', 82, '8', '39.6'),
(13, '30-01-2015', 71, '75', '570'),
(14, '07-01-2015', 78, '24', '51.6'),
(16, '08-01-2015', 71, '25', '185'),
(17, '08-03-2015', 73, '6', '222'),
(18, '14-01-2015', 75, '2', '138'),
(22, '11-02-2015', 84, '1', '17.5'),
(23, '11-02-2015', 85, '2', '47'),
(24, '17-02-2015', 71, '50', '380'),
(25, '13-02-2015', 71, '50', '380'),
(29, '13-02-2015', 90, '20', '244'),
(30, '19-02-2015', 90, '20', '244'),
(31, '26-02-2015', 0, '20', '0'),
(32, '26-02-2015', 90, '20', '244'),
(33, '10-03-2015', 71, '75', '570');

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ayant_droit` (
`idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=215 ;

--
-- Contenu de la table `ayant_droit`
--

INSERT INTO `ayant_droit` (`idayantdroit`, `idsalarie`, `nom_ayant_droit`, `prenom_ayant_droit`, `date_naissance_ayant_droit`) VALUES
(80, 3, 'AMARA', 'Nadia', ''),
(81, 3, 'AMARA', 'Meline', ''),
(82, 15, 'BINOT', 'Jules', ''),
(83, 16, 'BIZMAOUI PAPIN', 'Lony', ''),
(84, 16, 'BIZMAOUI PAPIN', 'Levy', ''),
(85, 21, 'BONARDE', 'Flora', ''),
(86, 21, 'BONARDE', 'Marie', ''),
(87, 26, 'BOURGAUD', 'Killian', ''),
(88, 26, 'BOURGAUD', 'Emma', ''),
(89, 26, 'BOURGAUD', 'Alix', ''),
(90, 31, 'BRISSY', 'Margot', ''),
(91, 37, 'CHAILLAND', 'Adele', ''),
(92, 37, 'CHAILLAND', 'Solene', ''),
(93, 37, 'CHAILLAND', 'Nais', ''),
(94, 38, 'CHAILLOUX', 'Maruis', ''),
(95, 38, 'CHAILLOUX', 'Capucine', ''),
(96, 41, 'CHARRIER', 'Ilona', ''),
(97, 41, 'CHARRIER', 'Emma', ''),
(98, 44, 'CH?TEAU', 'Leo', ''),
(99, 44, 'CH?TEAU', 'Kelia', ''),
(100, 50, 'COCHIN', 'Vincent', ''),
(101, 50, 'COCHIN', 'Benoit', ''),
(102, 52, 'COLAISSEAU', 'Alice', ''),
(103, 52, 'COLAISSEAU', 'Paul', ''),
(104, 58, 'DAVY', 'Baptiste', ''),
(105, 61, 'DELEMME', 'Noah', ''),
(106, 61, 'DELEMME', 'Hugo', ''),
(107, 63, 'DENECHERE', 'Thomas', ''),
(108, 63, 'DENECHERE', 'Rose', ''),
(109, 66, 'DEVAUD', 'Heloise', ''),
(110, 67, 'DIJOLS', 'Eden', ''),
(111, 68, 'DOISNEAU', 'Enzo', ''),
(112, 70, 'DOUET', 'Noah', ''),
(113, 71, 'DUPAS', 'Louise', ''),
(114, 72, 'DURAND CHATTON', 'Morgan', ''),
(115, 73, 'ELOBO', 'Simane', ''),
(116, 82, 'GASTINEAU', 'Jordan', ''),
(117, 82, 'GASTINEAU', 'Charline', ''),
(118, 82, 'GASTINEAU', 'Marie', ''),
(119, 85, 'GERARD', 'Lorinne', ''),
(120, 85, 'GERARD', 'Maxence', ''),
(121, 86, 'GESLIN', 'Melanie', ''),
(122, 86, 'GESLIN', 'Pauline', ''),
(123, 90, 'GAUDIN', 'Flavian', ''),
(124, 92, 'GOURMAUD', 'Clarence', ''),
(125, 95, 'GUEGAN', 'Matteo', ''),
(126, 95, 'GUEGAN', 'Lizea', ''),
(127, 101, 'GAUZI', 'Mahe', ''),
(128, 101, 'GAUZI', 'Liam', ''),
(129, 105, 'HUAU', 'Raphael', ''),
(130, 108, 'JAMOTEAU', 'Eliott', ''),
(131, 109, 'JARRY-FAURANT', 'Maxime', ''),
(132, 109, 'JARRY-FAURANT', 'Pauline', ''),
(133, 113, 'RINGUET', 'Ophelie', ''),
(134, 114, 'JOURNIAC', 'Angelique', ''),
(135, 114, 'JOURNIAC', 'Leandre', ''),
(136, 114, 'JOURNIAC', 'Rose', ''),
(137, 116, 'JURET', 'Lili-Rose', ''),
(138, 116, 'JURET', 'Angele', ''),
(139, 118, 'LAMY', 'Anthonin', ''),
(140, 118, 'LAMY', 'Albin', ''),
(141, 119, 'LANNIER', 'Enzo', ''),
(142, 119, 'LANNIER', 'Zoe', ''),
(143, 119, 'LANNIER', 'Erwan', ''),
(144, 121, 'LASNE', 'Aurelien', ''),
(145, 121, 'LASNE', 'Titouan', ''),
(146, 122, 'LATONNELLE', 'Thomas', ''),
(147, 122, 'LATONNELLE', 'Lea', ''),
(148, 123, 'LE BORGNE', 'Basile', ''),
(149, 127, 'LE JEAN', 'Florian', ''),
(150, 127, 'LE JEAN', 'Gabriel', ''),
(151, 128, 'LEBAILLY', 'Louise', ''),
(152, 129, 'LEBLANC', 'Louis', ''),
(153, 129, 'LEBLANC', 'Jean', ''),
(154, 129, 'LEBLANC', 'Jules', ''),
(155, 131, 'LECOMTE', 'Ninon', ''),
(156, 131, 'LECOMTE', 'Elian', ''),
(157, 133, 'LELIEVRE', 'Romain', ''),
(158, 133, 'LELIEVRE', 'Mathis', ''),
(159, 134, 'LENOGUE', 'Hugot', ''),
(160, 135, 'LESAGE', 'Stella', ''),
(161, 136, 'LOISEL', 'Noeline', ''),
(162, 139, 'LORINQUER', 'Lilou', ''),
(163, 139, 'LORINQUER', 'Nathael', ''),
(164, 139, 'LORINQUER', 'Lorys', ''),
(165, 144, 'MAUDET', 'Louis', ''),
(166, 147, 'MEIGNAN', 'Yaelle', ''),
(167, 150, 'MENDONCA', 'Aurelie', ''),
(168, 150, 'MENDONCA', 'Caroline', ''),
(169, 151, 'MERCEREAU', 'Romain', ''),
(170, 151, 'MERCEREAU', 'Jeanne', ''),
(171, 151, 'MERCEREAU', 'Claire', ''),
(172, 152, 'MERIAN', 'Martin', ''),
(173, 152, 'MERIAN', 'Louisa', ''),
(174, 159, 'OLIVEIRA', 'Mathis', ''),
(175, 159, 'OLIVEIRA', 'Timeo', ''),
(176, 161, 'PATAO', 'Neo', ''),
(177, 161, 'PATAO', 'Nina', ''),
(178, 161, 'PATAO', 'Laly', ''),
(179, 163, 'PERDIAU', 'Nicolas', ''),
(180, 166, 'PICHERIE', 'Arthur', ''),
(181, 166, 'PICHERIE', 'Nathan', ''),
(182, 166, 'PICHERIE', 'Oriane', ''),
(183, 173, 'PRIOU', 'Maxime', ''),
(184, 173, 'PRIOU', 'Enzo', ''),
(185, 179, 'REVERAULT', 'Antoine', ''),
(186, 179, 'REVERAULT', 'Lucas', ''),
(187, 182, 'RIPOCHE', 'Corentin', ''),
(188, 182, 'RIPOCHE', 'Noah', ''),
(189, 187, 'ROYER', 'Julien', ''),
(190, 195, 'SOULET', 'Mahe', ''),
(191, 195, 'SOULET', 'Nino', ''),
(192, 196, 'SOURISSEAU', 'Maela', ''),
(193, 196, 'SOURISSEAU', 'Gabriel', ''),
(194, 202, 'TESSIER', 'Alice', ''),
(195, 202, 'TESSIER', 'Clement', ''),
(196, 202, 'TESSIER', 'Mathieu', ''),
(197, 204, 'TIERCELIN', 'Enya', ''),
(198, 204, 'TIERCELIN', 'Terry', ''),
(199, 204, 'TIERCELIN', 'Rose', ''),
(200, 205, 'TORREGROSSA', 'Chloe', ''),
(201, 210, 'VIGAN', 'Corentin', ''),
(202, 210, 'VIGAN', 'Florian', ''),
(203, 210, 'VIGAN', 'Bastien', ''),
(204, 210, 'VIGAN', 'Zoe', ''),
(205, 212, 'VIVION', 'Eloise', ''),
(206, 213, 'YEKULI', 'Leo', ''),
(208, 185, 'ROUSSE (MARYVONNE)', '', ''),
(209, 25, 'BOULAY ( JENNIFER)', '', ''),
(210, 22, 'BORE ( M.PIERRE)', '', ''),
(211, 48, 'CIBRON', 'SOPHIE', ''),
(212, 198, 'TAUDON (CHRISTINE)', '', ''),
(213, 42, 'CHARRIER (ELENA)', '', ''),
(214, 24, 'BOUET (ANNETTE)', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE IF NOT EXISTS `bilan` (
`idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=249 ;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(41, 1, 'Achat: cinema', '760', '', ''),
(42, 1, 'Achat: BLACK M+', '78', '', ''),
(43, 1, 'Achat: BILLETERIE SHYM', '37', '', ''),
(44, 1, 'Achat: BILLETERIE 400 COUPS', '39.6', '', ''),
(46, 1, 'Achat: cinema', '570', '', ''),
(50, 1, 'Achat: CAFE', '51.6', '', ''),
(52, 1, 'Achat: cinema', '185', '', ''),
(53, 1, 'Achat: billeterie celtic legends', '222', '', ''),
(54, 1, 'Achat: billeterie Alain Souchon', '138', '', ''),
(154, 1, 'Achat: BILLETERIE PLANETE SAUVAGE ENFANT', '17.5', '', ''),
(155, 1, 'Achat: BILLETERIE PLANETTE SAUVAGE ADULTE', '47', '', ''),
(156, 1, 'Achat: cinema', '380', '', ''),
(157, 1, 'Achat: cinema', '380', '', ''),
(162, 2, 'Vente de Billetterie: LEGER Sonia pour la prestation cinema', '', '30', '82283468'),
(163, 2, 'Vente de Billetterie: BOULAY Jennifer pour la prestation BILLETERIE PARC DISNEYLAND ', '', '120.6', '31015638'),
(166, 1, 'Achat: BILLETERIE CHEQUE DOMICILE', '244', '', ''),
(167, 1, 'Achat: BILLETERIE CHEQUE DOMICILE', '244', '', ''),
(168, 1, 'Achat: ', '0', '', ''),
(169, 1, 'Achat: BILLETERIE CHEQUE DOMICILE', '244', '', ''),
(171, 2, 'Vente de Billetterie: CHAILLOU Sandra pour la prestation BILLETERIE CHEQUE DOMICILE', '', '198.2', '20240895'),
(174, 2, 'Vente de Billetterie: TREMBLAIS Catherine pour la prestation BILLETERIE PLANETTE SAUVAGE ADULTE', '', '42.3', '76917398'),
(175, 2, 'Vente de Billetterie: TREMBLAIS Catherine pour la prestation BILLETERIE PLANETE SAUVAGE ENFANT', '', '15.75', '91455193'),
(178, 2, 'Vente de Billetterie: GERARD Alexandra pour la prestation cinema', '', '54', '34213709'),
(180, 2, 'Vente de Billetterie: TAUDON Christine pour la prestation carte cezam salariÃ©s', '', '5', '38575939'),
(187, 2, 'Ajout de du produit fixe: SUBVENTION ASC JANVIER', '', '1616.06', ''),
(188, 2, 'Ajout de du produit fixe: RESTE SUR COMPTE AU 01-01-2015', '', '6036.41', ''),
(189, 2, 'Vente de Billetterie: RUBIO G.MICHEL pour la prestation cinema', '', '36', '31211729'),
(193, 2, 'Vente de Billetterie: RUBIO G.MICHEL pour la prestation BILLETERIE CHEQUE DOMICILE', '', '198.2', '82939271'),
(195, 1, 'Ajout de la charge Fixe: COTISATION CEZAM', '1016.55', '', ''),
(196, 1, 'Ajout de la charge Fixe: COTISATION CEZAM', '450', '', ''),
(198, 2, 'Vente de Billetterie: DIJOLS Christine pour la prestation cinema', '', '36', '82185976'),
(200, 2, 'Vente de Billetterie: MOREAU Pascale pour la prestation cinema', '', '30', '65642601'),
(202, 2, 'Vente de Billetterie: DELAREUX Isabelle pour la prestation cinema', '', '30', '14639435'),
(205, 2, 'Vente de Billetterie: GAZE CHRISTELLE pour la prestation cinema', '', '30', '63573962'),
(206, 2, 'Vente de Billetterie: GASTINEAU Isabelle pour la prestation cinema', '', '66', '3097597'),
(207, 2, 'Vente de Billetterie: DENECHERE Pascale pour la prestation cinema', '', '18', '65854746'),
(209, 2, 'Vente de Billetterie: CHEVREUX Melanie pour la prestation cinema', '', '36', '44739892'),
(214, 1, 'Ajout de la charge Fixe: FLEU DECES JARDINERIE ARDOISIERE POUR TELANGER AXEL', '130', '', ''),
(217, 2, 'Vente de Billetterie: ABID/PLANCHENAULT Sylvie pour la prestation cinema', '', '24', '24329046'),
(218, 2, 'Vente de Billetterie: SOULET Nino pour la prestation BILLETERIE PARC BADABOUM', '', '10.8', ''),
(219, 2, 'Vente de Billetterie: CHARRIER Elena pour la prestation carte cezam salariÃ©s', '', '5', '37883776'),
(222, 2, 'Vente de Billetterie: TREMBLAIS Catherine pour la prestation CAFE', '', '4.1', '10513747'),
(223, 2, 'Vente de Billetterie: TAUNAY M Laure pour la prestation cinema', '', '30', '99403945'),
(224, 2, 'Vente de Billetterie: DELAUNAY Dominique pour la prestation carte cezam salariÃ©s', '', '5', '9370115'),
(225, 2, 'Vente de Billetterie: HUIN Sylvie pour la prestation carte cezam salariÃ©s', '', '5', '24310715'),
(227, 2, 'Vente de Billetterie: BOUET Annette pour la prestation carte cezam salariÃ©s', '', '5', '80273592'),
(229, 2, 'Vente de Billetterie: SEHAQUI M Therese pour la prestation carte cezam salariÃ©s', '', '5', '67801284'),
(230, 2, 'Vente de Billetterie: FRANCFORT Catherine pour la prestation cinema', '', '24', '73528193'),
(232, 2, 'Vente de Billetterie: ABID/PLANCHENAULT Sylvie pour la prestation cinema', '', '24', '20660643'),
(233, 2, 'Vente de Billetterie: MAUSSION Christine pour la prestation CAFE', '', '2.05', '37153941'),
(234, 2, 'Vente de Billetterie: MAUSSION Christine pour la prestation CAFE DOSETTE', '', '7.1', '54269519'),
(235, 2, 'Vente de Billetterie: MAUSSION Christine pour la prestation CAFE', '', '4.3', '11500236'),
(237, 2, 'Vente de Billetterie: BEAUMONT Bernadette pour la prestation CAFE DOSETTE', '', '7.1', '92882005'),
(238, 2, 'Vente de Billetterie: CIBRON Christophe pour la prestation cinema', '', '30', '10090266'),
(241, 1, 'Ajout de la charge Fixe: FACTURE COMMANDE RIVADIS N&deg;015083551 (FICHE 31) POUR SALARIES', '250.45', '', ''),
(242, 2, 'Ajout de du produit fixe: REGLEMENT SALARIES POUR LA FACTURE RIVADIS N&deg;015083551(SEGARRA CHEQUE,PITHON CHEQUE,BEAUMONT ESPECE)', '', '39.93', ''),
(244, 2, 'Vente de Billetterie: TAUDON (CHRISTINE)  pour la prestation carte cezam conjoint/enfants', '', '2.5', ''),
(245, 1, 'Achat: cinema', '570', '', ''),
(246, 2, 'Ajout de du produit fixe: RESTE DANS LA CAISSE AU 01-01-2015', '', '311.62', '');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `billet_ayant_droit` (
`idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `billet_ayant_droit`
--

INSERT INTO `billet_ayant_droit` (`idbilletayantdroit`, `idayantdroit`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_facture`) VALUES
(5, 208, '30-01-2015', 3, '2.5', 1),
(6, 209, '30-01-2015', 3, '2.5', 1),
(8, 210, '30-01-2015', 3, '2.5', 1),
(9, 211, '05-02-2015', 3, '2.5', 1),
(10, 191, '03-02-2015', 3, '2.5', 1),
(12, 191, '24-02-2015', 3, '10.8', 1),
(13, 213, '27-01-2015', 3, '2.5', 1),
(14, 214, '03-02-2015', 3, '2.5', 1),
(16, 212, '07-03-2015', 3, '2.5', 1);

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE IF NOT EXISTS `billet_salarie` (
`idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=158 ;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`) VALUES
(9, 24, '06-01-2015', 3, '199.8', 1),
(10, 183, '13-01-2015', 3, '12', 1),
(11, 123, '13-01-2015', 3, '18', 1),
(12, 82, '13-01-2015', 3, '18', 1),
(15, 30, '13-01-2015', 3, '36', 1),
(16, 96, '13-01-2015', 3, '6', 1),
(17, 214, '13-01-2015', 3, '12', 1),
(18, 127, '13-01-2015', 3, '36', 1),
(19, 50, '08-01-2015', 3, '124.2', 1),
(22, 199, '03-01-2015', 3, '12', 1),
(23, 203, '06-01-2015', 3, '24', 1),
(24, 71, '06-01-2015', 3, '4.1', 1),
(25, 165, '06-01-2015', 3, '6', 1),
(26, 158, '07-01-2015', 3, '6', 1),
(27, 202, '07-01-2015', 3, '6', 1),
(28, 82, '13-01-2015', 3, '12', 1),
(29, 45, '13-01-2015', 3, '12', 1),
(30, 97, '20-01-2015', 3, '12', 1),
(33, 128, '06-01-2015', 3, '12', 1),
(34, 24, '06-01-2015', 3, '36', 1),
(35, 145, '06-01-2015', 3, '24', 1),
(37, 11, '06-01-2015', 3, '24', 1),
(38, 41, '07-01-2015', 3, '12', 1),
(39, 211, '07-01-2014', 3, '203.4', 1),
(40, 200, '07-01-2014', 3, '24', 1),
(41, 200, '06-01-2015', 3, '8.2', 1),
(43, 41, '13-01-2015', 3, '2.15', 1),
(48, 132, '30-01-2015', 3, '24', 1),
(49, 15, '30-01-2015', 3, '12', 1),
(50, 25, '30-01-2015', 3, '5', 1),
(52, 22, '30-01-2015', 3, '5', 1),
(54, 185, '30-01-2015', 3, '5', 1),
(55, 63, '30-01-2014', 3, '6', 1),
(56, 45, '30-01-2015', 3, '12', 1),
(57, 163, '30-01-2015', 3, '12', 1),
(58, 201, '30-01-2015', 3, '12', 1),
(59, 20, '30-01-2015', 3, '24', 1),
(61, 29, '29-01-2015', 3, '18', 1),
(62, 122, '29-01-2015', 3, '18', 1),
(63, 191, '29-01-2015', 3, '84', 1),
(64, 29, '29-01-2015', 3, '35.12', 1),
(65, 203, '24-02-2015', 3, '70.2', 1),
(66, 215, '03-02-2015', 3, '7.1', 1),
(67, 160, '29-01-2015', 3, '60', 1),
(68, 11, '29-01-2015', 3, '24', 1),
(69, 7, '29-01-2015', 3, '18', 1),
(70, 85, '29-01-2015', 3, '42', 1),
(71, 48, '05-02-2015', 3, '5', 1),
(72, 195, '03-02-2015', 3, '5', 1),
(73, 45, '29-01-2015', 3, '33.3', 1),
(74, 122, '11-02-2015', 3, '42', 1),
(75, 96, '11-02-2015', 3, '6', 1),
(76, 196, '05-02-2015', 3, '24', 1),
(77, 82, '05-02-2015', 3, '18', 1),
(78, 20, '05-02-2015', 3, '24', 1),
(79, 150, '05-02-2015', 3, '18', 1),
(81, 167, '12-02-2015', 3, '24', 1),
(82, 87, '12-02-2015', 3, '36', 1),
(84, 155, '12-02-2015', 3, '24', 1),
(85, 216, '12-02-2015', 3, '24', 1),
(86, 203, '12-02-2015', 3, '30', 1),
(87, 124, '17-02-2015', 3, '30', 1),
(88, 63, '17-02-2015', 3, '12', 1),
(89, 217, '17-02-2015', 3, '30', 1),
(90, 128, '17-02-2015', 3, '36', 1),
(91, 83, '17-02-2015', 3, '12', 1),
(92, 96, '17-02-2015', 0, '5', 1),
(93, 185, '17-02-2015', 3, '6', 1),
(94, 218, '13-01-2015', 3, '30', 1),
(96, 132, '07-03-2015', 3, '30', 1),
(97, 25, '07-03-2015', 3, '120.6', 1),
(100, 38, '17-02-2015', 3, '198.2', 1),
(102, 207, '10-02-2015', 3, '24', 1),
(103, 207, '10-02-2015', 3, '42.3', 1),
(104, 207, '10-02-2015', 3, '15.75', 1),
(105, 101, '19-02-2015', 3, '0', 0),
(106, 126, '07-03-2015', 3, '12', 1),
(107, 163, '07-03-2015', 3, '12', 1),
(108, 85, '07-03-2015', 3, '54', 1),
(109, 11, '07-03-2015', 3, '24', 1),
(110, 198, '07-03-2015', 3, '5', 1),
(111, 20, '07-03-2015', 3, '12', 1),
(118, 190, '07-03-2015', 3, '24', 1),
(119, 219, '07-03-2015', 0, '36', 1),
(120, 219, '07-03-2015', 3, '198.2', 1),
(121, 67, '07-03-2015', 3, '36', 1),
(122, 156, '07-03-2015', 3, '30', 1),
(123, 59, '07-03-2015', 3, '30', 1),
(124, 130, '07-03-2015', 3, '12', 1),
(125, 121, '07-03-2015', 3, '24', 1),
(126, 218, '07-03-2015', 3, '30', 1),
(127, 82, '07-03-2015', 3, '66', 1),
(128, 63, '07-03-2015', 3, '18', 1),
(129, 67, '07-03-2015', 3, '12', 1),
(130, 46, '07-03-2015', 3, '36', 1),
(131, 195, '07-03-2015', 3, '12', 1),
(137, 170, '11-03-2015', 3, '24', 0),
(138, 42, '27-01-2015', 3, '5', 1),
(139, 42, '21-01-2015', 3, '12', 1),
(140, 207, '29-01-2015', 3, '4.1', 1),
(141, 199, '21-01-2015', 3, '30', 1),
(142, 60, '03-02-2015', 3, '5', 1),
(143, 107, '03-02-2015', 3, '5', 1),
(145, 24, '03-02-2015', 3, '5', 1),
(146, 191, '03-02-2015', 3, '5', 1),
(147, 81, '10-03-2015', 3, '24', 1),
(148, 7, '10-03-2015', 3, '12', 1),
(149, 170, '12-02-2015', 3, '24', 1),
(150, 145, '12-03-2015', 3, '2.05', 1),
(151, 145, '12-02-2015', 3, '7.1', 1),
(152, 145, '12-02-2015', 3, '4.3', 1),
(154, 7, '12-02-2015', 3, '7.1', 1),
(155, 48, '03-03-2015', 1, '30', 1);

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE IF NOT EXISTS `charge_fixe` (
`idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `charge_fixe`
--

INSERT INTO `charge_fixe` (`idchargefixe`, `designation`, `date_charge_fixe`, `montant_charge`) VALUES
(18, 'COTISATION CEZAM', '14-01-2015', '1016.55'),
(19, 'COTISATION CEZAM', '14-01-2015', '450'),
(23, 'FLEU DECES JARDINERIE ARDOISIERE POUR TELANGER AXEL', '10-02-2015', '130'),
(25, 'FACTURE COMMANDE RIVADIS N&deg;015083551 (FICHE 31) POUR SALARIES', '07-03-2015', '250.45');

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE IF NOT EXISTS `compta_balance` (
`idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=159 ;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '0', '0'),
(81, 2, '', ''),
(82, 3, '0', '0'),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '', ''),
(87, 8, '', ''),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '0', '0'),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', ''),
(113, 34, '', ''),
(114, 35, '', ''),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '', ''),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '', ''),
(134, 55, '', ''),
(135, 56, '', ''),
(136, 57, '', ''),
(137, 58, '', ''),
(138, 59, '', ''),
(139, 60, '', ''),
(140, 61, '0', '0'),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE IF NOT EXISTS `compta_banque` (
`idcomptabanque` int(13) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_actif` (
`idcptbilanactif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_passif` (
`idcptbilanpassif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE IF NOT EXISTS `compta_caisse` (
`idcomptacaisse` int(13) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE IF NOT EXISTS `compta_compte` (
`idcomptacompte` int(13) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE IF NOT EXISTS `compta_livret` (
`idcomptalivret` int(13) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE IF NOT EXISTS `compta_mvm` (
`idcomptamvm` int(13) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE IF NOT EXISTS `compta_plan` (
`idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', 'CrÃ©ances Client'),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', ''),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', 'terrain'),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capitaux'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', ''),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Postaux'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'Frais d''administration'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achat de matÃ©riel '),
(61, 6, 'Autre Charge d''exploitation 1', 'Repas elus'),
(62, 6, 'Autre Charge d''exploitation 2', ''),
(63, 6, 'Autre Charge d''exploitation 3', ''),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE IF NOT EXISTS `compta_resultat` (
`idresultat` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE IF NOT EXISTS `config_etablissement` (
`idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'CE Clinique Saint LÃ©onard', '0.20', '0.10', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE IF NOT EXISTS `cpt_resultat` (
`idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=249 ;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(41, '', '1422403200', 'Achat - cinema', '760', ''),
(42, '', '1422403200', 'Achat - BLACK M+', '78', ''),
(43, '', '1422576000', 'Achat - BILLETERIE SHYM', '37', ''),
(44, '', '1422576000', 'Achat - BILLETERIE 400 COUPS', '39.6', ''),
(46, '', '1422576000', 'Achat - cinema', '570', ''),
(50, '', '1420588800', 'Achat - CAFE', '51.6', ''),
(52, '', '1420675200', 'Achat - cinema', '185', ''),
(53, '', '1425772800', 'Achat - billeterie celtic legends', '222', ''),
(54, '', '1421193600', 'Achat - billeterie Alain Souchon', '138', ''),
(154, '', '1423612800', 'Achat - BILLETERIE PLANETE SAUVAGE ENFANT', '17.5', ''),
(155, '', '1423612800', 'Achat - BILLETERIE PLANETTE SAUVAGE ADULTE', '47', ''),
(156, '', '1424131200', 'Achat - cinema', '380', ''),
(157, '', '1423785600', 'Achat - cinema', '380', ''),
(162, '82283468', '1425686400', 'Vente de Billetterie: LEGER Sonia pour la prestation cinema', '', '30'),
(163, '31015638', '1425686400', 'Vente de Billetterie: BOULAY Jennifer pour la prestation BILLETERIE PARC DISNEYLAND ', '', '120.6'),
(166, '', '1423785600', 'Achat - BILLETERIE CHEQUE DOMICILE', '244', ''),
(167, '', '1424304000', 'Achat - BILLETERIE CHEQUE DOMICILE', '244', ''),
(168, '', '1424908800', 'Achat - ', '0', ''),
(169, '', '1424908800', 'Achat - BILLETERIE CHEQUE DOMICILE', '244', ''),
(171, '20240895', '1424131200', 'Vente de Billetterie: CHAILLOU Sandra pour la prestation BILLETERIE CHEQUE DOMICILE', '', '198.2'),
(174, '76917398', '1423526400', 'Vente de Billetterie: TREMBLAIS Catherine pour la prestation BILLETERIE PLANETTE SAUVAGE ADULTE', '', '42.3'),
(175, '91455193', '1423526400', 'Vente de Billetterie: TREMBLAIS Catherine pour la prestation BILLETERIE PLANETE SAUVAGE ENFANT', '', '15.75'),
(178, '34213709', '1425686400', 'Vente de Billetterie: GERARD Alexandra pour la prestation cinema', '', '54'),
(180, '38575939', '1425686400', 'Vente de Billetterie: TAUDON Christine pour la prestation carte cezam salariÃ©s', '', '5'),
(187, '', '1424127600', 'SUBVENTION ASC JANVIER', '', '1616.06'),
(188, '', '1420412400', 'RESTE SUR COMPTE AU 01-01-2015', '', '6036.41'),
(189, '31211729', '1425682800', 'Vente de Billetterie: RUBIO G.MICHEL pour la prestation cinema', '', '36'),
(193, '82939271', '1425682800', 'Vente de Billetterie: RUBIO G.MICHEL pour la prestation BILLETERIE CHEQUE DOMICILE', '', '198.2'),
(195, '', '1421190000', 'COTISATION CEZAM', '1016.55', ''),
(196, '', '1421190000', 'COTISATION CEZAM', '450', ''),
(198, '82185976', '1425682800', 'Vente de Billetterie: DIJOLS Christine pour la prestation cinema', '', '36'),
(200, '65642601', '1425682800', 'Vente de Billetterie: MOREAU Pascale pour la prestation cinema', '', '30'),
(202, '14639435', '1425682800', 'Vente de Billetterie: DELAREUX Isabelle pour la prestation cinema', '', '30'),
(205, '63573962', '1425682800', 'Vente de Billetterie: GAZE CHRISTELLE pour la prestation cinema', '', '30'),
(206, '3097597', '1425682800', 'Vente de Billetterie: GASTINEAU Isabelle pour la prestation cinema', '', '66'),
(207, '65854746', '1425682800', 'Vente de Billetterie: DENECHERE Pascale pour la prestation cinema', '', '18'),
(209, '44739892', '1425682800', 'Vente de Billetterie: CHEVREUX Melanie pour la prestation cinema', '', '36'),
(214, '', '1423522800', 'FLEU DECES JARDINERIE ARDOISIERE POUR TELANGER AXEL', '130', ''),
(217, '24329046', '1426028400', 'Vente de Billetterie: ABID/PLANCHENAULT Sylvie pour la prestation cinema', '', '24'),
(218, '', '1424732400', 'Vente de Billetterie: SOULET Nino pour la prestation BILLETERIE PARC BADABOUM', '', '10.8'),
(219, '37883776', '1422313200', 'Vente de Billetterie: CHARRIER Elena pour la prestation carte cezam salariÃ©s', '', '5'),
(222, '10513747', '1422486000', 'Vente de Billetterie: TREMBLAIS Catherine pour la prestation CAFE', '', '4.1'),
(223, '99403945', '1421794800', 'Vente de Billetterie: TAUNAY M Laure pour la prestation cinema', '', '30'),
(224, '9370115', '1422918000', 'Vente de Billetterie: DELAUNAY Dominique pour la prestation carte cezam salariÃ©s', '', '5'),
(225, '24310715', '1422918000', 'Vente de Billetterie: HUIN Sylvie pour la prestation carte cezam salariÃ©s', '', '5'),
(227, '80273592', '1422918000', 'Vente de Billetterie: BOUET Annette pour la prestation carte cezam salariÃ©s', '', '5'),
(229, '67801284', '1422918000', 'Vente de Billetterie: SEHAQUI M Therese pour la prestation carte cezam salariÃ©s', '', '5'),
(230, '73528193', '1425942000', 'Vente de Billetterie: FRANCFORT Catherine pour la prestation cinema', '', '24'),
(232, '20660643', '1423695600', 'Vente de Billetterie: ABID/PLANCHENAULT Sylvie pour la prestation cinema', '', '24'),
(233, '37153941', '1426114800', 'Vente de Billetterie: MAUSSION Christine pour la prestation CAFE', '', '2.05'),
(234, '54269519', '1423695600', 'Vente de Billetterie: MAUSSION Christine pour la prestation CAFE DOSETTE', '', '7.1'),
(235, '11500236', '1423695600', 'Vente de Billetterie: MAUSSION Christine pour la prestation CAFE', '', '4.3'),
(237, '92882005', '1423695600', 'Vente de Billetterie: BEAUMONT Bernadette pour la prestation CAFE DOSETTE', '', '7.1'),
(238, '10090266', '1425337200', 'Vente de Billetterie: CIBRON Christophe pour la prestation cinema', '', '30'),
(241, '', '1425682800', 'FACTURE COMMANDE RIVADIS N&deg;015083551 (FICHE 31) POUR SALARIES', '250.45', ''),
(242, '', '1425682800', 'REGLEMENT SALARIES POUR LA FACTURE RIVADIS N&deg;015083551(SEGARRA CHEQUE,PITHON CHEQUE,BEAUMONT ESPECE)', '', '39.93'),
(244, '', '1425682800', 'Vente de Billetterie: TAUDON (CHRISTINE)  pour la prestation carte cezam conjoint/enfants', '', '2.5'),
(245, '', '1425942000', 'Achat - cinema', '570', ''),
(246, '', '1420066800', 'RESTE DANS LA CAISSE AU 01-01-2015', '', '311.62');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE IF NOT EXISTS `famille_prestation` (
`idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(46, 'CARTE ATOUT'),
(47, 'CAFE'),
(48, 'CINEMA CEZAM'),
(49, 'BILLETERIE CEZAM CELTIC LEGENDS'),
(50, 'billeterie  Alain Souchon'),
(51, 'billeterie Alain Souchon'),
(52, 'carte cezam'),
(53, 'CAFE'),
(54, 'CAFE DOSETTE'),
(55, 'billeterie BLACK M+'),
(56, 'BILLETERIE SHYM'),
(57, '400 COUP'),
(58, 'BILLETERIE 400 COUPS'),
(59, 'BILLETERIE AUSTRALIAN PINK FOYD SHOW'),
(60, 'PRADEL'),
(61, 'planette sauvage'),
(62, 'PLANETTE SAUVAGE ADULTE'),
(63, 'RIVADIS'),
(64, 'PARC BADABOUM'),
(65, 'PARC  DISNEYLAND'),
(66, 'CHEQUE DOMICILEUE '),
(67, 'CHEQUE DOMICILE');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_ayant_droit` (
`idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `ligne_billet_ayant_droit`
--

INSERT INTO `ligne_billet_ayant_droit` (`idlignebilletayantdroit`, `idbilletayantdroit`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`) VALUES
(5, 5, 77, '1', '2.5', '3.5', 0),
(6, 6, 77, '1', '2.5', '3.5', 0),
(8, 8, 77, '1', '2.5', '3.5', 0),
(9, 9, 77, '1', '2.5', '3.5', 0),
(10, 10, 77, '1', '2.5', '3.5', 0),
(12, 12, 88, '2', '10.8', '1.2', 0),
(13, 13, 77, '1', '2.5', '3.5', 0),
(14, 14, 77, '1', '2.5', '3.5', 0),
(16, 16, 77, '1', '2.5', '3.5', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_salarie` (
`idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=151 ;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`) VALUES
(3, 9, 73, '6', '199.8', '22.2', 0),
(4, 10, 71, '2', '12', '2.8', 0),
(5, 11, 71, '3', '18', '4.2', 0),
(6, 12, 71, '3', '18', '4.2', 0),
(13, 15, 71, '6', '36', '8.4', 0),
(14, 16, 71, '1', '6', '1.4', 0),
(15, 17, 71, '2', '12', '2.8', 0),
(16, 18, 71, '6', '36', '8.4', 0),
(17, 19, 75, '2', '124.2', '13.8', 0),
(21, 22, 71, '2', '12', '3.2', 0),
(22, 23, 71, '4', '24', '5.6', 0),
(23, 24, 78, '2', '4.1', '0', 0),
(24, 25, 71, '1', '6', '1.4', 0),
(25, 26, 71, '1', '6', '1.4', 0),
(26, 27, 71, '1', '6', '1.4', 0),
(27, 28, 71, '2', '12', '2.8', 0),
(28, 29, 71, '2', '12', '2.8', 0),
(29, 30, 71, '2', '12', '2.8', 0),
(33, 33, 71, '2', '12', '2.8', 0),
(34, 34, 71, '6', '36', '8.4', 0),
(35, 35, 71, '4', '24', '5.6', 0),
(37, 37, 71, '4', '24', '5.6', 0),
(38, 38, 71, '2', '12', '2.8', 0),
(39, 39, 83, '4', '203.4', '0', 0),
(40, 40, 71, '4', '24', '5.6', 0),
(41, 41, 78, '4', '8.2', '0', 0),
(43, 43, 78, '1', '2.15', '0', 0),
(47, 48, 71, '4', '24', '5.6', 0),
(48, 49, 71, '2', '12', '2.8', 0),
(49, 50, 76, '1', '5', '7', 0),
(51, 52, 76, '1', '5', '7', 0),
(53, 54, 76, '1', '5', '7', 0),
(54, 55, 71, '1', '6', '1.4', 0),
(55, 56, 71, '2', '12', '2.8', 0),
(56, 57, 71, '2', '12', '2.8', 0),
(57, 58, 71, '2', '12', '2.8', 0),
(58, 59, 71, '4', '24', '5.6', 0),
(60, 61, 71, '3', '18', '4.2', 0),
(61, 62, 71, '3', '18', '4.2', 0),
(62, 63, 71, '14', '84', '19.6', 0),
(64, 64, 82, '8', '35.12', '3.96', 0),
(65, 65, 80, '2', '70.2', '7.8', 0),
(66, 66, 79, '2', '7.1', '0', 0),
(67, 67, 71, '10', '60', '14', 0),
(68, 68, 71, '4', '24', '5.6', 0),
(69, 69, 71, '3', '18', '4.2', 0),
(70, 70, 71, '7', '42', '9.8', 0),
(71, 71, 76, '1', '5', '7', 0),
(72, 72, 76, '1', '5', '7', 0),
(73, 73, 81, '1', '33.3', '3.7', 0),
(74, 74, 71, '7', '42', '9.8', 0),
(75, 75, 71, '1', '6', '1.4', 0),
(76, 76, 71, '4', '24', '5.6', 0),
(77, 77, 71, '3', '18', '4.2', 0),
(78, 78, 71, '4', '24', '5.6', 0),
(79, 79, 71, '3', '18', '4.2', 0),
(81, 81, 71, '4', '24', '5.6', 0),
(82, 82, 71, '6', '36', '8.4', 0),
(83, 84, 71, '4', '24', '5.6', 0),
(84, 85, 71, '4', '24', '5.6', 0),
(85, 86, 71, '5', '30', '7', 0),
(86, 87, 71, '5', '30', '7', 0),
(87, 88, 71, '2', '12', '2.8', 0),
(88, 89, 71, '5', '30', '7', 0),
(89, 90, 71, '6', '36', '8.4', 0),
(90, 91, 71, '2', '12', '2.8', 0),
(91, 92, 76, '1', '5', '7', 0),
(92, 93, 71, '1', '6', '1.4', 0),
(93, 94, 71, '5', '30', '8', 0),
(95, 96, 71, '5', '30', '8', 0),
(96, 97, 89, '2', '120.6', '13.4', 0),
(99, 100, 90, '20', '198.2', '45.8', 0),
(101, 102, 71, '4', '24', '6.4', 0),
(102, 103, 85, '2', '42.3', '4.7', 0),
(103, 104, 84, '1', '15.75', '1.75', 0),
(104, 106, 71, '2', '12', '3.2', 0),
(105, 107, 71, '2', '12', '3.2', 0),
(106, 108, 71, '9', '54', '14.4', 0),
(107, 109, 71, '4', '24', '6.4', 0),
(108, 110, 76, '1', '5', '7', 0),
(109, 111, 71, '2', '12', '3.2', 0),
(111, 118, 71, '4', '24', '6.4', 0),
(112, 119, 71, '6', '36', '9.6', 0),
(113, 120, 90, '20', '198.2', '45.8', 0),
(114, 121, 71, '6', '36', '9.6', 0),
(115, 122, 71, '5', '30', '8', 0),
(116, 123, 71, '5', '30', '8', 0),
(117, 124, 71, '2', '12', '3.2', 0),
(118, 125, 71, '4', '24', '6.4', 0),
(119, 126, 71, '5', '30', '8', 0),
(120, 127, 71, '11', '66', '17.6', 0),
(121, 128, 71, '3', '18', '4.8', 0),
(122, 129, 71, '2', '12', '3.2', 0),
(123, 130, 71, '6', '36', '9.6', 0),
(124, 131, 71, '2', '12', '3.2', 0),
(130, 137, 71, '4', '24', '6.4', 0),
(131, 138, 76, '1', '5', '7', 0),
(132, 139, 71, '2', '12', '3.2', 0),
(133, 140, 78, '2', '4.1', '0', 0),
(134, 141, 71, '5', '30', '8', 0),
(135, 142, 76, '1', '5', '7', 0),
(136, 143, 76, '1', '5', '7', 0),
(138, 145, 76, '1', '5', '7', 0),
(139, 146, 76, '1', '5', '7', 0),
(140, 147, 71, '4', '24', '6.4', 0),
(141, 148, 71, '2', '12', '3.2', 0),
(142, 149, 71, '4', '24', '6.4', 0),
(143, 150, 78, '1', '2.05', '0', 0),
(144, 151, 79, '2', '7.1', '0', 0),
(145, 152, 78, '2', '4.3', '0', 0),
(147, 154, 79, '2', '7.1', '0', 0),
(148, 155, 71, '5', '30', '8', 0);

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE IF NOT EXISTS `log_systeme` (
`idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE IF NOT EXISTS `maj` (
`idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.2.0', '6315-classic');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE IF NOT EXISTS `membre` (
`iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'Administrateur', '25f9e794323b453885f5181f1b624d0b', 1),
(4, 'cecliniquesaintleonard', 'b4ea23a368b20bc1623e058f392f1fe4', 1),
(6, 'cecsl', '7f56ea08293af7c4e97501812b4b6f92', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
`idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '0'),
(3, 'vente_direct', '0');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE IF NOT EXISTS `prestation` (
`idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` longtext NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=91 ;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`, `commentaire`) VALUES
(69, 46, 'CARTE ATOUT', '01-12-2014', '17-09-2015', '17', '4', '21', '100', '100', 0, 'Valable pour piscine, patinoire, salle de sport ou autres partenaires'),
(71, 48, 'cinema', '01-01-2015', '31-05-2015', '6â‚¬', '1.60', '7.6', '20', '90', 0, ''),
(73, 49, 'billeterie celtic legends', '08-01-2015', '07/03/2015', '33.30', '3.70', '37', '100', '6', 0, ''),
(75, 51, 'billeterie Alain Souchon', '14-01-2015', '24-06-2015', '62.10', '6.90', '69', '100', '2', 0, ''),
(76, 52, 'carte cezam salariÃ©s', '01-01-2015', '31-12-2015', '5.00', '7', '12', '100', '18', 0, ''),
(77, 52, 'carte cezam conjoint/enfants', '01-01-2015', '31-12-2015', '2.50', '3.50', '6', '100', '5', 0, ''),
(78, 53, 'CAFE', '01-01-2015', '31-12-2015', '2.15', '0', '2.15', '100', '11', 0, ''),
(79, 54, 'CAFE DOSETTE', '01-01-2015', '01-09-2015', '3.55', '0', '3.55', '20', '4', 0, ''),
(80, 55, 'BLACK M+', '28-01-2015', '24-03-2015', '35.10', '3.90', '39', '10', '0', 0, ''),
(81, 56, 'BILLETERIE SHYM', '30-01-2015', '30-03-2015', '33.30', '3.70', '37', '10', '0', 0, ''),
(82, 58, 'BILLETERIE 400 COUPS', '30-01-2015', '28-03-2015', '4.39', '0.495', '4.885', '20', '0', 0, ''),
(83, 59, 'BILLETERIE', '06-01-2015', '30-03-2015', '50.85', '', '50.85', '4', '0', 0, ''),
(84, 61, 'BILLETERIE PLANETE SAUVAGE ENFANT', '11-02-2015', '30-04-2015', '15.75', '1.75', '17.5', '20', '1', 0, ''),
(85, 62, 'BILLETERIE PLANETTE SAUVAGE ADULTE', '11-02-2015', '30-04-2015', '21.15', '2.35', '23.5', '2', '2', 0, ''),
(86, 63, 'RIVADIS', '07-03-2015', '30-06-2015', '', '0', '0', '20', '10', 0, ''),
(87, 60, 'PRADEL', '15-02-2015', '30-06-2015', '', '0', '0', '10', '6', 0, ''),
(88, 64, 'BILLETERIE PARC BADABOUM', '24-02-2015', '30-03-2015', '5.40', '0.60', '6', '20', '0', 0, ''),
(89, 65, 'BILLETERIE PARC DISNEYLAND ', '24-02-2015', '30-03-2015', '60.30', '6.70', '67', '20', '0', 0, ''),
(90, 67, 'BILLETERIE CHEQUE DOMICILE', '13-02-2015', '', '9.91', '2.29', '12.2', '50', '60', 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE IF NOT EXISTS `produit_fixe` (
`idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Contenu de la table `produit_fixe`
--

INSERT INTO `produit_fixe` (`idproduitfixe`, `designation`, `date_produit_fixe`, `montant_produit`) VALUES
(20, 'SUBVENTION ASC JANVIER', '17-02-2015', '1616.06'),
(21, 'RESTE SUR COMPTE AU 01-01-2015', '05-01-2015', '6036.41'),
(23, 'REGLEMENT SALARIES POUR LA FACTURE RIVADIS N&deg;015083551(SEGARRA CHEQUE,PITHON CHEQUE,BEAUMONT ESPECE)', '07-03-2015', '39.93'),
(24, 'RESTE DANS LA CAISSE AU 01-01-2015', '01-01-2015', '311.62');

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `reg_billet_ayant_droit` (
`idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `reg_billet_ayant_droit`
--

INSERT INTO `reg_billet_ayant_droit` (`idregbilletayantdroit`, `idbilletayantdroit`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(4, 5, 1, '2.5', 'CA', 'ROUSSE', '6828220', 1),
(5, 6, 1, '2.5', 'CM', 'BOULAY', '7384659', 1),
(7, 8, 1, '2.5', 'CA', 'BORE', '05354927001', 1),
(8, 9, 1, '2.5', 'CM', 'CIBRON', '6265074', 1),
(9, 10, 1, '2.5', 'CA', 'SOULET', '6615541', 1),
(11, 12, 1, '10.8', 'CA', 'SOULET', '9959250', 1),
(12, 13, 3, '2.5', '', '', '', 0),
(13, 14, 3, '2.5', '', '', '', 0),
(15, 16, 1, '2.5', 'CA', 'TAUDON', '7583568', 1);

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `reg_billet_salarie` (
`idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=134 ;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(4, 22, 3, '12', '', '', '', 0),
(5, 23, 3, '24', '', '', '', 0),
(6, 24, 3, '4.1', '', '', '', 0),
(7, 25, 3, '6', '', '', '', 0),
(8, 26, 3, '6', '', '', '', 0),
(9, 27, 3, '6', '', '', '', 0),
(10, 28, 3, '12', '', '', '', 0),
(11, 29, 3, '12', '', '', '', 0),
(12, 30, 3, '12', '', '', '', 0),
(16, 33, 1, '12', 'CE', 'LEBAILLY', '0000027', 0),
(17, 9, 1, '199.8', 'CM', 'BOUET', '6571572', 0),
(18, 34, 1, '36', 'CM', 'BOUET', '6571572', 0),
(19, 35, 1, '24', 'BP', 'MAUSSION', '0000097', 0),
(21, 37, 1, '24', 'CM', 'BERTEAU', '5240694', 0),
(22, 10, 1, '12', 'CE', 'RIVEREAU', '3995487', 0),
(23, 11, 1, '18', 'CIC', 'LEBORGNE', '5210906', 0),
(24, 12, 1, '18', 'BP', 'GASTINEAU', '0003066', 0),
(25, 18, 1, '36', 'CE', 'LE JEAN', '0004554', 0),
(26, 38, 1, '12', 'CE', 'CHARREAU', '9362062', 0),
(27, 15, 1, '36', 'CE', 'BRARD', '5103889', 0),
(28, 16, 1, '6', 'LA POSTE', 'GUIHO', '4674053', 0),
(29, 17, 1, '12', 'CA', 'MAQUIN', '2236539', 0),
(30, 39, 1, '203.4', 'BP', 'VIVIEN', '7105', 0),
(31, 40, 1, '24', 'CAISSE EPARGNE', 'TELLANGER', '3959', 0),
(32, 41, 1, '8.2', 'ce', 'TELLANGER', '9823959', 0),
(34, 43, 1, '2.15', 'CE', 'CHARREAU', '9362062', 0),
(37, 48, 1, '24', 'CM', 'LEGER', '6905150', 0),
(38, 49, 1, '12', 'CM', 'BINOT', '5271912', 0),
(39, 50, 1, '5', 'CM', 'BOULAY', '7384659', 0),
(41, 54, 1, '5', 'CA', 'ROUSSE', '6828220', 0),
(42, 19, 1, '124.2', 'CA', 'COCHIN', '5140080', 0),
(43, 52, 1, '5', 'CA', 'BORE', '05354927001', 0),
(45, 56, 1, '12', 'BOURSORAMA', 'CHEIGNON', '8310544', 0),
(47, 62, 1, '18', 'CA', 'LATONNELLE', '4267947', 0),
(48, 55, 1, '6', 'BP', 'DENECHERE', '0141773', 0),
(49, 57, 1, '12', 'CE', 'PERDRIAU', '0000030', 0),
(50, 58, 1, '12', 'LA POSTE', 'TESSIE-GRAS', '4653012', 0),
(51, 59, 1, '24', 'CE', 'BONFILS', '7588051', 0),
(53, 61, 1, '18', 'LA POSTE', 'BOUTREUX', '4644063', 0),
(54, 63, 1, '84', 'CA', 'SEHAQUI', '9407352', 0),
(55, 64, 1, '35.12', 'LA POSTE', 'BOUTREUX', '4644063', 0),
(56, 65, 3, '70.2', '', 'THEULIER', '', 0),
(57, 66, 1, '7.1', 'CE', 'JULIENNE', '0000261', 0),
(58, 67, 1, '60', 'CA', 'PASQUITO', '5668279', 0),
(59, 68, 1, '24', 'CM', 'BERTEAU', '5240695', 0),
(60, 69, 1, '18', 'CA', 'BEAUMONT', '0681424', 0),
(61, 70, 1, '42', 'CE', 'GERARD', '0008342', 0),
(62, 71, 1, '5', 'CM', 'CIBRON', '6265074', 0),
(63, 72, 1, '5', 'CA', 'SOULET', '6615541', 0),
(64, 73, 1, '33.3', 'BOURSORAMA', 'CHEIGNON', '8310545', 0),
(65, 74, 1, '42', 'CA', 'LATONELLE', '4267949', 0),
(66, 75, 1, '6', 'LA POSTE', 'GUIHO', '4674058', 0),
(67, 76, 1, '24', 'BPA', 'SOURISSEAU', '00001698', 0),
(68, 77, 1, '18', 'BPA', 'GASTINEAU', '0003084', 0),
(69, 78, 1, '24', 'CE', 'BONFILS', '7588057', 0),
(70, 79, 1, '18', 'BPA', 'MENDONCA', '0590234', 0),
(72, 81, 1, '24', 'CM', 'PIEL', '5308838', 0),
(73, 82, 1, '36', 'CA', 'GILBERT', '5411145', 0),
(74, 84, 1, '24', 'CA', 'MOREAU', '0318270', 0),
(75, 85, 1, '24', 'BP ', 'PRUNAUX-CASER', '0000410', 0),
(76, 86, 1, '30', 'CA', 'THEULIER', '5225914', 0),
(77, 87, 1, '30', 'lcl', 'LE CALVEZ', '0267678', 0),
(78, 88, 1, '12', 'BP', 'DENECHERE', '0141780', 0),
(79, 89, 1, '30', 'BNP', 'YVON', '4888598', 0),
(80, 90, 1, '36', 'CE', 'LEBAILLY', '0000039', 0),
(81, 91, 1, '12', 'CM', 'GAUDELET', '5439121', 0),
(82, 92, 1, '5', 'LA POSTE', 'GUIHO', '4674060', 0),
(83, 93, 1, '6', 'CA', 'ROUSSE', '127334', 0),
(84, 94, 1, '30', 'LC', 'GAZE', '9524903', 0),
(85, 96, 1, '30', 'CM', 'LEGER', '7015558', 0),
(86, 97, 1, '120.6', 'CM', 'BOULAY', '7384660', 0),
(87, 100, 1, '198.2', 'CE', 'CHAILLOU', '0002412', 0),
(89, 102, 1, '24', 'SG', 'TREMBLAIS', '0002401', 0),
(90, 103, 1, '42.3', 'SG', 'TREMBLAIS', '0002401', 0),
(91, 104, 1, '15.75', 'SG', 'TREMBLAIS', '0002401', 0),
(92, 106, 1, '12', 'LA POSTE', 'LE GALL', '459716', 0),
(93, 107, 1, '12', 'CE', 'PERDRIAU', '0000033', 0),
(94, 108, 1, '54', 'CE', 'GERARD', '0008347', 0),
(95, 109, 1, '24', 'CM', 'BERTEAU', '5240698', 0),
(96, 110, 1, '5', 'CA', 'TAUDON', '7583568', 0),
(97, 111, 1, '12', 'CE', 'BONFILS', '7588063', 0),
(98, 118, 1, '24', 'SG', 'SEGARRA', '0000737', 0),
(99, 119, 1, '36', 'CE', 'RUBIO', '678971', 0),
(100, 120, 1, '198.2', 'CE', 'RUBIO', '678971', 0),
(101, 121, 1, '36', 'BNP', 'DIJOLS', '7414678', 0),
(102, 122, 1, '30', 'LA POSTE', 'MOREAU', '4583031', 0),
(103, 123, 1, '30', 'BPA', 'DELAREUX', '0000272', 0),
(104, 124, 1, '12', 'BPA', 'LECLERC', '0000149', 0),
(105, 125, 1, '24', 'CE', 'LASNE', '0000395', 0),
(106, 126, 1, '30', 'LCL', 'GAZE', '9524908', 0),
(107, 127, 1, '66', 'BPA', 'GASTINEAU', '0003090', 0),
(108, 128, 1, '18', 'BPA', 'DENECHERE', '0141781', 0),
(109, 129, 1, '12', 'BNP', 'DIJOLS', '7414678', 0),
(110, 130, 1, '36', 'CA', 'CHEVREUX', '451794', 0),
(111, 131, 1, '12', 'CA', 'SOULET', '9959250', 0),
(117, 138, 3, '5', '', '', '', 0),
(118, 139, 3, '12', '', '', '', 0),
(119, 140, 3, '4.1', '', '', '', 0),
(120, 141, 3, '30', '', '', '', 0),
(121, 142, 3, '5', '', '', '', 0),
(122, 143, 3, '5', '', '', '', 0),
(123, 145, 3, '5', '', '', '', 0),
(124, 146, 3, '5', '', '', '', 0),
(125, 147, 3, '24', '', '', '', 0),
(126, 148, 3, '12', '', '', '', 0),
(127, 149, 3, '24', '', '', '', 0),
(128, 150, 3, '2.05', '', '', '', 0),
(129, 151, 3, '7.1', '', '', '', 0),
(130, 152, 3, '4.3', '', '', '', 0),
(131, 154, 3, '7.1', '', '', '', 0),
(132, 155, 3, '30', '', '', '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE IF NOT EXISTS `remise_banque` (
`idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Contenu de la table `remise_banque`
--

INSERT INTO `remise_banque` (`idremisebanque`, `date_remise`, `type_remise`, `num_remise`, `montant_remise`, `valid`) VALUES
(8, '30-01-2015', 1, '6165244', '327.32', 1),
(9, '30-01-2015', 1, '6165243', '312.3', 1),
(11, '11-02-2015', 1, '6165245', '166.1', 1),
(12, '11-01-2015', 1, '6165246', '165.3', 1),
(13, '11-02-2015', 2, 'fiche 21', '164.3', 1),
(15, '12-02-2015', 1, '6165248', '138', 1),
(16, '17-02-2015', 1, '6859737', '131', 1),
(17, '13-01-2015', 1, '6165240', '182.15', 1),
(19, '07-01-2015', 1, '6165238', '295.6', 1),
(21, '07-03-2015', 1, '6859739', '430.85', 1),
(23, '07-01-2015', 1, '6859741', '390.2', 1),
(25, '07-01-2015', 1, '6859740', '172.8', 1),
(26, '07-01-2015', 1, '6859742', '121.5', 1);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE IF NOT EXISTS `remise_banque_chq` (
`idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=153 ;

--
-- Contenu de la table `remise_banque_chq`
--

INSERT INTO `remise_banque_chq` (`idremisebanquechq`, `idremisebanque`, `idreglementventepresta`) VALUES
(39, 8, 48),
(40, 8, 45),
(41, 8, 49),
(42, 8, 50),
(43, 8, 54),
(44, 8, 53),
(45, 8, 55),
(46, 8, 51),
(47, 8, 42),
(48, 9, 41),
(49, 9, 0),
(50, 9, 4),
(51, 9, 37),
(52, 9, 38),
(53, 9, 39),
(54, 9, 5),
(55, 9, 43),
(56, 9, 7),
(57, 9, 47),
(58, 9, 17),
(59, 9, 18),
(66, 11, 57),
(67, 11, 58),
(68, 11, 59),
(69, 11, 60),
(70, 11, 61),
(71, 11, 62),
(72, 11, 63),
(73, 11, 8),
(74, 11, 9),
(75, 12, 64),
(76, 12, 65),
(77, 12, 66),
(78, 12, 67),
(79, 12, 68),
(80, 12, 69),
(81, 12, 70),
(82, 15, 72),
(83, 15, 73),
(84, 15, 74),
(85, 15, 75),
(86, 15, 76),
(87, 16, 77),
(88, 16, 78),
(89, 16, 79),
(90, 16, 80),
(91, 16, 81),
(92, 16, 82),
(93, 16, 83),
(95, 17, 84),
(96, 17, 29),
(97, 17, 28),
(98, 17, 27),
(99, 17, 24),
(100, 17, 26),
(101, 17, 34),
(102, 17, 25),
(103, 17, 22),
(104, 17, 23),
(105, 19, 30),
(106, 19, 19),
(107, 19, 21),
(108, 19, 16),
(109, 19, 31),
(110, 19, 32),
(111, 21, 85),
(112, 21, 87),
(113, 21, 86),
(114, 21, 89),
(115, 21, 90),
(116, 21, 91),
(124, 23, 98),
(125, 23, 99),
(126, 23, 100),
(127, 23, 101),
(128, 23, 102),
(129, 23, 103),
(130, 23, 104),
(131, 23, 105),
(140, 25, 106),
(141, 25, 107),
(142, 25, 108),
(143, 25, 109),
(144, 25, 110),
(145, 25, 11),
(146, 26, 92),
(147, 26, 93),
(148, 26, 94),
(149, 26, 95),
(150, 26, 96),
(151, 26, 97),
(152, 26, 15);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE IF NOT EXISTS `remise_banque_esp` (
`idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `remise_banque_esp`
--

INSERT INTO `remise_banque_esp` (`idremisebanqueesp`, `idremisebanque`, `idreglementventepresta`) VALUES
(1, 13, 4),
(2, 13, 6),
(3, 13, 8),
(4, 13, 9),
(5, 13, 10),
(6, 13, 5),
(7, 13, 7),
(8, 13, 11),
(9, 13, 12),
(10, 13, 56);

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE IF NOT EXISTS `salarie` (
`idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=220 ;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`) VALUES
(1, '', 2, 'ABELLARD', 'Marion', '', '', '', '', '', '', '', '', '19/06/2014', '', '', '', '', '', 'CDD', 1),
(2, '', 2, 'AILLERIE', 'Myriam', '', '', '', '', '', '', '', '', '07/01/2003', '', '', '', '', '', 'CDI', 1),
(3, '', 2, 'AMARA', 'Nadia', '', '', '', '', '', '', '', '', '11/12/2007', '', '', '', '', '', 'CDI', 1),
(4, '', 1, 'ANTIER', 'Sylvie', '', '', '', '', '', '', '', '', '06/05/2013', '', '', '', '', '', 'CDI', 1),
(5, '', 2, 'AUGUET', 'Joelle', '', '', '', '', '', '', '', '', '21/09/2000', '', '', '', '', '', 'CDI', 1),
(6, '', 2, 'BAILLY', 'Michelle', '', '', '', '', '', '', '', '', '26/06/1990', '', '', '', '', '', 'CDI', 1),
(7, '', 2, 'BEAUMONT', 'Bernadette', '', '', '', '', '', '', '', '', '05/04/1988', '', '', '', '', '', 'CDI', 1),
(8, '', 1, 'BEAUVAIS', 'Nicolas', '', '', '', '', '', '', '', '', '02/09/2013', '', '', '', '', '', 'CDD', 1),
(9, '', 2, 'BELLOIS', 'Karine', '', '', '', '', '', '', '', '', '19/02/2014', '', '', '', '', '', 'CDD', 1),
(10, '', 1, 'BENIER', 'Marie Dominique', '', '', '', '', '', '', '', '', '25/01/1973', '31-01-2015', '', '', '', 'RETRAITE', 'CDI', 1),
(11, '', 2, 'BERTEAU', 'Patricia', '', '', '', '', '', '', '', '', '05/12/2011', '', '', '', '', '', 'CDI', 1),
(12, '', 2, 'BERTRAND', 'Erika', '', '', '', '', '', '', '', '', '22/04/2013', '', '', '', '', '', 'CDI', 1),
(13, '', 2, 'BIBARD', 'Audrey', '', '', '', '', '', '', '', '', '22/06/2009', '', '', '', '', '', 'CDI', 1),
(14, '', 2, 'BIGOT', 'Louise', '', '', '', '', '', '', '', '', '13/02/2014', '', '', '', '', '', 'CDD', 1),
(15, '', 2, 'BINOT', 'Lucie', '', '', '', '', '', '', '', '', '26/04/2004', '', '', '', '', '', 'CDI', 1),
(16, '', 2, 'BIZMAOUI PAPIN', 'Myriam', '', '', '', '', '', '', '', '', '02/04/2008', '', '', '', '', '', 'CDI', 1),
(17, '', 2, 'BLAITEAU', 'Dalila', '', '', '', '', '', '', '', '', '07/08/1996', '', '', '', '', '', 'CDI', 1),
(18, '', 2, 'BLEZ', 'Manon', '', '', '', '', '', '', '', '', '05/09/2013', '', '', '', '', '', 'CDI', 1),
(19, '', 2, 'BOIS', 'Marie', '', '', '', '', '', '', '', '', '02/12/2010', '', '', '', '', '', 'CDI', 1),
(20, '', 2, 'BONFILS', 'Cecile', '', '', '', '', '', '', '', '', '17/06/1997', '', '', '', '', '', 'CDI', 1),
(21, '', 2, 'BONNARDE', 'Armelle', '', '', '', '', '', '', '', '', '20/07/2011', '', '', '', '', '', 'CDI', 1),
(22, '', 2, 'BORE', 'Marie Pierre', '', '', '', '', '', '', '', '', '15/01/1997', '', '', '', '', '', 'CDI', 1),
(23, '', 2, 'BOSSU', 'Catherine', '', '', '', '', '', '', '', '', '01/02/2014', '', '', '', '', '', 'CDD', 1),
(24, '', 2, 'BOUET', 'Annette', '', '', '', '', '', '', '', '', '26/05/2005', '', '', '', '', '', 'CDI', 1),
(25, '', 2, 'BOULAY', 'Jennifer', '', '', '', '', '', '', '', '', '28/08/2013', '', '', '', '', '', 'CDD', 1),
(26, '', 1, 'BOURGAUD', 'Mickael', '', '', '', '', '', '', '', '', '03/01/2007', '', '', '', '', '', 'CDI', 1),
(27, '', 1, 'BOURGET', 'Louis', '', '', '', '', '', '', '', '', '20/06/2014', '', '', '', '', '', 'CDD', 1),
(28, '', 1, 'BOUTIN', 'David', '', '', '', '', '', '', '', '', '29/11/2013', '', '', '', '', '', 'CDD', 1),
(29, '', 2, 'BOUTREUX', 'Anne Sophie', '', '', '', '', '', '', '', '', '27/08/2013', '', '', '', '', '', 'CDD', 1),
(30, '', 2, 'BRARD', 'Marie Pierre', '', '', '', '', '', '', '', '', '02/06/2008', '', '', '', '', '', 'CDI', 1),
(31, '', 2, 'BRISSY', 'Helene', '', '', '', '', '', '', '', '', '03/10/2011', '', '', '', '', '', 'CDI', 1),
(32, '', 2, 'BUSH', 'Magali', '', '', '', '', '', '', '', '', '04/09/2013', '', '', '', '', '', 'CDD', 1),
(33, '', 2, 'CADELE', 'Marie Claude', '', '', '', '', '', '', '', '', '28/02/2007', '', '', '', '', '', 'CDI', 1),
(34, '', 2, 'CARRE', 'Audrey', '', '', '', '', '', '', '', '', '03/10/2012', '', '', '', '', '', 'CDI', 1),
(35, '', 2, 'CAYRE', 'St?phanie', '', '', '', '', '', '', '', '', '14/04/2014', '', '', '', '', '', 'CDD', 1),
(36, '', 1, 'CHAILLAND', 'Pierre', '', '', '', '', '', '', '', '', '05/06/2013', '', '', '', '', '', 'CDD', 1),
(37, '', 1, 'CHAILLAND', 'Julien', '', '', '', '', '', '', '', '', '02/01/2006', '', '', '', '', '', 'CDI', 1),
(38, '', 2, 'CHAILLOU', 'Sandra', '', '', '', '', '', '', '', '', '13/09/1999', '', '', '', '', '', 'CDI', 1),
(39, '', 2, 'CHALLIER', 'Jacqueline', '', '', '', '', '', '', '', '', '10/06/2010', '', '', '', '', '', 'CDI', 1),
(40, '', 1, 'CHAMPIGNY', 'Antoine', '', '', '', '', '', '', '', '', '10/01/2011', '', '', '', '', '', 'CDI', 1),
(41, '', 2, 'CHARREAU', 'Helene', '', '', '', '', '', '', '', '', '04/01/1989', '', '', '', '', '', 'CDI', 1),
(42, '', 2, 'CHARRIER', 'Elena', '', '', '', '', '', '', '', '', '24/11/2003', '', '', '', '', '', 'CDI', 1),
(43, '', 2, 'CHARTIER', 'Brigitte', '', '', '', '', '', '', '', '', '24/01/1977', '', '', '', '', '', 'CDI', 1),
(44, '', 2, 'CHATEAU', 'Sandrine', '', '', '', '', '', '', '', '', '09/01/2006', '', '', '', '', '', 'CDI', 1),
(45, '', 2, 'CHEIGNON', 'Aurore', '', '', '', '', '', '', '', '', '23/09/1993', '', '', '', '', '', 'CDI', 1),
(46, '', 2, 'CHEVREUX', 'Melanie', '', '', '', '', '', '', '', '', '30/06/2011', '', '', '', '', '', 'CDI', 1),
(47, '', 2, 'CHEVRIER', 'B?atrice', '', '', '', '', '', '', '', '', '12/09/2011', '', '', '', '', '', 'CDI', 1),
(48, '', 1, 'CIBRON', 'Christophe', '', '', '', '', '', '', '', '', '15/03/1993', '', '', '', '', '', 'CDI', 1),
(49, '', 2, 'CLOUTOT', 'Sophie', '', '', '', '', '', '', '', '', '12/10/1998', '', '', '', '', '', 'CDI', 1),
(50, '', 1, 'COCHIN', 'Yvon', '', '', '', '', '', '', '', '', '30/07/2012', '', '', '', '', '', 'CDI', 1),
(51, '', 1, 'COIGNARD', 'Jeremy', '', '', '', '', '', '', '', '', '20/10/2011', '', '', '', '', '', 'CDD', 1),
(52, '', 2, 'COLAISSEAU', 'Christine', '', '', '', '', '', '', '', '', '12/03/2010', '', '', '', '', '', 'CDI', 1),
(53, '', 2, 'CORVE', 'Gilberte', '', '', '', '', '', '', '', '', '24/03/2001', '', '', '', '', '', 'CDI', 1),
(54, '', 2, 'COTTENCEAU', 'Monique', '', '', '', '', '', '', '', '', '17/09/2004', '', '', '', '', '', 'CDI', 1),
(55, '', 2, 'COURCELLE', 'Pauline', '', '', '', '', '', '', '', '', '10/02/2014', '', '', '', '', '', 'CDD', 1),
(56, '', 2, 'CRANSAC', 'Christel', '', '', '', '', '', '', '', '', '08/04/2011', '', '', '', '', '', 'CDI', 1),
(57, '', 2, 'DABOUDET', 'Valerie', '', '', '', '', '', '', '', '', '09/05/2005', '', '', '', '', '', 'CDI', 1),
(58, '', 2, 'DAVY', 'Katia', '', '', '', '', '', '', '', '', '30/03/1995', '', '', '', '', '', 'CDI', 1),
(59, '', 2, 'DELAREUX', 'Isabelle', '', '', '', '', '', '', '', '', '02/01/1984', '', '', '', '', '', 'CDI', 1),
(60, '', 2, 'DELAUNAY', 'Dominique', '', '', '', '', '', '', '', '', '01/11/2008', '', '', '', '', '', 'CDI', 1),
(61, '', 1, 'DELEMME', 'Anthony', '', '', '', '', '', '', '', '', '01/11/2008', '', '', '', '', '', 'CDI', 1),
(62, '', 2, 'DENANCE', 'Claudia', '', '', '', '', '', '', '', '', '01/08/1973', '', '', '', '', '', 'CDI', 1),
(63, '', 2, 'DENECHERE', 'Pascale', '', '', '', '', '', '', '', '', '28/11/1995', '', '', '', '', '', 'CDI', 1),
(64, '', 1, 'DEROUET', 'Jerome', '', '', '', '', '', '', '', '', '24/02/1995', '', '', '', '', '', 'CDI', 1),
(65, '', 2, 'DESCHRYVER', 'Elisabeth', '', '', '', '', '', '', '', '', '01/06/2007', '', '', '', '', '', 'CDI', 1),
(66, '', 2, 'DEVAUD', 'Sandrine', '', '', '', '', '', '', '', '', '02/10/2000', '', '', '', '', '', 'CDI', 1),
(67, '', 2, 'DIJOLS', 'Christine', '', '', '', '', '', '', '', '', '02/05/2011', '', '', '', '', '', 'CDI', 1),
(68, '', 2, 'DOISNEAU', 'Geraldine', '', '', '', '', '', '', '', '', '03/01/1994', '', '', '', '', '', 'CDI', 1),
(69, '', 2, 'DONEAU', 'Emilie', '', '', '', '', '', '', '', '', '12/12/2011', '', '', '', '', '', 'CDI', 1),
(70, '', 2, 'DOUET', 'Charline', '', '', '', '', '', '', '', '', '10/09/2009', '', '', '', '', '', 'CDI', 1),
(71, '', 2, 'DUPAS', 'FranÃ§oise', '', '', '', '', '', '', '', '', '18/08/1997', '', '', '', '', '', 'CDI', 1),
(72, '', 2, 'DURAND CHATTON', 'Pascale', '', '', '', '', '', '', '', '', '02/12/2004', '', '', '', '', '', 'CDI', 1),
(73, '', 2, 'ELOBO', 'Renee', '', '', '', '', '', '', '', '', '15/02/2012', '', '', '', '', '', 'CDI', 1),
(74, '', 1, 'ESNAULT', 'Claude', '', '', '', '', '', '', '', '', '28/05/1984', '', '', '', '', '', 'CDI', 1),
(75, '', 2, 'FERRAND', 'Mauricette', '', '', '', '', '', '', '', '', '27/11/2008', '', '', '', '', '', 'CDI', 1),
(76, '', 2, 'FLEURY', 'Marylene', '', '', '', '', '', '', '', '', '22/02/2010', '', '', '', '', '', 'CDI', 1),
(77, '', 2, 'FOUBLE', 'Camille', '', '', '', '', '', '', '', '', '23/09/2013', '', '', '', '', '', 'CDI', 1),
(78, '', 2, 'FOUQUERAY', 'Edwige', '', '', '', '', '', '', '', '', '05/12/2011', '', '', '', '', '', 'CDI', 1),
(79, '', 2, 'FOUQUET', 'Chantal', '', '', '', '', '', '', '', '', '01/04/2010', '', '', '', '', '', 'CDI', 1),
(80, '', 1, 'FRABOULET', 'Jean Yves', '', '', '', '', '', '', '', '', '24/04/2012', '', '', '', '', '', 'CDI', 1),
(81, '', 2, 'FRANCFORT', 'Catherine', '', '', '', '', '', '', '', '', '15/10/2008', '', '', '', '', '', 'CDI', 1),
(82, '', 2, 'GASTINEAU', 'Isabelle', '', '', '', '', '', '', '', '', '19/03/2002', '', '', '', '', '', 'CDI', 1),
(83, '', 2, 'GAUDELET', 'Maryline', '', '', '', '', '', '', '', '', '01/12/1981', '', '', '', '', '', 'CDI', 1),
(84, '', 2, 'GAUTHIER', 'Emeline', '', '', '', '', '', '', '', '', '12/03/2014', '', '', '', '', '', 'CDD', 1),
(85, '', 2, 'GERARD', 'Alexandra', '', '', '', '', '', '', '', '', '26/10/1999', '', '', '', '', '', 'CDI', 1),
(86, '', 2, 'GESLIN', 'Sarah', '', '', '', '', '', '', '', '', '20/01/2003', '', '', '', '', '', 'CDI', 1),
(87, '', 2, 'GILBERT', 'Lucie', '', '', '', '', '', '', '', '', '02/07/2013', '', '', '', '', '', 'CDI', 1),
(88, '', 2, 'GILET', 'Brigitte', '', '', '', '', '', '', '', '', '10/03/1983', '', '', '', '', '', 'CDI', 1),
(89, '', 2, 'GISLARD', 'Catherine', '', '', '', '', '', '', '', '', '04/07/2007', '', '', '', '', '', 'CDI', 1),
(90, '', 2, 'GODIN', 'St?phanie', '', '', '', '', '', '', '', '', '06/02/2014', '', '', '', '', '', 'CDD', 1),
(91, '', 1, 'GOHIER', 'Simon', '', '', '', '', '', '', '', '', '29/06/2013', '', '', '', '', '', 'CDD', 1),
(92, '', 2, 'GOURMAUD', 'Delphine', '', '', '', '', '', '', '', '', '03/03/2010', '', '', '', '', '', 'CDI', 1),
(93, '', 1, 'GRAU', 'Cecilio', '', '', '', '', '', '', '', '', '01/12/2010', '', '', '', '', '', 'CDI', 1),
(94, '', 2, 'GRIFFON', 'Carine', '', '', '', '', '', '', '', '', '06/04/2009', '', '', '', '', '', 'CDI', 1),
(95, '', 2, 'GUEGAN', 'Cecilia', '', '', '', '', '', '', '', '', '18/10/2005', '', '', '', '', '', 'CDI', 1),
(96, '', 2, 'GUIHO', 'Odette', '', '', '', '', '', '', '', '', '10/02/1998', '', '', '', '', '', 'CDI', 1),
(97, '', 2, 'GUILLOT', 'Claire', '', '', '', '', '', '', '', '', '11/10/2010', '', '', '', '', '', 'CDI', 1),
(98, '', 1, 'HAISSANT', 'Thibaud', '', '', '', '', '', '', '', '', '05/07/2007', '', '', '', '', '', 'CDI', 1),
(99, '', 1, 'HAMON', 'Olivier', '', '', '', '', '', '', '', '', '23/04/2014', '', '', '', '', '', 'CDD', 1),
(100, '', 2, 'HEBBACHE', 'Michelle', '', '', '', '', '', '', '', '', '19/09/1977', '', '', '', '', '', 'CDI', 1),
(101, '', 2, 'HENNE', 'Teresa', '', '', '', '', '', '', '', '', '07/02/2011', '', '', '', '', '', 'CDI', 1),
(102, '', 2, 'HERANVAL', 'Malvina', '', '', '', '', '', '', '', '', '15/07/2013', '', '', '', '', '', 'CDI', 1),
(103, '', 1, 'HERAUD', 'Pierre', '', '', '', '', '', '', '', '', '20/07/2011', '', '', '', '', '', 'CDI', 1),
(104, '', 2, 'HODET', 'Martine', '', '', '', '', '', '', '', '', '01/02/2014', '', '', '', '', '', 'CDI', 1),
(105, '', 2, 'HUAU', 'Carine', '', '', '', '', '', '', '', '', '03/10/2011', '', '', '', '', '', 'CDI', 1),
(106, '', 1, 'HUGARD', 'Jacques', '', '', '', '', '', '', '', '', '20/08/2009', '', '', '', '', '', 'CDI', 1),
(107, '', 2, 'HUIN', 'Sylvie', '', '', '', '', '', '', '', '', '01/02/2011', '', '', '', '', '', 'CDI', 1),
(108, '', 2, 'JAMOTEAU', 'Adeline', '', '', '', '', '', '', '', '', '18/01/2010', '', '', '', '', '', 'CDI', 1),
(109, '', 2, 'JARRY FAURANT', 'Anne', '', '', '', '', '', '', '', '', '23/06/2003', '', '', '', '', '', 'CDI', 1),
(110, '', 2, 'JEMIN', 'Christine', '', '', '', '', '', '', '', '', '11/08/1975', '', '', '', '', '', 'CDI', 1),
(111, '', 1, 'JEMIN', 'Dany', '', '', '', '', '', '', '', '', '23/01/2014', '', '', '', '', '', 'CDD', 1),
(112, '', 2, 'JOUAN', 'Fanny', '', '', '', '', '', '', '', '', '02/05/2011', '', '', '', '', '', 'CDI', 1),
(113, '', 2, 'JOUANNEAU', 'Carole', '', '', '', '', '', '', '', '', '28/09/2010', '', '', '', '', '', 'CDI', 1),
(114, '', 2, 'JOURNIAC', 'Adeline', '', '', '', '', '', '', '', '', '31/12/2007', '', '', '', '', '', 'CDI', 1),
(115, '', 1, 'JUGUET', 'Philippe', '', '', '', '', '', '', '', '', '19/03/2012', '', '', '', '', '', 'CDI', 1),
(116, '', 2, 'JURET', 'Marlene', '', '', '', '', '', '', '', '', '23/05/2005', '', '', '', '', '', 'CDI', 1),
(117, '', 2, 'KIMBOROWICZ', 'Elodie', '', '', '', '', '', '', '', '', '15/10/2012', '', '', '', '', '', 'CDI', 1),
(118, '', 2, 'LAMY', 'Nathalie', '', '', '', '', '', '', '', '', '01/12/2003', '', '', '', '', '', 'CDI', 1),
(119, '', 1, 'LANNIER', 'Yann', '', '', '', '', '', '', '', '', '13/03/2010', '', '', '', '', '', 'CDI', 1),
(120, '', 2, 'LARCIER', 'Guylaine', '', '', '', '', '', '', '', '', '03/07/1997', '', '', '', '', '', 'CDI', 1),
(121, '', 2, 'LASNE', 'Allison', '', '', '', '', '', '', '', '', '02/07/2007', '', '', '', '', '', 'CDI', 1),
(122, '', 2, 'LATONNELLE', 'Anne', '', '', '', '', '', '', '', '', '11/12/2006', '', '', '', '', '', 'CDI', 1),
(123, '', 2, 'LE BORGNE', 'Celine', '', '', '', '', '', '', '', '', '12/01/2012', '', '', '', '', '', 'CDI', 1),
(124, '', 2, 'LE CALVEZ', 'Jocelyne', '', '', '', '', '', '', '', '', '08/10/2002', '', '', '', '', '', 'CDI', 1),
(125, '', 2, 'LE CALVEZ', 'Marine', '', '', '', '', '', '', '', '', '29/01/2012', '', '', '', '', '', 'CDI', 1),
(126, '', 2, 'LE GAL', 'Barbara', '', '', '', '', '', '', '', '', '27/05/2003', '', '', '', '', '', 'CDI', 1),
(127, '', 1, 'LE JEAN', 'GaÃ«l', '', '', '', '', '', '', '', '', '01/10/2012', '', '', '', '', '', 'CDI', 1),
(128, '', 2, 'LEBAILLY', 'Emilie', '', '', '', '', '', '', '', '', '07/09/2010', '', '', '', '', '', 'CDI', 1),
(129, '', 1, 'LEBLANC', 'Pascal', '', '', '', '', '', '', '', '', '01/07/2004', '', '', '', '', '', 'CDI', 1),
(130, '', 2, 'LECLERC', 'Caroline', '', '', '', '', '', '', '', '', '26/11/2009', '', '', '', '', '', 'CDI', 1),
(131, '', 2, 'LECOMTE', 'Ludivine', '', '', '', '', '', '', '', '', '09/02/2004', '', '', '', '', '', 'CDI', 1),
(132, '', 2, 'LEGER', 'Sonia', '', '', '', '', '', '', '', '', '06/12/1994', '', '', '', '', '', 'CDI', 1),
(133, '', 2, 'LELIEVRE', 'Isabelle', '', '', '', '', '', '', '', '', '10/07/1989', '', '', '', '', '', 'CDI', 1),
(134, '', 2, 'LENOGUE', 'Angelique', '', '', '', '', '', '', '', '', '05/11/2004', '', '', '', '', '', 'CDI', 1),
(135, '', 2, 'LESAGE', 'Catherine', '', '', '', '', '', '', '', '', '18/11/2000', '', '', '', '', '', 'CDI', 1),
(136, '', 1, 'LOISEL', 'Nicolas', '', '', '', '', '', '', '', '', '10/04/2003', '', '', '', '', '', 'CDI', 1),
(137, '', 2, 'LOPEZ DE CARVALHO', 'Nathalie', '', '', '', '', '', '', '', '', '10/06/2014', '', '', '', '', '', 'CDD', 1),
(138, '', 2, 'LORINQUER', 'Pauline', '', '', '', '', '', '', '', '', '07/07/2008', '', '', '', '', '', 'CDD', 1),
(139, '', 2, 'LORINQUER', 'Melanie', '', '', '', '', '', '', '', '', '14/11/2005', '', '', '', '', '', 'CDI', 1),
(140, '', 1, 'LUCAS', 'Jean Michel', '', '', '', '', '', '', '', '', '13/10/2008', '', '', '', '', '', 'CDI', 1),
(141, '', 2, 'MALINGE', 'Anicette', '', '', '', '', '', '', '', '', '27/01/2014', '', '', '', '', '', 'CDD', 1),
(142, '', 1, 'MARAUD', 'Philippe', '', '', '', '', '', '', '', '', '30/08/2010', '', '', '', '', '', 'CDI', 1),
(143, '', 2, 'MARTINEAU', 'Laure Anne', '', '', '', '', '', '', '', '', '04/01/2011', '', '', '', '', '', 'CDI', 1),
(144, '', 2, 'MAUDET', 'Delphine', '', '', '', '', '', '', '', '', '17/08/2009', '', '', '', '', '', 'CDI', 1),
(145, '', 2, 'MAUSSION', 'Christine', '', '', '', '', '', '', '', '', '16/11/1993', '', '', '', '', '', 'CDI', 1),
(146, '', 2, 'MBIDA', 'Martine', '', '', '', '', '', '', '', '', '16/01/1995', '', '', '', '', '', 'CDI', 1),
(147, '', 2, 'MEIGNAN', 'Claudia', '', '', '', '', '', '', '', '', '22/02/1996', '', '', '', '', '', 'CDI', 1),
(148, '', 2, 'MENANT', 'Sylvie', '', '', '', '', '', '', '', '', '04/02/2008', '', '', '', '', '', 'CDI', 1),
(149, '', 2, 'MENARD', 'Chloe', '', '', '', '', '', '', '', '', '23/04/2013', '', '', '', '', '', 'CDI', 1),
(150, '', 2, 'MENDONCA', 'Maria Fernanda', '', '', '', '', '', '', '', '', '01/02/1996', '', '', '', '', '', 'CDI', 1),
(151, '', 2, 'MERCEREAU', 'Aude', '', '', '', '', '', '', '', '', '05/03/2003', '', '', '', '', '', 'CDI', 1),
(152, '', 2, 'MERIAN', 'Gaelle', '', '', '', '', '', '', '', '', '19/09/2005', '', '', '', '', '', 'CDI', 1),
(153, '', 2, 'MEURIC', 'Fran?oise', '', '', '', '', '', '', '', '', '29/08/2013', '', '', '', '', '', 'CDD', 1),
(154, '', 2, 'MONNIER', 'Sarah', '', '', '', '', '', '', '', '', '07/08/2012', '', '', '', '', '', 'CDI', 1),
(155, '', 2, 'MOREAU', 'Sandra', '', '', '', '', '', '', '', '', '24/11/2008', '', '', '', '', '', 'CDI', 1),
(156, '', 2, 'MOREAU', 'Pascale', '', '', '', '', '', '', '', '', '06/06/2011', '', '', '', '', '', 'CDI', 1),
(157, '', 2, 'NASRI', 'Marion', '', '', '', '', '', '', '', '', '13/06/2003', '', '', '', '', '', 'CDI', 1),
(158, '', 1, 'OLIVEAU', 'Jean Rene', '', '', '', '', '', '', '', '', '18/12/1987', '', '', '', '', '', 'CDI', 1),
(159, '', 2, 'OLIVEIRA', 'Cecile', '', '', '', '', '', '', '', '', '12/05/2003', '', '', '', '', '', 'CDI', 1),
(160, '', 2, 'PASCUITO', 'Isabelle', '', '', '', '', '', '', '', '', '12/01/2008', '', '', '', '', '', 'CDD', 1),
(161, '', 1, 'PATAO', 'Armand', '', '', '', '', '', '', '', '', '25/06/2007', '', '', '', '', '', 'CDI', 1),
(162, '', 2, 'PECOT', 'Sandrine', '', '', '', '', '', '', '', '', '01/02/2002', '', '', '', '', '', 'CDI', 1),
(163, '', 2, 'PERDRIAU', 'Carine', '', '', '', '', '', '', '', '', '12/06/1998', '', '', '', '', '', 'CDI', 1),
(164, '', 2, 'PERDRIAU', 'Sophie', '', '', '', '', '', '', '', '', '09/04/1985', '', '', '', '', '', 'CDI', 1),
(165, '', 2, 'PETITEAU', 'Sarah', '', '', '', '', '', '', '', '', '25/03/2011', '', '', '', '', '', 'CDI', 1),
(166, '', 2, 'PICHERIT', 'Valerie', '', '', '', '', '', '', '', '', '22/10/1992', '', '', '', '', '', 'CDI', 1),
(167, '', 2, 'PIEL', 'Guylaine', '', '', '', '', '', '', '', '', '19/04/1991', '', '', '', '', '', 'CDI', 1),
(168, '', 2, 'PITHON', 'Adeline', '', '', '', '', '', '', '', '', '26/10/2005', '', '', '', '', '', 'CDI', 1),
(169, '', 1, 'PITULA', 'R?mi', '', '', '', '', '', '', '', '', '23/12/2013', '', '', '', '', '', 'CDD', 1),
(170, '', 2, 'ABID/PLANCHENAULT', 'Sylvie', '', '', '', '', '', '', '', '', '01/11/2004', '', '', '', '', '', 'CDI', 1),
(171, '', 2, 'POIROUX', 'Marie Helene', '', '', '', '', '', '', '', '', '30/03/1977', '', '', '', '', '', 'CDI', 1),
(172, '', 2, 'POUTREL', 'Sylvie', '', '', '', '', '', '', '', '', '22/11/2010', '', '', '', '', '', 'CDI', 1),
(173, '', 2, 'PRIOU', 'Julie', '', '', '', '', '', '', '', '', '15/03/2002', '', '', '', '', '', 'CDI', 1),
(174, '', 2, 'PRUD HOMME', 'Laurence', '', '', '', '', '', '', '', '', '09/09/2013', '', '', '', '', '', 'CDD', 1),
(175, '', 2, 'PRUDHOMME', 'Celine', '', '', '', '', '', '', '', '', '01/02/2003', '', '', '', '', '', 'CDI', 1),
(176, '', 2, 'RENAUD', 'Sandrine', '', '', '', '', '', '', '', '', '01/02/2013', '', '', '', '', '', 'CDI', 1),
(177, '', 1, 'RENAULT', 'Marc', '', '', '', '', '', '', '', '', '26/04/1976', '', '', '', '', '', 'CDI', 1),
(178, '', 2, 'RENAULT', 'Claire', '', '', '', '', '', '', '', '', '01/09/1975', '', '', '', '', '', 'CDI', 1),
(179, '', 1, 'REVEREAULT', 'John', '', '', '', '', '', '', '', '', '07/05/1997', '', '', '', '', '', 'CDI', 1),
(180, '', 2, 'REVEREAULT', 'Melanie', '', '', '', '', '', '', '', '', '09/02/1995', '', '', '', '', '', 'CDI', 1),
(181, '', 2, 'RICHARD', 'Francoise', '', '', '', '', '', '', '', '', '07/11/1996', '', '', '', '', '', 'CDI', 1),
(182, '', 2, 'RIPOCHE', 'Geraldine', '', '', '', '', '', '', '', '', '27/06/2004', '', '', '', '', '', 'CDI', 1),
(183, '', 2, 'RIVEREAU', 'Anne Sophie', '', '', '', '', '', '', '', '', '27/05/1994', '', '', '', '', '', 'CDI', 1),
(184, '', 2, 'ROBIN', 'Odile', '', '', '', '', '', '', '', '', '01/09/2013', '', '', '', '', '', 'CDD', 1),
(185, '', 2, 'ROUSSE', 'Maryvonne', '', '', '', '', '', '', '', '', '22/06/2005', '', '', '', '', '', 'CDI', 1),
(186, '', 2, 'ROUSSEAU', 'Alexia', '', '', '', '', '', '', '', '', '24/08/2012', '', '', '', '', '', 'CDD', 1),
(187, '', 2, 'ROYER', 'Catherine', '', '', '', '', '', '', '', '', '03/07/2012', '', '', '', '', '', 'CDI', 1),
(188, '', 1, 'SALAUD', 'Vivien', '', '', '', '', '', '', '', '', '03/12/2012', '', '', '', '', '', 'CDI', 1),
(189, '', 1, 'SAULOU', 'Guillaume', '', '', '', '', '', '', '', '', '02/07/2012', '', '', '', '', '', 'CDD', 1),
(190, '', 2, 'SEGARRA', 'Agnes', '', '', '', '', '', '', '', '', '03/07/1997', '', '', '', '', '', 'CDI', 1),
(191, '', 2, 'SEHAQUI', 'M Therese', '', '', '', '', '', '', '', '', '01/01/2004', '', '', '', '', '', 'CDI', 1),
(192, '', 2, 'SEURRE', 'Marie Jose', '', '', '', '', '', '', '', '', '08/08/2011', '', '', '', '', '', 'CDI', 1),
(193, '', 2, 'SOUALAH', 'Bahija', '', '', '', '', '', '', '', '', '01/03/1987', '', '', '', '', '', 'CDI', 1),
(194, '', 2, 'SOUCHARD', 'Marine', '', '', '', '', '', '', '', '', '30/08/2010', '', '', '', '', '', 'CDI', 1),
(195, '', 2, 'SOULET', 'Elodie', '', '', '', '', '', '', '', '', '08/07/2009', '', '', '', '', '', 'CDI', 1),
(196, '', 2, 'SOURISSEAU', 'Aurore', '', '', '', '', '', '', '', '', '14/01/2008', '', '', '', '', '', 'CDI', 1),
(197, '', 2, 'TAUBIN', 'Marine', '', '', '', '', '', '', '', '', '04/01/2012', '', '', '', '', '', 'CDI', 1),
(198, '', 2, 'TAUDON', 'Christine', '', '', '', '', '', '', '', '', '01/06/1985', '', '', '', '', '', 'CDI', 1),
(199, '', 2, 'TAUNAY', 'M Laure', '', '', '', '', '', '', '', '', '09/05/2003', '', '', '', '', '', 'CDI', 1),
(200, '', 2, 'TELLANGER', 'Axelle', '', '', '', '', '', '', '', '', '13/03/1989', '', '', '', '', '', 'CDI', 1),
(201, '', 2, 'TESSIE', 'Francoise', '', '', '', '', '', '', '', '', '25/07/1988', '', '', '', '', '', 'CDI', 1),
(202, '', 2, 'TESSIER', 'Florence', '', '', '', '', '', '', '', '', '14/02/2006', '', '', '', '', '', 'CDI', 1),
(203, '', 2, 'THEULIER', 'Laure', '', '', '', '', '', '', '', '', '03/09/1989', '', '', '', '', '', 'CDI', 1),
(204, '', 2, 'TIERCELIN', 'Charl?ne', '', '', '', '', '', '', '', '', '02/01/2012', '', '', '', '', '', 'CDI', 1),
(205, '', 2, 'TORREGROSSA', 'C?line', '', '', '', '', '', '', '', '', '12/12/2011', '', '', '', '', '', 'CDI', 1),
(206, '', 1, 'TOUDJI', 'Akouete Pierre', '', '', '', '', '', '', '', '', '13/12/2004', '', '', '', '', '', 'CDI', 1),
(207, '', 2, 'TREMBLAIS', 'Catherine', '', '', '', '', '', '', '', '', '13/03/1984', '', '', '', '', '', 'CDI', 1),
(208, '', 2, 'TROISPOILS', 'Anne', '', '', '', '', '', '', '', '', '06/04/1979', '', '', '', '', '', 'CDI', 1),
(209, '', 1, 'VENJEAN', 'Philippe', '', '', '', '', '', '', '', '', '05/01/2004', '', '', '', '', '', 'CDI', 1),
(210, '', 2, 'VIGAN', 'Corinne', '', '', '', '', '', '', '', '', '29/11/1999', '', '', '', '', '', 'CDI', 1),
(211, '', 1, 'VIVIEN', 'HervÃ©', '', '', '', '', '', '', '', '', '02/12/2013', '', '', '', '', '', 'CDI', 1),
(212, '', 2, 'VIVION', 'Beatrice', '', '', '', '', '', '', '', '', '16/11/2009', '', '', '', '', '', 'CDI', 1),
(213, '', 2, 'YEKULI', 'Aurelie', '', '', '', '', '', '', '', '', '17/11/2007', '', '', '', '', '', 'CDI', 1),
(214, '', 2, 'MAQUIN', 'CATHERINE', '', '', '', '', '', '', '', '', '', '05-03-2012', '1', '', '', 'RETRAITE', '', 1),
(215, '', 1, 'JULIENNE', 'THEO', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1),
(216, '', 2, 'PRUNAUX-CAZER', '', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'CDD', 1),
(217, '', 2, 'YVON', 'ANAELLE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'CDD', 1),
(218, '', 2, 'GAZE', 'CHRISTELLE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'CDD', 1),
(219, '', 1, 'RUBIO', 'G.MICHEL', '', '', '', '', '', '', '', '', '', '01-01-2013', '1', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE IF NOT EXISTS `solde_caisse` (
`idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=152 ;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(13, '06-03-2015', '6571572', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOUET.', '', '199.8', 0),
(14, '06-03-2015', '6571572', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOUET.', '', '36', 0),
(20, '06-03-2015', '0004554', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LE JEAN.', '', '36', 0),
(22, '06-03-2015', '5103889', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BRARD.', '', '36', 0),
(25, '06-03-2015', '7105', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de VIVIEN.', '', '203.4', 0),
(27, '06-03-2015', '9823959', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de TELLANGER.', '', '8.2', 0),
(29, '06-03-2015', '9362062', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CHARREAU.', '', '2.15', 0),
(38, '06-03-2015', '6828220', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUSSE.', '', '5', 0),
(39, '06-03-2015', '5140080', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de COCHIN.', '', '124.2', 0),
(40, '09-03-2015', '05354927001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BORE.', '', '5', 0),
(44, '09-03-2015', '4267947', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LATONNELLE.', '', '18', 0),
(50, '09-03-2015', '4644063', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOUTREUX.', '', '18', 0),
(52, '09-03-2015', '9407352', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de SEHAQUI.', '', '84', 0),
(53, '09-03-2015', '4644063', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOUTREUX.', '', '35.12', 0),
(54, '30-01-2015', '6165244', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6165244 en date du 30-01-2015.', '327.32', '', 1),
(58, '30-01-2015', '6165243', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6165243 en date du 30-01-2015.', '312.3', '', 1),
(60, '09-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '70.2', 1),
(61, '09-03-2015', '0000261', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de JULIENNE.', '', '7.1', 0),
(62, '09-03-2015', '5668279', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PASQUITO.', '', '60', 0),
(64, '09-03-2015', '0681424', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BEAUMONT.', '', '18', 0),
(65, '09-03-2015', '0008342', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GERARD.', '', '42', 0),
(66, '09-03-2015', '6265074', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CIBRON.', '', '5', 0),
(68, '09-03-2015', '6615541', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de SOULET.', '', '5', 0),
(70, '11-02-2015', '6165245', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6165245 en date du 11-02-2015.', '166.1', '', 1),
(71, '09-03-2015', '8310545', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CHEIGNON.', '', '33.3', 0),
(72, '09-03-2015', '4267949', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LATONELLE.', '', '42', 0),
(75, '09-03-2015', '0003084', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GASTINEAU.', '', '18', 0),
(77, '09-03-2015', '0590234', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MENDONCA.', '', '18', 0),
(78, '11-01-2015', '6165246', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6165246 en date du 11-01-2015.', '165.3', '', 1),
(81, '10-03-2015', '5411145', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GILBERT.', '', '36', 0),
(84, '10-03-2015', '5225914', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de THEULIER.', '', '30', 0),
(85, '12-02-2015', '6165248', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6165248 en date du 12-02-2015.', '138', '', 1),
(86, '10-03-2015', '0267678', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LE CALVEZ.', '', '30', 0),
(88, '10-03-2015', '4888598', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de YVON.', '', '30', 0),
(89, '10-03-2015', '0000039', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LEBAILLY.', '', '36', 0),
(91, '10-03-2015', '4674060', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUIHO.', '', '5', 0),
(92, '10-03-2015', '127334', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUSSE.', '', '6', 0),
(93, '17-02-2015', '6859737', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6859737 en date du 17-02-2015.', '131', '', 1),
(94, '11-03-2015', '9524903', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GAZE.', '', '30', 0),
(95, '13-01-2015', '6165240', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6165240 en date du 13-01-2015.', '182.15', '', 1),
(96, '07-01-2015', '6165238', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6165238 en date du 07-01-2015.', '295.6', '', 1),
(97, '11-03-2015', '7015558', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LEGER.', '', '30', 0),
(98, '11-03-2015', '7384660', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOULAY.', '', '120.6', 0),
(99, '11-03-2015', '0002412', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CHAILLOU.', '', '198.2', 0),
(101, '11-03-2015', '0002401', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de TREMBLAIS.', '', '42.3', 0),
(102, '11-03-2015', '0002401', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de TREMBLAIS.', '', '15.75', 0),
(105, '11-03-2015', '0008347', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GERARD.', '', '54', 0),
(107, '11-03-2015', '7583568', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de TAUDON.', '', '5', 0),
(111, '11-03-2015', '678971', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de RUBIO.', '', '36', 0),
(112, '11-03-2015', '678971', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de RUBIO.', '', '198.2', 0),
(113, '11-03-2015', '7414678', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DIJOLS.', '', '36', 0),
(114, '11-03-2015', '4583031', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MOREAU.', '', '30', 0),
(115, '11-03-2015', '0000272', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DELAREUX.', '', '30', 0),
(118, '07-01-2015', '6859741', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6859741 en date du 07-01-2015.', '390.2', '', 1),
(119, '11-03-2015', '9524908', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GAZE.', '', '30', 0),
(120, '11-03-2015', '0003090', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GASTINEAU.', '', '66', 0),
(121, '11-03-2015', '0141781', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DENECHERE.', '', '18', 0),
(123, '11-03-2015', '451794', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CHEVREUX.', '', '36', 0),
(126, '11-03-2015', '4765006', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ABBID.', '', '20', 0),
(127, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '2', 0),
(128, '11-03-2015', '5006', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ABIB.', '', '22', 0),
(129, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '2', 0),
(130, '11-03-2015', '9959250', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de SOULET.', '', '10.8', 0),
(131, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '5', 0),
(134, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '4.1', 0),
(135, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '30', 0),
(136, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '5', 0),
(137, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '5', 0),
(138, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '5', 0),
(140, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '5', 0),
(141, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '24', 0),
(143, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '24', 0),
(144, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '2.05', 0),
(145, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '7.1', 0),
(146, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '4.3', 0),
(147, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '7.1', 0),
(148, '11-03-2015', '', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation par EspÃ¨ce.', '', '30', 0),
(149, '11-03-2015', '7583568', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de TAUDON.', '', '2.5', 0),
(150, '07-01-2015', '6859742', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 6859742 en date du 07-01-2015.', '121.5', '', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
 ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
 ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
 ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
 ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
 ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
 ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
 ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
 ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
 ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
 ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
 ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
 ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
 ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
 ADD PRIMARY KEY (`idcomptamvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
 ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
 ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
 ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
 ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
 ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
 ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
 ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
 ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
 ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
 ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
 ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
 ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
 ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
 ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
 ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
 ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
 ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
 ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
 ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
 ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=215;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=249;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=249;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=151;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=134;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=220;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=152;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
