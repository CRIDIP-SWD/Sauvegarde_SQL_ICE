-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Lun 30 Novembre 2015 à 10:04
-- Version du serveur :  5.5.46-0+deb7u1
-- Version de PHP :  5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cecouthouis`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `achat_presta`
--

INSERT INTO `achat_presta` (`idachatpresta`, `date_achat`, `idprestation`, `qte`, `total_achat`, `num_mouvement`) VALUES
(4, '22-06-2015', 63, '50', '280', ''),
(5, '08-07-2015', 63, '100', '560', '');

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(43, 1, 'Achat: CINEVILLE SAINT GILLES CROIX DE VIE', '280', '', ''),
(44, 1, 'Achat: CINEVILLE SAINT GILLES CROIX DE VIE', '560', '', ''),
(45, 2, 'Vente de Billetterie: MORISSEAU JEAN YVES pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '28639894'),
(46, 2, 'Vente de Billetterie: MORISSEAU KARINE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '82482736'),
(47, 2, 'Vente de Billetterie: MERCERON CLAUDE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '79159547'),
(48, 2, 'Vente de Billetterie: DEGRANGE JEREMY pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '38622853'),
(49, 2, 'Vente de Billetterie: MORINEAU HERVE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '28448124'),
(50, 2, 'Vente de Billetterie: GARREAU JEAN NOEL pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '81908442'),
(51, 2, 'Vente de Billetterie: ANTHEAUME CYRIL pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '44118101'),
(52, 2, 'Vente de Billetterie: HUGUET MICHAEL pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '47194255'),
(53, 2, 'Vente de Billetterie: PHILIPPE CORENTIN pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '54110998'),
(54, 2, 'Vente de Billetterie: LECHELARD FRANCOIS pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '18357738'),
(55, 2, 'Ajout du produit fixe: REMBOURSEMENT PAR SALARIES LE MARAIS 2013-2014', '', '1710', '6284894603'),
(56, 2, 'Ajout du produit fixe: SUBVENTION ASC 2015', '', '22887', '9191481364'),
(57, 2, 'Vente de Billetterie: GAUCHER DOMINIQUE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '14364039'),
(58, 2, 'Vente de Billetterie: COUTHOUIS GERARD pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '14.4', '19087549'),
(59, 2, 'Vente de Billetterie: CHATAIGNER NICOLAS pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '14.4', '92483541'),
(60, 2, 'Vente de Billetterie: PEREDO DAVID pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18', '83735925');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`, `num_mouvement`) VALUES
(22, 131, '30-06-2015', 3, '18', 1, '28639894'),
(23, 132, '30-06-2015', 3, '18', 1, '82482736'),
(24, 125, '29-06-2015', 3, '18', 1, '79159547'),
(25, 95, '02-07-2015', 3, '18', 1, '38622853'),
(26, 130, '01-07-2015', 3, '18', 1, '28448124'),
(27, 101, '01-07-2015', 3, '18', 1, '81908442'),
(28, 71, '01-07-2015', 3, '18', 1, '44118101'),
(29, 115, '05-07-2015', 3, '18', 1, '47194255'),
(30, 137, '06-07-2015', 3, '18', 1, '54110998'),
(31, 118, '08-07-2015', 3, '18', 1, '18357738'),
(32, 102, '05-08-2015', 3, '18', 1, '14364039'),
(33, 93, '07-08-2015', 3, '14.4', 1, '19087549'),
(34, 88, '20-07-2015', 3, '14.4', 1, '92483541'),
(35, 135, '22-07-2015', 3, '18', 1, '83735925');

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '678.12', ''),
(81, 2, '', ''),
(82, 3, '6292.72', '3339.28'),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '', ''),
(87, 8, '', ''),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '7916.28', '10160.12'),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', ''),
(113, 34, '', ''),
(114, 35, '', '4577'),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '444.82', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '2200', ''),
(128, 49, '', ''),
(129, 50, '36.75', ''),
(130, 51, '65.75', ''),
(131, 52, '160', ''),
(132, 53, '22.3', ''),
(133, 54, '30', ''),
(134, 55, '', ''),
(135, 56, '', ''),
(136, 57, '191.14', '0'),
(137, 58, '', ''),
(138, 59, '38.52', ''),
(139, 60, '', ''),
(140, 61, '', ''),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_banque`
--

INSERT INTO `compta_banque` (`idcomptabanque`, `num_mouvement`, `date_bq`, `desc_bq`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '', '1420671600', 'PRELV ASSU SFR', 3, '', '3.00'),
(3, '', '1422572400', 'ASPRO INFORMATIQUE', 3, '', '160.00'),
(4, '', '1421190000', 'PRELV SFR', 3, '', '19.00'),
(5, '', '1423436400', 'PRELV ASSU SFR', 3, '', '3.00'),
(6, '', '1423782000', 'PRELV SFR', 3, '', '19.00'),
(7, '', '1425855600', 'PRELV ASSU SFR', 3, '', '3.00'),
(8, '', '1425942000', 'SUBVENTION', 3, '4577.00', ''),
(9, '', '1426460400', 'PRELV SFR', 3, '', '19.00'),
(10, '', '1426633200', 'RETRAIT 512 VERS CAISSE', 3, '', '100.'),
(11, '', '1426633200', 'RETRAIT BANQUE 512 VERS CAISSE', 3, '', '50.00'),
(12, '', '1426633200', 'FRAIS RESTAURANT FLUNCH', 3, '', '65.75'),
(13, '', '1427410800', 'CDT GESTION', 3, '', '2200.00'),
(14, '', '1428530400', 'ASSURANCE SFR', 3, '', '3.00'),
(15, '', '1428876000', 'SFR MOBILE', 3, '', '19.00'),
(16, '7097432', '1431295200', 'PRLV ASSU SFR', 3, '', '3.00'),
(17, '5866761', '1431381600', 'CAFES MERLING CH 0879909', 3, '', '103.03'),
(18, '2704170', '1431640800', 'PRELV SFR', 3, '', '19.00'),
(19, '6437510', '1433196000', 'PRELV FACTURE CARTE BANQUAIRE', 3, '', '38.52'),
(20, '3600486', '1433714400', 'PRELV ASSU SFR', 3, '', '3.00'),
(21, '5655836', '1434319200', 'PRELV SFR', 3, '', '19.50'),
(22, '2642890', '1434924000', 'CAFES MERLING ', 3, '', '341.79'),
(23, '3494444', '1436306400', 'PRELV ASSU SFR', 3, '', '3.00'),
(24, '8577092', '1436911200', 'PRELV SFR', 3, '', '19.00'),
(25, '3278403', '1439157600', 'PRELV SFR ASSU', 3, '', '3.00'),
(26, '1737254', '1439416800', 'PRELV SFR', 3, '', '19.00'),
(27, '4883995', '1441663200', 'PRELV ASSU SFR', 3, '', '3.00'),
(28, '6933975', '1442181600', 'PRELV SFR', 3, '', '19.00'),
(29, '5406351', '1444255200', 'PRELV ASSU SFR ', 3, '', '3.00'),
(30, '8051114', '1444773600', 'PRELV SFR', 3, '', '19.64'),
(31, '7691355', '1445986800', 'LA POSTE ENVOI RECOM CV', 3, '', '36.75'),
(32, '8827724', '1445986800', 'HYPER U ACHAT ENVELOPPES', 3, '', '22.30');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_actif`
--

INSERT INTO `compta_bilan_actif` (`idcptbilanactif`, `num_mouvement`, `idcomptaplan`, `montant`) VALUES
(1, '', 3, '1715.72'),
(2, '', 1, '528.12');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_passif`
--

INSERT INTO `compta_bilan_passif` (`idcptbilanpassif`, `num_mouvement`, `idcomptaplan`, `montant`) VALUES
(1, '', 28, '2243.84');

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_caisse`
--

INSERT INTO `compta_caisse` (`idcomptacaisse`, `num_mouvement`, `date_caisse`, `desc_caisse`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '', '1426633200', 'RETRAIT BANQUE 512 VERS CAISSE 530', 1, '100.00', ''),
(2, '', '1426633200', 'RETRAIT BANQUE 512 VERS CAISSE', 1, '50.00', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_compte`
--

INSERT INTO `compta_compte` (`idcomptacompte`, `num_mouvement`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '', 3, '1715.72', ''),
(2, '', 1, '528.12', ''),
(3, '', 28, '', '2243.84'),
(4, '', 54, '3.00', ''),
(5, '', 3, '', '3.00'),
(8, '', 52, '160.00', ''),
(9, '', 3, '', '160.00'),
(10, '', 57, '19.00', ''),
(11, '', 3, '', '19.00'),
(12, '', 54, '3.00', ''),
(13, '', 3, '', '3.00'),
(14, '', 57, '19.00', ''),
(15, '', 3, '', '19.00'),
(16, '', 54, '3.00', ''),
(17, '', 3, '', '3.00'),
(18, '', 35, '', '4577.00'),
(19, '', 3, '4577.00', ''),
(20, '', 57, '19.00', ''),
(21, '', 3, '', '19.00'),
(22, '', 3, '', '100.'),
(23, '', 1, '100.00', ''),
(24, '', 3, '', '50.00'),
(25, '', 1, '50.00', ''),
(26, '', 51, '65.75', ''),
(27, '', 3, '', '65.75'),
(28, '', 48, '2200.00', ''),
(29, '', 3, '', '2200.00'),
(30, '', 54, '3.00', ''),
(31, '', 3, '', '3.00'),
(32, '', 57, '19.00', ''),
(33, '', 3, '', '19.00'),
(34, '7560313', 54, '3.00', ''),
(35, '7097432', 3, '', '3.00'),
(36, '5531384', 40, '103.03', ''),
(37, '5866761', 3, '', '103.03'),
(38, '8629446', 57, '19.00', ''),
(39, '7665206', 59, '38.52', ''),
(40, '9875061', 54, '3.00', ''),
(41, '4602842', 57, '19.50', ''),
(42, '2148689', 40, '341.79', ''),
(43, '5000122', 54, '3.00', ''),
(44, '9803243', 57, '19.00', ''),
(45, '2704170', 3, '', '19.00'),
(46, '6437510', 3, '', '38.52'),
(47, '3600486', 3, '', '3.00'),
(48, '5655836', 3, '', '19.50'),
(49, '2642890', 3, '', '341.79'),
(50, '3494444', 3, '', '3.00'),
(51, '8577092', 3, '', '19.00'),
(52, '3536098', 54, '3.00', ''),
(53, '2625771', 57, '19.00', ''),
(54, '2437621', 54, '3.00', ''),
(55, '4046637', 57, '19.00', ''),
(56, '2778107', 54, '3.00', ''),
(57, '4247352', 57, '19.64', ''),
(58, '5939722', 50, '36.75', ''),
(59, '2885120', 53, '22.30', ''),
(60, '3278403', 3, '', '3.00'),
(61, '1737254', 3, '', '19.00'),
(62, '4883995', 3, '', '3.00'),
(63, '6933975', 3, '', '19.00'),
(64, '5406351', 3, '', '3.00'),
(65, '8051114', 3, '', '19.64'),
(66, '7691355', 3, '', '36.75'),
(67, '8827724', 3, '', '22.30');

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_mvm`
--

INSERT INTO `compta_mvm` (`idcomptamvm`, `num_mouvement`, `date_mvm`, `desc_mvm`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '', '1420671600', 'PREV ASSU SFR', 54, '3.00', ''),
(3, '', '1422572400', 'F02 ASPRO INFORMATIQUE', 52, '160.00', ''),
(4, '', '1421190000', 'PRELV SFR', 57, '19.00', ''),
(5, '', '1423436400', 'PRELV ASSU SFR', 54, '3.00', ''),
(6, '', '1423782000', 'PRELV SFR', 57, '19.00', ''),
(7, '', '1425855600', 'PREVL ASSU SFR', 54, '3.00', ''),
(8, '', '1425942000', 'SUBVENTION', 35, '', '4577.00'),
(9, '', '1426460400', 'PRELV SFR', 57, '19.00', ''),
(10, '', '1426633200', 'FRAIS RESTAURANT FLUNCH', 51, '65.75', ''),
(11, '', '1427410800', 'CDT GESTION', 48, '2200.00', ''),
(12, '', '1428530400', 'ASSURANCE SFR', 54, '3.00', ''),
(13, '', '1428876000', 'SFR MOBILE PRELV', 57, '19.00', ''),
(14, '7560313', '1431295200', 'PRLV ASSU SFR', 54, '3.00', ''),
(15, '5531384', '1431381600', 'CAFES MERLING ch 0879909', 40, '103.03', ''),
(16, '8629446', '1431640800', 'PRELV SFR', 57, '19.00', ''),
(17, '7665206', '1433196000', 'PRELV FACTURE CARTE BANQUAIRE', 59, '38.52', ''),
(18, '9875061', '1433714400', 'PRELV ASSU SFR', 54, '3.00', ''),
(19, '4602842', '1434319200', 'PRELV SFR', 57, '19.50', ''),
(20, '2148689', '1434924000', 'CAFES MERLING CH 0879910', 40, '341.79', ''),
(21, '5000122', '1436306400', 'PRELV ASSU SFR', 54, '3.00', ''),
(22, '9803243', '1436911200', 'PRELV SFR ', 57, '19.00', ''),
(23, '3536098', '1439157600', 'PRELV ASSU SFR', 54, '3.00', ''),
(24, '2625771', '1439416800', 'PRELV SFR', 57, '19.00', ''),
(25, '2437621', '1441663200', 'PRELV ASSU SFR', 54, '3.00', ''),
(26, '4046637', '1442181600', 'PRELV SFR', 57, '19.00', ''),
(27, '2778107', '1444255200', 'PRELV ASSU SFR', 54, '3.00', ''),
(28, '4247352', '1444773600', 'PRELV SFR', 57, '19.64', ''),
(29, '5939722', '1445986800', 'LA POSTE RECOM ENVOI CV', 50, '36.75', ''),
(30, '2885120', '1445986800', 'HYPER U ACHAT ENVELOPPES', 53, '22.30', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', 'CrÃ©ances Client'),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', ''),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', ''),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Postaux'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'Frais d''administration'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achat de matÃ©riel '),
(61, 6, 'Autre Charge d''exploitation 1', ''),
(62, 6, 'Autre Charge d''exploitation 2', ''),
(63, 6, 'Autre Charge d''exploitation 3', ''),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_pret`
--

CREATE TABLE `compta_pret` (
  `idcomptapret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_pret` varchar(255) NOT NULL,
  `desc_pret` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_resultat`
--

INSERT INTO `compta_resultat` (`idresultat`, `num_mouvement`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '', 54, '3.00', ''),
(3, '', 52, '160.00', ''),
(4, '', 57, '19.00', ''),
(5, '', 54, '3.00', ''),
(6, '', 57, '19.00', ''),
(7, '', 54, '3.00', ''),
(8, '', 35, '', '4577.00'),
(9, '', 57, '19.00', ''),
(10, '', 51, '65.75', ''),
(11, '', 48, '2200.00', ''),
(12, '', 54, '3.00', ''),
(13, '', 57, '19.00', ''),
(14, '7560313', 54, '3.00', ''),
(15, '5531384', 40, '103.03', ''),
(16, '8629446', 57, '19.00', ''),
(17, '7665206', 59, '38.52', ''),
(18, '9875061', 54, '3.00', ''),
(19, '4602842', 57, '19.50', ''),
(20, '2148689', 40, '341.79', ''),
(21, '5000122', 54, '3.00', ''),
(22, '9803243', 57, '19.00', ''),
(23, '3536098', 54, '3.00', ''),
(24, '2625771', 57, '19.00', ''),
(25, '2437621', 54, '3.00', ''),
(26, '4046637', 57, '19.00', ''),
(27, '2778107', 54, '3.00', ''),
(28, '4247352', 57, '19.64', ''),
(29, '5939722', 50, '36.75', ''),
(30, '2885120', 53, '22.30', '');

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'COMITE D''ENTREPRISE COUTHOUIS', '', '', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(43, '', '1434924000', 'Achat - CINEVILLE SAINT GILLES CROIX DE VIE', '280', ''),
(44, '', '1436306400', 'Achat - CINEVILLE SAINT GILLES CROIX DE VIE', '560', ''),
(45, '28639894', '1435615200', 'Vente de Billetterie: MORISSEAU JEAN YVES pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(46, '82482736', '1435615200', 'Vente de Billetterie: MORISSEAU KARINE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(47, '79159547', '1435528800', 'Vente de Billetterie: MERCERON CLAUDE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(48, '38622853', '1435788000', 'Vente de Billetterie: DEGRANGE JEREMY pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(49, '28448124', '1435701600', 'Vente de Billetterie: MORINEAU HERVE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(50, '81908442', '1435701600', 'Vente de Billetterie: GARREAU JEAN NOEL pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(51, '44118101', '1435701600', 'Vente de Billetterie: ANTHEAUME CYRIL pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(52, '47194255', '1436047200', 'Vente de Billetterie: HUGUET MICHAEL pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(53, '54110998', '1436133600', 'Vente de Billetterie: PHILIPPE CORENTIN pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(54, '18357738', '1436306400', 'Vente de Billetterie: LECHELARD FRANCOIS pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(55, '6284894603', '1434146400', 'REMBOURSEMENT PAR SALARIES LE MARAIS 2013-2014', '', '1710'),
(56, '9191481364', '1425942000', 'SUBVENTION ASC 2015', '', '22887'),
(57, '14364039', '1438725600', 'Vente de Billetterie: GAUCHER DOMINIQUE pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18'),
(58, '19087549', '1438898400', 'Vente de Billetterie: COUTHOUIS GERARD pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '14.4'),
(59, '92483541', '1437343200', 'Vente de Billetterie: CHATAIGNER NICOLAS pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '14.4'),
(60, '83735925', '1437516000', 'Vente de Billetterie: PEREDO DAVID pour la prestation CINEVILLE SAINT GILLES CROIX DE VIE', '', '18');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(44, 'CEZAM'),
(45, 'ANCV'),
(46, 'CINEMA'),
(47, 'BON D ACHAT'),
(48, 'Fournisseurs divers');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`, `commentaire`) VALUES
(20, 22, 63, '5', '18', '10', 0, ''),
(21, 23, 63, '5', '18', '10', 0, ''),
(22, 24, 63, '5', '18', '10', 0, ''),
(23, 25, 63, '5', '18', '10', 0, ''),
(24, 26, 63, '5', '18', '10', 0, ''),
(25, 27, 63, '5', '18', '10', 0, ''),
(26, 28, 63, '5', '18', '10', 0, ''),
(27, 29, 63, '5', '18', '10', 0, ''),
(28, 30, 63, '5', '18', '10', 0, ''),
(29, 31, 63, '5', '18', '10', 0, ''),
(30, 32, 63, '5', '18', '10', 0, ''),
(31, 33, 63, '4', '14.4', '8', 0, ''),
(32, 34, 63, '4', '14.4', '8', 0, ''),
(33, 35, 63, '5', '18', '10', 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.6.4', '29315-PREM');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'administrateur', '882baf28143fb700b388a87ef561a6e5', 1),
(4, 'DIRECCTE', 'fec53977d16cbfc9fa0650bbb7fe1525', 1),
(5, 'cecouthouis', '1fcbfb33e1eb455bef54d0bbab9bb46f', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '0'),
(3, 'vente_direct', '0');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`) VALUES
(63, 46, 'CINEVILLE SAINT GILLES CROIX DE VIE', '01-05-2015', '31-01-2016', '3.60', '2.00', '5.6', '5', '232', 0),
(64, 45, 'CHEQUES ANCV 2015', '15-05-2015', '31-12-2015', '0', '200', '200', '1', '63', 0),
(65, 47, 'BON ACHAT ENFANTS', '06-05-2015', '31-12-2015', '0', '20', '20', '1', '49', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `produit_fixe`
--

INSERT INTO `produit_fixe` (`idproduitfixe`, `designation`, `date_produit_fixe`, `montant_produit`, `num_mouvement`) VALUES
(2, 'REMBOURSEMENT PAR SALARIES LE MARAIS 2013-2014', '13-06-2015', '1710', '6284894603'),
(3, 'SUBVENTION ASC 2015', '10-03-2015', '22887', '9191481364');

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(6, 22, 1, '18', 'CA', 'Morisseau', '9506634', 1),
(7, 23, 1, '18', 'CA', 'Morisseau J-Yves', '9506634', 1),
(8, 24, 1, '18', 'CM', 'Debasseux M-France', '1148784', 1),
(9, 25, 1, '18', 'CM', 'Degrange JÃ©rÃ©my', '2335622', 1),
(10, 26, 1, '18', 'CM', 'Morineau HervÃ©', '1412581', 1),
(11, 27, 1, '18', 'CM', 'Garreau J-Noel', '1899078', 1),
(12, 28, 1, '18', 'CM', 'Antheaume C', '1490673', 1),
(14, 29, 1, '13', 'CIC', 'Huguet M', '4163136', 1),
(15, 29, 1, '5', 'CIC', 'Huguet M', '4251976', 1),
(16, 30, 1, '18', 'CM', 'CORENTIN PHILIPPE', '1367348', 1),
(17, 31, 1, '18', 'BNP', 'LECHELARD FRANCOIS', '3369527', 1),
(18, 32, 1, '18', 'CE', 'GAUCHER DOMINIQUE', '0000130', 1),
(19, 33, 1, '14.4', 'CM', 'Couthouis gerard', '8323938', 1),
(20, 34, 1, '14.4', 'CM', 'Chataigner nicolas', '1698683', 1),
(21, 35, 1, '18', 'CM', 'Peredo David', '0000770', 1);

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque`
--

INSERT INTO `remise_banque` (`idremisebanque`, `date_remise`, `type_remise`, `num_remise`, `montant_remise`, `valid`) VALUES
(1, '07-08-2015', 1, '2083496', '108', 1),
(2, '7-08-2015', 1, '2083497', '136.8', 1);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque_chq`
--

INSERT INTO `remise_banque_chq` (`idremisebanquechq`, `idremisebanque`, `idreglementventepresta`) VALUES
(1, 1, 14),
(2, 1, 15),
(3, 1, 16),
(4, 1, 17),
(5, 1, 0),
(6, 1, 12),
(7, 1, 11),
(8, 1, 10),
(9, 2, 9),
(10, 2, 8),
(11, 2, 6),
(12, 2, 7),
(13, 2, 18),
(14, 2, 19),
(15, 2, 20),
(16, 2, 21);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(70, '', 1, 'AGOSTINHO', 'ALEXANDRE', 'LES GRANDES GUINIARDIERES', '', '85160', 'SAINT JEAN DE MONTS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(71, '', 1, 'ANTHEAUME', 'CYRIL', '42 CHEMIN DE ROCHEVILLE', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(72, '', 1, 'AUBRON', 'DIDIER', 'CHEMIN DU PAS MARTIN', '', '85270', 'NOTRE DAME DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(73, '', 1, 'AUBRON', 'HERVE', '8 RUE DU SAULNAY', '', '85270', 'NOTRE DAME DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(74, '', 1, 'AUBRON ', 'JEROME', '94 CHEMIN DES GUIGNARDIERES', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(75, '', 1, 'AVERTY ', 'ERIC', '205 ROUTE DU SOULLANDEAU', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(76, '', 1, 'BARRETEAU ', 'CHARLES', '5 RUE DU BOIS', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(77, '', 1, 'BONJEAN', 'JEAN MICHEL', 'IMPASSE DE LA GAUBETIERE', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(78, '', 1, 'BONNEAU', 'JACQUES', '33 RUE GEORGES CLEMENCEAU', '', '85220', 'SAINT REVEREND', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(79, '', 2, 'BONNEAU', 'MARIE CLAIRE', '24 CHEMIN DES OLIVETTES', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(80, '', 1, 'BOUCHER', 'EMMANUEL', '39 LE TEMPLE', '', '44270', 'SAINT MEME LE TENU', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(81, '', 1, 'BOURCEREAU', 'FRANCK', '4 RUE DE L EPINAY', '', '85220', 'LA CHAISE GIRAUD', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(82, '', 1, 'BOUTOLLEAU', 'PATRICE', '21 RESIDENCE CORALLI', '', '85230', 'BEAUVOIR SUR MER', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(83, '', 2, 'BRIAND ', 'FRANCOISE', '7 LOTISSEMENT DE L ECLUSE', '', '85230', 'BOUIN', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(84, '', 1, 'BRIAND', 'JEAN PAUL', '6 ALLEE DE LA VERRIE', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(85, '', 3, 'BROSSAUD', 'KARINE', '5 RUE DE LA GROSSE PIERRE', '', '44650', 'TOUVOIS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(86, '', 2, 'BROSSET', 'SYLVIE', '10 CHEMIN DE LA ROCHE AUX CHATS', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(87, '', 1, 'BURGAUD', 'JEAN MARCEL', '8 CHEMIN DU FRESNE', '', '85300', 'LE PERRIER', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(88, '', 1, 'CHATAIGNER', 'NICOLAS', '620 RUE DE LA BARRE', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(89, '', 1, 'CHAUVIN', 'ALAIN', '14 CHEMIN DE BRECHARD', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(90, '', 2, 'CHERBITE', 'ROSA MARIA', 'L ERMITAGE', '', '85230', 'SAINT GERVAIS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(91, '', 1, 'CHERIF', 'PASCAL', '4 RUE DE LA RENAUDIERE', '', '85690', 'NOTRE DAME DE MONTS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(92, '', 1, 'COUTHOUIS', 'FREDDY', '587 RUE DE LA REPUBLIQUE', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(93, '', 1, 'COUTHOUIS', 'GERARD', 'LES RELIQUES', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(94, '', 2, 'COUTHOUIS', 'VERONIQUE', '13 RUE DES CHARDONNERETS', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(95, '', 1, 'DEGRANGE', 'JEREMY', '14 RUE DU CORMIER', '', '85220', 'APREMONT', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(96, '', 1, 'DUPE', 'DIMITRI', '62 RUE DES MIMOSAS', '', '85670', 'SAINT CHRISTOPHE DU LIGNERON', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(97, '', 1, 'DUPONT', 'DOMINIQUE', '231 ROUTE DES BORGNERES', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(98, '', 1, 'FRANCHETTE', 'NICOLAS', 'LA CHAUVIERE', '', '85300', 'FROIDFOND', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(99, '', 1, 'FRESLON', 'DAVID', '11D RUE RENE GOSCINY', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(100, '', 3, 'FRIOUX', 'JESSICA', 'LA DAVIERE', '', '85190', 'MACHE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(101, '', 1, 'GARREAU', 'JEAN NOEL', '235 IMPASSE DES MERISIERS', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(102, '', 1, 'GAUCHER', 'DOMINIQUE', '22 RUE DU FERLIN', '', '85670', 'FALLERON', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(103, '', 2, 'GAUDIN', 'CATHERINE', '4 RUE MASSENET', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(104, '', 1, 'GAUVRIT', 'CLAUDE', '173 ALLEE DES GATTES', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(105, '', 1, 'GONZALES', 'KEVIN', '40 LA CROIX DE LA  BARBIERE', '', '85190', 'AIZENAY', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(106, '', 3, 'GRONDIN', 'AUDREY', 'LE PETIT BOIS', '', '85300', 'SALLERTAINE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(107, '', 2, 'GUIHAL', 'PATRICIA', 'LA BOIVELLINE LE PORT', '', '44270', 'MACHECOUL', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(108, '', 1, 'GUILBAUD', 'GILLES', 'L ESPINASSIERE', '', '85710', 'LA GARNACHE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(109, '', 1, 'GUILLOT', 'CHRISTOPHE', '4 IMPASSE DES 10 SILLONS', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(110, '', 3, 'GUITTONNEA', 'LESLIE', '4 IMPASSE DES PEUPLIERS', '', '85300', 'FROIDFOND', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(111, '', 1, 'GUYON', 'BERNARD', '69 ROUTE DES SABLES', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(112, '', 1, 'HELIN', 'PATRICK', '17 IMPASSE DES PEUPLIERS', '', '85300', 'FROIDFOND', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(113, '', 1, 'HERVE', 'GINO', '264 ROUTE DE SAINT PAUL', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(114, '', 1, 'HUBERT', 'DAMIEN', '1 IMPASSE DES CHENES', '', '85670', 'SAINT JEAN DE MONTS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(115, '', 1, 'HUGUET', 'MICHAEL', '16 RUE THOMAS COUTURE', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(116, '', 2, 'KLIMMEK', 'NATHALIA', '1 ALLEE REINE MARGOT', '', '85300', 'SALLERTAINE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(117, '', 3, 'LANDAIS', 'GIPSY', '164 ROUTE DU PERRIER', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(118, '', 1, 'LECHELARD', 'FRANCOIS', '205 CHEMIN FIEF DES GACHERIES', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(119, '', 1, 'LESEVE ', 'JEANNICK', '300 ROUTE DE CHALLANS', '', '85300', 'LE PERRIER', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(120, '', 1, 'LOGEAIS', 'JEAN NOEL', 'CHEMIN DE LA NOUE', '', '85270', 'NOTRE DAME DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(121, '', 1, 'LOGEAIS', 'JOHAN', '46 BOULEVARD JEAN YOLE', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(122, '', 3, 'MAINDRON', 'DOMINIQUE', '27 RUE GARROS', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(123, '', 1, 'MARECHAL', 'LUC', '18 RUE DES VIOLETTES', '', '85270', 'NOTRE DAME DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(124, '', 1, 'MASSE', 'YVES', '23 RUE DE L OCEAN', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(125, '', 1, 'MERCERON', 'CLAUDE', '34 CHEMIN DE BEL AIR', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(126, '', 1, 'MERIEAU', 'DAVID', '47 CHEMIN DE LA TISONNIERE', '', '85270', 'SAINT HILAIRE DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(127, '', 1, 'MERLET', 'JULIEN', '111B ROUTE DU MAILLEAU', '', '85300', 'LE PERRIER', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(128, '', 3, 'MERRET', 'GWENAELLE', 'LE CHARDONNERET', '', '85710', 'BOIS DE CENE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(129, '', 2, 'MIHALACHE', 'MARIANA', '29 RUE DE LA PROUTIERE', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(130, '', 1, 'MORINEAU', 'HERVE', '2TER RUE DE LA RIVE', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(131, '', 1, 'MORISSEAU', 'JEAN YVES', '80 CHEMIN DE TOUT VENT', '', '85270', 'NOTRE DAME DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(132, '', 3, 'MORISSEAU', 'KARINE', '159 RUE DE LA REPUBLIQUE', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(133, '', 1, 'MOSSION', 'ERIC', 'LE JARRY', '', '85300', 'SALLERTAINE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(134, '', 1, 'NEAU', 'CEDRIC', '34 RES DU CHALLANDEAU', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(135, '', 1, 'PEREDO', 'DAVID', '6 RUE CALMETTE', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(136, '', 1, 'PETITGAS', 'JEROME', '4 HAMEAU DE LA RIVIERE', '', '85220', 'SAINT MAIXENT SUR VIE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(137, '', 1, 'PHILIPPE', 'CORENTIN', '12 RUE DE LA CARTREE', '', '85220', 'SAINT MAIXENT SUR VIE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(138, '', 1, 'PHILIPPON', 'JEAN  PASCAL', '1 ALLEE DES PLATANES', '', '85220', 'SAINT REVERENT', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(139, '', 1, 'PILLET', 'THIERRY', '7 RUE DU BOIS MENARD', '', '85300 ', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(140, '', 3, 'RABALLAND', 'NADINE', '48 CHEMIN DE HEURTEVENT', '', '85300', 'SOULLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(141, '', 1, 'RABILLER', 'FELICIEN', '36 CHEMIN DE LA CONGE', '', '85270', 'SAINT HILAYRE DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(142, '', 1, 'RAFFIN', 'THIERRY', '965 CHEMIN DES LANDES', '', '85270', 'NOTRE DAME DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(143, '', 1, 'REMY', 'FRANCOIS', '1B ALLEE DE LA PROUTIERE', '', '85230', 'SAINT URBAIN', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(144, '', 3, 'RESTINI', 'LAETITIA', '620 RUE DE LA BARRE', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(145, '', 1, 'RETAILLEAU', 'NICOLAS', '6 RUE DES HALBRANS', '', '85160', 'SAINT JEAN DE MONTS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(146, '', 3, 'RONDEAU', 'KATIA', '27 RUE DES 18 OTAGES', '', '85220', 'APREMONT', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(147, '', 1, 'ROUSSEAU', 'JACKY', 'LES CAILLONNELLES', '', '85270', 'NOTRE DAME DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(148, '', 1, 'SEILLER', 'REGIS', '4 IMPASSE DU CHAMP FROID', '', '85160', 'SAINT JEAN DE MONTS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(149, '', 1, 'SMIDA', 'MONCEF', '4 ALLEE MICHEL AMELINEAU', '', '85710', 'LA GARNACHE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(150, '', 2, 'THIBAUD', 'MARYLENE', '141 ROUTE DE CHOLET', '', '85300', 'CHALLANS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(151, '', 1, 'VRIGNAUD', 'JEAN NOEL', '11 ALLEE MICHEL AMELINEAU', '', '85710', 'LA GARNACHE', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(152, '', 3, 'BESSONET', 'AURELIE', '60 RUE DES BOUTONS D OR', '', '85220', 'COMMEQUIERS', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999'),
(153, '', 1, 'JUGUET', 'MICHAEL', '10 RUE DE LA CAILLAUDIERE', '', '85270', 'SAINT HILAIRE DE RIEZ', '', '', '', '', '', '', '1', '', '', '', '', 1, '9999999999999999');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(9, '1435615200', '9506634', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Morisseau.', '', '18', 0),
(10, '1435615200', '9506634', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Morisseau J-Yves.', '', '18', 0),
(11, '1435528800', '1148784', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Debasseux M-France.', '', '18', 0),
(12, '1435788000', '2335622', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Degrange JÃ©rÃ©my.', '', '18', 0),
(13, '1435701600', '1412581', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Morineau HervÃ©.', '', '18', 0),
(14, '1435701600', '1899078', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Garreau J-Noel.', '', '18', 0),
(15, '1435701600', '1490673', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Antheaume C.', '', '18', 0),
(17, '1436047200', '4163136', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Huguet M.', '', '13', 0),
(18, '1436047200', '4251976', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Huguet M.', '', '5', 0),
(19, '1436133600', '1367348', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CORENTIN PHILIPPE.', '', '18', 0),
(20, '1436306400', '3369527', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LECHELARD FRANCOIS.', '', '18', 0),
(21, '1438725600', '0000130', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GAUCHER DOMINIQUE.', '', '18', 0),
(22, '1438898400', '8323938', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Couthouis gerard.', '', '14.4', 0),
(23, '1437343200', '1698683', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Chataigner nicolas.', '', '14.4', 0),
(24, '1437516000', '0000770', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de Peredo David.', '', '18', 0),
(25, '1438898400', '2083496', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 2083496 en date du 07-08-2015.', '108', '', 1),
(27, '1438898400', '2083497', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 2083497 en date du 07-08-2015.', '136.8', '', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  ADD PRIMARY KEY (`idcomptapret`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  MODIFY `idcomptapret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
