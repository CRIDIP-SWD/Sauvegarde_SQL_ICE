-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Lun 23 Novembre 2015 à 10:03
-- Version du serveur :  5.5.46-0+deb7u1
-- Version de PHP :  5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cemlp`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `achat_presta`
--

INSERT INTO `achat_presta` (`idachatpresta`, `date_achat`, `idprestation`, `qte`, `total_achat`, `num_mouvement`) VALUES
(7, '24-03-2015', 84, '2863', '28630', ''),
(9, '10-03-2015', 85, '176', '528', ''),
(12, '2015', 0, '', '0', ''),
(13, '04-01-2015', 87, '1', '120', ''),
(15, '04-01-2015', 86, '50', '7000', ''),
(16, '20-04-2015', 88, '13830', '1383', ''),
(17, '20-05-2015', 88, '4920', '492', ''),
(18, '15-01-2015', 88, '4840', '484', ''),
(19, '01-01-2015', 89, '7', '49', ''),
(23, '01-01-2015 ', 0, '', '0', ''),
(25, '24-02-2015', 93, '50', '395', ''),
(26, '01-01-2015', 93, '144', '1137.6', ''),
(27, '08-06-2015', 92, '4', '35.6', ''),
(28, '01-01-2015', 91, '9', '57.6', ''),
(29, '08-06-2015', 90, '3', '28.5', ''),
(30, '20-03-2015', 93, '200', '1580', ''),
(31, '21-07-2015', 94, '20', '280', ''),
(32, '21-09-2015', 86, '3', '420', '5618958501'),
(33, '29-09-2015', 96, '150', '1215', '2081150296'),
(34, '20-10-2015', 88, '14250', '1425', '5883693043'),
(35, '20-10-2015', 88, '6870', '687', '6342124119');

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ayant_droit`
--

INSERT INTO `ayant_droit` (`idayantdroit`, `idsalarie`, `nom_ayant_droit`, `prenom_ayant_droit`, `date_naissance_ayant_droit`, `solde_ayant_droit`) VALUES
(82, 109, 'ADAM', 'LILIAN', '29/11/1999', '0'),
(83, 116, 'BACHELOT', 'ANTOINE', '12/07/2006', '0'),
(84, 116, 'BACHELOT', 'FABIEN', '12/06/2004', '0'),
(85, 83, 'BADOUR', 'ALYMA', '29/03/2005', '0'),
(86, 126, 'BOUDAUD', 'AXEL', '28/04/2012', '0'),
(87, 126, 'BOUDAUD', 'ELISA', '23/09/2007', '0'),
(88, 126, 'BOUDAUD', 'TYPHAINE', '05/09/2003', '0'),
(89, 128, 'BOUFAQOUS', 'ADAM', '17/04/2002', '0'),
(90, 128, 'BOUFAQOUS', 'MARIA', '27/12/2004', '0'),
(91, 123, 'BOUVIER', 'CLEMENCE', '06/05/2002', '0'),
(92, 123, 'BOUVIER', 'MANON', '30/09/1999', '0'),
(93, 77, 'BRUNET  (AUDIC)', 'CORENTIN', '10/09/2001', '0'),
(94, 72, 'CARTRON', 'JULIETTE', '24/06/2004', '0'),
(95, 72, 'CARTRON', 'THEOPHILE', '12/09/2000', '0'),
(96, 159, 'CERIBAS', 'JREM', '15/02/2005', '0'),
(97, 159, 'CERIBAS', 'NEBI', '06/02/2002', '0'),
(98, 159, 'CERIBAS', 'YELIZ', '18/05/1999', '0'),
(99, 154, 'CHAPLAIN THOMAS', 'ANTHONYN', '18/06/2014', '0'),
(100, 92, 'CHOLLET', 'LOUNA CHLOE', '30/06/1999', '0'),
(101, 92, 'CHOLLET', 'TOM BASILE', '16/01/2008', '0'),
(102, 130, 'CLEMENT', 'ELEA', '17/05/2010', '0'),
(103, 130, 'CLEMENT', 'NOLAN', '13/07/2008', '0'),
(104, 130, 'CLOUET', 'NATHAN', '12/11/2013', '0'),
(105, 106, 'COSNIER', 'JADE MARILYNE', '23/12/2008', '0'),
(106, 106, 'COSNIER', 'LORENE', '09/07/2003', '0'),
(107, 111, 'COUINET', 'ANNA', '17/09/2013', '0'),
(108, 111, 'COUINET', 'LALIE', '25/07/2006', '0'),
(109, 111, 'COUINET', 'MANON', '27/02/2010', '0'),
(110, 90, 'CROS MIGOT', 'FLORENT VALENTIN', '18/06/2001', '0'),
(111, 90, 'CROS MIGOT', 'LAURINE OCEANE', '15/10/2004', '0'),
(112, 90, 'CROS MIGOT', 'VALENTINE ', '02/06/2011', '0'),
(113, 145, 'DAUCHY', 'ANTHONY', '01/07/2000', '0'),
(114, 100, 'DELPHIN', 'AXELLE', '06/03/2002', '0'),
(115, 100, 'DELPHIN', 'LILI', '16/12/2004', '0'),
(116, 100, 'DELPHIN', 'NYLA', '25/08/2007', '0'),
(117, 145, 'DINGREVILLE RICHOMME', 'LEONIE', '16/06/2005', '0'),
(118, 113, 'DOUILLY', 'CLEMENT', '13/04/2001', '0'),
(119, 117, 'FAUCHEUX', 'OPHELIE', '15/04/2000', '0'),
(120, 120, 'FOURNIER', 'LAURA', '16/03/2001', '0'),
(121, 120, 'FOURNIER', 'LILY ROSE', '08/01/2001', '0'),
(122, 120, 'FOURNIER', 'OCEANE', '03/09/2005', '0'),
(123, 120, 'FOURNIER ', 'SAMUEL', '21/01/2006', '0'),
(124, 139, 'GALLET', 'ETHAN', '05/12/2003', '0'),
(125, 131, 'GARNIER', 'MATHIS', '02/01/2004', '0'),
(126, 131, 'GARNIER', 'NATHALENA', '03/06/2001', '0'),
(127, 131, 'GARNIER', 'NOA', '04/02/2008', '0'),
(128, 114, 'GAULTIER', 'MAEVA', '22/01/2002', '0'),
(129, 76, 'GUERIN', 'DANNY', '04/12/2006', '0'),
(130, 76, 'GUERIN', 'KENNY', '17/09/2002', '0'),
(131, 101, 'GUERTIN', 'LEON', '07/03/2004', '0'),
(132, 102, 'HANQUART', 'Alice', '30/12/2009', '0'),
(133, 102, 'HANQUART', 'Sacha', '08/03/2007', '0'),
(134, 97, 'HAULBERT', 'AMANDINE', '23/05/2000', '0'),
(135, 97, 'HAULBERT', 'MATEO', '30/09/2002', '0'),
(136, 142, 'IDDER', 'Ilyes', '27/12/2008', '0'),
(137, 142, 'IDDER', 'LINA', '31/08/2011', '0'),
(138, 86, 'JANIN', 'ANNA', '25/03/2009', '0'),
(139, 86, 'JANIN', 'LILOU', '10/02/2006', '0'),
(140, 86, 'JANIN', 'NOA', '25/03/2009', '0'),
(141, 86, 'JANIN', 'TOM', '19/02/2004', '0'),
(142, 146, 'KERBOURCH', 'ERWANN', '11/05/2001', '0'),
(143, 146, 'KERBOURCH', 'NOLWENN', '17/05/2003', '0'),
(144, 133, 'KHALIL  (LEHOREAU)', 'KAHINA', '15/02/2006', '0'),
(145, 75, 'LAURIOU', 'CAMILLE', '17/12/2000', '0'),
(146, 133, 'LEHOREAU', 'LINDSAY', '22/07/1999', '0'),
(147, 140, 'LUBIN', 'CYNTHIA', '09/03/1999', '0'),
(148, 140, 'LUBIN', 'ELLIOT TAO', '19/06/2014', '0'),
(149, 140, 'LUBIN', 'NAYA', '16/03/2011', '0'),
(150, 103, 'MESLET', 'LISA', '21/06/1999', '0'),
(151, 150, 'MILON', 'LEANE', '27/11/2007', '0'),
(152, 151, 'NIANGORAN', 'AIME AMANI', '27/11/2009', '0'),
(153, 151, 'NIANGORAN', 'ANGELINE', '13/08/2014', '0'),
(154, 151, 'NIANGORAN', 'ELIE', '04/11/2011', '0'),
(155, 151, 'NIANGORAN', 'ISMAEL PIERRE ANIS', '22/07/2002', '0'),
(156, 151, 'NIANGORAN', 'NATHAN LUC ANGE', '25/11/2012', '0'),
(157, 153, 'PASCAL', 'Malya', '10/06/2004', '0'),
(158, 153, 'PASCAL', 'Melissa', '06/08/2001', '0'),
(159, 124, 'PECOT', 'Juliette', '31/08/2006', '0'),
(160, 124, 'PECOT', 'Lilou', '31/08/2006', '0'),
(161, 115, 'RICHOMME', 'Leonie', '16/06/2005', '0'),
(162, 143, 'ROUAULT', 'CLEA', '29/04/2009', '0'),
(163, 143, 'ROUAULT', 'EMY', '30/06/2012', '0'),
(164, 104, 'VALLEE', 'LIAM', '31/12/2010', '0'),
(165, 104, 'VALLEE', 'MARIE', '01/08/2005', '0'),
(166, 105, 'VERITE GUERRIAU', 'MATTEO', '29/05/2002', '0'),
(167, 109, 'ADAM STEPHANE ', 'ALLOCATION LOISIR', '', '50'),
(168, 99, 'ARMOURDOM LAURENT', 'ALLOCATION LOISIR', '', '50'),
(169, 106, 'COSNIER CHRISTOPHE ', 'ALLOCATION LOISIRS', '', '0'),
(170, 107, 'FOUGERI ANNE', 'ALLOCATION LOISIRS', '', '0'),
(171, 108, 'MARTIN PATRICIA', 'ALLOCATION LOISIRS', '', '0'),
(172, 110, 'BRANCHEREAU HERVE', 'ALLOCATION LOISIRS', '', '50'),
(173, 111, 'COUINET SOLEN', 'ALLOCATION LOISIRS', '', '50'),
(174, 112, 'DAVID ARMEL', 'ALLOCATION LOISIRS', '', '50'),
(175, 113, 'DOUILLY OLIVIER', 'ALLOCATION LOISIRS', '', '0'),
(176, 114, 'GAULTIER SEBASTIEN', 'ALLOCATION LOISIRS', '', '0'),
(177, 115, 'RICHOMME HERVE', 'ALLOCATION LOISIRS', '', '50'),
(178, 116, 'BACHELOT CHRISTELLE', 'ALLOCATION LOISIRS', '', '0'),
(179, 117, 'FAUCHEUX FREDDY', 'ALLOCATION LOISIRS', '', '0'),
(180, 118, 'FRESNEAU VERONIQUE', 'ALLOCATION LOISIRS', '', '0'),
(181, 119, 'GUERIN HUGUETTE', 'ALLOCATION LOISIRS', '', '0'),
(182, 120, 'FOUNIER MARIO', 'ALLOCATION LOISIRS', '', '8'),
(183, 121, 'AUDIC GAELLE', 'ALLOCATION LOISIRS', '', '0'),
(184, 122, 'GREFFIER ARNAUD', 'ALLOCATION LOISIRS', '', '0'),
(185, 123, 'BOUVIER FREDERIC', 'ALLOCATION LOISIRS', '', '50'),
(186, 124, 'PECOT THIERRY', 'ALLOCATION LOISIRS', '', '0'),
(187, 125, 'CARUSO SYLVANA', 'ALLOCATION LOISIRS', '', '50'),
(188, 126, 'BOUDEAU VIRGINIE', 'ALLOCATION LOISIRS', '', '0'),
(189, 127, 'DASYLVA JEAN PIERRE', 'ALLOCATION LOISIRS', '', '6'),
(190, 128, 'BOUFAQOUS ABDELJALIL', 'ALLOCATION LOISIRS', '', '50'),
(191, 129, 'CLEMENT CHRISTOPHE', 'ALLOCATION LOISIRS', '', '0'),
(192, 130, 'CLEMENT OLIVIER', 'ALLOCATION LOISIRS', '', '0'),
(193, 131, 'GARNIER DAVID', 'ALLOCATION LOISIRS', '', '0'),
(194, 132, 'ONILLON PATRICIA', 'ALLOCATION LOISIRS', '', '16.5'),
(195, 133, 'LEHOREAU WADA VIRGINIE', 'ALLOCATION LOISIRS', '', '50'),
(196, 134, 'BLEJAN CHRISTIAN', 'ALLOCATION LOISIRS', '', '50'),
(197, 135, 'RAGOT VIRGINIE', 'ALLOCATION LOISIRS', '', '50'),
(198, 136, 'BERGERET STEPHANE', 'ALLOCATION LOISIRS', '', '0'),
(199, 137, 'POUPAULT ISABELLE', 'ALLOCATION LOISIRS', '', '0'),
(200, 138, 'CHAPEAU OLIVIER', 'ALLOCATION LOISIRS', '', '50'),
(201, 139, 'GALLET STEPHANE', 'ALLOCATION LOISIRS', '', '0'),
(202, 140, 'LUBIN MICHEL', 'ALLOCATION LOISIRS', '', '50'),
(203, 141, 'GUYADER YOHANN', 'ALLOCATION LOISIRS', '', '50'),
(204, 142, 'IDDER MEHDI', 'ALLOCATION LOISIRS', '', '50'),
(205, 143, 'ROUAULT ANTHONY', 'ALLOCATION LOISIRS', '', '0'),
(206, 88, 'PILLARD ISABELLE', 'ALLOCATION LOISIRS', '', '50'),
(207, 89, 'KOCH NATHALIE', 'ALLOCATION LOISIRS', '', '0'),
(208, 90, 'CROS SEVERINE', 'ALLOCATION LOISIRS', '', '0'),
(209, 91, 'ROUFFIAC CHRISTOPHE', 'ALLOCATION LOISIRS', '', '0'),
(210, 92, 'SUREAU LYDIE', 'ALLOCATION LOISIRS', '', '0'),
(211, 93, 'PIOU BENOIT', 'ALLOCATION LOISIRS', '', '50'),
(212, 94, 'JOUBERT KARINE', 'ALLOCATION LOISIRS', '', '50'),
(213, 95, 'DESMARS VERONIQUE', 'ALLOCATION LOISIRS', '', '0'),
(214, 96, 'DAVY ANTOINE', 'ALLOCATION LOISIRS', '', '50'),
(215, 97, 'HAULBERT VINCENT', 'ALLOCATION LOISIRS', '', '0'),
(216, 98, 'BOIVIN VERONIQUE', 'ALLOCATION LOISIRS', '', '50'),
(217, 100, 'DELPHIN SEBASTIEN', 'ALLOCATION LOISIRS', '', '50'),
(218, 101, 'GUERTIN NOEL ', 'ALLOCATION LOISIRS', '', '50'),
(219, 102, 'HANQUART SANDRA', 'ALLOCATION LOISIRS', '', '50'),
(220, 103, 'MESLET THIERRY', 'ALLOCATION LOISIRS', '', '50'),
(221, 104, 'VALLEE KARINE', 'ALLOCATION LOISIRS', '', '0'),
(222, 105, 'GUERRIAU MALIKA ', 'ALLOCATION LOISIRS', '', '0'),
(223, 72, 'CARTRON OLIVIER', 'ALLOCATION LOISIRS', '', '50'),
(224, 73, 'DROUIN DIDIER', 'ALLOCATION LOISIRS', '', '0'),
(225, 74, 'MARCHAIS LAURENT', 'ALLOCATION LOISIRS', '', '50'),
(226, 75, 'LAURIOU MICKAEL', 'ALLOCATION LOISIRS', '', '50'),
(227, 76, 'GUERIN JOHNNY', 'ALLOCATION LOISIRS', '', '0'),
(228, 77, 'BRUNET DOMINIQUE', 'ALLOCATION LOISIRS', '', '50'),
(229, 78, 'POIRRIER THIERRY', 'ALLOCATION LOISIRS', '', '0'),
(230, 79, 'NEGRI', 'BRIGITTE', '', '50'),
(231, 80, 'BAULU CATHERINE', 'ALLOCATION LOISIRS', '', '0'),
(232, 81, 'MORTIER FREDERIC', 'ALLOCATION LOISIRS', '', '0'),
(233, 82, 'ROUSSEL PASCAL', 'ALLOCATION LOISIRS', '', '0'),
(234, 83, 'BADOUR STEPHANE', 'ALLOCATION LOISIRS', '', '0'),
(235, 84, 'DAGUENE FRANCOISE', 'ALLOCATION LOISIRS', '', '18'),
(236, 85, 'MACKOWSKI CORINE ', 'ALLOCATION LOISIRS', '', '0'),
(237, 86, 'JANIN SEBASTIEN', 'ALLOCATION LOISIRS', '', '50'),
(238, 87, 'CHALOPIN BERNADETTE', 'ALLOCATION LOISIRS', '', '0.2'),
(239, 144, 'MARSAULT FRANCOISE', 'ALLOCATION LOISIRS', '', '0'),
(240, 145, 'DINGREVILLE ALINE', 'ALLOCATION LOISIRS', '', '50'),
(241, 147, 'MOTTEAU THIERRY ', 'ALLOCATION LOISIRS', '', '50'),
(242, 148, 'CHAFFIN MIREILLE', 'ALLOCATION LOISIRS', '', '50'),
(243, 149, 'CHESNEL BRIGITTE ', 'ALLOCATION LOISIRS', '', '50'),
(244, 150, 'CLOUET EMILIE', 'ALLOCATION LOISIRS', '', '50'),
(245, 151, 'NIANGORAN OURA SEVERIN', 'ALLOCATION LOISIRS', '', '50'),
(246, 152, 'DAGUER STEPHANE', 'ALLOCATION LOISIRS', '', '50'),
(247, 153, 'PASCAL LIONEL', 'ALLOCATION LOISIRS', '', '50'),
(248, 154, 'CHAPLAIN ANGELINA', 'ALLOCATION LOISIRS', '', '50'),
(249, 155, 'CRIBIER EMILIE', 'ALLOCATION LOISIRS', '', '50'),
(250, 156, 'SALAUN ANDRE', 'ALLOCATION LOISIRS', '', '50'),
(251, 157, 'BARRIERES AMANDINE', 'ALLOCATION LOISIRS', '', '0'),
(252, 158, 'PERGER ASTRID ', 'ALLOCATION LOISIRS', '', '50'),
(253, 159, 'CERIBAS FILIZ', 'ALLOCATION LOISIRS', '', '0'),
(254, 146, 'kerbourch', 'allocation loisirs', '', '0'),
(255, 155, 'cribier', 'leane', '09-11-2015', ''),
(256, 106, 'COSNIER', 'PAIGE', '14-01-2005', '0'),
(257, 150, 'CLOUET', 'NATHAN', '12-11-2013', '');

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(138, 2, 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation CHARLIE HEBDO', '', '36', '77888520'),
(140, 2, 'Vente de Billetterie: SALAUN ANDRE pour la prestation CHARLIE HEBDO', '', '3', '35203667'),
(143, 2, 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation CHARLIE HEBDO', '', '3', '34093613'),
(146, 2, 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation CHARLIE HEBDO', '', '3', '90007063'),
(148, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation CHARLIE HEBDO', '', '15', '94566683'),
(150, 2, 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation CHARLIE HEBDO', '', '3', '7070390'),
(151, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation CHARLIE HEBDO', '', '12', '20918838'),
(154, 2, 'Vente de Billetterie: GUERIN JOHNNY pour la prestation CHARLIE HEBDO', '', '15', '57787493'),
(155, 2, 'Vente de Billetterie: HAULBERT VINCENT pour la prestation CHARLIE HEBDO', '', '3', '43396733'),
(159, 2, 'Vente de Billetterie: FOURNIER MARIO pour la prestation CHARLIE HEBDO', '', '6', '64231022'),
(160, 2, 'Vente de Billetterie: BOUFAQOUS ABDELJALIL pour la prestation CHARLIE HEBDO', '', '3', '58433076'),
(161, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation CHARLIE HEBDO', '', '15', '38867830'),
(162, 2, 'Vente de Billetterie: COSNIER CHRISTOPHE pour la prestation CHARLIE HEBDO', '', '3', '93588287'),
(163, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation CHARLIE HEBDO', '', '6', '5716332'),
(164, 2, 'Vente de Billetterie: DAVY ANTOINE pour la prestation CHARLIE HEBDO', '', '3', '40247192'),
(165, 2, 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation CHARLIE HEBDO', '', '6', '78190047'),
(166, 2, 'Vente de Billetterie: SUREAU LYDIE pour la prestation CHARLIE HEBDO', '', '6', '22957854'),
(167, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation CHARLIE HEBDO', '', '6', '6950154'),
(168, 2, 'Vente de Billetterie: DAGUER St?phane pour la prestation CHARLIE HEBDO', '', '6', '99680257'),
(169, 2, 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation CHARLIE HEBDO', '', '6', '22796043'),
(170, 2, 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation CHARLIE HEBDO', '', '6', '92148009'),
(171, 2, 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation CHARLIE HEBDO', '', '3', '1403553'),
(172, 2, 'Vente de Billetterie: DASYLVA JEAN-PIERRE pour la prestation CHARLIE HEBDO', '', '6', '97490311'),
(173, 2, 'Vente de Billetterie: GUERIN HUGUETTE pour la prestation CHARLIE HEBDO', '', '6', '3641379'),
(174, 2, 'Vente de Billetterie: LUBIN MICHEL pour la prestation CHARLIE HEBDO', '', '3', '54188181'),
(175, 2, 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation CHARLIE HEBDO', '', '6', '35864404'),
(176, 2, 'Vente de Billetterie: MORTIER FREDERIC pour la prestation CHARLIE HEBDO', '', '6', '59615731'),
(177, 2, 'Vente de Billetterie: DAGUENE FRANCOISE pour la prestation CHARLIE HEBDO', '', '6', '53405864'),
(178, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation CHARLIE HEBDO', '', '3', '67706393'),
(179, 2, 'Vente de Billetterie: MARTIN PATRICIA pour la prestation CHARLIE HEBDO', '', '3', '14437311'),
(180, 2, 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation CHARLIE HEBDO', '', '6', '35284155'),
(181, 2, 'Vente de Billetterie: COUINET SOLEN pour la prestation CHARLIE HEBDO', '', '6', '29814792'),
(182, 2, 'Vente de Billetterie: GALLET STEPHANE pour la prestation CHARLIE HEBDO', '', '6', '49456544'),
(183, 2, 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation CHARLIE HEBDO', '', '6', '73238056'),
(184, 2, 'Vente de Billetterie: BRUNET DOMINIQUE pour la prestation CHARLIE HEBDO', '', '6', '75019028'),
(185, 2, 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation CHARLIE HEBDO', '', '6', '24745278'),
(186, 2, 'Vente de Billetterie: PILLARD ISABELLE pour la prestation CHARLIE HEBDO', '', '6', '64707700'),
(187, 2, 'Vente de Billetterie: FOUGERI ANNIE pour la prestation CHARLIE HEBDO', '', '6', '75633744'),
(188, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation CHARLIE HEBDO', '', '6', '16124366'),
(189, 2, 'Vente de Billetterie: BAULU CATHERINE pour la prestation CHARLIE HEBDO', '', '6', '51215389'),
(190, 2, 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation CHARLIE HEBDO', '', '6', '91945333'),
(191, 2, 'Vente de Billetterie: HANQUART SANDRA pour la prestation CHARLIE HEBDO', '', '3', '85210311'),
(192, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation CHARLIE HEBDO', '', '3', '48633428'),
(193, 2, 'Vente de Billetterie: AUDIC GAELLE pour la prestation CHARLIE HEBDO', '', '6', '63016188'),
(194, 2, 'Vente de Billetterie: NEGRI BRIGITTE pour la prestation CHARLIE HEBDO', '', '6', '31132058'),
(195, 2, 'Vente de Billetterie: JOUBERT KARINE pour la prestation CHARLIE HEBDO', '', '6', '6777589'),
(196, 2, 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation CHARLIE HEBDO', '', '6', '13090392'),
(197, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation CHARLIE HEBDO', '', '3', '61360544'),
(198, 2, 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation CHARLIE HEBDO', '', '3', '70083078'),
(199, 2, 'Vente de Billetterie: BOUDAUD VIRGINIE pour la prestation CHARLIE HEBDO', '', '6', '32806862'),
(200, 2, 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation CHARLIE HEBDO', '', '6', '49065071'),
(201, 2, 'Vente de Billetterie: MOTTEAU Thierry pour la prestation CHARLIE HEBDO', '', '6', '75220921'),
(202, 2, 'Vente de Billetterie: CARTRON OLIVIER pour la prestation CHARLIE HEBDO', '', '6', '55183117'),
(203, 2, 'Vente de Billetterie: KERBOURCH FLORENT pour la prestation CHARLIE HEBDO', '', '6', '40627513'),
(204, 2, 'Vente de Billetterie: VALLEE KARINE pour la prestation CHARLIE HEBDO', '', '3', '83343185'),
(205, 2, 'Vente de Billetterie: ADAM STEPHANE pour la prestation CHARLIE HEBDO', '', '6', '97735416'),
(206, 2, 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation CHARLIE HEBDO', '', '114', '94135703'),
(208, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation ANCV', '', '0', '8479379'),
(209, 2, 'Vente de Billetterie: AUDIC GAELLE pour la prestation ANCV', '', '0', '49882624'),
(210, 2, 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation ANCV', '', '0', '93697071'),
(211, 2, 'Vente de Billetterie: BADOUR STEPHANE pour la prestation ANCV', '', '0', '97247732'),
(212, 2, 'Vente de Billetterie: BAULU CATHERINE pour la prestation ANCV', '', '0', '30993821'),
(213, 2, 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation ANCV', '', '0', '24977592'),
(214, 2, 'Vente de Billetterie: BERGERET STEPHANE pour la prestation ANCV', '', '0', '20189309'),
(215, 2, 'Vente de Billetterie: BLEJAN CHRISTIAN pour la prestation ANCV', '', '0', '59163041'),
(216, 2, 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation ANCV', '', '0', '75688351'),
(217, 2, 'Vente de Billetterie: BOUDAUD VIRGINIE pour la prestation ANCV', '', '0', '3338363'),
(218, 2, 'Vente de Billetterie: BOUFAQOUS ABDELJALIL pour la prestation ANCV', '', '0', '53448053'),
(219, 2, 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation ANCV', '', '0', '43027788'),
(220, 2, 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation ANCV', '', '0', '79192664'),
(221, 2, 'Vente de Billetterie: BRUNET DOMINIQUE pour la prestation ANCV', '', '0', '159702'),
(222, 2, 'Vente de Billetterie: CERIBAS FILIZ pour la prestation ANCV', '', '0', '57819881'),
(223, 2, 'Vente de Billetterie: CARTRON OLIVIER pour la prestation ANCV', '', '0', '91009880'),
(224, 2, 'Vente de Billetterie: CARUSO SYLVANA pour la prestation ANCV', '', '0', '62011560'),
(225, 2, 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation ANCV', '', '0', '79127592'),
(226, 2, 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation ANCV', '', '0', '5003578'),
(227, 2, 'Vente de Billetterie: CHAPEAU OLIVIER pour la prestation ANCV', '', '0', '80616188'),
(228, 2, 'Vente de Billetterie: CLEMENT CHRISTOPHE pour la prestation ANCV', '', '0', '14778122'),
(229, 2, 'Vente de Billetterie: CHAFFIN Mireille pour la prestation ANCV', '', '0', '81034255'),
(230, 2, 'Vente de Billetterie: CHESNEL Brigitte pour la prestation ANCV', '', '0', '24663597'),
(231, 2, 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation ANCV', '', '0', '42823596'),
(232, 2, 'Vente de Billetterie: COSNIER CHRISTOPHE pour la prestation ANCV', '', '0', '11305967'),
(233, 2, 'Vente de Billetterie: COUINET SOLEN pour la prestation ANCV', '', '0', '19334189'),
(234, 2, 'Vente de Billetterie: CRIBIER EMILIE pour la prestation ANCV', '', '0', '17076540'),
(235, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation ANCV', '', '0', '45701470'),
(236, 2, 'Vente de Billetterie: DASYLVA JEAN-PIERRE pour la prestation ANCV', '', '0', '51048573'),
(237, 2, 'Vente de Billetterie: DAGUENE FRANCOISE pour la prestation ANCV', '', '0', '66264316'),
(238, 2, 'Vente de Billetterie: DAVID ARMEL pour la prestation ANCV', '', '0', '91888070'),
(239, 2, 'Vente de Billetterie: DAVY ANTOINE pour la prestation ANCV', '', '0', '87350808'),
(240, 2, 'Vente de Billetterie: DAGUER St?phane pour la prestation ANCV', '', '0', '57507241'),
(241, 2, 'Vente de Billetterie: DELPHIN SEBASTIEN pour la prestation ANCV', '', '0', '78800495'),
(242, 2, 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation ANCV', '', '0', '68038015'),
(243, 2, 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation ANCV', '', '0', '94066706'),
(244, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation ANCV', '', '0', '32904556'),
(245, 2, 'Vente de Billetterie: DROUIN DIDIER pour la prestation ANCV', '', '0', '27537106'),
(246, 2, 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation ANCV', '', '0', '42322294'),
(247, 2, 'Vente de Billetterie: FOUGERI ANNIE pour la prestation ANCV', '', '0', '46932091'),
(248, 2, 'Vente de Billetterie: FOURNIER MARIO pour la prestation ANCV', '', '0', '19654332'),
(249, 2, 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation ANCV', '', '0', '69719070'),
(250, 2, 'Vente de Billetterie: GALLET STEPHANE pour la prestation ANCV', '', '0', '45453025'),
(251, 2, 'Vente de Billetterie: GARNIER DAVID pour la prestation ANCV', '', '0', '36445874'),
(252, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation ANCV', '', '0', '10841302'),
(253, 2, 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation ANCV', '', '0', '13993517'),
(254, 2, 'Vente de Billetterie: GUERIN HUGUETTE pour la prestation ANCV', '', '0', '2138763'),
(255, 2, 'Vente de Billetterie: GUERIN JOHNNY pour la prestation ANCV', '', '0', '87282689'),
(256, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation ANCV', '', '0', '58203426'),
(257, 2, 'Vente de Billetterie: GUERTIN NOEL pour la prestation ANCV', '', '0', '76864041'),
(258, 2, 'Vente de Billetterie: GUYADER YOHANN pour la prestation ANCV', '', '0', '36439926'),
(259, 2, 'Vente de Billetterie: HANQUART SANDRA pour la prestation ANCV', '', '0', '34538179'),
(260, 2, 'Vente de Billetterie: HAULBERT VINCENT pour la prestation ANCV', '', '0', '35962979'),
(261, 2, 'Vente de Billetterie: KOCH NATHALIE pour la prestation ANCV', '', '0', '8927745'),
(262, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation ANCV', '', '0', '76885985'),
(263, 2, 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation ANCV', '', '0', '18280906'),
(264, 2, 'Vente de Billetterie: KERBOURCH FLORENT pour la prestation ANCV', '', '0', '3562170'),
(265, 2, 'Vente de Billetterie: JOUBERT KARINE pour la prestation ANCV', '', '0', '39033078'),
(266, 2, 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation ANCV', '', '0', '3622185'),
(267, 2, 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation ANCV', '', '0', '33020021'),
(268, 2, 'Vente de Billetterie: LUBIN MICHEL pour la prestation ANCV', '', '0', '51689716'),
(269, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation ANCV', '', '0', '47254636'),
(270, 2, 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation ANCV', '', '0', '56687340'),
(271, 2, 'Vente de Billetterie: MARTIN PATRICIA pour la prestation ANCV', '', '0', '43863993'),
(272, 2, 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation ANCV', '', '0', '39135385'),
(273, 2, 'Vente de Billetterie: MOTTEAU Thierry pour la prestation ANCV', '', '0', '73992271'),
(274, 2, 'Vente de Billetterie: MESLET THIERRY pour la prestation ANCV', '', '0', '10736636'),
(275, 2, 'Vente de Billetterie: MORTIER FREDERIC pour la prestation ANCV', '', '0', '14983785'),
(276, 2, 'Vente de Billetterie: NIANGORAN Oura Severin pour la prestation ANCV', '', '0', '55596080'),
(277, 2, 'Vente de Billetterie: NEGRI BRIGITTE pour la prestation ANCV', '', '0', '10163521'),
(278, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation ANCV', '', '0', '80797451'),
(279, 2, 'Vente de Billetterie: PASCAL LIONEL pour la prestation ANCV', '', '0', '75840471'),
(280, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation ANCV', '', '0', '26519796'),
(281, 2, 'Vente de Billetterie: PERGER ASTRID pour la prestation ANCV', '', '0', '57742559'),
(282, 2, 'Vente de Billetterie: PILLARD ISABELLE pour la prestation ANCV', '', '0', '84260926'),
(283, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation ANCV', '', '0', '60444437'),
(284, 2, 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation ANCV', '', '0', '36379633'),
(285, 2, 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation ANCV', '', '0', '20690905'),
(286, 2, 'Vente de Billetterie: RICHOMME HERVE pour la prestation ANCV', '', '0', '86013461'),
(287, 2, 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation ANCV', '', '0', '23654142'),
(288, 2, 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation ANCV', '', '0', '15607057'),
(289, 2, 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation ANCV', '', '0', '36813535'),
(290, 2, 'Vente de Billetterie: VALLEE KARINE pour la prestation ANCV', '', '0', '7378713'),
(291, 2, 'Vente de Billetterie: SALAUN ANDRE pour la prestation ANCV', '', '0', '8641962'),
(292, 2, 'Vente de Billetterie: SUREAU LYDIE pour la prestation ANCV', '', '0', '46964535'),
(328, 2, 'Ajout du produit fixe: SOLDE SUBVENTION 2015 (budget 2014)', '', '1.10', '2866321090'),
(332, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation Mobil home 120', '', '120', '22704853'),
(333, 2, 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '321', '99466543'),
(334, 2, 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation vente parfums', '', '163', '38968883'),
(335, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280', '54329905'),
(336, 2, 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation Mobil Home 140', '', '140', '70503049'),
(337, 2, 'Vente de Billetterie: CLEMENT CHRISTOPHE pour la prestation Mobil Home 140', '', '280', '83272284'),
(338, 2, 'Vente de Billetterie: COSNIER CHRISTOPHE pour la prestation Mobil Home 140', '', '140', '24717805'),
(339, 2, 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation Mobil Home 140', '', '140', '83446436'),
(340, 2, 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation Mobil Home 140', '', '280', '46414316'),
(341, 2, 'Vente de Billetterie: CLOUET Emilie pour la prestation Mobil Home 140', '', '140', '76223985'),
(342, 2, 'Vente de Billetterie: JOUBERT KARINE pour la prestation Mobil Home 140', '', '140', '95013897'),
(343, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation Mobil Home 140', '', '140', '92941828'),
(344, 2, 'Vente de Billetterie: COUINET SOLEN pour la prestation Mobil Home 140', '', '140', '91005854'),
(345, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation Mobil Home 140', '', '280', '56221445'),
(346, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation Mobil Home 140', '', '140', '36087532'),
(347, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140', '84147055'),
(348, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '280', '47246505'),
(349, 2, 'Vente de Billetterie: GUERIN JOHNNY pour la prestation Mobil Home 140', '', '140', '20883318'),
(350, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280', '26518598'),
(351, 2, 'Vente de Billetterie: GALLET STEPHANE pour la prestation Mobil Home 140', '', '140', '4169744'),
(352, 2, 'Vente de Billetterie: GALLET STEPHANE pour la prestation Mobil Home 140', '', '140', '83401100'),
(353, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140', '14936841'),
(354, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140', '32434769'),
(355, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140', '27126414'),
(356, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation Mobil Home 140', '', '140', '27964394'),
(357, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140', '84614899'),
(358, 2, 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation Mobil Home 140', '', '140', '13890845'),
(359, 2, 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation Mobil Home 140', '', '280', '56467682'),
(360, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280', '96086758'),
(361, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140', '36219443'),
(362, 2, 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation Mobil Home 140', '', '280', '33350447'),
(363, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280', '87401578'),
(364, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation vente parfums', '', '187', '43837257'),
(365, 2, 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation vente parfums', '', '39', '95691609'),
(366, 2, 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation vente parfums', '', '59', '28668247'),
(367, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '47', '65780771'),
(368, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '88', '15108811'),
(369, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '70', '37001892'),
(370, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '47', '40260497'),
(371, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '48', '93699737'),
(372, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '50', '11350408'),
(373, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '63', '90254930'),
(374, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '133', '40800676'),
(375, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '69', '56948978'),
(376, 2, 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '145', '2695252'),
(377, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation vente parfums', '', '117', '42158759'),
(378, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140', '19519094'),
(379, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140', '89781454'),
(380, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140', '66872676'),
(381, 2, 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation Mobil Home 140', '', '280', '43279116'),
(382, 2, 'Vente de Billetterie: AUDIC GAELLE pour la prestation Mobil Home 140', '', '140', '2498617'),
(383, 2, 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '221', '59737801'),
(384, 2, 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '76', '75261277'),
(385, 2, 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation vente parfums', '', '61', '9397852'),
(386, 2, 'Vente de Billetterie: GUYADER YOHANN pour la prestation vente parfums', '', '93', '74124673'),
(387, 2, 'Vente de Billetterie: FOUGERI ANNIE pour la prestation vente parfums', '', '46', '61693184'),
(388, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation vente parfums', '', '64', '1896277'),
(389, 2, 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation vente parfums', '', '96', '54861570'),
(390, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '56', '37293044'),
(394, 1, 'Remboursement de la prestation: ALLOCATION VACANCE pour MACKOWSKI CORINE', '150', '', '889982583001'),
(395, 1, 'Remboursement de la prestation: ALLOCATION VACANCE pour MARTIN PATRICIA', '150', '', '612524654716'),
(396, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour BERGERET STEPHANE ALLOCATION LOISIRS', '50', '', '6984846322'),
(397, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour CHALOPIN BERNADETTE ALLOCATION LOISIRS', '49.80', '', '5033455626'),
(398, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour MARTIN PATRICIA ALLOCATION LOISIRS', '50', '', '8280871194'),
(405, 2, 'Vente de Billetterie: BADOUR STEPHANE pour la prestation CHARLIE HEBDO', '', '6', '000001'),
(406, 2, 'Vente de Billetterie: CLOUET EMILIE pour la prestation CHARLIE HEBDO', '', '6', '000002'),
(407, 2, 'Vente de Billetterie: CHAPEAU OLIVIER pour la prestation CHARLIE HEBDO', '', '6', '000003'),
(408, 2, 'Vente de Billetterie: GARNIER DAVID pour la prestation CHARLIE HEBDO', '', '6', '000004'),
(409, 2, 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation CHARLIE HEBDO', '', '6', '000005'),
(410, 2, 'Vente de Billetterie: CLEMENT CHRISTOPHE pour la prestation CHARLIE HEBDO', '', '6', '000006'),
(411, 2, 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation CHARLIE HEBDO', '', '6', '000007'),
(412, 2, 'Vente de Billetterie: CARUSO SYLVANA pour la prestation CHARLIE HEBDO', '', '6', '000008'),
(413, 2, 'Vente de Billetterie: BERGER ASTRID pour la prestation CHARLIE HEBDO', '', '6', '000009'),
(414, 2, 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation CHARLIE HEBDO', '', '6', '000010'),
(415, 1, 'Remboursement de la prestation: alllocation vacance  pour CHALOPIN BERNADETTE', '150', '', '438415773213'),
(416, 1, 'Remboursement de la prestation: alllocation vacance  pour ROUFFIAC CHRISTOPHE', '150', '', '16831546091'),
(417, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour FOUNIER MARIO ALLOCATION LOISIRS', '42', '', '8886342398'),
(418, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour GALLET STEPHANE ALLOCATION LOISIRS', '50', '', '586332703'),
(419, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour KOCH NATHALIE ALLOCATION LOISIRS', '50', '', '4950911482'),
(420, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '51282607'),
(421, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation cin&eacute;ma 2015', '', '24', '79129670'),
(422, 2, 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation cin&eacute;ma 2015', '', '24', '39684921'),
(423, 2, 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation cin&eacute;ma 2015', '', '24', '64360491'),
(424, 2, 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation cin&eacute;ma 2015', '', '24', '74780411'),
(425, 2, 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30', '57593944'),
(426, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation cin&eacute;ma 2015', '', '24', '21886527'),
(427, 2, 'Vente de Billetterie: BAULU CATHERINE pour la prestation cin&eacute;ma 2015', '', '24', '62962139'),
(428, 2, 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30', '17527469'),
(429, 2, 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation cin&eacute;ma 2015', '', '24', '91024312'),
(430, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation cin&eacute;ma 2015', '', '24', '21228151'),
(431, 2, 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation cin&eacute;ma 2015', '', '12', '85617058'),
(432, 2, 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation cin&eacute;ma 2015', '', '12', '34440248'),
(433, 2, 'Vente de Billetterie: RICHOMME HERVE pour la prestation cin&eacute;ma 2015', '', '24', '36062617'),
(439, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation cin&eacute;ma 2015', '', '18', '65905228'),
(440, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24', '98735446'),
(441, 2, 'Vente de Billetterie: GARNIER DAVID pour la prestation cin&eacute;ma 2015', '', '30', '3565326'),
(442, 2, 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation cin&eacute;ma 2015', '', '48', '66058938'),
(443, 2, 'Vente de Billetterie: MESLET THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '23811416'),
(444, 2, 'Vente de Billetterie: CLOUET Emilie pour la prestation cin&eacute;ma 2015', '', '18', '5090115'),
(445, 2, 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation cin&eacute;ma 2015', '', '42', '93018735'),
(446, 2, 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation cin&eacute;ma 2015', '', '24', '48142725'),
(447, 2, 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation cin&eacute;ma 2015', '', '12', '5191271'),
(448, 2, 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24', '50685941'),
(449, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation cin&eacute;ma 2015', '', '24', '84155268'),
(450, 2, 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation cin&eacute;ma 2015', '', '24', '16726167'),
(451, 2, 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation cin&eacute;ma 2015', '', '24', '1923109'),
(452, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '48961877'),
(453, 2, 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation cin&eacute;ma 2015', '', '24', '73405539'),
(454, 2, 'Vente de Billetterie: MOTTEAU Thierry pour la prestation cin&eacute;ma 2015', '', '24', '93579470'),
(455, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation cin&eacute;ma 2015', '', '24', '84045960'),
(456, 2, 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation cin&eacute;ma 2015', '', '24', '33707857'),
(457, 2, 'Vente de Billetterie: MORTIER FREDERIC pour la prestation cin&eacute;ma 2015', '', '24', '70486482'),
(458, 2, 'Vente de Billetterie: AUDIC GAELLE pour la prestation cin&eacute;ma 2015', '', '18', '22566591'),
(459, 2, 'Vente de Billetterie: VALLEE KARINE pour la prestation cin&eacute;ma 2015', '', '12', '76658017'),
(460, 2, 'Vente de Billetterie: GUERTIN NOEL pour la prestation cin&eacute;ma 2015', '', '24', '47461529'),
(461, 2, 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation cin&eacute;ma 2015', '', '12', '30433642'),
(462, 2, 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation cin&eacute;ma 2015', '', '24', '76414721'),
(463, 2, 'Vente de Billetterie: GUYADER YOHANN pour la prestation cin&eacute;ma 2015', '', '36', '6929080'),
(465, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24', '60316808'),
(466, 2, 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation cin&eacute;ma 2015', '', '24', '92400437'),
(467, 2, 'Vente de Billetterie: CERIBAS FILIZ pour la prestation cin&eacute;ma 2015', '', '30', '44711276'),
(468, 2, 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation cin&eacute;ma 2015', '', '24', '82099288'),
(469, 2, 'Vente de Billetterie: BERGERET STEPHANE pour la prestation cin&eacute;ma 2015', '', '12', '60431516'),
(470, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation cin&eacute;ma 2015', '', '24', '8060080'),
(471, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation cin&eacute;ma 2015', '', '24', '77167360'),
(472, 2, 'Vente de Billetterie: AUDIC GAELLE pour la prestation cin&eacute;ma 2015', '', '24', '53954817'),
(473, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation cin&eacute;ma 2015', '', '24', '97945720'),
(474, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation cin&eacute;ma 2015', '', '24', '58817256'),
(475, 2, 'Vente de Billetterie: FOUGERI ANNIE pour la prestation cin&eacute;ma 2015', '', '24', '37333506'),
(476, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation cin&eacute;ma 2015', '', '24', '90803018'),
(477, 2, 'Vente de Billetterie: HAULBERT VINCENT pour la prestation cin&eacute;ma 2015', '', '24', '54273009'),
(478, 2, 'Vente de Billetterie: CRIBIER EMILIE pour la prestation cin&eacute;ma 2015', '', '12', '76573345'),
(479, 2, 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation cin&eacute;ma 2015', '', '24', '31128959'),
(480, 2, 'Vente de Billetterie: BERGERET STEPHANE pour la prestation cin&eacute;ma 2015', '', '24', '78953575'),
(481, 2, 'Vente de Billetterie: GUYADER YOHANN pour la prestation cin&eacute;ma 2015', '', '36', '3670390'),
(482, 2, 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation cin&eacute;ma 2015', '', '12', '38331041'),
(483, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '94391932'),
(484, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation cin&eacute;ma 2015', '', '24', '57322921'),
(485, 2, 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation cin&eacute;ma 2015', '', '12', '18386139'),
(486, 2, 'Vente de Billetterie: GUYADER YOHANN pour la prestation cin&eacute;ma 2015', '', '24', '27966879'),
(487, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation cin&eacute;ma 2015', '', '24', '44786894'),
(488, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '76915919'),
(489, 2, 'Vente de Billetterie: BERGERET STEPHANE pour la prestation cin&eacute;ma 2015', '', '24', '48400238'),
(490, 2, 'Vente de Billetterie: DAVID ARMEL pour la prestation cin&eacute;ma 2015', '', '24', '66373148'),
(491, 2, 'Vente de Billetterie: HAULBERT VINCENT pour la prestation cin&eacute;ma 2015', '', '24', '88263688'),
(492, 2, 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30', '72131237'),
(493, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation cin&eacute;ma 2015', '', '12', '91446764'),
(494, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour MACKOWSKI CORINE  ALLOCATION LOISIRS', '50', '', '8836364937'),
(495, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour BACHELOT CHRISTELLE ALLOCATION LOISIRS', '50', '', '3693116345'),
(496, 1, 'Remboursement de la prestation: alloc vacance pour DOUILLY OLIVIER', '150', '', '421351411846'),
(497, 1, 'Remboursement de la prestation: allocation loisirs pour DOUILLY OLIVIER ALLOCATION LOISIRS', '50', '', '4050343218'),
(498, 1, 'Remboursement de la prestation: alllocation vacance  pour GUERIN JOHNNY', '150', '', '903106779791'),
(499, 1, 'Remboursement de la prestation: alllocation vacance  pour LAURIOU MICKAEL', '150', '', '400730542839'),
(500, 1, 'Remboursement de la prestation: alllocation vacance  pour ROUAULT ANTHONY', '150', '', '685626462567'),
(501, 1, 'Remboursement de la prestation: alllocation vacance  pour CARUSO SYLVANA', '150', '', '999402718618'),
(502, 1, 'Remboursement de la prestation: alllocation vacance  pour DASYLVA JEAN-PIERRE', '150', '', '323534653057'),
(503, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour ROUAULT ANTHONY ALLOCATION LOISIRS', '50', '', '4209308610'),
(504, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour GUERRIAU MALIKA  ALLOCATION LOISIRS', '50', '', '2507952159'),
(506, 1, 'Remboursement de la prestation: allocation vacance pour SUREAU LYDIE', '150', '', '644799424335'),
(507, 1, 'Remboursement de la prestation: allocation vacance pour IDDER MEHDI', '150', '', '99525161088'),
(508, 1, 'Remboursement de la prestation: allocation vacance pour NEGRI BRIGITTE', '150', '', '565350872930'),
(509, 1, 'Remboursement de la prestation: allocation vacance pour KERBOURCH FLORENT', '150', '', '420539968181'),
(510, 1, 'Remboursement de la prestation: allocation vacance pour AUDIC GAELLE', '150', '', '312499290798'),
(511, 1, 'Remboursement de la prestation: allocation vacance pour MESLET THIERRY', '150', '', '513738993090'),
(512, 1, 'Remboursement de la prestation: allocation vacance pour BAULU CATHERINE', '150', '', '625417531468'),
(513, 1, 'Remboursement de la prestation: allocation vacance pour CRIBIER EMILIE', '150', '', '87278132327'),
(514, 1, 'Remboursement de la prestation: allocation vacance pour ROUSSEL PASCALE', '150', '', '679863286204'),
(515, 1, 'Remboursement de la prestation: allocation vacance pour MARCHAIS LAURENT', '150', '', '888595257420'),
(516, 1, 'Remboursement de la prestation: allocation vacance pour COUINET SOLEN', '150', '', '471647528932'),
(517, 1, 'Remboursement de la prestation: allocation vacance pour LUBIN MICHEL', '150', '', '77512939461'),
(518, 1, 'Remboursement de la prestation: allocation vacance pour BACHELOT CHRISTELLE', '150', '', '9936326650'),
(519, 1, 'Remboursement de la prestation: allocation vacance pour DESMARS VERONIQUE', '150', '', '584448751993'),
(520, 1, 'Remboursement de la prestation: allocation vacance pour HAULBERT VINCENT', '150', '', '163545305841'),
(521, 1, 'Remboursement de la prestation: allocation vacance pour CROS SEVERINE', '150', '', '40894807782'),
(522, 1, 'Remboursement de la prestation: allocation vacance pour JOUBERT KARINE', '150', '', '239772253670'),
(523, 1, 'Remboursement de la prestation: allocation vacance pour GALLET STEPHANE', '150', '', '683775858953'),
(524, 2, 'Ajout du produit fixe: don de la direction concours de boules achat lots ', '', '250', '7510536895'),
(525, 1, 'Remboursement de la prestation: allocation vacance pour DELPHIN SEBASTIEN', '150', '', '847594105638'),
(526, 1, 'Remboursement de la prestation: allocation vacance pour JANIN SEBASTIEN', '150', '', '5751915742'),
(527, 1, 'Remboursement de la prestation: allocation vacance pour GUERRIAU MALIKA', '150', '', '454039545264'),
(528, 1, 'Remboursement de la prestation: allocation vacance pour BOUVIER FREDERIC', '150', '', '536473579705'),
(529, 1, 'Remboursement de la prestation: allocation vacance pour KOCH NATHALIE', '150', '', '259158585221'),
(530, 1, 'Remboursement de la prestation: allocation vacance pour BOUDAUD VIRGINIE', '150', '', '40721359198'),
(531, 1, 'Remboursement de la prestation: allocation vacance pour BRANCHEREAU HERVE', '150', '', '780559918377'),
(532, 1, 'Remboursement de la prestation: allocation vacance pour MOTTEAU Thierry', '150', '', '319234014489'),
(533, 1, 'Remboursement de la prestation: allocation vacance pour FAUCHEUX FREDDY', '150', '', '571244949475'),
(534, 1, 'Remboursement de la prestation: allocation vacance pour ARMOURDOM LAURENT', '150', '', '481509226374'),
(535, 1, 'Remboursement de la prestation: allocation vacance pour CLEMENT OLIVIER', '150', '', '238586999011'),
(536, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour BOUDEAU VIRGINIE ALLOCATION LOISIRS', '50', '', '705041090'),
(537, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour GARNIER DAVID ALLOCATION LOISIRS', '50', '', '2741586822'),
(538, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour FRESNEAU VERONIQUE ALLOCATION LOISIRS', '50', '', '1428685626'),
(539, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour FAUCHEUX FREDDY ALLOCATION LOISIRS', '50', '', '4699004418'),
(540, 1, 'Remboursement de la prestation: allocation vacance pour BERGERET STEPHANE', '150', '', '225719915238'),
(541, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour SUREAU LYDIE ALLOCATION LOISIRS', '50', '', '6836895565'),
(542, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour AUDIC GAELLE ALLOCATION LOISIRS', '50', '', '9294497575'),
(544, 2, 'Vente de Billetterie: DAGUER St?phane pour la prestation Concours de boules - MIXEUR', '', '0', '97629744'),
(546, 2, 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation cin&eacute;ma 2015', '', '12', '16113822'),
(547, 2, 'Vente de Billetterie: GARNIER DAVID pour la prestation cin&eacute;ma 2015', '', '24', '67085243'),
(548, 2, 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation cin&eacute;ma 2015', '', '24', '56393529'),
(549, 2, 'Vente de Billetterie: MESLET THIERRY pour la prestation cin&eacute;ma 2015', '', '36', '29506070'),
(550, 2, 'Vente de Billetterie: GUERTIN NOEL pour la prestation cin&eacute;ma 2015', '', '12', '26358660'),
(551, 2, 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation cin&eacute;ma 2015', '', '12', '72812836'),
(552, 2, 'Vente de Billetterie: FOURNIER MARIO pour la prestation cin&eacute;ma 2015', '', '6', '68349084'),
(553, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation cin&eacute;ma 2015', '', '24', '83203092'),
(554, 2, 'Vente de Billetterie: MOTTEAU Thierry pour la prestation cin&eacute;ma 2015', '', '24', '25001941'),
(555, 2, 'Vente de Billetterie: NEGRI BRIGITTE pour la prestation cin&eacute;ma 2015', '', '24', '58273290'),
(556, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation cin&eacute;ma 2015', '', '24', '36444209'),
(557, 2, 'Vente de Billetterie: JOUBERT KARINE pour la prestation cin&eacute;ma 2015', '', '12', '72318495'),
(560, 2, 'Vente de Billetterie: BAULU CATHERINE pour la prestation cin&eacute;ma 2015', '', '24', '54490717'),
(561, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation cin&eacute;ma 2015', '', '24', '83458012'),
(562, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24', '71251061'),
(563, 2, 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation cin&eacute;ma 2015', '', '12', '23151142'),
(564, 2, 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30', '74741047'),
(565, 2, 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation cin&eacute;ma 2015', '', '24', '26302169'),
(566, 2, 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation cin&eacute;ma 2015', '', '24', '79217448'),
(567, 2, 'Vente de Billetterie: SUREAU LYDIE pour la prestation cin&eacute;ma 2015', '', '12', '63853104'),
(568, 2, 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation cin&eacute;ma 2015', '', '24', '51888054'),
(569, 2, 'Vente de Billetterie: KERBOURCH FLORENT pour la prestation cin&eacute;ma 2015', '', '24', '17867403'),
(570, 2, 'Vente de Billetterie: DAGUER St?phane pour la prestation cin&eacute;ma 2015', '', '24', '25989343'),
(571, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '35934991'),
(572, 2, 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation cin&eacute;ma 2015', '', '24', '8929502'),
(573, 2, 'Vente de Billetterie: BRUNET DOMINIQUE pour la prestation cin&eacute;ma 2015', '', '24', '96161978'),
(574, 2, 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation cin&eacute;ma 2015', '', '6', '34372446'),
(575, 2, 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation cin&eacute;ma 2015', '', '24', '26409362'),
(576, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '28143541'),
(577, 2, 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation cin&eacute;ma 2015', '', '24', '58163654'),
(578, 2, 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation cin&eacute;ma 2015', '', '12', '66895493'),
(579, 2, 'Vente de Billetterie: GUERIN JOHNNY pour la prestation cin&eacute;ma 2015', '', '24', '43007147'),
(580, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation cin&eacute;ma 2015', '', '24', '81027120'),
(581, 1, 'Remboursement de la prestation: allocation vacance pour PILLARD ISABELLE', '150', '', '914618178736'),
(582, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour HAULBERT VINCENT ALLOCATION LOISIRS', '50', '', '6501609310'),
(583, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour GAULTIER SEBASTIEN ALLOCATION LOISIRS', '50', '', '8153159632'),
(584, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour GREFFIER ARNAUD ALLOCATION LOISIRS', '50', '', '9475106336'),
(585, 2, 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation Concours de boules - FRITEUSE', '', '0', '66897190'),
(586, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation Concours de boules - CAFETIERE', '', '0', '29624657'),
(587, 2, 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation Concours de boules - POELE', '', '0', '82272904'),
(588, 2, 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation Concours de boules - KARCHER', '', '0', '46233333'),
(589, 2, 'Vente de Billetterie: DROUIN DIDIER pour la prestation Concours de boules - Perceuse', '', '0', '25862678'),
(590, 2, 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation Concours de boules - Couteaux', '', '0', '87103301'),
(591, 2, 'Vente de Billetterie: DROUIN DIDIER pour la prestation Concours de boules - USTENSILE  CUISINE', '', '0', '28940623'),
(592, 2, 'Vente de Billetterie: CHAPEAU OLIVIER pour la prestation Concours de boules - Tuyau Karcher', '', '0', '31605110'),
(593, 2, 'Vente de Billetterie: DAGUER St?phane pour la prestation Concours de boules - TOASTER', '', '0', '67736922'),
(594, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation Concours de boules - BOUILLOIRE', '', '0', '30759278'),
(595, 2, 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation Concours de boules - Balance cuisine', '', '0', '55487353'),
(596, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation Concours de boules - Haut parleur', '', '0', '8483222'),
(597, 2, 'Vente de Billetterie: NIANGORAN Oura Severin pour la prestation Concours de boules - Haut parleur', '', '0', '98975262'),
(598, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation Concours de boules - Blender', '', '0', '47551203'),
(599, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation Concours de boules - Mixeur', '', '0', '29507336'),
(600, 2, 'Vente de Billetterie: NIANGORAN Oura Severin pour la prestation Concours de boules - Tuyau eau', '', '0', '84859217'),
(601, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation Concours de boules - Tournevis', '', '0', '64756491'),
(602, 2, 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation Concours de boules - Bon achat Leroy', '', '0', '65282587'),
(603, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Concours de boules - Fondue', '', '0', '85594598'),
(604, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Concours de boules - Croque monsieur', '', '0', '74254500'),
(605, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation Concours de boules - Ricard', '', '0', '96677038'),
(606, 2, 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation Concours de boules - 2 WE MOBIL HOME', '', '0', '27220252'),
(607, 2, 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation Concours de boules - Bon achat DECATHLON', '', '0', '89336531'),
(608, 2, 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation Concours de boules - Bon achat DECATHLON', '', '0', '45659438'),
(610, 2, 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation Concours de boules - Bon d achat super U', '', '0', '51214610'),
(611, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation Concours de boules - 2 bons achat super U de 40', '', '0', '56748610'),
(612, 2, 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation Concours de boules - Bon achat  super U', '', '0', '70507603'),
(613, 2, 'Vente de Billetterie: DROUIN DIDIER pour la prestation Concours de boules - Bon achat super U', '', '0', '40495308'),
(614, 2, 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation Concours de boules - 2 bons achat super U', '', '0', '36296409'),
(615, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation Concours de boules - Bon achat super U', '', '0', '24701546'),
(616, 2, 'Vente de Billetterie: LEVRON Jean Louis pour la prestation Concours de boules - KARCHER', '', '0', '25630849'),
(617, 2, 'Vente de Billetterie: VERMELUN Christian pour la prestation Concours de boules', '', '0', '37359359'),
(618, 2, 'Vente de Billetterie: LEVRON Jean Louis pour la prestation Concours de boules - WHYSKY', '', '0', '91024544'),
(619, 2, 'Vente de Billetterie: VERMELUN Christian pour la prestation Concours de boules - RICARD', '', '0', '20578087'),
(620, 1, 'Ajout de la charge Fixe: HIPPIE FANNY REPAS CONCOURS DE BOULES', '400', '', '4969886597'),
(621, 1, 'Remboursement de la prestation: allocation vacance pour BRUNET DOMINIQUE', '150', '', '451765113510'),
(622, 1, 'Remboursement de la prestation: allocation vacance pour GAULTIER SEBASTIEN', '150', '', '77137953137'),
(623, 1, 'Remboursement de la prestation: allocation vacance pour HANQUART SANDRA', '150', '', '299420020543'),
(624, 1, 'Remboursement de la prestation: allocation vacance pour ONILLON PATRICIA', '150', '', '330027887132'),
(625, 1, 'Remboursement de la prestation: allocation vacance pour FOUGERI ANNIE', '150', '', '724870459176'),
(626, 1, 'Remboursement de la prestation: allocation vacance pour MARSAULT FRANCOISE', '150', '', '68782654591'),
(627, 1, 'Remboursement de la prestation: allocation vacance pour CLEMENT CHRISTOPHE', '140.28', '', '380398741458'),
(628, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour CLEMENT CHRISTOPHE ALLOCATION LOISIRS', '50', '', '9059728528'),
(629, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour kerbourch allocation loisirs', '50', '', '9348237318'),
(630, 1, 'Achat: Mobil Home 140', '420', '', '5618958501'),
(631, 2, 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation Concours de boules - BLENDER', '', '0', '95490643'),
(632, 1, 'Ajout de la charge Fixe: ACHATS LOTS CONCOURS DE BOULES', '1232.58', '', '6469923663'),
(633, 1, 'Remboursement de la prestation: allocation vacance pour CHESNEL Brigitte', '150', '', '799762269947'),
(634, 1, 'Remboursement de la prestation: allocation vacance pour DAGUENE FRANCOISE', '150', '', '562917870469'),
(635, 1, 'Remboursement de la prestation: allocation vacance pour MORTIER FREDERIC', '150', '', '845400576014'),
(636, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour CROS SEVERINE ALLOCATION LOISIRS', '50', '', '3178855488'),
(637, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour FOUGERI ANNE ALLOCATION LOISIRS', '50', '', '9789497838'),
(638, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour ROUFFIAC CHRISTOPHE ALLOCATION LOISIRS', '50', '', '709789256'),
(639, 2, 'Vente de Billetterie: MESLET THIERRY pour la prestation cin&eacute;ma 2015', '', '12', '90203574'),
(640, 2, 'Vente de Billetterie: FOURNIER MARIO pour la prestation cin&eacute;ma 2015', '', '24', '94232139'),
(641, 2, 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation cin&eacute;ma 2015', '', '24', '44395444'),
(642, 2, 'Vente de Billetterie: MOTTEAU Thierry pour la prestation cin&eacute;ma 2015', '', '24', '39155593'),
(643, 1, 'Achat: CINEMA 8.10', '1215', '', '2081150296'),
(644, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation PAPEA', '', '72', '90894694'),
(645, 2, 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation PAPEA', '', '48', '48346952'),
(646, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation PAPEA', '', '36', '2205404'),
(647, 2, 'Vente de Billetterie: VERMELUN Christian pour la prestation Mobil Home 140', '', '140', '10223465'),
(648, 2, 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation Mobil Home 140', '', '140', '43611251'),
(649, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation Mobil Home 140', '', '280', '88961358'),
(650, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140', '61269797'),
(651, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140', '49639855'),
(652, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation Mobil Home 140', '', '140', '22236582'),
(653, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation Mobil Home 140', '', '140', '76450508'),
(654, 1, 'Remboursement de la prestation: allocation vacance pour VALLEE KARINE', '150', '', '902611814905'),
(655, 1, 'Remboursement de la prestation: allocation vacance pour RICHOMME HERVE', '150', '', '663407182321'),
(656, 1, 'Remboursement de la prestation: 79.30 pour PERGER ASTRID', '79.30', '', '216121441685'),
(657, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour VALLEE KARINE ALLOCATION LOISIRS', '50', '', '5949488841'),
(658, 1, 'Remboursement de la prestation: ALLOC LOISIRS  pour PECOT THIERRY ALLOCATION LOISIRS', '50', '', '4050949277'),
(659, 2, 'Vente de Billetterie: MESLET THIERRY pour la prestation CINEMA 8.10', '', '12', '15607231'),
(660, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation CINEMA 8.10', '', '12', '52890284'),
(661, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation CINEMA 8.10', '', '12', '18871054'),
(662, 2, 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation CINEMA 8.10', '', '24', '19237128'),
(663, 2, 'Vente de Billetterie: HAULBERT VINCENT pour la prestation CINEMA 8.10', '', '24', '38521367'),
(664, 2, 'Vente de Billetterie: MARTIN PATRICIA pour la prestation CINEMA 8.10', '', '24', '68559812'),
(665, 2, 'Vente de Billetterie: GUERIN JOHNNY pour la prestation CINEMA 8.10', '', '24', '36767902'),
(666, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation CINEMA 8.10', '', '24', '91220172'),
(667, 1, 'Remboursement de la prestation: allocation vacance pour CHAPEAU OLIVIER', '150', '', '357426176779'),
(668, 1, 'Remboursement de la prestation: allocation vacance pour BADOUR STEPHANE', '130', '', '122393353843'),
(669, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour BARRIERES AMANDINE ALLOCATION LOISIRS', '50', '', '8968575764'),
(670, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour MORTIER FREDERIC ALLOCATION LOISIRS', '50', '', '799871600'),
(671, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour DAGUENE FRANCOISE ALLOCATION LOISIRS', '32', '', '247338373'),
(672, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour DASYLVA JEAN PIERRE ALLOCATION LOISIRS', '44', '', '6609840537'),
(673, 1, 'Remboursement de la prestation: ALLOCATION LOISIRS pour DROUIN DIDIER ALLOCATION LOISIRS', '50', '', '404292350'),
(674, 1, 'Achat: vente parfums', '1425', '', '5883693043'),
(675, 2, 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation vente parfums', '', '74', '30480582'),
(676, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '47', '13430460');
INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(678, 2, 'Vente de Billetterie: BAULU CATHERINE pour la prestation vente parfums', '', '79', '21750440'),
(679, 2, 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation vente parfums', '', '106', '59141813'),
(680, 2, 'Vente de Billetterie: ONILLON PATRICIA pour la prestation vente parfums', '', '62', '54376067'),
(681, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '68', '25923048'),
(682, 2, 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation vente parfums', '', '76', '50521710'),
(683, 2, 'Vente de Billetterie: BOUDAUD VIRGINIE pour la prestation vente parfums', '', '47', '40097634'),
(684, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '187', '48638718'),
(685, 2, 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '436', '17738159'),
(686, 2, 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation vente parfums', '', '102', '59195284'),
(687, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation vente parfums', '', '54', '65258758'),
(688, 2, 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation vente parfums', '', '87', '89963425'),
(689, 1, 'Achat: vente parfums', '687', '', '6342124119'),
(690, 2, 'Vente de Billetterie: CERIBAS FILIZ pour la prestation vente parfums', '', '152', '18400972'),
(691, 2, 'Vente de Billetterie: CERIBAS FILIZ pour la prestation vente parfums', '', '244', '58938556'),
(692, 2, 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '71', '13089680'),
(694, 2, 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation vente parfums', '', '56', '77232090'),
(695, 2, 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation vente parfums', '', '164', '10649859'),
(696, 2, 'Vente de Billetterie: POIRRIER THIERRY pour la prestation CINEMA 8.10', '', '24', '6101564'),
(697, 2, 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation CINEMA 8.10', '', '12', '93949724'),
(698, 2, 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation CINEMA 8.10', '', '12', '1615334'),
(699, 2, 'Vente de Billetterie: GUYADER YOHANN pour la prestation CINEMA 8.10', '', '24', '83482016'),
(700, 2, 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation CINEMA 8.10', '', '24', '63365946'),
(701, 2, 'Vente de Billetterie: AUDIC GAELLE pour la prestation CINEMA 8.10', '', '12', '48257728'),
(702, 2, 'Vente de Billetterie: GARNIER DAVID pour la prestation CINEMA 8.10', '', '30', '83520603'),
(703, 2, 'Vente de Billetterie: PIOU BENOIT pour la prestation CINEMA 8.10', '', '24', '4708401'),
(704, 2, 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation CINEMA 8.10', '', '24', '31593916'),
(705, 2, 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation CINEMA 8.10', '', '48', '4470272'),
(706, 2, 'Vente de Billetterie: CERIBAS FILIZ pour la prestation CINEMA 8.10', '', '30', '66493705'),
(707, 2, 'Vente de Billetterie: HANQUART SANDRA pour la prestation CINEMA 8.10', '', '24', '33782369'),
(708, 2, 'Vente de Billetterie: RICHOMME HERVE pour la prestation CINEMA 8.10', '', '24', '1906217'),
(709, 2, 'Vente de Billetterie: HAULBERT VINCENT pour la prestation CINEMA 8.10', '', '24', '48597139'),
(710, 2, 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation CINEMA 8.10', '', '12', '69515852'),
(711, 2, 'Vente de Billetterie: CROS SEVERINE pour la prestation CINEMA 8.10', '', '24', '90883384'),
(712, 2, 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation CINEMA 8.10', '', '24', '13539760'),
(713, 2, 'Vente de Billetterie: VALLEE KARINE pour la prestation CINEMA 8.10', '', '24', '23524402'),
(714, 2, 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation CINEMA 8.10', '', '24', '75849186'),
(715, 2, 'Vente de Billetterie: MARTIN PATRICIA pour la prestation CINEMA 8.10', '', '24', '44444917'),
(716, 2, 'Vente de Billetterie: IDDER MEHDI pour la prestation CINEMA 8.10', '', '24', '29432977'),
(717, 1, 'Remboursement de la prestation: allocation vacance pour PECOT THIERRY', '150', '', '512463990133'),
(718, 1, 'Remboursement de la prestation: alllocation vacance  pour COSNIER CHRISTOPHE', '80.32', '', '908418876119'),
(719, 1, 'Remboursement de la prestation: allocation vacance pour BOIVIN VERONIQUE', '150', '', '741440337151');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`, `num_mouvement`) VALUES
(101, 109, '24-03-2015', 3, '0', 1, '0'),
(103, 110, '10-03-2015', 3, '36', 1, '0'),
(104, 83, '10-03-2015', 3, '6', 1, '0'),
(105, 156, '10-03-2015', 3, '3', 1, '0'),
(106, 150, '10-03-2015', 3, '6', 1, '0'),
(107, 138, '10-03-2015', 3, '6', 1, '0'),
(108, 130, '10-03-2015', 3, '3', 1, '0'),
(109, 131, '10-03-2015', 3, '6', 1, '0'),
(110, 144, '10-03-2015', 3, '6', 1, '0'),
(111, 133, '10-03-2015', 3, '3', 1, '0'),
(112, 103, '10-03-2015', 3, '6', 1, '0'),
(113, 113, '10-03-2015', 3, '15', 1, '0'),
(114, 129, '10-03-2015', 3, '6', 1, '0'),
(115, 75, '10-03-2015', 3, '3', 1, '0'),
(116, 99, '10-03-2015', 3, '12', 1, '0'),
(117, 86, '10-03-2015', 3, '6', 1, '0'),
(118, 125, '10-03-2015', 3, '6', 1, '0'),
(119, 76, '10-03-2015', 3, '15', 1, '0'),
(120, 97, '10-03-2015', 3, '3', 1, '0'),
(121, 158, '10-03-2015', 3, '6', 1, '0'),
(122, 116, '10-03-2015', 3, '6', 1, '0'),
(124, 120, '10-03-2015', 3, '6', 1, '0'),
(125, 128, '10-03-2015', 3, '3', 1, '0'),
(126, 114, '10-03-2015', 3, '15', 1, '0'),
(127, 106, '10-03-2015', 3, '3', 1, '0'),
(128, 132, '10-03-2015', 3, '6', 1, '0'),
(129, 96, '10-03-2015', 3, '3', 1, '0'),
(130, 82, '10-03-2015', 3, '6', 1, '0'),
(131, 92, '10-03-2015', 3, '6', 1, '0'),
(132, 124, '10-03-2015', 3, '6', 1, '0'),
(133, 152, '10-03-2015', 3, '6', 1, '0'),
(134, 87, '10-03-2015', 3, '6', 1, '0'),
(135, 143, '10-03-2015', 3, '6', 1, '0'),
(136, 98, '10-03-2015', 3, '3', 1, '0'),
(137, 127, '10-03-2015', 3, '6', 1, '0'),
(138, 119, '10-03-2015', 3, '6', 1, '0'),
(139, 140, '10-03-2015', 3, '3', 1, '0'),
(140, 75, '10-03-2015', 3, '6', 1, '0'),
(141, 81, '10-03-2015', 3, '6', 1, '0'),
(142, 84, '10-03-2015', 3, '6', 1, '0'),
(143, 78, '10-03-2015', 3, '3', 1, '0'),
(144, 108, '10-03-2015', 3, '3', 1, '0'),
(145, 123, '10-03-2015', 3, '6', 1, '0'),
(146, 111, '10-03-2015', 3, '6', 1, '0'),
(147, 139, '10-03-2015', 3, '6', 1, '0'),
(148, 91, '10-03-2015', 3, '6', 1, '0'),
(149, 77, '10-03-2015', 3, '6', 1, '0'),
(150, 118, '10-03-2015', 3, '6', 1, '0'),
(151, 88, '10-03-2015', 3, '6', 1, '0'),
(152, 107, '10-03-2015', 3, '6', 1, '0'),
(153, 105, '10-03-2015', 3, '6', 1, '0'),
(154, 80, '10-03-2015', 3, '6', 1, '0'),
(155, 145, '10-03-2015', 3, '6', 1, '0'),
(156, 102, '10-03-2015', 3, '3', 1, '0'),
(157, 74, '10-03-2015', 3, '3', 1, '0'),
(158, 121, '10-03-2015', 3, '6', 1, '0'),
(159, 79, '10-03-2015', 3, '6', 1, '0'),
(160, 94, '10-03-2015', 3, '6', 1, '0'),
(161, 135, '10-03-2015', 3, '6', 1, '0'),
(162, 90, '10-03-2015', 3, '3', 1, '0'),
(163, 154, '10-03-2015', 3, '3', 1, '0'),
(164, 126, '10-03-2015', 3, '6', 1, '0'),
(165, 117, '10-03-2015', 3, '6', 1, '0'),
(166, 147, '10-03-2015', 3, '6', 1, '0'),
(167, 72, '10-03-2015', 3, '6', 1, '0'),
(168, 146, '10-03-2015', 3, '6', 1, '0'),
(169, 104, '10-03-2015', 3, '3', 1, '0'),
(170, 109, '10-03-2015', 3, '6', 1, '0'),
(171, 137, '10-03-2015', 3, '114', 1, '0'),
(173, 99, '24-03-2015', 3, '0', 1, '0'),
(174, 121, '24-03-2015', 3, '0', 1, '0'),
(175, 116, '24-03-2015', 3, '0', 1, '0'),
(176, 83, '24-03-2015', 3, '0', 1, '0'),
(177, 80, '24-03-2015', 3, '0', 1, '0'),
(178, 157, '24-03-2015', 3, '0', 1, '0'),
(179, 136, '24-03-2015', 3, '0', 1, '0'),
(180, 134, '24-03-2015', 3, '0', 1, '0'),
(181, 98, '24-03-2015', 3, '0', 1, '0'),
(182, 126, '24-03-2015', 3, '0', 1, '0'),
(183, 128, '24-03-2015', 3, '0', 1, '0'),
(184, 123, '24-03-2015', 3, '0', 1, '0'),
(185, 110, '24-03-2015', 3, '0', 1, '0'),
(186, 77, '24-03-2015', 3, '0', 1, '0'),
(187, 159, '24-03-2015', 3, '0', 1, '0'),
(188, 72, '24-03-2015', 3, '0', 1, '0'),
(189, 125, '24-03-2015', 3, '0', 1, '0'),
(190, 154, '24-03-2015', 3, '0', 1, '0'),
(191, 87, '24-03-2015', 3, '0', 1, '0'),
(192, 138, '24-03-2015', 3, '0', 1, '0'),
(193, 129, '24-03-2015', 3, '0', 1, '0'),
(194, 148, '24-03-2015', 3, '0', 1, '0'),
(195, 149, '24-03-2015', 3, '0', 1, '0'),
(196, 130, '24-03-2015', 3, '0', 1, '0'),
(197, 106, '24-03-2015', 3, '0', 1, '0'),
(198, 111, '24-03-2015', 3, '0', 1, '0'),
(199, 155, '24-03-2015', 3, '0', 1, '0'),
(200, 90, '24-03-2015', 3, '0', 1, '0'),
(201, 127, '24-03-2015', 3, '0', 1, '0'),
(202, 84, '24-03-2015', 3, '0', 1, '0'),
(203, 112, '24-03-2015', 3, '0', 1, '0'),
(204, 96, '24-03-2015', 3, '0', 1, '0'),
(205, 152, '24-03-2015', 3, '0', 1, '0'),
(206, 100, '24-03-2015', 3, '0', 1, '0'),
(207, 95, '24-03-2015', 3, '0', 1, '0'),
(208, 145, '24-03-2015', 3, '0', 1, '0'),
(209, 113, '24-03-2015', 3, '0', 1, '0'),
(210, 73, '24-03-2015', 3, '0', 1, '0'),
(211, 117, '24-03-2015', 3, '0', 1, '0'),
(212, 107, '24-03-2015', 3, '0', 1, '0'),
(213, 120, '24-03-2015', 3, '0', 1, '0'),
(214, 118, '24-03-2015', 3, '0', 1, '0'),
(215, 139, '24-03-2015', 3, '0', 1, '0'),
(216, 131, '24-03-2015', 3, '0', 1, '0'),
(217, 114, '24-03-2015', 3, '0', 1, '0'),
(218, 122, '24-03-2015', 3, '0', 1, '0'),
(219, 119, '24-03-2015', 3, '0', 1, '0'),
(220, 76, '24-03-2015', 3, '0', 1, '0'),
(221, 105, '24-03-2015', 3, '0', 1, '0'),
(223, 101, '24-03-2015', 3, '0', 1, '0'),
(224, 141, '24-03-2015', 3, '0', 1, '0'),
(225, 102, '24-03-2015', 3, '0', 1, '0'),
(226, 97, '24-03-2015', 3, '0', 1, '0'),
(227, 89, '24-03-2015', 3, '0', 1, '0'),
(228, 142, '24-03-2015', 3, '0', 1, '0'),
(229, 86, '24-03-2015', 3, '0', 1, '0'),
(230, 146, '24-03-2015', 3, '0', 1, '0'),
(231, 94, '24-03-2015', 3, '0', 1, '0'),
(232, 75, '24-03-2015', 3, '0', 1, '0'),
(233, 133, '24-03-2015', 3, '0', 1, '0'),
(234, 140, '24-03-2015', 3, '0', 1, '0'),
(235, 74, '24-03-2015', 3, '0', 1, '0'),
(236, 85, '24-03-2015', 3, '0', 1, '0'),
(237, 108, '24-03-2015', 3, '0', 1, '0'),
(238, 144, '24-03-2015', 3, '0', 1, '0'),
(239, 147, '24-03-2015', 3, '0', 1, '0'),
(240, 103, '24-03-2015', 3, '0', 1, '0'),
(241, 81, '24-03-2015', 3, '0', 1, '0'),
(242, 151, '24-03-2015', 3, '0', 1, '0'),
(243, 79, '24-03-2015', 3, '0', 1, '0'),
(244, 132, '24-03-2015', 3, '0', 1, '0'),
(245, 153, '24-03-2015', 3, '0', 1, '0'),
(246, 124, '24-03-2015', 3, '0', 1, '0'),
(247, 158, '24-03-2015', 3, '0', 1, '0'),
(248, 88, '24-03-2015', 3, '0', 1, '0'),
(249, 78, '24-03-2015', 3, '0', 1, '0'),
(250, 137, '24-03-2015', 3, '0', 1, '0'),
(251, 135, '24-03-2015', 3, '0', 1, '0'),
(252, 115, '24-03-2015', 3, '0', 1, '0'),
(253, 143, '24-03-2015', 3, '0', 1, '0'),
(254, 91, '24-03-2015', 3, '0', 1, '0'),
(255, 82, '24-03-2015', 3, '0', 1, '0'),
(256, 104, '24-03-2015', 3, '0', 1, '0'),
(257, 156, '24-03-2015', 3, '0', 1, '0'),
(258, 92, '24-03-2015', 3, '0', 1, '0'),
(261, 132, '05-05-2015', 3, '120', 1, '22704853'),
(262, 95, '17-02-2015', 3, '321', 1, '99466543'),
(263, 133, '17-02-2015', 3, '163', 1, '38968883'),
(264, 78, '02-01-2015', 3, '280', 1, '54329905'),
(265, 86, '02-01-2015', 3, '140', 1, '70503049'),
(266, 129, '02-01-2015', 3, '280', 1, '83272284'),
(267, 106, '02-01-2015', 3, '140', 1, '24717805'),
(268, 116, '02-01-2015', 3, '140', 1, '83446436'),
(269, 145, '02-01-2015', 3, '280', 1, '46414316'),
(270, 150, '15-04-2015', 3, '140', 1, '76223985'),
(271, 94, '15-04-2015', 3, '140', 1, '95013897'),
(272, 132, '15-01-2015', 3, '140', 1, '92941828'),
(273, 111, '10-04-2015', 3, '140', 1, '91005854'),
(274, 74, '15-01-2015', 3, '280', 1, '56221445'),
(275, 90, '10-04-2015', 3, '140', 1, '36087532'),
(276, 113, '10-04-2015', 3, '140', 1, '84147055'),
(277, 113, '10-04-2015', 3, '280', 1, '47246505'),
(278, 76, '15-01-2015', 3, '140', 1, '20883318'),
(279, 78, '15-04-2015', 3, '280', 1, '26518598'),
(280, 139, '15-04-2015', 3, '140', 1, '4169744'),
(281, 139, '15-04-2015', 3, '140', 1, '83401100'),
(282, 78, '15-04-2015', 3, '140', 1, '14936841'),
(283, 113, '15-04-2015', 3, '140', 1, '32434769'),
(284, 78, '15-04-2015', 3, '140', 1, '27126414'),
(285, 114, '15-04-2015', 3, '140', 1, '27964394'),
(286, 78, '15-04-2015', 3, '140', 1, '84614899'),
(287, 117, '15-04-2015', 3, '140', 1, '13890845'),
(288, 130, '15-04-2015', 3, '280', 1, '56467682'),
(289, 78, '15-04-2015', 3, '280', 1, '96086758'),
(290, 113, '15-04-2015', 3, '140', 1, '36219443'),
(291, 91, '15-04-2015', 3, '280', 1, '33350447'),
(292, 78, '15-04-2015', 3, '280', 1, '87401578'),
(293, 142, '02-05-2015', 3, '187', 1, '43837257'),
(294, 91, '10-05-2015', 3, '39', 1, '95691609'),
(295, 85, '10-05-2015', 3, '59', 1, '28668247'),
(296, 105, '10-05-2015', 3, '47', 1, '65780771'),
(297, 105, '10-05-2015', 3, '88', 1, '15108811'),
(298, 105, '10-05-2015', 3, '70', 1, '37001892'),
(299, 105, '10-05-2015', 3, '47', 1, '40260497'),
(300, 124, '10-05-2015', 3, '48', 1, '93699737'),
(301, 124, '10-05-2015', 3, '50', 1, '11350408'),
(302, 124, '10-05-2015', 3, '63', 1, '90254930'),
(303, 124, '10-05-2015', 3, '133', 1, '40800676'),
(304, 124, '10-05-2015', 3, '69', 1, '56948978'),
(305, 95, '10-05-2015', 3, '145', 1, '2695252'),
(306, 132, '10-05-2015', 3, '117', 1, '42158759'),
(307, 78, '14-04-2015', 3, '140', 1, '19519094'),
(308, 113, '20-05-2015', 3, '140', 1, '89781454'),
(309, 113, '15-05-2015', 3, '140', 1, '66872676'),
(310, 98, '15-05-2015', 3, '280', 1, '43279116'),
(311, 121, '15-05-2015', 3, '140', 1, '2498617'),
(312, 95, '10-05-2015', 3, '221', 1, '59737801'),
(313, 95, '10-05-2015', 3, '76', 1, '75261277'),
(314, 118, '10-05-2015', 3, '61', 1, '9397852'),
(315, 141, '10-05-2015', 3, '93', 1, '74124673'),
(316, 107, '10-05-2015', 3, '46', 1, '61693184'),
(317, 114, '10-05-2015', 3, '64', 1, '1896277'),
(318, 82, '10-05-2015', 3, '96', 1, '54861570'),
(319, 124, '10-05-2015', 3, '56', 1, '37293044'),
(320, 124, '01-01-2015', 3, '24', 1, '51282607'),
(321, 105, '01-01-2015', 3, '24', 1, '79129670'),
(322, 110, '01-01-2015', 3, '24', 1, '39684921'),
(323, 145, '01-01-2015', 3, '24', 1, '64360491'),
(324, 87, '01-01-2015', 3, '24', 1, '74780411'),
(325, 140, '01-01-2015', 3, '30', 1, '57593944'),
(326, 74, '01-01-2015', 3, '24', 1, '21886527'),
(327, 80, '01-01-2015', 3, '24', 1, '62962139'),
(328, 140, '01-01-2015', 3, '30', 1, '17527469'),
(329, 118, '01-01-2015', 3, '24', 1, '91024312'),
(330, 142, '01-01-2015', 3, '24', 1, '21228151'),
(331, 137, '01-01-2015', 3, '12', 1, '85617058'),
(332, 137, '01-01-2015', 3, '12', 1, '34440248'),
(333, 115, '01-01-2015', 3, '24', 1, '36062617'),
(334, 113, '01-02-2015', 3, '18', 1, '65905228'),
(335, 114, '01-02-2015', 3, '24', 1, '98735446'),
(336, 131, '01-02-2015', 3, '30', 1, '3565326'),
(337, 91, '01-02-2015', 3, '48', 1, '66058938'),
(338, 103, '01-02-2015', 3, '24', 1, '23811416'),
(339, 150, '01-02-2015', 3, '18', 1, '5090115'),
(340, 117, '01-02-2015', 3, '42', 1, '93018735'),
(341, 130, '01-02-2015', 3, '24', 1, '48142725'),
(342, 135, '01-02-2015', 3, '12', 1, '5191271'),
(343, 86, '01-02-2015', 3, '24', 1, '50685941'),
(344, 105, '01-02-2015', 3, '24', 1, '84155268'),
(345, 143, '01-02-2015', 3, '24', 1, '16726167'),
(346, 85, '01-02-2015', 3, '24', 1, '1923109'),
(347, 124, '01-02-2015', 3, '24', 1, '48961877'),
(348, 110, '01-02-2015', 3, '24', 1, '73405539'),
(349, 147, '01-02-2015', 3, '24', 1, '93579470'),
(350, 90, '01-02-2015', 3, '24', 1, '84045960'),
(351, 82, '01-02-2015', 3, '24', 1, '33707857'),
(352, 81, '15-02-2015', 3, '24', 1, '70486482'),
(353, 121, '15-02-2015', 3, '18', 1, '22566591'),
(354, 104, '15-02-2015', 3, '12', 1, '76658017'),
(355, 101, '15-02-2015', 3, '24', 1, '47461529'),
(356, 157, '15-02-2015', 3, '12', 1, '30433642'),
(357, 116, '15-02-2015', 3, '24', 1, '76414721'),
(358, 141, '15-02-2015', 3, '36', 1, '6929080'),
(359, 114, '15-03-2015', 3, '24', 1, '60316808'),
(360, 82, '15-03-2015', 3, '24', 1, '92400437'),
(361, 159, '15-03-2015', 3, '30', 1, '44711276'),
(362, 87, '15-03-2015', 3, '24', 1, '82099288'),
(363, 136, '15-03-2015', 3, '12', 1, '60431516'),
(364, 132, '15-03-2015', 3, '24', 1, '8060080'),
(365, 74, '15-03-2015', 3, '24', 1, '77167360'),
(366, 121, '15-03-2015', 3, '24', 1, '53954817'),
(367, 113, '15-04-2015', 3, '24', 1, '97945720'),
(368, 90, '15-04-2015', 3, '24', 1, '58817256'),
(369, 107, '15-04-2015', 3, '24', 1, '37333506'),
(370, 105, '15-04-2015', 3, '24', 1, '90803018'),
(371, 97, '15-04-2015', 3, '24', 1, '54273009'),
(372, 155, '15-04-2015', 3, '12', 1, '76573345'),
(373, 145, '15-04-2015', 3, '24', 1, '31128959'),
(374, 136, '15-04-2015', 3, '24', 1, '78953575'),
(375, 141, '15-04-2015', 3, '36', 1, '3670390'),
(376, 157, '20-04-2015', 3, '12', 1, '38331041'),
(377, 124, '20-04-2015', 3, '24', 1, '94391932'),
(378, 99, '20-04-2015', 3, '24', 1, '57322921'),
(379, 123, '15-05-2015', 3, '12', 1, '18386139'),
(380, 141, '15-05-2015', 3, '24', 1, '27966879'),
(381, 142, '15-05-2015', 3, '24', 1, '44786894'),
(382, 124, '15-05-2015', 3, '24', 1, '76915919'),
(383, 136, '15-05-2015', 3, '24', 1, '48400238'),
(384, 112, '15-05-2015', 3, '24', 1, '66373148'),
(385, 97, '15-05-2015', 3, '24', 1, '88263688'),
(386, 140, '15-05-2015', 3, '30', 1, '72131237'),
(387, 142, '15-05-2015', 3, '12', 1, '91446764'),
(389, 152, '08-09-2015', 3, '0', 1, '97629744'),
(390, 120, '10-06-2015', 3, '6', 1, '68349084'),
(391, 157, '10-07-2015', 3, '12', 1, '16113822'),
(392, 131, '16-07-2015', 3, '24', 1, '67085243'),
(393, 122, '23-07-2015', 3, '24', 1, '56393529'),
(394, 103, '06-08-2015', 3, '36', 1, '29506070'),
(395, 101, '06-08-2015', 3, '12', 1, '26358660'),
(396, 91, '25-08-2015', 3, '12', 1, '72812836'),
(397, 94, '12-06-2015', 3, '12', 1, '72318495'),
(399, 113, '10-06-2015', 3, '24', 1, '36444209'),
(400, 79, '25-06-2015', 3, '24', 1, '58273290'),
(401, 147, '17-06-2015', 3, '24', 1, '25001941'),
(402, 90, '22-06-2015', 3, '24', 1, '83203092'),
(403, 77, '02-07-2015', 3, '24', 1, '96161978'),
(404, 82, '02-07-2015', 3, '24', 1, '8929502'),
(405, 124, '06-07-2015', 3, '24', 1, '35934991'),
(406, 152, '07-07-2015', 3, '24', 1, '25989343'),
(407, 146, '09-07-2015', 3, '24', 1, '17867403'),
(408, 116, '09-07-2015', 3, '24', 1, '51888054'),
(409, 92, '09-07-2015', 3, '12', 1, '63853104'),
(410, 118, '09-07-2015', 3, '24', 1, '79217448'),
(411, 110, '09-07-2015', 3, '24', 1, '26302169'),
(413, 140, '10-07-2015', 3, '30', 1, '74741047'),
(414, 0, '16-07-2015', 0, '0', 0, ''),
(415, 114, '17-07-2015', 3, '24', 1, '71251061'),
(416, 99, '17-07-2015', 3, '24', 1, '83458012'),
(417, 80, '22-07-2015', 3, '24', 1, '54490717'),
(419, 123, '17-07-2015', 3, '12', 1, '23151142'),
(420, 122, '06-08-2015', 3, '24', 1, '58163654'),
(421, 98, '06-08-2015', 3, '12', 1, '66895493'),
(422, 78, '18-08-2015', 3, '24', 1, '81027120'),
(423, 76, '18-08-2015', 3, '24', 1, '43007147'),
(424, 124, '18-08-2015', 3, '24', 1, '28143541'),
(425, 85, '25-08-2015', 3, '24', 1, '26409362'),
(426, 117, '28-08-2015', 3, '6', 1, '34372446'),
(427, 135, '08-09-2015', 3, '0', 1, '66897190'),
(428, 74, '08-09-2015', 3, '0', 1, '29624657'),
(429, 137, '08-09-2015', 3, '0', 1, '82272904'),
(430, 75, '08-09-2015', 3, '0', 1, '46233333'),
(431, 73, '08-09-2015', 3, '0', 1, '25862678'),
(432, 75, '08-09-2015', 3, '0', 1, '87103301'),
(433, 73, '08-09-2015', 3, '0', 1, '28940623'),
(434, 138, '08-09-2015', 3, '0', 1, '31605110'),
(435, 152, '08-09-2015', 3, '0', 1, '67736922'),
(436, 99, '08-09-2015', 3, '0', 1, '30759278'),
(437, 137, '08-09-2015', 3, '0', 1, '55487353'),
(438, 142, '08-09-2015', 3, '0', 1, '8483222'),
(439, 151, '08-09-2015', 3, '0', 1, '98975262'),
(440, 142, '08-09-2015', 3, '0', 1, '47551203'),
(441, 114, '08-09-2015', 3, '0', 1, '29507336'),
(442, 151, '08-09-2015', 3, '0', 1, '84859217'),
(443, 99, '08-09-2015', 3, '0', 1, '64756491'),
(444, 144, '08-09-2015', 3, '0', 1, '65282587'),
(445, 113, '08-09-2015', 3, '0', 1, '85594598'),
(446, 113, '08-09-2015', 3, '0', 1, '74254500'),
(447, 74, '08-09-2015', 3, '0', 1, '96677038'),
(448, 130, '08-09-2015', 3, '0', 1, '27220252'),
(449, 144, '08-09-2015', 3, '0', 1, '89336531'),
(450, 117, '08-09-2015', 3, '0', 1, '45659438'),
(451, 135, '08-09-2015', 3, '0', 1, '95490643'),
(452, 117, '08-09-2015', 3, '0', 1, '51214610'),
(453, 99, '08-09-2015', 3, '0', 1, '56748610'),
(454, 75, '08-09-2015', 3, '0', 1, '70507603'),
(455, 73, '08-09-2015', 3, '0', 1, '40495308'),
(456, 137, '08-09-2015', 3, '0', 1, '36296409'),
(457, 142, '08-09-2015', 3, '0', 1, '24701546'),
(458, 160, '08-09-2015', 3, '0', 1, '25630849'),
(459, 161, '08-09-2015', 3, '0', 1, '37359359'),
(460, 160, '08-09-2015', 3, '0', 1, '91024544'),
(461, 161, '08-09-2015', 3, '0', 1, '20578087'),
(462, 103, '21-09-2015', 3, '12', 1, '90203574'),
(463, 147, '21-09-2015', 3, '24', 1, '39155593'),
(464, 74, '21-09-2015', 3, '24', 1, '44395444'),
(465, 120, '21-09-2015', 3, '24', 1, '94232139'),
(466, 105, '08-09-2015', 3, '72', 1, '90894694'),
(467, 145, '08-09-2015', 3, '48', 1, '48346952'),
(468, 99, '08-09-2015', 3, '36', 1, '2205404'),
(469, 124, '01-10-2015', 3, '140', 1, '76450508'),
(470, 124, '01-10-2015', 3, '140', 1, '22236582'),
(471, 113, '01-10-2015', 3, '140', 1, '49639855'),
(472, 113, '01-10-2015', 3, '140', 1, '61269797'),
(473, 124, '01-10-2015', 3, '280', 1, '88961358'),
(474, 154, '01-10-2015', 3, '140', 1, '43611251'),
(475, 161, '01-10-2015', 3, '140', 1, '10223465'),
(476, 90, '02-10-2015', 3, '24', 1, '91220172'),
(477, 76, '02-10-2015', 3, '24', 1, '36767902'),
(478, 103, '02-10-2015', 3, '12', 1, '15607231'),
(479, 108, '02-10-2015', 3, '24', 1, '68559812'),
(480, 97, '02-10-2015', 3, '24', 1, '38521367'),
(481, 122, '02-10-2015', 3, '24', 1, '19237128'),
(482, 142, '02-10-2015', 3, '12', 1, '18871054'),
(483, 132, '02-10-2015', 3, '12', 1, '52890284'),
(484, 116, '20-10-2015', 3, '74', 1, '30480582'),
(485, 105, '20-10-2015', 3, '47', 1, '13430460'),
(486, 80, '20-10-2015', 3, '79', 1, '21750440'),
(487, 118, '20-10-2015', 3, '106', 1, '59141813'),
(488, 132, '20-10-2015', 3, '62', 1, '54376067'),
(489, 105, '20-10-2015', 3, '68', 1, '25923048'),
(490, 82, '20-10-2015', 3, '76', 1, '50521710'),
(491, 126, '20-10-2015', 3, '47', 1, '40097634'),
(492, 105, '20-10-2015', 3, '187', 1, '48638718'),
(493, 95, '20-10-2015', 3, '436', 1, '17738159'),
(494, 114, '20-10-2015', 3, '102', 1, '59195284'),
(496, 113, '20-10-2015', 3, '54', 1, '65258758'),
(497, 113, '20-10-2015', 3, '87', 1, '89963425'),
(498, 159, '20-10-2015', 3, '152', 1, '18400972'),
(499, 159, '20-10-2015', 3, '244', 1, '58938556'),
(500, 124, '20-10-2015', 3, '71', 1, '13089680'),
(501, 144, '20-10-2015', 3, '56', 1, '77232090'),
(502, 144, '20-10-2015', 3, '164', 1, '10649859'),
(503, 78, '07-10-2015', 3, '24', 1, '6101564'),
(504, 143, '13-10-2015', 3, '12', 1, '93949724'),
(505, 154, '06-10-2015', 3, '12', 1, '1615334'),
(506, 141, '01-11-2015', 3, '24', 1, '83482016'),
(507, 99, '01-11-2015', 3, '24', 1, '63365946'),
(508, 121, '01-11-2015', 3, '12', 1, '48257728'),
(509, 131, '01-11-2015', 3, '30', 1, '83520603'),
(510, 93, '01-11-2015', 3, '24', 1, '4708401'),
(511, 133, '01-11-2015', 3, '24', 1, '31593916'),
(512, 91, '01-11-2015', 3, '48', 1, '4470272'),
(513, 159, '01-11-2015', 3, '30', 1, '66493705'),
(514, 102, '01-11-2015', 3, '24', 1, '33782369'),
(515, 115, '01-11-2015', 3, '24', 1, '1906217'),
(516, 97, '01-11-2015', 3, '24', 1, '48597139'),
(517, 123, '01-11-2015', 3, '12', 1, '69515852'),
(518, 90, '01-11-2015', 3, '24', 1, '90883384'),
(519, 144, '01-11-2015', 3, '24', 1, '13539760'),
(520, 104, '01-11-2015', 3, '24', 1, '23524402'),
(521, 105, '01-11-2015', 3, '24', 1, '75849186'),
(522, 108, '01-11-2015', 3, '24', 1, '44444917'),
(523, 142, '01-11-2015', 3, '24', 1, '29432977');

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `charge_fixe`
--

INSERT INTO `charge_fixe` (`idchargefixe`, `designation`, `date_charge_fixe`, `montant_charge`, `num_mouvement`) VALUES
(5, 'FRAIS ENVOI ANCV', '24-03-2015', '302.50', ''),
(7, 'HIPPIE FANNY REPAS CONCOURS DE BOULES', '08-09-2015', '400', '4969886597'),
(8, 'ACHATS LOTS CONCOURS DE BOULES', '08-09-2015', '1232.58', '6469923663');

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '', ''),
(81, 2, '', ''),
(82, 3, '', ''),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '', ''),
(87, 8, '', ''),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '', ''),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', ''),
(113, 34, '', ''),
(114, 35, '', ''),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '', ''),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '', ''),
(134, 55, '', ''),
(135, 56, '', ''),
(136, 57, '', ''),
(137, 58, '', ''),
(138, 59, '', ''),
(139, 60, '', ''),
(140, 61, '', ''),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', 'CrÃ©ances Client'),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', ''),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', 'Achats Combustible'),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', ''),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Postaux'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'Frais d''administration'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phonie'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achat de matÃ©riel '),
(61, 6, 'Autre Charge d''exploitation 1', ''),
(62, 6, 'Autre Charge d''exploitation 2', ''),
(63, 6, 'Autre Charge d''exploitation 3', ''),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'COMITE D''ENTREPRISE MLP', '0', '0', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '31-12-2014', '31-12-2015');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(138, '77888520', '1425942000', 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation CHARLIE HEBDO', '', '36'),
(140, '35203667', '1425942000', 'Vente de Billetterie: SALAUN ANDRE pour la prestation CHARLIE HEBDO', '', '3'),
(143, '34093613', '1425942000', 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation CHARLIE HEBDO', '', '3'),
(146, '90007063', '1425942000', 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation CHARLIE HEBDO', '', '3'),
(148, '94566683', '1425942000', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation CHARLIE HEBDO', '', '15'),
(150, '7070390', '1425942000', 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation CHARLIE HEBDO', '', '3'),
(151, '20918838', '1425942000', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation CHARLIE HEBDO', '', '12'),
(154, '57787493', '1425942000', 'Vente de Billetterie: GUERIN JOHNNY pour la prestation CHARLIE HEBDO', '', '15'),
(155, '43396733', '1425942000', 'Vente de Billetterie: HAULBERT VINCENT pour la prestation CHARLIE HEBDO', '', '3'),
(159, '64231022', '1425942000', 'Vente de Billetterie: FOURNIER MARIO pour la prestation CHARLIE HEBDO', '', '6'),
(160, '58433076', '1425942000', 'Vente de Billetterie: BOUFAQOUS ABDELJALIL pour la prestation CHARLIE HEBDO', '', '3'),
(161, '38867830', '1425942000', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation CHARLIE HEBDO', '', '15'),
(162, '93588287', '1425942000', 'Vente de Billetterie: COSNIER CHRISTOPHE pour la prestation CHARLIE HEBDO', '', '3'),
(163, '5716332', '1425942000', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation CHARLIE HEBDO', '', '6'),
(164, '40247192', '1425942000', 'Vente de Billetterie: DAVY ANTOINE pour la prestation CHARLIE HEBDO', '', '3'),
(165, '78190047', '1425942000', 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation CHARLIE HEBDO', '', '6'),
(166, '22957854', '1425942000', 'Vente de Billetterie: SUREAU LYDIE pour la prestation CHARLIE HEBDO', '', '6'),
(167, '6950154', '1425942000', 'Vente de Billetterie: PECOT THIERRY pour la prestation CHARLIE HEBDO', '', '6'),
(168, '99680257', '1425942000', 'Vente de Billetterie: DAGUER St?phane pour la prestation CHARLIE HEBDO', '', '6'),
(169, '22796043', '1425942000', 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation CHARLIE HEBDO', '', '6'),
(170, '92148009', '1425942000', 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation CHARLIE HEBDO', '', '6'),
(171, '1403553', '1425942000', 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation CHARLIE HEBDO', '', '3'),
(172, '97490311', '1425942000', 'Vente de Billetterie: DASYLVA JEAN-PIERRE pour la prestation CHARLIE HEBDO', '', '6'),
(173, '3641379', '1425942000', 'Vente de Billetterie: GUERIN HUGUETTE pour la prestation CHARLIE HEBDO', '', '6'),
(174, '54188181', '1425942000', 'Vente de Billetterie: LUBIN MICHEL pour la prestation CHARLIE HEBDO', '', '3'),
(175, '35864404', '1425942000', 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation CHARLIE HEBDO', '', '6'),
(176, '59615731', '1425942000', 'Vente de Billetterie: MORTIER FREDERIC pour la prestation CHARLIE HEBDO', '', '6'),
(177, '53405864', '1425942000', 'Vente de Billetterie: DAGUENE FRANCOISE pour la prestation CHARLIE HEBDO', '', '6'),
(178, '67706393', '1425942000', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation CHARLIE HEBDO', '', '3'),
(179, '14437311', '1425942000', 'Vente de Billetterie: MARTIN PATRICIA pour la prestation CHARLIE HEBDO', '', '3'),
(180, '35284155', '1425942000', 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation CHARLIE HEBDO', '', '6'),
(181, '29814792', '1425942000', 'Vente de Billetterie: COUINET SOLEN pour la prestation CHARLIE HEBDO', '', '6'),
(182, '49456544', '1425942000', 'Vente de Billetterie: GALLET STEPHANE pour la prestation CHARLIE HEBDO', '', '6'),
(183, '73238056', '1425942000', 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation CHARLIE HEBDO', '', '6'),
(184, '75019028', '1425942000', 'Vente de Billetterie: BRUNET DOMINIQUE pour la prestation CHARLIE HEBDO', '', '6'),
(185, '24745278', '1425942000', 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation CHARLIE HEBDO', '', '6'),
(186, '64707700', '1425942000', 'Vente de Billetterie: PILLARD ISABELLE pour la prestation CHARLIE HEBDO', '', '6'),
(187, '75633744', '1425942000', 'Vente de Billetterie: FOUGERI ANNIE pour la prestation CHARLIE HEBDO', '', '6'),
(188, '16124366', '1425942000', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation CHARLIE HEBDO', '', '6'),
(189, '51215389', '1425942000', 'Vente de Billetterie: BAULU CATHERINE pour la prestation CHARLIE HEBDO', '', '6'),
(190, '91945333', '1425942000', 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation CHARLIE HEBDO', '', '6'),
(191, '85210311', '1425942000', 'Vente de Billetterie: HANQUART SANDRA pour la prestation CHARLIE HEBDO', '', '3'),
(192, '48633428', '1425942000', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation CHARLIE HEBDO', '', '3'),
(193, '63016188', '1425942000', 'Vente de Billetterie: AUDIC GAELLE pour la prestation CHARLIE HEBDO', '', '6'),
(194, '31132058', '1425942000', 'Vente de Billetterie: NEGRI BRIGITTE pour la prestation CHARLIE HEBDO', '', '6'),
(195, '6777589', '1425942000', 'Vente de Billetterie: JOUBERT KARINE pour la prestation CHARLIE HEBDO', '', '6'),
(196, '13090392', '1425942000', 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation CHARLIE HEBDO', '', '6'),
(197, '61360544', '1425942000', 'Vente de Billetterie: CROS SEVERINE pour la prestation CHARLIE HEBDO', '', '3'),
(198, '70083078', '1425942000', 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation CHARLIE HEBDO', '', '3'),
(199, '32806862', '1425942000', 'Vente de Billetterie: BOUDAUD VIRGINIE pour la prestation CHARLIE HEBDO', '', '6'),
(200, '49065071', '1425942000', 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation CHARLIE HEBDO', '', '6'),
(201, '75220921', '1425942000', 'Vente de Billetterie: MOTTEAU Thierry pour la prestation CHARLIE HEBDO', '', '6'),
(202, '55183117', '1425942000', 'Vente de Billetterie: CARTRON OLIVIER pour la prestation CHARLIE HEBDO', '', '6'),
(203, '40627513', '1425942000', 'Vente de Billetterie: KERBOURCH FLORENT pour la prestation CHARLIE HEBDO', '', '6'),
(204, '83343185', '1425942000', 'Vente de Billetterie: VALLEE KARINE pour la prestation CHARLIE HEBDO', '', '3'),
(205, '97735416', '1425942000', 'Vente de Billetterie: ADAM STEPHANE pour la prestation CHARLIE HEBDO', '', '6'),
(206, '94135703', '1425942000', 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation CHARLIE HEBDO', '', '114'),
(208, '8479379', '1427151600', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation ANCV', '', '0'),
(209, '49882624', '1427151600', 'Vente de Billetterie: AUDIC GAELLE pour la prestation ANCV', '', '0'),
(210, '93697071', '1427151600', 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation ANCV', '', '0'),
(211, '97247732', '1427151600', 'Vente de Billetterie: BADOUR STEPHANE pour la prestation ANCV', '', '0'),
(212, '30993821', '1427151600', 'Vente de Billetterie: BAULU CATHERINE pour la prestation ANCV', '', '0'),
(213, '24977592', '1427151600', 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation ANCV', '', '0'),
(214, '20189309', '1427151600', 'Vente de Billetterie: BERGERET STEPHANE pour la prestation ANCV', '', '0'),
(215, '59163041', '1427151600', 'Vente de Billetterie: BLEJAN CHRISTIAN pour la prestation ANCV', '', '0'),
(216, '75688351', '1427151600', 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation ANCV', '', '0'),
(217, '3338363', '1427151600', 'Vente de Billetterie: BOUDAUD VIRGINIE pour la prestation ANCV', '', '0'),
(218, '53448053', '1427151600', 'Vente de Billetterie: BOUFAQOUS ABDELJALIL pour la prestation ANCV', '', '0'),
(219, '43027788', '1427151600', 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation ANCV', '', '0'),
(220, '79192664', '1427151600', 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation ANCV', '', '0'),
(221, '159702', '1427151600', 'Vente de Billetterie: BRUNET DOMINIQUE pour la prestation ANCV', '', '0'),
(222, '57819881', '1427151600', 'Vente de Billetterie: CERIBAS FILIZ pour la prestation ANCV', '', '0'),
(223, '91009880', '1427151600', 'Vente de Billetterie: CARTRON OLIVIER pour la prestation ANCV', '', '0'),
(224, '62011560', '1427151600', 'Vente de Billetterie: CARUSO SYLVANA pour la prestation ANCV', '', '0'),
(225, '79127592', '1427151600', 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation ANCV', '', '0'),
(226, '5003578', '1427151600', 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation ANCV', '', '0'),
(227, '80616188', '1427151600', 'Vente de Billetterie: CHAPEAU OLIVIER pour la prestation ANCV', '', '0'),
(228, '14778122', '1427151600', 'Vente de Billetterie: CLEMENT CHRISTOPHE pour la prestation ANCV', '', '0'),
(229, '81034255', '1427151600', 'Vente de Billetterie: CHAFFIN Mireille pour la prestation ANCV', '', '0'),
(230, '24663597', '1427151600', 'Vente de Billetterie: CHESNEL Brigitte pour la prestation ANCV', '', '0'),
(231, '42823596', '1427151600', 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation ANCV', '', '0'),
(232, '11305967', '1427151600', 'Vente de Billetterie: COSNIER CHRISTOPHE pour la prestation ANCV', '', '0'),
(233, '19334189', '1427151600', 'Vente de Billetterie: COUINET SOLEN pour la prestation ANCV', '', '0'),
(234, '17076540', '1427151600', 'Vente de Billetterie: CRIBIER EMILIE pour la prestation ANCV', '', '0'),
(235, '45701470', '1427151600', 'Vente de Billetterie: CROS SEVERINE pour la prestation ANCV', '', '0'),
(236, '51048573', '1427151600', 'Vente de Billetterie: DASYLVA JEAN-PIERRE pour la prestation ANCV', '', '0'),
(237, '66264316', '1427151600', 'Vente de Billetterie: DAGUENE FRANCOISE pour la prestation ANCV', '', '0'),
(238, '91888070', '1427151600', 'Vente de Billetterie: DAVID ARMEL pour la prestation ANCV', '', '0'),
(239, '87350808', '1427151600', 'Vente de Billetterie: DAVY ANTOINE pour la prestation ANCV', '', '0'),
(240, '57507241', '1427151600', 'Vente de Billetterie: DAGUER St?phane pour la prestation ANCV', '', '0'),
(241, '78800495', '1427151600', 'Vente de Billetterie: DELPHIN SEBASTIEN pour la prestation ANCV', '', '0'),
(242, '68038015', '1427151600', 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation ANCV', '', '0'),
(243, '94066706', '1427151600', 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation ANCV', '', '0'),
(244, '32904556', '1427151600', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation ANCV', '', '0'),
(245, '27537106', '1427151600', 'Vente de Billetterie: DROUIN DIDIER pour la prestation ANCV', '', '0'),
(246, '42322294', '1427151600', 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation ANCV', '', '0'),
(247, '46932091', '1427151600', 'Vente de Billetterie: FOUGERI ANNIE pour la prestation ANCV', '', '0'),
(248, '19654332', '1427151600', 'Vente de Billetterie: FOURNIER MARIO pour la prestation ANCV', '', '0'),
(249, '69719070', '1427151600', 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation ANCV', '', '0'),
(250, '45453025', '1427151600', 'Vente de Billetterie: GALLET STEPHANE pour la prestation ANCV', '', '0'),
(251, '36445874', '1427151600', 'Vente de Billetterie: GARNIER DAVID pour la prestation ANCV', '', '0'),
(252, '10841302', '1427151600', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation ANCV', '', '0'),
(253, '13993517', '1427151600', 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation ANCV', '', '0'),
(254, '2138763', '1427151600', 'Vente de Billetterie: GUERIN HUGUETTE pour la prestation ANCV', '', '0'),
(255, '87282689', '1427151600', 'Vente de Billetterie: GUERIN JOHNNY pour la prestation ANCV', '', '0'),
(256, '58203426', '1427151600', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation ANCV', '', '0'),
(257, '76864041', '1427151600', 'Vente de Billetterie: GUERTIN NOEL pour la prestation ANCV', '', '0'),
(258, '36439926', '1427151600', 'Vente de Billetterie: GUYADER YOHANN pour la prestation ANCV', '', '0'),
(259, '34538179', '1427151600', 'Vente de Billetterie: HANQUART SANDRA pour la prestation ANCV', '', '0'),
(260, '35962979', '1427151600', 'Vente de Billetterie: HAULBERT VINCENT pour la prestation ANCV', '', '0'),
(261, '8927745', '1427151600', 'Vente de Billetterie: KOCH NATHALIE pour la prestation ANCV', '', '0'),
(262, '76885985', '1427151600', 'Vente de Billetterie: IDDER MEHDI pour la prestation ANCV', '', '0'),
(263, '18280906', '1427151600', 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation ANCV', '', '0'),
(264, '3562170', '1427151600', 'Vente de Billetterie: KERBOURCH FLORENT pour la prestation ANCV', '', '0'),
(265, '39033078', '1427151600', 'Vente de Billetterie: JOUBERT KARINE pour la prestation ANCV', '', '0'),
(266, '3622185', '1427151600', 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation ANCV', '', '0'),
(267, '33020021', '1427151600', 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation ANCV', '', '0'),
(268, '51689716', '1427151600', 'Vente de Billetterie: LUBIN MICHEL pour la prestation ANCV', '', '0'),
(269, '47254636', '1427151600', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation ANCV', '', '0'),
(270, '56687340', '1427151600', 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation ANCV', '', '0'),
(271, '43863993', '1427151600', 'Vente de Billetterie: MARTIN PATRICIA pour la prestation ANCV', '', '0'),
(272, '39135385', '1427151600', 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation ANCV', '', '0'),
(273, '73992271', '1427151600', 'Vente de Billetterie: MOTTEAU Thierry pour la prestation ANCV', '', '0'),
(274, '10736636', '1427151600', 'Vente de Billetterie: MESLET THIERRY pour la prestation ANCV', '', '0'),
(275, '14983785', '1427151600', 'Vente de Billetterie: MORTIER FREDERIC pour la prestation ANCV', '', '0'),
(276, '55596080', '1427151600', 'Vente de Billetterie: NIANGORAN Oura Severin pour la prestation ANCV', '', '0'),
(277, '10163521', '1427151600', 'Vente de Billetterie: NEGRI BRIGITTE pour la prestation ANCV', '', '0'),
(278, '80797451', '1427151600', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation ANCV', '', '0'),
(279, '75840471', '1427151600', 'Vente de Billetterie: PASCAL LIONEL pour la prestation ANCV', '', '0'),
(280, '26519796', '1427151600', 'Vente de Billetterie: PECOT THIERRY pour la prestation ANCV', '', '0'),
(281, '57742559', '1427151600', 'Vente de Billetterie: PERGER ASTRID pour la prestation ANCV', '', '0'),
(282, '84260926', '1427151600', 'Vente de Billetterie: PILLARD ISABELLE pour la prestation ANCV', '', '0'),
(283, '60444437', '1427151600', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation ANCV', '', '0'),
(284, '36379633', '1427151600', 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation ANCV', '', '0'),
(285, '20690905', '1427151600', 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation ANCV', '', '0'),
(286, '86013461', '1427151600', 'Vente de Billetterie: RICHOMME HERVE pour la prestation ANCV', '', '0'),
(287, '23654142', '1427151600', 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation ANCV', '', '0'),
(288, '15607057', '1427151600', 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation ANCV', '', '0'),
(289, '36813535', '1427151600', 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation ANCV', '', '0'),
(290, '7378713', '1427151600', 'Vente de Billetterie: VALLEE KARINE pour la prestation ANCV', '', '0'),
(291, '8641962', '1427151600', 'Vente de Billetterie: SALAUN ANDRE pour la prestation ANCV', '', '0'),
(292, '46964535', '1427151600', 'Vente de Billetterie: SUREAU LYDIE pour la prestation ANCV', '', '0'),
(328, '2866321090', '1431295200', 'SOLDE SUBVENTION 2015 (budget 2014)', '', '1.10'),
(332, '22704853', '1430776800', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation Mobil home 120', '', '120'),
(333, '99466543', '1424127600', 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '321'),
(334, '38968883', '1424127600', 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation vente parfums', '', '163'),
(335, '54329905', '1420153200', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280'),
(336, '70503049', '1420153200', 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation Mobil Home 140', '', '140'),
(337, '83272284', '1420153200', 'Vente de Billetterie: CLEMENT CHRISTOPHE pour la prestation Mobil Home 140', '', '280'),
(338, '24717805', '1420153200', 'Vente de Billetterie: COSNIER CHRISTOPHE pour la prestation Mobil Home 140', '', '140'),
(339, '83446436', '1420153200', 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation Mobil Home 140', '', '140'),
(340, '46414316', '1420153200', 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation Mobil Home 140', '', '280'),
(341, '76223985', '1429048800', 'Vente de Billetterie: CLOUET Emilie pour la prestation Mobil Home 140', '', '140'),
(342, '95013897', '1429048800', 'Vente de Billetterie: JOUBERT KARINE pour la prestation Mobil Home 140', '', '140'),
(343, '92941828', '1421276400', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation Mobil Home 140', '', '140'),
(344, '91005854', '1428616800', 'Vente de Billetterie: COUINET SOLEN pour la prestation Mobil Home 140', '', '140'),
(345, '56221445', '1421276400', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation Mobil Home 140', '', '280'),
(346, '36087532', '1428616800', 'Vente de Billetterie: CROS SEVERINE pour la prestation Mobil Home 140', '', '140'),
(347, '84147055', '1428616800', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140'),
(348, '47246505', '1428616800', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '280'),
(349, '20883318', '1421276400', 'Vente de Billetterie: GUERIN JOHNNY pour la prestation Mobil Home 140', '', '140'),
(350, '26518598', '1429048800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280'),
(351, '4169744', '1429048800', 'Vente de Billetterie: GALLET STEPHANE pour la prestation Mobil Home 140', '', '140'),
(352, '83401100', '1429048800', 'Vente de Billetterie: GALLET STEPHANE pour la prestation Mobil Home 140', '', '140'),
(353, '14936841', '1429048800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140'),
(354, '32434769', '1429048800', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140'),
(355, '27126414', '1429048800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140'),
(356, '27964394', '1429048800', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation Mobil Home 140', '', '140'),
(357, '84614899', '1429048800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140'),
(358, '13890845', '1429048800', 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation Mobil Home 140', '', '140'),
(359, '56467682', '1429048800', 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation Mobil Home 140', '', '280'),
(360, '96086758', '1429048800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280'),
(361, '36219443', '1429048800', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140'),
(362, '33350447', '1429048800', 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation Mobil Home 140', '', '280'),
(363, '87401578', '1429048800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '280'),
(364, '43837257', '1430517600', 'Vente de Billetterie: IDDER MEHDI pour la prestation vente parfums', '', '187'),
(365, '95691609', '1431208800', 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation vente parfums', '', '39'),
(366, '28668247', '1431208800', 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation vente parfums', '', '59'),
(367, '65780771', '1431208800', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '47'),
(368, '15108811', '1431208800', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '88'),
(369, '37001892', '1431208800', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '70'),
(370, '40260497', '1431208800', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '47'),
(371, '93699737', '1431208800', 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '48'),
(372, '11350408', '1431208800', 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '50'),
(373, '90254930', '1431208800', 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '63'),
(374, '40800676', '1431208800', 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '133'),
(375, '56948978', '1431208800', 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '69'),
(376, '2695252', '1431208800', 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '145'),
(377, '42158759', '1431208800', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation vente parfums', '', '117'),
(378, '19519094', '1428962400', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation Mobil Home 140', '', '140'),
(379, '89781454', '1432072800', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140'),
(380, '66872676', '1431640800', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140'),
(381, '43279116', '1431640800', 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation Mobil Home 140', '', '280'),
(382, '2498617', '1431640800', 'Vente de Billetterie: AUDIC GAELLE pour la prestation Mobil Home 140', '', '140'),
(383, '59737801', '1431208800', 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '221'),
(384, '75261277', '1431208800', 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '76'),
(385, '9397852', '1431208800', 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation vente parfums', '', '61'),
(386, '74124673', '1431208800', 'Vente de Billetterie: GUYADER YOHANN pour la prestation vente parfums', '', '93'),
(387, '61693184', '1431208800', 'Vente de Billetterie: FOUGERI ANNIE pour la prestation vente parfums', '', '46'),
(388, '1896277', '1431208800', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation vente parfums', '', '64'),
(389, '54861570', '1431208800', 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation vente parfums', '', '96'),
(390, '37293044', '1431208800', 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '56'),
(394, '889982583001', '1433196000', 'Remboursement de la Prestation pour MACKOWSKI CORINE - ALLOCATION VACANCE', '150', ''),
(395, '612524654716', '1433196000', 'Remboursement de la Prestation pour MARTIN PATRICIA - ALLOCATION VACANCE', '150', ''),
(396, '6984846322', '1433196000', 'Remboursement de la Prestation pour BERGERET STEPHANE ALLOCATION LOISIRS', '50', ''),
(397, '5033455626', '1433196000', 'Remboursement de la Prestation pour CHALOPIN BERNADETTE ALLOCATION LOISIRS', '49.80', ''),
(398, '8280871194', '1433196000', 'Remboursement de la Prestation pour MARTIN PATRICIA ALLOCATION LOISIRS', '50', ''),
(405, '000001', '1425970800', 'Vente de Billetterie: BADOUR STEPHANE pour la prestation CHARLIE HEBDO', '', '6'),
(406, '000002', '1425970800', 'Vente de Billetterie: CLOUET EMILIE pour la prestation CHARLIE HEBDO', '', '6'),
(407, '000003', '1425970800', 'Vente de Billetterie: CHAPEAU OLIVIER pour la prestation CHARLIE HEBDO', '', '6'),
(408, '00004', '1425970800', 'Vente de Billetterie: GARNIER DAVID pour la prestation CHARLIE HEBDO', '', '6'),
(409, '000005', '1425970800', 'Vente de Billetterie: MARSAULT FRANCOIS pour la prestation CHARLIE HEBDO', '', '6'),
(410, '000006', '1425970800', 'Vente de Billetterie: CLEMENT CHRISTOPHE pour la prestation CHARLIE HEBDO', '', '6'),
(411, '000007', '1425970800', 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation CHARLIE HEBDO', '', '6'),
(412, '000008', '1425970800', 'Vente de Billetterie: CARUSO SYLVANA pour la prestation CHARLIE HEBDO', '', '6'),
(413, '000009', '1425970800', 'Vente de Billetterie: BERGER ASTRID pour la prestation CHARLIE HEBDO', '', '6'),
(414, '000010', '1425970800', 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation CHARLIE HEBDO', '', '6'),
(415, '438415773213', '1434319200', 'Remboursement de la Prestation pour CHALOPIN BERNADETTE - alllocation vacance ', '150', ''),
(416, '16831546091', '1434319200', 'Remboursement de la Prestation pour ROUFFIAC CHRISTOPHE - alllocation vacance ', '150', ''),
(417, '8886342398', '1434319200', 'Remboursement de la Prestation pour FOUNIER MARIO ALLOCATION LOISIRS - ALLOCATION LOISIRS', '42', ''),
(418, '586332703', '1434319200', 'Remboursement de la Prestation pour GALLET STEPHANE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(419, '4950911482', '1434319200', 'Remboursement de la Prestation pour KOCH NATHALIE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(420, '51282607', '1420066800', 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(421, '79129670', '1420066800', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation cin&eacute;ma 2015', '', '24'),
(422, '39684921', '1420066800', 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation cin&eacute;ma 2015', '', '24'),
(423, '64360491', '1420066800', 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation cin&eacute;ma 2015', '', '24'),
(424, '74780411', '1420066800', 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation cin&eacute;ma 2015', '', '24'),
(425, '57593944', '1420066800', 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30'),
(426, '21886527', '1420066800', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation cin&eacute;ma 2015', '', '24'),
(427, '62962139', '1420066800', 'Vente de Billetterie: BAULU CATHERINE pour la prestation cin&eacute;ma 2015', '', '24'),
(428, '17527469', '1420066800', 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30'),
(429, '91024312', '1420066800', 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation cin&eacute;ma 2015', '', '24'),
(430, '21228151', '1420066800', 'Vente de Billetterie: IDDER MEHDI pour la prestation cin&eacute;ma 2015', '', '24'),
(431, '85617058', '1420066800', 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation cin&eacute;ma 2015', '', '12'),
(432, '34440248', '1420066800', 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation cin&eacute;ma 2015', '', '12'),
(433, '36062617', '1420066800', 'Vente de Billetterie: RICHOMME HERVE pour la prestation cin&eacute;ma 2015', '', '24'),
(439, '65905228', '1422745200', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation cin&eacute;ma 2015', '', '18'),
(440, '98735446', '1422745200', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24'),
(441, '3565326', '1422745200', 'Vente de Billetterie: GARNIER DAVID pour la prestation cin&eacute;ma 2015', '', '30'),
(442, '66058938', '1422745200', 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation cin&eacute;ma 2015', '', '48'),
(443, '23811416', '1422745200', 'Vente de Billetterie: MESLET THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(444, '5090115', '1422745200', 'Vente de Billetterie: CLOUET Emilie pour la prestation cin&eacute;ma 2015', '', '18'),
(445, '93018735', '1422745200', 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation cin&eacute;ma 2015', '', '42'),
(446, '48142725', '1422745200', 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation cin&eacute;ma 2015', '', '24'),
(447, '5191271', '1422745200', 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation cin&eacute;ma 2015', '', '12'),
(448, '50685941', '1422745200', 'Vente de Billetterie: JANIN SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24'),
(449, '84155268', '1422745200', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation cin&eacute;ma 2015', '', '24'),
(450, '16726167', '1422745200', 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation cin&eacute;ma 2015', '', '24'),
(451, '1923109', '1422745200', 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation cin&eacute;ma 2015', '', '24'),
(452, '48961877', '1422745200', 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(453, '73405539', '1422745200', 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation cin&eacute;ma 2015', '', '24'),
(454, '93579470', '1422745200', 'Vente de Billetterie: MOTTEAU Thierry pour la prestation cin&eacute;ma 2015', '', '24'),
(455, '84045960', '1422745200', 'Vente de Billetterie: CROS SEVERINE pour la prestation cin&eacute;ma 2015', '', '24'),
(456, '33707857', '1422745200', 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation cin&eacute;ma 2015', '', '24'),
(457, '70486482', '1423954800', 'Vente de Billetterie: MORTIER FREDERIC pour la prestation cin&eacute;ma 2015', '', '24'),
(458, '22566591', '1423954800', 'Vente de Billetterie: AUDIC GAELLE pour la prestation cin&eacute;ma 2015', '', '18'),
(459, '76658017', '1423954800', 'Vente de Billetterie: VALLEE KARINE pour la prestation cin&eacute;ma 2015', '', '12'),
(460, '47461529', '1423954800', 'Vente de Billetterie: GUERTIN NOEL pour la prestation cin&eacute;ma 2015', '', '24'),
(461, '30433642', '1423954800', 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation cin&eacute;ma 2015', '', '12'),
(462, '76414721', '1423954800', 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation cin&eacute;ma 2015', '', '24'),
(463, '6929080', '1423954800', 'Vente de Billetterie: GUYADER YOHANN pour la prestation cin&eacute;ma 2015', '', '36'),
(465, '60316808', '1426374000', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24'),
(466, '92400437', '1426374000', 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation cin&eacute;ma 2015', '', '24'),
(467, '44711276', '1426374000', 'Vente de Billetterie: CERIBAS FILIZ pour la prestation cin&eacute;ma 2015', '', '30'),
(468, '82099288', '1426374000', 'Vente de Billetterie: CHALOPIN BERNADETTE pour la prestation cin&eacute;ma 2015', '', '24'),
(469, '60431516', '1426374000', 'Vente de Billetterie: BERGERET STEPHANE pour la prestation cin&eacute;ma 2015', '', '12'),
(470, '8060080', '1426374000', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation cin&eacute;ma 2015', '', '24'),
(471, '77167360', '1426374000', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation cin&eacute;ma 2015', '', '24'),
(472, '53954817', '1426374000', 'Vente de Billetterie: AUDIC GAELLE pour la prestation cin&eacute;ma 2015', '', '24'),
(473, '97945720', '1429048800', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation cin&eacute;ma 2015', '', '24'),
(474, '58817256', '1429048800', 'Vente de Billetterie: CROS SEVERINE pour la prestation cin&eacute;ma 2015', '', '24'),
(475, '37333506', '1429048800', 'Vente de Billetterie: FOUGERI ANNIE pour la prestation cin&eacute;ma 2015', '', '24'),
(476, '90803018', '1429048800', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation cin&eacute;ma 2015', '', '24'),
(477, '54273009', '1429048800', 'Vente de Billetterie: HAULBERT VINCENT pour la prestation cin&eacute;ma 2015', '', '24'),
(478, '76573345', '1429048800', 'Vente de Billetterie: CRIBIER EMILIE pour la prestation cin&eacute;ma 2015', '', '12'),
(479, '31128959', '1429048800', 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation cin&eacute;ma 2015', '', '24'),
(480, '78953575', '1429048800', 'Vente de Billetterie: BERGERET STEPHANE pour la prestation cin&eacute;ma 2015', '', '24'),
(481, '3670390', '1429048800', 'Vente de Billetterie: GUYADER YOHANN pour la prestation cin&eacute;ma 2015', '', '36'),
(482, '38331041', '1429480800', 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation cin&eacute;ma 2015', '', '12'),
(483, '94391932', '1429480800', 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(484, '57322921', '1429480800', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation cin&eacute;ma 2015', '', '24'),
(485, '18386139', '1431640800', 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation cin&eacute;ma 2015', '', '12'),
(486, '27966879', '1431640800', 'Vente de Billetterie: GUYADER YOHANN pour la prestation cin&eacute;ma 2015', '', '24'),
(487, '44786894', '1431640800', 'Vente de Billetterie: IDDER MEHDI pour la prestation cin&eacute;ma 2015', '', '24'),
(488, '76915919', '1431640800', 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(489, '48400238', '1431640800', 'Vente de Billetterie: BERGERET STEPHANE pour la prestation cin&eacute;ma 2015', '', '24'),
(490, '66373148', '1431640800', 'Vente de Billetterie: DAVID ARMEL pour la prestation cin&eacute;ma 2015', '', '24'),
(491, '88263688', '1431640800', 'Vente de Billetterie: HAULBERT VINCENT pour la prestation cin&eacute;ma 2015', '', '24'),
(492, '72131237', '1431640800', 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30'),
(493, '91446764', '1431640800', 'Vente de Billetterie: IDDER MEHDI pour la prestation cin&eacute;ma 2015', '', '12'),
(494, '8836364937', '1435096800', 'Remboursement de la Prestation pour MACKOWSKI CORINE  ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(495, '3693116345', '1435096800', 'Remboursement de la Prestation pour BACHELOT CHRISTELLE ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(496, '421351411846', '1436652000', 'Remboursement de la Prestation pour DOUILLY OLIVIER - alloc vacance', '150', ''),
(497, '4050343218', '1437429600', 'Remboursement de la Prestation pour DOUILLY OLIVIER ALLOCATION LOISIRS - allocation loisirs', '50', ''),
(498, '903106779791', '1438034400', 'Remboursement de la Prestation pour GUERIN JOHNNY - alllocation vacance ', '150', ''),
(499, '400730542839', '1438034400', 'Remboursement de la Prestation pour LAURIOU MICKAEL - alllocation vacance ', '150', ''),
(500, '685626462567', '1438034400', 'Remboursement de la Prestation pour ROUAULT ANTHONY - alllocation vacance ', '150', ''),
(501, '999402718618', '1438034400', 'Remboursement de la Prestation pour CARUSO SYLVANA - alllocation vacance ', '150', ''),
(502, '323534653057', '1438034400', 'Remboursement de la Prestation pour DASYLVA JEAN-PIERRE - alllocation vacance ', '150', ''),
(503, '4209308610', '1438034400', 'Remboursement de la Prestation pour ROUAULT ANTHONY ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(504, '2507952159', '1438034400', 'Remboursement de la Prestation pour GUERRIAU MALIKA  ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(506, '644799424335', '1440367200', 'Remboursement de la Prestation pour SUREAU LYDIE - allocation vacance', '150', ''),
(507, '99525161088', '1440367200', 'Remboursement de la Prestation pour IDDER MEHDI - allocation vacance', '150', ''),
(508, '565350872930', '1440453600', 'Remboursement de la Prestation pour NEGRI BRIGITTE - allocation vacance', '150', ''),
(509, '420539968181', '1440453600', 'Remboursement de la Prestation pour KERBOURCH FLORENT - allocation vacance', '150', ''),
(510, '312499290798', '1440453600', 'Remboursement de la Prestation pour AUDIC GAELLE - allocation vacance', '150', ''),
(511, '513738993090', '1440453600', 'Remboursement de la Prestation pour MESLET THIERRY - allocation vacance', '150', ''),
(512, '625417531468', '1440453600', 'Remboursement de la Prestation pour BAULU CATHERINE - allocation vacance', '150', ''),
(513, '87278132327', '1440453600', 'Remboursement de la Prestation pour CRIBIER EMILIE - allocation vacance', '150', ''),
(514, '679863286204', '1440453600', 'Remboursement de la Prestation pour ROUSSEL PASCALE - allocation vacance', '150', ''),
(515, '888595257420', '1440453600', 'Remboursement de la Prestation pour MARCHAIS LAURENT - allocation vacance', '150', ''),
(516, '471647528932', '1440453600', 'Remboursement de la Prestation pour COUINET SOLEN - allocation vacance', '150', ''),
(517, '77512939461', '1440453600', 'Remboursement de la Prestation pour LUBIN MICHEL - allocation vacance', '150', ''),
(518, '9936326650', '1440453600', 'Remboursement de la Prestation pour BACHELOT CHRISTELLE - allocation vacance', '150', ''),
(519, '584448751993', '1440453600', 'Remboursement de la Prestation pour DESMARS VERONIQUE - allocation vacance', '150', ''),
(520, '163545305841', '1440453600', 'Remboursement de la Prestation pour HAULBERT VINCENT - allocation vacance', '150', ''),
(521, '40894807782', '1440453600', 'Remboursement de la Prestation pour CROS SEVERINE - allocation vacance', '150', ''),
(522, '239772253670', '1440453600', 'Remboursement de la Prestation pour JOUBERT KARINE - allocation vacance', '150', ''),
(523, '683775858953', '1440453600', 'Remboursement de la Prestation pour GALLET STEPHANE - allocation vacance', '150', ''),
(524, '7510536895', '1440540000', 'don de la direction concours de boules achat lots ', '', '250'),
(525, '847594105638', '1441058400', 'Remboursement de la Prestation pour DELPHIN SEBASTIEN - allocation vacance', '150', ''),
(526, '5751915742', '1441144800', 'Remboursement de la Prestation pour JANIN SEBASTIEN - allocation vacance', '150', ''),
(527, '454039545264', '1441144800', 'Remboursement de la Prestation pour GUERRIAU MALIKA - allocation vacance', '150', ''),
(528, '536473579705', '1441058400', 'Remboursement de la Prestation pour BOUVIER FREDERIC - allocation vacance', '150', ''),
(529, '259158585221', '1441058400', 'Remboursement de la Prestation pour KOCH NATHALIE - allocation vacance', '150', ''),
(530, '40721359198', '1441144800', 'Remboursement de la Prestation pour BOUDAUD VIRGINIE - allocation vacance', '150', ''),
(531, '780559918377', '1441058400', 'Remboursement de la Prestation pour BRANCHEREAU HERVE - allocation vacance', '150', ''),
(532, '319234014489', '1441058400', 'Remboursement de la Prestation pour MOTTEAU Thierry - allocation vacance', '150', ''),
(533, '571244949475', '1441058400', 'Remboursement de la Prestation pour FAUCHEUX FREDDY - allocation vacance', '150', ''),
(534, '481509226374', '1441058400', 'Remboursement de la Prestation pour ARMOURDOM LAURENT - allocation vacance', '150', ''),
(535, '238586999011', '1441058400', 'Remboursement de la Prestation pour CLEMENT OLIVIER - allocation vacance', '150', ''),
(536, '705041090', '1441058400', 'Remboursement de la Prestation pour BOUDEAU VIRGINIE ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(537, '2741586822', '1441058400', 'Remboursement de la Prestation pour GARNIER DAVID ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(538, '1428685626', '1441058400', 'Remboursement de la Prestation pour FRESNEAU VERONIQUE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(539, '4699004418', '1441058400', 'Remboursement de la Prestation pour FAUCHEUX FREDDY ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(540, '225719915238', '1441576800', 'Remboursement de la Prestation pour BERGERET STEPHANE - allocation vacance', '150', ''),
(541, '6836895565', '1441576800', 'Remboursement de la Prestation pour SUREAU LYDIE ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(542, '9294497575', '1441663200', 'Remboursement de la Prestation pour AUDIC GAELLE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(544, '97629744', '1441663200', 'Vente de Billetterie: DAGUER St?phane pour la prestation Concours de boules - MIXEUR', '', '0'),
(546, '16113822', '1436479200', 'Vente de Billetterie: BARRIERES AMANDINE pour la prestation cin&eacute;ma 2015', '', '12'),
(547, '67085243', '1436997600', 'Vente de Billetterie: GARNIER DAVID pour la prestation cin&eacute;ma 2015', '', '24'),
(548, '56393529', '1437602400', 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation cin&eacute;ma 2015', '', '24'),
(549, '29506070', '1438812000', 'Vente de Billetterie: MESLET THIERRY pour la prestation cin&eacute;ma 2015', '', '36'),
(550, '26358660', '1438812000', 'Vente de Billetterie: GUERTIN NOEL pour la prestation cin&eacute;ma 2015', '', '12'),
(551, '72812836', '1440453600', 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation cin&eacute;ma 2015', '', '12'),
(552, '68349084', '1433887200', 'Vente de Billetterie: FOURNIER MARIO pour la prestation cin&eacute;ma 2015', '', '6'),
(553, '83203092', '1434924000', 'Vente de Billetterie: CROS SEVERINE pour la prestation cin&eacute;ma 2015', '', '24'),
(554, '25001941', '1434492000', 'Vente de Billetterie: MOTTEAU Thierry pour la prestation cin&eacute;ma 2015', '', '24'),
(555, '58273290', '1435183200', 'Vente de Billetterie: NEGRI BRIGITTE pour la prestation cin&eacute;ma 2015', '', '24'),
(556, '36444209', '1433887200', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation cin&eacute;ma 2015', '', '24'),
(557, '72318495', '1434060000', 'Vente de Billetterie: JOUBERT KARINE pour la prestation cin&eacute;ma 2015', '', '12'),
(560, '54490717', '1437516000', 'Vente de Billetterie: BAULU CATHERINE pour la prestation cin&eacute;ma 2015', '', '24'),
(561, '83458012', '1437084000', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation cin&eacute;ma 2015', '', '24'),
(562, '71251061', '1437084000', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation cin&eacute;ma 2015', '', '24'),
(563, '23151142', '1437084000', 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation cin&eacute;ma 2015', '', '12'),
(564, '74741047', '1436479200', 'Vente de Billetterie: LUBIN MICHEL pour la prestation cin&eacute;ma 2015', '', '30'),
(565, '26302169', '1436392800', 'Vente de Billetterie: BRANCHEREAU HERVE pour la prestation cin&eacute;ma 2015', '', '24'),
(566, '79217448', '1436392800', 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation cin&eacute;ma 2015', '', '24'),
(567, '63853104', '1436392800', 'Vente de Billetterie: SUREAU LYDIE pour la prestation cin&eacute;ma 2015', '', '12'),
(568, '51888054', '1436392800', 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation cin&eacute;ma 2015', '', '24'),
(569, '17867403', '1436392800', 'Vente de Billetterie: KERBOURCH FLORENT pour la prestation cin&eacute;ma 2015', '', '24'),
(570, '25989343', '1436220000', 'Vente de Billetterie: DAGUER St?phane pour la prestation cin&eacute;ma 2015', '', '24'),
(571, '35934991', '1436133600', 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(572, '8929502', '1435788000', 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation cin&eacute;ma 2015', '', '24'),
(573, '96161978', '1435788000', 'Vente de Billetterie: BRUNET DOMINIQUE pour la prestation cin&eacute;ma 2015', '', '24'),
(574, '34372446', '1440712800', 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation cin&eacute;ma 2015', '', '6'),
(575, '26409362', '1440453600', 'Vente de Billetterie: MACKOWSKI CORINE pour la prestation cin&eacute;ma 2015', '', '24'),
(576, '28143541', '1439848800', 'Vente de Billetterie: PECOT THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(577, '58163654', '1438812000', 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation cin&eacute;ma 2015', '', '24'),
(578, '66895493', '1438812000', 'Vente de Billetterie: BOIVIN VERONIQUE pour la prestation cin&eacute;ma 2015', '', '12'),
(579, '43007147', '1439848800', 'Vente de Billetterie: GUERIN JOHNNY pour la prestation cin&eacute;ma 2015', '', '24'),
(580, '81027120', '1439848800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation cin&eacute;ma 2015', '', '24'),
(581, '914618178736', '1441231200', 'Remboursement de la Prestation pour PILLARD ISABELLE - allocation vacance', '150', ''),
(582, '6501609310', '1441836000', 'Remboursement de la Prestation pour HAULBERT VINCENT ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(583, '8153159632', '1441144800', 'Remboursement de la Prestation pour GAULTIER SEBASTIEN ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(584, '9475106336', '1441231200', 'Remboursement de la Prestation pour GREFFIER ARNAUD ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(585, '66897190', '1441663200', 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation Concours de boules - FRITEUSE', '', '0'),
(586, '29624657', '1441663200', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation Concours de boules - CAFETIERE', '', '0'),
(587, '82272904', '1441663200', 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation Concours de boules - POELE', '', '0'),
(588, '46233333', '1441663200', 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation Concours de boules - KARCHER', '', '0'),
(589, '25862678', '1441663200', 'Vente de Billetterie: DROUIN DIDIER pour la prestation Concours de boules - Perceuse', '', '0'),
(590, '87103301', '1441663200', 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation Concours de boules - Couteaux', '', '0'),
(591, '28940623', '1441663200', 'Vente de Billetterie: DROUIN DIDIER pour la prestation Concours de boules - USTENSILE  CUISINE', '', '0'),
(592, '31605110', '1441663200', 'Vente de Billetterie: CHAPEAU OLIVIER pour la prestation Concours de boules - Tuyau Karcher', '', '0'),
(593, '67736922', '1441663200', 'Vente de Billetterie: DAGUER St?phane pour la prestation Concours de boules - TOASTER', '', '0'),
(594, '30759278', '1441663200', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation Concours de boules - BOUILLOIRE', '', '0'),
(595, '55487353', '1441663200', 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation Concours de boules - Balance cuisine', '', '0'),
(596, '8483222', '1441663200', 'Vente de Billetterie: IDDER MEHDI pour la prestation Concours de boules - Haut parleur', '', '0'),
(597, '98975262', '1441663200', 'Vente de Billetterie: NIANGORAN Oura Severin pour la prestation Concours de boules - Haut parleur', '', '0'),
(598, '47551203', '1441663200', 'Vente de Billetterie: IDDER MEHDI pour la prestation Concours de boules - Blender', '', '0'),
(599, '29507336', '1441663200', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation Concours de boules - Mixeur', '', '0'),
(600, '84859217', '1441663200', 'Vente de Billetterie: NIANGORAN Oura Severin pour la prestation Concours de boules - Tuyau eau', '', '0'),
(601, '64756491', '1441663200', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation Concours de boules - Tournevis', '', '0'),
(602, '65282587', '1441663200', 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation Concours de boules - Bon achat Leroy', '', '0'),
(603, '85594598', '1441663200', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Concours de boules - Fondue', '', '0'),
(604, '74254500', '1441663200', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Concours de boules - Croque monsieur', '', '0'),
(605, '96677038', '1441663200', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation Concours de boules - Ricard', '', '0'),
(606, '27220252', '1441663200', 'Vente de Billetterie: CLEMENT OLIVIER pour la prestation Concours de boules - 2 WE MOBIL HOME', '', '0'),
(607, '89336531', '1441663200', 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation Concours de boules - Bon achat DECATHLON', '', '0'),
(608, '45659438', '1441663200', 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation Concours de boules - Bon achat DECATHLON', '', '0'),
(610, '51214610', '1441663200', 'Vente de Billetterie: FAUCHEUX FREDDY pour la prestation Concours de boules - Bon d achat super U', '', '0'),
(611, '56748610', '1441663200', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation Concours de boules - 2 bons achat super U de 40', '', '0'),
(612, '70507603', '1441663200', 'Vente de Billetterie: LAURIOU MICKAEL pour la prestation Concours de boules - Bon achat  super U', '', '0'),
(613, '40495308', '1441663200', 'Vente de Billetterie: DROUIN DIDIER pour la prestation Concours de boules - Bon achat super U', '', '0'),
(614, '36296409', '1441663200', 'Vente de Billetterie: POUPAULT ISABELLE pour la prestation Concours de boules - 2 bons achat super U', '', '0'),
(615, '24701546', '1441663200', 'Vente de Billetterie: IDDER MEHDI pour la prestation Concours de boules - Bon achat super U', '', '0'),
(616, '25630849', '1441663200', 'Vente de Billetterie: LEVRON Jean Louis pour la prestation Concours de boules - KARCHER', '', '0'),
(617, '37359359', '1441663200', 'Vente de Billetterie: VERMELUN Christian pour la prestation Concours de boules', '', '0'),
(618, '91024544', '1441663200', 'Vente de Billetterie: LEVRON Jean Louis pour la prestation Concours de boules - WHYSKY', '', '0'),
(619, '20578087', '1441663200', 'Vente de Billetterie: VERMELUN Christian pour la prestation Concours de boules - RICARD', '', '0'),
(620, '4969886597', '1441663200', 'HIPPIE FANNY REPAS CONCOURS DE BOULES', '400', ''),
(621, '451765113510', '1442786400', 'Remboursement de la Prestation pour BRUNET DOMINIQUE - allocation vacance', '150', ''),
(622, '77137953137', '1442786400', 'Remboursement de la Prestation pour GAULTIER SEBASTIEN - allocation vacance', '150', ''),
(623, '299420020543', '1442786400', 'Remboursement de la Prestation pour HANQUART SANDRA - allocation vacance', '150', ''),
(624, '330027887132', '1442786400', 'Remboursement de la Prestation pour ONILLON PATRICIA - allocation vacance', '150', ''),
(625, '724870459176', '1442786400', 'Remboursement de la Prestation pour FOUGERI ANNIE - allocation vacance', '150', ''),
(626, '68782654591', '1442786400', 'Remboursement de la Prestation pour MARSAULT FRANCOISE - allocation vacance', '150', ''),
(627, '380398741458', '1442786400', 'Remboursement de la Prestation pour CLEMENT CHRISTOPHE - allocation vacance', '140.28', ''),
(628, '9059728528', '1442786400', 'Remboursement de la Prestation pour CLEMENT CHRISTOPHE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(629, '9348237318', '1442786400', 'Remboursement de la Prestation pour kerbourch allocation loisirs - ALLOCATION LOISIRS', '50', ''),
(630, '5618958501', '1442786400', 'Achat - Mobil Home 140', '420', ''),
(631, '95490643', '1441663200', 'Vente de Billetterie: RAGOT VIRGINIE pour la prestation Concours de boules - BLENDER', '', '0'),
(632, '6469923663', '1441663200', 'ACHATS LOTS CONCOURS DE BOULES', '1232.58', ''),
(633, '799762269947', '1443477600', 'Remboursement de la Prestation pour CHESNEL Brigitte - allocation vacance', '150', '');
INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(634, '562917870469', '1443477600', 'Remboursement de la Prestation pour DAGUENE FRANCOISE - allocation vacance', '150', ''),
(635, '845400576014', '1443477600', 'Remboursement de la Prestation pour MORTIER FREDERIC - allocation vacance', '150', ''),
(636, '3178855488', '1443477600', 'Remboursement de la Prestation pour CROS SEVERINE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(637, '9789497838', '1443477600', 'Remboursement de la Prestation pour FOUGERI ANNE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(638, '709789256', '1443477600', 'Remboursement de la Prestation pour ROUFFIAC CHRISTOPHE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(639, '90203574', '1442786400', 'Vente de Billetterie: MESLET THIERRY pour la prestation cin&eacute;ma 2015', '', '12'),
(640, '94232139', '1442786400', 'Vente de Billetterie: FOURNIER MARIO pour la prestation cin&eacute;ma 2015', '', '24'),
(641, '44395444', '1442786400', 'Vente de Billetterie: MARCHAIS LAURENT pour la prestation cin&eacute;ma 2015', '', '24'),
(642, '39155593', '1442786400', 'Vente de Billetterie: MOTTEAU Thierry pour la prestation cin&eacute;ma 2015', '', '24'),
(643, '2081150296', '1443477600', 'Achat - CINEMA 8.10', '1215', ''),
(644, '90894694', '1441663200', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation PAPEA', '', '72'),
(645, '48346952', '1441663200', 'Vente de Billetterie: DINGREVILLE ALINE pour la prestation PAPEA', '', '48'),
(646, '2205404', '1441663200', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation PAPEA', '', '36'),
(647, '10223465', '1443650400', 'Vente de Billetterie: VERMELUN Christian pour la prestation Mobil Home 140', '', '140'),
(648, '43611251', '1443650400', 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation Mobil Home 140', '', '140'),
(649, '88961358', '1443650400', 'Vente de Billetterie: PECOT THIERRY pour la prestation Mobil Home 140', '', '280'),
(650, '61269797', '1443650400', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140'),
(651, '49639855', '1443650400', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation Mobil Home 140', '', '140'),
(652, '22236582', '1443650400', 'Vente de Billetterie: PECOT THIERRY pour la prestation Mobil Home 140', '', '140'),
(653, '76450508', '1443650400', 'Vente de Billetterie: PECOT THIERRY pour la prestation Mobil Home 140', '', '140'),
(654, '902611814905', '1443736800', 'Remboursement de la Prestation pour VALLEE KARINE - allocation vacance', '150', ''),
(655, '663407182321', '1443736800', 'Remboursement de la Prestation pour RICHOMME HERVE - allocation vacance', '150', ''),
(656, '216121441685', '1443736800', 'Remboursement de la Prestation pour PERGER ASTRID - 79.30', '79.30', ''),
(657, '5949488841', '1443736800', 'Remboursement de la Prestation pour VALLEE KARINE ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(658, '4050949277', '1443736800', 'Remboursement de la Prestation pour PECOT THIERRY ALLOCATION LOISIRS - ALLOC LOISIRS ', '50', ''),
(659, '15607231', '1443736800', 'Vente de Billetterie: MESLET THIERRY pour la prestation CINEMA 8.10', '', '12'),
(660, '52890284', '1443736800', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation CINEMA 8.10', '', '12'),
(661, '18871054', '1443736800', 'Vente de Billetterie: IDDER MEHDI pour la prestation CINEMA 8.10', '', '12'),
(662, '19237128', '1443736800', 'Vente de Billetterie: GREFFIER ARNAUD pour la prestation CINEMA 8.10', '', '24'),
(663, '38521367', '1443736800', 'Vente de Billetterie: HAULBERT VINCENT pour la prestation CINEMA 8.10', '', '24'),
(664, '68559812', '1443736800', 'Vente de Billetterie: MARTIN PATRICIA pour la prestation CINEMA 8.10', '', '24'),
(665, '36767902', '1443736800', 'Vente de Billetterie: GUERIN JOHNNY pour la prestation CINEMA 8.10', '', '24'),
(666, '91220172', '1443736800', 'Vente de Billetterie: CROS SEVERINE pour la prestation CINEMA 8.10', '', '24'),
(667, '357426176779', '1443650400', 'Remboursement de la Prestation pour CHAPEAU OLIVIER - allocation vacance', '150', ''),
(668, '122393353843', '1443823200', 'Remboursement de la Prestation pour BADOUR STEPHANE - allocation vacance', '130', ''),
(669, '8968575764', '1443736800', 'Remboursement de la Prestation pour BARRIERES AMANDINE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(670, '799871600', '1445292000', 'Remboursement de la Prestation pour MORTIER FREDERIC ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(671, '247338373', '1445292000', 'Remboursement de la Prestation pour DAGUENE FRANCOISE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '32', ''),
(672, '6609840537', '1445292000', 'Remboursement de la Prestation pour DASYLVA JEAN PIERRE ALLOCATION LOISIRS - ALLOCATION LOISIRS', '44', ''),
(673, '404292350', '1445292000', 'Remboursement de la Prestation pour DROUIN DIDIER ALLOCATION LOISIRS - ALLOCATION LOISIRS', '50', ''),
(674, '5883693043', '1445292000', 'Achat - vente parfums', '1425', ''),
(675, '30480582', '1445292000', 'Vente de Billetterie: BACHELOT CHRISTELLE pour la prestation vente parfums', '', '74'),
(676, '13430460', '1445292000', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '47'),
(678, '21750440', '1445292000', 'Vente de Billetterie: BAULU CATHERINE pour la prestation vente parfums', '', '79'),
(679, '59141813', '1445292000', 'Vente de Billetterie: FRESNEAU VERONIQUE pour la prestation vente parfums', '', '106'),
(680, '54376067', '1445292000', 'Vente de Billetterie: ONILLON PATRICIA pour la prestation vente parfums', '', '62'),
(681, '25923048', '1445292000', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '68'),
(682, '50521710', '1445292000', 'Vente de Billetterie: ROUSSEL PASCALE pour la prestation vente parfums', '', '76'),
(683, '40097634', '1445292000', 'Vente de Billetterie: BOUDAUD VIRGINIE pour la prestation vente parfums', '', '47'),
(684, '48638718', '1445292000', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation vente parfums', '', '187'),
(685, '17738159', '1445292000', 'Vente de Billetterie: DESMARS VERONIQUE pour la prestation vente parfums', '', '436'),
(686, '59195284', '1445292000', 'Vente de Billetterie: GAULTIER SEBASTIEN pour la prestation vente parfums', '', '102'),
(687, '65258758', '1445292000', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation vente parfums', '', '54'),
(688, '89963425', '1445292000', 'Vente de Billetterie: DOUILLY OLIVIER pour la prestation vente parfums', '', '87'),
(689, '6342124119', '1445292000', 'Achat - vente parfums', '687', ''),
(690, '18400972', '1445292000', 'Vente de Billetterie: CERIBAS FILIZ pour la prestation vente parfums', '', '152'),
(691, '58938556', '1445292000', 'Vente de Billetterie: CERIBAS FILIZ pour la prestation vente parfums', '', '244'),
(692, '13089680', '1445292000', 'Vente de Billetterie: PECOT THIERRY pour la prestation vente parfums', '', '71'),
(694, '77232090', '1445292000', 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation vente parfums', '', '56'),
(695, '10649859', '1445292000', 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation vente parfums', '', '164'),
(696, '6101564', '1444168800', 'Vente de Billetterie: POIRRIER THIERRY pour la prestation CINEMA 8.10', '', '24'),
(697, '93949724', '1444687200', 'Vente de Billetterie: ROUAULT ANTHONY pour la prestation CINEMA 8.10', '', '12'),
(698, '1615334', '1444082400', 'Vente de Billetterie: CHAPLAIN ANGELINA pour la prestation CINEMA 8.10', '', '12'),
(699, '83482016', '1446332400', 'Vente de Billetterie: GUYADER YOHANN pour la prestation CINEMA 8.10', '', '24'),
(700, '63365946', '1446332400', 'Vente de Billetterie: ARMOURDOM LAURENT pour la prestation CINEMA 8.10', '', '24'),
(701, '48257728', '1446332400', 'Vente de Billetterie: AUDIC GAELLE pour la prestation CINEMA 8.10', '', '12'),
(702, '83520603', '1446332400', 'Vente de Billetterie: GARNIER DAVID pour la prestation CINEMA 8.10', '', '30'),
(703, '4708401', '1446332400', 'Vente de Billetterie: PIOU BENOIT pour la prestation CINEMA 8.10', '', '24'),
(704, '31593916', '1446332400', 'Vente de Billetterie: LEHOREAU WADA VIRGINIE pour la prestation CINEMA 8.10', '', '24'),
(705, '4470272', '1446332400', 'Vente de Billetterie: ROUFFIAC CHRISTOPHE pour la prestation CINEMA 8.10', '', '48'),
(706, '66493705', '1446332400', 'Vente de Billetterie: CERIBAS FILIZ pour la prestation CINEMA 8.10', '', '30'),
(707, '33782369', '1446332400', 'Vente de Billetterie: HANQUART SANDRA pour la prestation CINEMA 8.10', '', '24'),
(708, '1906217', '1446332400', 'Vente de Billetterie: RICHOMME HERVE pour la prestation CINEMA 8.10', '', '24'),
(709, '48597139', '1446332400', 'Vente de Billetterie: HAULBERT VINCENT pour la prestation CINEMA 8.10', '', '24'),
(710, '69515852', '1446332400', 'Vente de Billetterie: BOUVIER FREDERIC pour la prestation CINEMA 8.10', '', '12'),
(711, '90883384', '1446332400', 'Vente de Billetterie: CROS SEVERINE pour la prestation CINEMA 8.10', '', '24'),
(712, '13539760', '1446332400', 'Vente de Billetterie: MARSAULT FRANCOISE pour la prestation CINEMA 8.10', '', '24'),
(713, '23524402', '1446332400', 'Vente de Billetterie: VALLEE KARINE pour la prestation CINEMA 8.10', '', '24'),
(714, '75849186', '1446332400', 'Vente de Billetterie: GUERRIAU MALIKA pour la prestation CINEMA 8.10', '', '24'),
(715, '44444917', '1446332400', 'Vente de Billetterie: MARTIN PATRICIA pour la prestation CINEMA 8.10', '', '24'),
(716, '29432977', '1446332400', 'Vente de Billetterie: IDDER MEHDI pour la prestation CINEMA 8.10', '', '24'),
(717, '512463990133', '1446418800', 'Remboursement de la Prestation pour PECOT THIERRY - allocation vacance', '150', ''),
(718, '908418876119', '1446418800', 'Remboursement de la Prestation pour COSNIER CHRISTOPHE - alllocation vacance ', '80.32', ''),
(719, '741440337151', '1446332400', 'Remboursement de la Prestation pour BOIVIN VERONIQUE - allocation vacance', '150', '');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(48, 'Actions Aides Vacances'),
(49, 'Actions diverses'),
(54, 'Mobil Home'),
(55, 'cin&eacute;ma '),
(56, 'CADEAUX');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`, `commentaire`) VALUES
(96, 101, 84, '9', '0', '90', 0, ''),
(100, 103, 85, '12', '36', '0', 0, ''),
(101, 104, 85, '2', '6', '0', 0, ''),
(102, 105, 85, '1', '3', '0', 0, ''),
(103, 106, 85, '2', '6', '0', 0, ''),
(104, 107, 85, '2', '6', '0', 0, ''),
(105, 108, 85, '1', '3', '0', 0, ''),
(106, 109, 85, '2', '6', '0', 0, ''),
(107, 110, 85, '2', '6', '0', 0, ''),
(108, 111, 85, '1', '3', '0', 0, ''),
(109, 112, 85, '2', '6', '0', 0, ''),
(110, 113, 85, '5', '15', '0', 0, ''),
(111, 114, 85, '2', '6', '0', 0, ''),
(112, 115, 85, '1', '3', '0', 0, ''),
(113, 116, 85, '4', '12', '0', 0, ''),
(114, 117, 85, '2', '6', '0', 0, ''),
(115, 118, 85, '2', '6', '0', 0, ''),
(116, 119, 85, '5', '15', '0', 0, ''),
(117, 120, 85, '1', '3', '0', 0, ''),
(118, 121, 85, '2', '6', '0', 0, ''),
(119, 122, 85, '2', '6', '0', 0, ''),
(121, 124, 85, '2', '6', '0', 0, ''),
(122, 125, 85, '1', '3', '0', 0, ''),
(123, 126, 85, '5', '15', '0', 0, ''),
(124, 127, 85, '1', '3', '0', 0, ''),
(125, 128, 85, '2', '6', '0', 0, ''),
(126, 129, 85, '1', '3', '0', 0, ''),
(127, 130, 85, '2', '6', '0', 0, ''),
(128, 131, 85, '2', '6', '0', 0, ''),
(129, 132, 85, '2', '6', '0', 0, ''),
(130, 133, 85, '2', '6', '0', 0, ''),
(131, 134, 85, '2', '6', '0', 0, ''),
(132, 135, 85, '2', '6', '0', 0, ''),
(133, 136, 85, '1', '3', '0', 0, ''),
(134, 137, 85, '2', '6', '0', 0, ''),
(135, 138, 85, '2', '6', '0', 0, ''),
(136, 139, 85, '1', '3', '0', 0, ''),
(137, 140, 85, '2', '6', '0', 0, ''),
(138, 141, 85, '2', '6', '0', 0, ''),
(139, 142, 85, '2', '6', '0', 0, ''),
(140, 143, 85, '1', '3', '0', 0, ''),
(141, 144, 85, '1', '3', '0', 0, ''),
(142, 145, 85, '2', '6', '0', 0, ''),
(143, 146, 85, '2', '6', '0', 0, ''),
(144, 147, 85, '2', '6', '0', 0, ''),
(145, 148, 85, '2', '6', '0', 0, ''),
(146, 149, 85, '2', '6', '0', 0, ''),
(147, 150, 85, '2', '6', '0', 0, ''),
(148, 151, 85, '2', '6', '0', 0, ''),
(149, 152, 85, '2', '6', '0', 0, ''),
(150, 153, 85, '2', '6', '0', 0, ''),
(151, 154, 85, '2', '6', '0', 0, ''),
(152, 155, 85, '2', '6', '0', 0, ''),
(153, 156, 85, '1', '3', '0', 0, ''),
(154, 157, 85, '1', '3', '0', 0, ''),
(155, 158, 85, '2', '6', '0', 0, ''),
(156, 159, 85, '2', '6', '0', 0, ''),
(157, 160, 85, '2', '6', '0', 0, ''),
(158, 161, 85, '2', '6', '0', 0, ''),
(159, 162, 85, '1', '3', '0', 0, ''),
(160, 163, 85, '1', '3', '0', 0, ''),
(161, 164, 85, '2', '6', '0', 0, ''),
(162, 165, 85, '2', '6', '0', 0, ''),
(163, 166, 85, '2', '6', '0', 0, ''),
(164, 167, 85, '2', '6', '0', 0, ''),
(165, 168, 85, '2', '6', '0', 0, ''),
(166, 169, 85, '1', '3', '0', 0, ''),
(167, 170, 85, '2', '6', '0', 0, ''),
(168, 171, 85, '38', '114', '0', 0, ''),
(170, 173, 84, '9', '0', '90', 0, ''),
(171, 174, 84, '9', '0', '90', 0, ''),
(172, 175, 84, '9', '0', '90', 0, ''),
(173, 176, 84, '9', '0', '90', 0, ''),
(174, 177, 84, '9', '0', '90', 0, ''),
(175, 178, 84, '9', '0', '90', 0, ''),
(176, 179, 84, '9', '0', '90', 0, ''),
(177, 180, 84, '9', '0', '90', 0, ''),
(178, 181, 84, '9', '0', '90', 0, ''),
(179, 182, 84, '9', '0', '90', 0, ''),
(180, 183, 84, '9', '0', '90', 0, ''),
(181, 184, 84, '9', '0', '90', 0, ''),
(182, 185, 84, '9', '0', '90', 0, ''),
(183, 186, 84, '9', '0', '90', 0, ''),
(184, 187, 84, '9', '0', '90', 0, ''),
(185, 188, 84, '7', '0', '70', 0, ''),
(186, 189, 84, '5', '0', '50', 0, ''),
(187, 190, 84, '9', '0', '90', 0, ''),
(188, 191, 84, '9', '0', '90', 0, ''),
(189, 192, 84, '9', '0', '90', 0, ''),
(190, 193, 84, '9', '0', '90', 0, ''),
(191, 194, 84, '9', '0', '90', 0, ''),
(192, 195, 84, '9', '0', '90', 0, ''),
(193, 196, 84, '9', '0', '90', 0, ''),
(194, 197, 84, '9', '0', '90', 0, ''),
(195, 198, 84, '9', '0', '90', 0, ''),
(196, 199, 84, '9', '0', '90', 0, ''),
(197, 200, 84, '7', '0', '70', 0, ''),
(198, 201, 84, '9', '0', '90', 0, ''),
(199, 202, 84, '9', '0', '90', 0, ''),
(200, 203, 84, '9', '0', '90', 0, ''),
(201, 204, 84, '9', '0', '90', 0, ''),
(202, 205, 84, '9', '0', '90', 0, ''),
(203, 206, 84, '9', '0', '90', 0, ''),
(204, 207, 84, '9', '0', '90', 0, ''),
(205, 208, 84, '9', '0', '90', 0, ''),
(206, 209, 84, '9', '0', '90', 0, ''),
(207, 210, 84, '9', '0', '90', 0, ''),
(208, 211, 84, '9', '0', '90', 0, ''),
(209, 212, 84, '9', '0', '90', 0, ''),
(210, 213, 84, '9', '0', '90', 0, ''),
(211, 214, 84, '9', '0', '90', 0, ''),
(212, 215, 84, '7', '0', '70', 0, ''),
(213, 216, 84, '9', '0', '90', 0, ''),
(214, 217, 84, '9', '0', '90', 0, ''),
(215, 218, 84, '9', '0', '90', 0, ''),
(216, 219, 84, '9', '0', '90', 0, ''),
(217, 220, 84, '7', '0', '70', 0, ''),
(218, 221, 84, '9', '0', '90', 0, ''),
(219, 223, 84, '9', '0', '90', 0, ''),
(220, 224, 84, '9', '0', '90', 0, ''),
(221, 225, 84, '9', '0', '90', 0, ''),
(222, 226, 84, '9', '0', '90', 0, ''),
(223, 227, 84, '7', '0', '70', 0, ''),
(224, 228, 84, '9', '0', '90', 0, ''),
(225, 229, 84, '9', '0', '90', 0, ''),
(226, 230, 84, '5', '0', '50', 0, ''),
(227, 231, 84, '9', '0', '90', 0, ''),
(228, 232, 84, '9', '0', '90', 0, ''),
(229, 233, 84, '9', '0', '90', 0, ''),
(230, 234, 84, '9', '0', '90', 0, ''),
(231, 235, 84, '9', '0', '90', 0, ''),
(232, 236, 84, '9', '0', '90', 0, ''),
(233, 237, 84, '9', '0', '90', 0, ''),
(234, 238, 84, '9', '0', '90', 0, ''),
(235, 239, 84, '5', '0', '50', 0, ''),
(236, 240, 84, '9', '0', '90', 0, ''),
(237, 241, 84, '9', '0', '90', 0, ''),
(238, 242, 84, '9', '0', '90', 0, ''),
(239, 243, 84, '9', '0', '90', 0, ''),
(240, 244, 84, '9', '0', '90', 0, ''),
(241, 245, 84, '5', '0', '50', 0, ''),
(242, 246, 84, '9', '0', '90', 0, ''),
(243, 247, 84, '9', '0', '90', 0, ''),
(244, 248, 84, '9', '0', '90', 0, ''),
(245, 249, 84, '9', '0', '90', 0, ''),
(246, 250, 84, '9', '0', '90', 0, ''),
(247, 251, 84, '9', '0', '90', 0, ''),
(248, 252, 84, '9', '0', '90', 0, ''),
(249, 253, 84, '9', '0', '90', 0, ''),
(250, 254, 84, '9', '0', '90', 0, ''),
(251, 255, 84, '9', '0', '90', 0, ''),
(252, 256, 84, '9', '0', '90', 0, ''),
(253, 257, 84, '9', '0', '90', 0, ''),
(254, 258, 84, '9', '0', '90', 0, ''),
(257, 261, 87, '1', '120', '0', 0, ''),
(258, 262, 88, '3210', '321', '0', 0, ''),
(259, 263, 88, '1630', '163', '0', 0, ''),
(260, 264, 86, '2', '280', '0', 0, ''),
(261, 265, 86, '1', '140', '0', 0, ''),
(262, 266, 86, '2', '280', '0', 0, ''),
(263, 267, 86, '1', '140', '0', 0, ''),
(264, 268, 86, '1', '140', '0', 0, ''),
(265, 269, 86, '2', '280', '0', 0, ''),
(266, 270, 86, '1', '140', '0', 0, ''),
(267, 271, 86, '1', '140', '0', 0, ''),
(268, 272, 86, '1', '140', '0', 0, ''),
(269, 273, 86, '1', '140', '0', 0, ''),
(270, 274, 86, '2', '280', '0', 0, ''),
(271, 275, 86, '1', '140', '0', 0, ''),
(272, 276, 86, '1', '140', '0', 0, ''),
(273, 277, 86, '2', '280', '0', 0, ''),
(274, 278, 86, '1', '140', '0', 0, ''),
(275, 279, 86, '2', '280', '0', 0, ''),
(276, 280, 86, '1', '140', '0', 0, ''),
(277, 281, 86, '1', '140', '0', 0, ''),
(278, 282, 86, '1', '140', '0', 0, ''),
(279, 283, 86, '1', '140', '0', 0, ''),
(280, 284, 86, '1', '140', '0', 0, ''),
(281, 285, 86, '1', '140', '0', 0, ''),
(282, 286, 86, '1', '140', '0', 0, ''),
(283, 287, 86, '1', '140', '0', 0, ''),
(284, 288, 86, '2', '280', '0', 0, ''),
(285, 289, 86, '2', '280', '0', 0, ''),
(286, 290, 86, '1', '140', '0', 0, ''),
(287, 291, 86, '2', '280', '0', 0, ''),
(288, 292, 86, '2', '280', '0', 0, ''),
(289, 293, 88, '1870', '187', '0', 0, ''),
(290, 294, 88, '390', '39', '0', 0, ''),
(291, 295, 88, '590', '59', '0', 0, ''),
(292, 296, 88, '470', '47', '0', 0, ''),
(293, 297, 88, '880', '88', '0', 0, ''),
(294, 298, 88, '700', '70', '0', 0, ''),
(295, 299, 88, '470', '47', '0', 0, ''),
(296, 300, 88, '480', '48', '0', 0, ''),
(297, 301, 88, '500', '50', '0', 0, ''),
(298, 302, 88, '630', '63', '0', 0, ''),
(299, 303, 88, '1330', '133', '0', 0, ''),
(300, 304, 88, '690', '69', '0', 0, ''),
(301, 305, 88, '1450', '145', '0', 0, ''),
(302, 306, 88, '1170', '117', '0', 0, ''),
(303, 307, 86, '1', '140', '0', 0, ''),
(304, 308, 86, '1', '140', '0', 0, ''),
(305, 309, 86, '1', '140', '0', 0, ''),
(306, 310, 86, '2', '280', '0', 0, ''),
(307, 311, 86, '1', '140', '0', 0, ''),
(308, 312, 88, '2210', '221', '0', 0, ''),
(309, 313, 88, '760', '76', '0', 0, ''),
(310, 314, 88, '610', '61', '0', 0, ''),
(311, 315, 88, '930', '93', '0', 0, ''),
(312, 316, 88, '460', '46', '0', 0, ''),
(313, 317, 88, '640', '64', '0', 0, ''),
(314, 318, 88, '960', '96', '0', 0, ''),
(315, 319, 88, '560', '56', '0', 0, ''),
(316, 320, 93, '4', '24', '7.6', 0, ''),
(317, 321, 93, '4', '24', '7.6', 0, ''),
(318, 322, 93, '4', '24', '7.6', 0, ''),
(319, 323, 93, '4', '24', '7.6', 0, ''),
(320, 324, 93, '4', '24', '7.6', 0, ''),
(321, 325, 93, '5', '30', '9.5', 0, ''),
(322, 326, 93, '4', '24', '7.6', 0, ''),
(323, 327, 93, '4', '24', '7.6', 0, ''),
(324, 328, 93, '5', '30', '9.5', 0, ''),
(325, 329, 93, '4', '24', '7.6', 0, ''),
(326, 330, 93, '4', '24', '7.6', 0, ''),
(327, 331, 93, '2', '12', '3.8', 0, ''),
(328, 332, 93, '2', '12', '3.8', 0, ''),
(329, 333, 93, '4', '24', '7.6', 0, ''),
(330, 334, 93, '3', '18', '5.7', 0, ''),
(331, 335, 93, '4', '24', '7.6', 0, ''),
(332, 336, 93, '5', '30', '9.5', 0, ''),
(333, 337, 93, '8', '48', '15.2', 0, ''),
(334, 338, 93, '4', '24', '7.6', 0, ''),
(335, 339, 93, '3', '18', '5.7', 0, ''),
(336, 340, 93, '7', '42', '13.3', 0, ''),
(337, 341, 93, '4', '24', '7.6', 0, ''),
(338, 342, 93, '2', '12', '3.8', 0, ''),
(339, 343, 93, '4', '24', '7.6', 0, ''),
(340, 344, 93, '4', '24', '7.6', 0, ''),
(341, 345, 93, '4', '24', '7.6', 0, ''),
(342, 346, 93, '4', '24', '7.6', 0, ''),
(343, 347, 93, '4', '24', '7.6', 0, ''),
(344, 348, 93, '4', '24', '7.6', 0, ''),
(345, 349, 93, '4', '24', '7.6', 0, ''),
(346, 350, 93, '4', '24', '7.6', 0, ''),
(347, 351, 93, '4', '24', '7.6', 0, ''),
(348, 352, 93, '4', '24', '7.6', 0, ''),
(349, 353, 93, '3', '18', '5.7', 0, ''),
(350, 354, 93, '2', '12', '3.8', 0, ''),
(351, 355, 93, '4', '24', '7.6', 0, ''),
(352, 356, 93, '2', '12', '3.8', 0, ''),
(353, 357, 93, '4', '24', '7.6', 0, ''),
(354, 358, 93, '6', '36', '11.4', 0, ''),
(355, 359, 93, '4', '24', '7.6', 0, ''),
(356, 360, 93, '4', '24', '7.6', 0, ''),
(357, 361, 93, '5', '30', '9.5', 0, ''),
(358, 362, 93, '4', '24', '7.6', 0, ''),
(359, 363, 93, '2', '12', '3.8', 0, ''),
(360, 364, 93, '4', '24', '7.6', 0, ''),
(361, 365, 93, '4', '24', '7.6', 0, ''),
(362, 366, 93, '4', '24', '7.6', 0, ''),
(363, 367, 93, '4', '24', '7.6', 0, ''),
(364, 368, 93, '4', '24', '7.6', 0, ''),
(365, 369, 93, '4', '24', '7.6', 0, ''),
(366, 370, 93, '4', '24', '7.6', 0, ''),
(367, 371, 93, '4', '24', '7.6', 0, ''),
(368, 372, 93, '2', '12', '3.8', 0, ''),
(369, 373, 93, '4', '24', '7.6', 0, ''),
(370, 374, 93, '4', '24', '7.6', 0, ''),
(371, 375, 93, '6', '36', '11.4', 0, ''),
(372, 376, 93, '2', '12', '3.8', 0, ''),
(373, 377, 93, '4', '24', '7.6', 0, ''),
(374, 378, 93, '4', '24', '7.6', 0, ''),
(375, 379, 93, '2', '12', '3.8', 0, ''),
(376, 380, 93, '4', '24', '7.6', 0, ''),
(377, 381, 93, '4', '24', '7.6', 0, ''),
(378, 382, 93, '4', '24', '7.6', 0, ''),
(379, 383, 93, '4', '24', '7.6', 0, ''),
(380, 384, 93, '4', '24', '7.6', 0, ''),
(381, 385, 93, '4', '24', '7.6', 0, ''),
(382, 386, 93, '5', '30', '9.5', 0, ''),
(383, 387, 93, '2', '12', '3.8', 0, ''),
(384, 389, 95, '21.24', '0', '21.24', 0, 'MIXEUR'),
(386, 391, 93, '2', '12', '3.8', 0, ''),
(387, 392, 93, '4', '24', '7.6', 0, ''),
(388, 393, 93, '4', '24', '7.6', 0, ''),
(389, 394, 93, '6', '36', '11.4', 0, ''),
(390, 395, 93, '2', '12', '3.8', 0, ''),
(391, 396, 93, '2', '12', '3.8', 0, ''),
(392, 390, 93, '1', '6', '1.9', 0, ''),
(393, 402, 93, '4', '24', '7.6', 0, ''),
(394, 401, 93, '4', '24', '7.6', 0, ''),
(395, 400, 93, '4', '24', '7.6', 0, ''),
(396, 399, 93, '4', '24', '7.6', 0, ''),
(397, 397, 93, '2', '12', '3.8', 0, ''),
(400, 417, 93, '4', '24', '7.6', 0, ''),
(401, 416, 93, '4', '24', '7.6', 0, ''),
(402, 415, 93, '4', '24', '7.6', 0, ''),
(403, 419, 93, '2', '12', '3.8', 0, ''),
(404, 413, 93, '5', '30', '9.5', 0, ''),
(405, 411, 93, '4', '24', '7.6', 0, ''),
(406, 410, 93, '4', '24', '7.6', 0, ''),
(407, 409, 93, '2', '12', '3.8', 0, ''),
(408, 408, 93, '4', '24', '7.6', 0, ''),
(409, 407, 93, '4', '24', '7.6', 0, ''),
(410, 406, 93, '4', '24', '7.6', 0, ''),
(411, 405, 93, '4', '24', '7.6', 0, ''),
(412, 404, 93, '4', '24', '7.6', 0, ''),
(413, 403, 93, '4', '24', '7.6', 0, ''),
(414, 426, 93, '1', '6', '1.9', 0, ''),
(415, 425, 93, '4', '24', '7.6', 0, ''),
(416, 424, 93, '4', '24', '7.6', 0, ''),
(417, 420, 93, '4', '24', '7.6', 0, ''),
(418, 421, 93, '2', '12', '3.8', 0, ''),
(419, 423, 93, '4', '24', '7.6', 0, ''),
(420, 422, 93, '4', '24', '7.6', 0, ''),
(421, 427, 95, '27.49', '0', '27.49', 0, 'FRITEUSE'),
(422, 428, 95, '12.49', '0', '12.49', 0, 'CAFETIERE'),
(423, 429, 95, '18.30', '0', '18.3', 0, 'POELE'),
(424, 430, 95, '35', '0', '35', 0, 'KARCHER'),
(425, 431, 95, '35', '0', '35', 0, 'Perceuse'),
(426, 432, 95, '9.95', '0', '9.95', 0, 'Couteaux'),
(427, 433, 95, '12.50', '0', '12.5', 0, 'USTENSILE  CUISINE'),
(428, 434, 95, '10.00', '0', '10', 0, 'Tuyau Karcher'),
(429, 435, 95, '14.99', '0', '14.99', 0, 'TOASTER'),
(430, 436, 95, '7.50', '0', '7.5', 0, 'BOUILLOIRE'),
(431, 437, 95, '6.65', '0', '6.65', 0, 'Balance cuisine'),
(432, 438, 95, '17.49', '0', '17.49', 0, 'Haut parleur'),
(433, 439, 95, '17.49', '0', '17.49', 0, 'Haut parleur'),
(434, 440, 95, '27.96', '0', '27.96', 0, 'Blender'),
(435, 441, 95, '24.94', '0', '24.94', 0, 'Mixeur'),
(436, 442, 95, '49.90', '0', '49.9', 0, 'Tuyau eau'),
(437, 443, 95, '18.50', '0', '18.5', 0, 'Tournevis'),
(438, 444, 95, '75', '0', '75', 0, 'Bon achat Leroy'),
(439, 445, 95, '54.90', '0', '54.9', 0, 'Fondue'),
(440, 446, 95, '54.99', '0', '54.99', 0, 'Croque monsieur'),
(441, 447, 95, '36.21', '0', '36.21', 0, 'Ricard'),
(442, 448, 95, '0', '0', '0', 0, '2 WE MOBIL HOME'),
(443, 449, 95, '75', '0', '75', 0, 'Bon achat DECATHLON'),
(444, 450, 95, '75', '0', '75', 0, 'Bon achat DECATHLON'),
(446, 452, 95, '75', '0', '75', 0, 'Bon d achat super U'),
(447, 453, 95, '80', '0', '80', 0, '2 bons achat super U de 40'),
(448, 454, 95, '40', '0', '40', 0, 'Bon achat  super U'),
(449, 455, 95, '40', '0', '40', 0, 'Bon achat super U'),
(450, 456, 95, '60', '0', '60', 0, '2 bons achat super U'),
(451, 457, 95, '20', '0', '20', 0, 'Bon achat super U'),
(452, 458, 95, '34.90', '0', '34.9', 0, 'KARCHER'),
(453, 459, 95, '29.95', '0', '29.95', 0, ''),
(454, 460, 95, '43.13', '0', '43.13', 0, 'WHYSKY'),
(455, 461, 95, '36.21', '0', '36.21', 0, 'RICARD'),
(456, 451, 95, '34.90', '0', '34.9', 0, 'BLENDER'),
(457, 462, 93, '2', '12', '3.8', 0, ''),
(458, 465, 93, '4', '24', '7.6', 0, ''),
(459, 464, 93, '4', '24', '7.6', 0, ''),
(460, 463, 93, '4', '24', '7.6', 0, ''),
(461, 466, 94, '6', '72', '12', 0, ''),
(462, 467, 94, '4', '48', '8', 0, ''),
(463, 468, 94, '3', '36', '6', 0, ''),
(464, 475, 86, '1', '140', '0', 0, ''),
(465, 474, 86, '1', '140', '0', 0, ''),
(466, 473, 86, '2', '280', '0', 0, ''),
(467, 472, 86, '1', '140', '0', 0, ''),
(468, 471, 86, '1', '140', '0', 0, ''),
(469, 470, 86, '1', '140', '0', 0, ''),
(470, 469, 86, '1', '140', '0', 0, ''),
(471, 478, 96, '2', '12', '4.2', 0, ''),
(472, 483, 96, '2', '12', '4.2', 0, ''),
(473, 482, 96, '2', '12', '4.2', 0, ''),
(474, 481, 96, '4', '24', '8.4', 0, ''),
(475, 480, 96, '4', '24', '8.4', 0, ''),
(476, 479, 96, '4', '24', '8.4', 0, ''),
(477, 477, 96, '4', '24', '8.4', 0, ''),
(478, 476, 96, '4', '24', '8.4', 0, ''),
(479, 484, 88, '740', '74', '0', 0, ''),
(480, 485, 88, '470', '47', '0', 0, ''),
(482, 486, 88, '790', '79', '0', 0, ''),
(483, 487, 88, '1060', '106', '0', 0, ''),
(484, 488, 88, '620', '62', '0', 0, ''),
(485, 489, 88, '680', '68', '0', 0, ''),
(486, 490, 88, '760', '76', '0', 0, ''),
(487, 491, 88, '470', '47', '0', 0, ''),
(488, 492, 88, '1870', '187', '0', 0, ''),
(489, 493, 88, '4360', '436', '0', 0, ''),
(490, 494, 88, '1020', '102', '0', 0, ''),
(491, 496, 88, '540', '54', '0', 0, ''),
(492, 497, 88, '870', '87', '0', 0, ''),
(493, 498, 88, '1520', '152', '0', 0, ''),
(494, 499, 88, '2440', '244', '0', 0, ''),
(495, 500, 88, '710', '71', '0', 0, ''),
(497, 501, 88, '560', '56', '0', 0, ''),
(498, 502, 88, '1640', '164', '0', 0, ''),
(499, 503, 96, '4', '24', '8.4', 0, ''),
(500, 504, 96, '2', '12', '4.2', 0, ''),
(501, 505, 96, '2', '12', '4.2', 0, ''),
(502, 506, 96, '4', '24', '8.4', 0, ''),
(503, 507, 96, '4', '24', '8.4', 0, ''),
(504, 508, 96, '2', '12', '4.2', 0, ''),
(505, 509, 96, '5', '30', '10.5', 0, ''),
(506, 510, 96, '4', '24', '8.4', 0, ''),
(507, 511, 96, '4', '24', '8.4', 0, ''),
(508, 512, 96, '8', '48', '16.8', 0, ''),
(509, 513, 96, '5', '30', '10.5', 0, ''),
(510, 514, 96, '4', '24', '8.4', 0, ''),
(511, 515, 96, '4', '24', '8.4', 0, ''),
(512, 516, 96, '4', '24', '8.4', 0, ''),
(513, 517, 96, '2', '12', '4.2', 0, ''),
(514, 518, 96, '4', '24', '8.4', 0, ''),
(515, 519, 96, '4', '24', '8.4', 0, ''),
(516, 520, 96, '4', '24', '8.4', 0, ''),
(517, 521, 96, '4', '24', '8.4', 0, ''),
(518, 522, 96, '4', '24', '8.4', 0, ''),
(519, 523, 96, '4', '24', '8.4', 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.6.1', '15315-PREM');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'administrateur', '882baf28143fb700b388a87ef561a6e5', 1),
(5, 'MLP49', '9a5ce07dc05f6301a793524079a47491', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '1'),
(3, 'vente_direct', '1');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`) VALUES
(84, 48, 'ANCV', '01-01-2015', '31-12-2015', '0', '10', '10', '1000', '2115', 0),
(85, 49, 'CHARLIE HEBDO', '01-01-2015', '31-12-2015', '3', '0', '3', '50', '0', 0),
(86, 54, 'Mobil Home 140', '01-01-2015', '01-10-2015', '140', '0', '140', '50', '0', 0),
(87, 54, 'Mobil home 120', '', '', '120', '0', '120', '1', '0', 0),
(88, 49, 'vente parfums', '01-01-2015', '16-12-2015', '0.10', '0', '0.1', '100000', '0', 0),
(89, 49, 'billeterie laser games', '01-01-2015', '31-12-2015', '7', '0', '7', '10', '7', 0),
(90, 49, 'bowling 9,5', '01-01-2015', '31-12-2015', '9.5', '0', '9.5', '3', '3', 0),
(91, 49, 'bowling 6,40', '01-01-2015', '08-06-2015', '6.4', '0', '6.4', '9', '9', 0),
(92, 49, 'bowling 8,90', '01-01-2015', '08-06-2015', '8.90', '0', '8.9', '4', '4', 0),
(93, 55, 'cin&eacute;ma 2015', '01-01-2015', '15-04-2015', '6.00', '1.9', '7.9', '100', '0', 0),
(94, 49, 'PAPEA', '17-07-2015', '25-09-2016', '12', '2', '14', '20', '7', 0),
(95, 56, 'Concours de boules', '01-08-2015', '30-09-2015', '0', '1', '1', '1000', '0', 0),
(96, 55, 'CINEMA 8.10', '29-09-2015', '31-05-2016', '6', '2.10', '8.1', '100', '42', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `produit_fixe`
--

INSERT INTO `produit_fixe` (`idproduitfixe`, `designation`, `date_produit_fixe`, `montant_produit`, `num_mouvement`) VALUES
(6, 'ANCV REVERSEMENT ENTREPRISE', '24-03-2015', '21510.00', ''),
(7, 'SUBVENTION ASC 2015', '10-02-2015', '39400', ''),
(8, 'SOLDE SUBVENTION 2015 (budget 2014)', '11-05-2015', '1.10', '2866321090'),
(9, 'don de la direction concours de boules achat lots ', '26-08-2015', '250', '7510536895');

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(92, 101, 3, '0', '', 'ADAM StÃ©phane', '766913721', 1),
(96, 104, 3, '6', '', 'BADOUR', '104897766', 1),
(97, 105, 3, '3', '', 'SALAUN ', '797541324', 1),
(98, 106, 3, '6', '', 'CLOUET', '298064446', 1),
(99, 107, 3, '6', '', 'CHAPEAU', '977030626', 1),
(100, 108, 3, '3', '', 'CLEMENT OLIVIER', '394389083', 1),
(101, 109, 3, '6', '', 'GARNIER', '152476817', 1),
(102, 110, 3, '6', '', 'MARSEAULT', '911071250', 1),
(103, 111, 3, '3', '', 'LEHOREAU', '411485864', 1),
(104, 112, 3, '6', '', 'MESLET', '592027465', 1),
(105, 113, 3, '15', '', 'DOUILLY OLIVIER', '523125745', 1),
(106, 114, 3, '6', '', 'CLEMENT CHRISTOPHE', '543193829', 1),
(107, 115, 3, '3', '', 'LAURIOU', '192632237', 1),
(108, 116, 3, '12', '', 'AMOURDOM', '422362157', 1),
(109, 117, 3, '6', '', 'JANIN', '354694855', 1),
(110, 118, 3, '6', '', 'CARUSO', '622025983', 1),
(111, 119, 3, '15', '', 'GUERIN J', '812637190', 1),
(112, 120, 3, '3', '', 'HAULBERT', '236792301', 1),
(113, 121, 3, '6', '', 'PERGER', '112330733', 1),
(114, 122, 3, '6', '', 'BACHELOT', '281873541', 1),
(115, 124, 3, '6', '', 'FOURNIER', '583329484', 1),
(116, 125, 3, '3', '', 'BOUFAQOUS', '872746796', 1),
(117, 126, 3, '15', '', 'GAULTIER SEBASTIEN ', '145886889', 1),
(118, 127, 3, '3', '', 'COSNIER CHRISTOPHE ', '386873173', 1),
(119, 128, 3, '6', '', 'ONILLON', '223114167', 1),
(120, 129, 3, '3', '', 'DAVY ANTOINE ', '380509489', 1),
(121, 130, 3, '6', '', 'ROUSSEL', '716914646', 1),
(122, 131, 3, '6', '', 'SUREAU', '662180566', 1),
(123, 132, 3, '6', '', 'PECOT', '403411754', 1),
(124, 133, 3, '6', '', 'DAGUER', '902751593', 1),
(125, 134, 3, '6', '', 'CHALOPIN', '885403846', 1),
(126, 135, 3, '6', '', 'ROUAULT', '440083101', 1),
(127, 136, 3, '3', '', 'BOIVIN', '414586393', 1),
(128, 137, 3, '6', '', 'DASYLVA', '521540793', 1),
(129, 138, 3, '6', '', 'GUERIN H', '460706309', 1),
(130, 139, 3, '3', '', 'LUBIN', '890059948', 1),
(131, 140, 3, '6', '', 'POUR VERMEULUN RETRAITE', '995997985', 1),
(132, 141, 3, '6', '', 'MORTIER FRED', '789351199', 1),
(133, 142, 3, '6', '', 'DAGUENET FRANCOISE', '844670349', 1),
(134, 143, 3, '3', '', 'POIRRIER', '350923409', 1),
(135, 144, 3, '3', '', 'MARTIN', '521953889', 1),
(136, 145, 3, '6', '', 'BOUVIER', '392720217', 1),
(137, 146, 3, '6', '', 'COUINET', '308847003', 1),
(138, 147, 3, '6', '', 'GALLET', '410158386', 1),
(139, 148, 3, '6', '', 'ROUFFIAC', '325485797', 1),
(140, 149, 3, '6', '', 'BRUNET', '831103717', 1),
(141, 150, 3, '6', '', 'FRESNEAU', '404232360', 1),
(142, 151, 3, '6', '', 'PILLARD', '759244341', 1),
(143, 152, 3, '6', '', 'FOUGERI', '832273424', 1),
(144, 153, 3, '6', '', 'GUERRIAU', '461467387', 1),
(145, 154, 3, '6', '', 'BEAULU', '617109972', 1),
(146, 155, 3, '6', '', 'DINGREVILLE', '656563256', 1),
(147, 156, 3, '3', '', 'HANQUART', '241293941', 1),
(148, 157, 3, '3', '', 'MARCHAIS ', '149558185', 1),
(149, 158, 3, '6', '', 'AUDIC', '186024369', 1),
(150, 159, 3, '6', '', 'NEGRI', '882957214', 1),
(151, 160, 3, '6', '', 'JOUBERT', '607343854', 1),
(152, 161, 3, '6', '', 'RAGOT', '384051438', 1),
(153, 162, 3, '3', '', 'CROS', '157842225', 1),
(154, 163, 3, '3', '', 'CHAPLAIN', '816292467', 1),
(155, 164, 3, '6', '', 'BOUDAUD', '355304580', 1),
(156, 165, 3, '6', '', 'FAUCHEUX', '173593721', 1),
(157, 166, 3, '6', '', 'MOTTEAU', '131953357', 1),
(158, 167, 3, '6', '', 'CARTRON OLIVIER', '557096876', 1),
(159, 168, 3, '6', '', 'KERBOURCH', '853394655', 1),
(160, 169, 3, '3', '', 'VALLEE KARINE', '994232917', 1),
(161, 170, 3, '6', '', 'ADAM', '378305914', 1),
(162, 171, 3, '64', '', 'POUPAULT', '230280355', 1),
(163, 171, 1, '50', '', 'POUPAULT', '', 1),
(164, 173, 3, '0', '', 'ARMOUDOM', '424131378', 1),
(165, 174, 3, '0', '', 'AUDIC ', '862115431', 1),
(166, 175, 3, '0', '', 'BACHELOT', '395123788', 1),
(167, 176, 3, '0', '', 'BADOUR', '625788347', 1),
(168, 177, 3, '0', '', 'BAULU', '966770825', 1),
(169, 178, 3, '0', '', 'BARRIERES', '255802760', 1),
(170, 179, 3, '0', '', 'BERGERET', '949694798', 1),
(171, 180, 3, '0', '', 'BLEJAN', '538575797', 1),
(172, 181, 3, '0', '', 'BOIVIN', '681704076', 1),
(173, 182, 3, '0', '', 'BOUDAUD', '887661087', 1),
(174, 183, 3, '0', '', 'BOUFAQOUS', '662237876', 1),
(175, 184, 3, '0', '', 'BOUVIER', '431846300', 1),
(176, 185, 3, '0', '', 'BRANCHEREAU', '576939767', 1),
(177, 186, 3, '0', '', 'BRUNET', '957697386', 1),
(178, 187, 3, '0', '', 'CERIBAS', '978733291', 1),
(179, 188, 3, '0', '', 'CARTRON', '574746800', 1),
(180, 189, 3, '0', '', 'CARUSO', '360282895', 1),
(181, 190, 3, '0', '', 'CHAPLAIN', '240423486', 1),
(182, 191, 3, '0', '', 'CHALOPIN', '994259658', 1),
(183, 192, 3, '0', '', 'CHAPEAU', '457396337', 1),
(184, 193, 3, '0', '', 'CLEMENT', '717038642', 1),
(185, 194, 3, '0', '', 'CHAFFIN', '348543307', 1),
(186, 195, 3, '0', '', 'CHESNEL', '556248914', 1),
(187, 196, 3, '0', '', 'CLEMENT OLIVIER', '749898697', 1),
(188, 197, 3, '0', '', 'COSNIER', '916776793', 1),
(189, 198, 3, '0', '', 'COUINET', '234847516', 1),
(190, 199, 3, '0', '', 'CRIBIER', '824315112', 1),
(191, 200, 3, '0', '', 'CROS', '504269207', 1),
(192, 201, 3, '0', '', 'DASYLVA', '761116794', 1),
(193, 202, 3, '0', '', 'DAGUENE', '973423513', 1),
(194, 203, 3, '0', '', 'DAVID', '631992934', 1),
(195, 204, 3, '0', '', 'DAVY', '267353562', 1),
(196, 205, 3, '0', '', 'DAGUER', '444540781', 1),
(197, 206, 3, '0', '', 'DELPHIN', '142774062', 1),
(198, 207, 3, '0', '', 'DESMARS', '448265166', 1),
(199, 208, 3, '0', '', 'DINGREVILLE', '141557884', 1),
(200, 209, 3, '0', '', 'DOUILLY', '456005313', 1),
(201, 210, 3, '0', '', 'DROUIN', '102151907', 1),
(202, 211, 3, '0', '', 'FAUCHEUX', '350224335', 1),
(203, 212, 3, '0', '', 'FOUGERI', '912959411', 1),
(204, 213, 3, '0', '', 'FOURNIER', '387084197', 1),
(205, 214, 3, '0', '', 'FRESNEAU', '663689511', 1),
(206, 215, 3, '0', '', 'GALLET', '583470672', 1),
(207, 216, 3, '0', '', 'GARNIER', '201952384', 1),
(208, 217, 3, '0', '', 'GAULITIER', '374492890', 1),
(209, 218, 3, '0', '', 'GREFFIER', '487519573', 1),
(210, 219, 3, '0', '', 'GUERIN Huguette', '440273151', 1),
(211, 220, 3, '0', '', 'GUERIN Johnny', '162037432', 1),
(212, 221, 3, '0', '', 'GUERRIAU Malika', '194967553', 1),
(213, 223, 3, '0', '', 'GUERTIN', '609944795', 1),
(214, 224, 3, '0', '', 'GUYADER', '828210490', 1),
(215, 225, 3, '0', '', 'HANQUART', '148696587', 1),
(216, 226, 3, '0', '', 'HAULBERT', '452441518', 1),
(217, 227, 3, '0', '', 'KOCH', '181188544', 1),
(218, 228, 3, '0', '', 'IDDER MEHDI', '928024384', 1),
(219, 229, 3, '0', '', 'JANIN', '884446455', 1),
(220, 230, 3, '0', '', 'KERBOURCH', '634814728', 1),
(221, 231, 3, '0', '', 'JOUBERT', '241446207', 1),
(222, 232, 3, '0', '', 'LAURIOU', '518004305', 1),
(223, 233, 3, '0', '', 'LEHOREAU', '139637656', 1),
(224, 234, 3, '0', '', 'LUBIN', '375057776', 1),
(225, 235, 3, '0', '', 'MARCHAIS', '792158708', 1),
(226, 236, 3, '0', '', 'MACKOSKI', '984404511', 1),
(227, 237, 3, '0', '', 'MARTIN', '285943317', 1),
(228, 238, 3, '0', '', 'MARSAULT', '362128824', 1),
(229, 239, 3, '0', '', 'MOTTEAU', '559764482', 1),
(230, 240, 3, '0', '', 'MESLET', '239791752', 1),
(231, 241, 3, '0', '', 'MORTIER', '881597023', 1),
(232, 242, 3, '0', '', 'NIANGORAN', '532970310', 1),
(233, 243, 3, '0', '', 'NEGRI', '388877479', 1),
(234, 244, 3, '0', '', 'ONILLON', '233265766', 1),
(235, 245, 3, '0', '', 'PASCAL LIONEL', '547099650', 1),
(236, 246, 3, '0', '', 'PECOT', '320599329', 1),
(237, 247, 3, '0', '', 'PERGER', '749010268', 1),
(238, 248, 3, '0', '', 'PILLARD', '666146118', 1),
(239, 249, 3, '0', '', 'POIRRIER', '859979942', 1),
(240, 250, 3, '0', '', 'POUPAULT', '373198785', 1),
(241, 251, 3, '0', '', 'RAGOT', '276036180', 1),
(242, 252, 3, '0', '', 'RICHOMME', '799034307', 1),
(243, 253, 3, '0', '', 'ROUAULT', '569295260', 1),
(244, 254, 3, '0', '', 'ROUFFIAC', '464988710', 1),
(245, 255, 3, '0', '', 'ROUSSEL', '658479725', 1),
(246, 256, 3, '0', '', 'VALLEE', '545762463', 1),
(247, 257, 3, '0', '', 'SALAUN', '540562995', 1),
(248, 258, 3, '0', '', 'SUREAU', '166237657', 1),
(249, 103, 3, '36', '', 'BRANCHEREAU', '578116979', 1),
(250, 261, 1, '120', 'CA', 'ONILLON', '234', 1),
(251, 262, 1, '321', 'CC', 'DESMARS', '001', 1),
(252, 263, 1, '163', 'CC', 'LEHOREAU', '002', 1),
(253, 264, 1, '280', 'CA', 'POIRRIER', '002', 1),
(254, 265, 1, '140', 'CC', 'JANIN', '002', 1),
(255, 266, 1, '280', 'CA', 'CLEMENT', '0001', 1),
(256, 267, 1, '140', 'CA', 'COSNIER', '1526', 1),
(257, 268, 1, '140', 'CM', 'BACHELOT', '002', 1),
(258, 269, 1, '280', 'CM', 'DINGREVILLE', '477', 1),
(259, 270, 1, '140', 'CA', 'CLOUET', '156', 1),
(260, 271, 1, '140', 'CA', 'JOUBERT', '125', 1),
(261, 272, 1, '140', 'CA', 'ONILLON', '001', 1),
(262, 273, 1, '140', 'CA', 'COUINET', '002', 1),
(263, 274, 1, '280', 'CA', 'MARCHAIS', '969', 1),
(264, 275, 1, '140', 'CA', 'CROS', '0020', 1),
(265, 276, 1, '140', 'BNP', 'BOURGEAIS', '456', 1),
(266, 277, 1, '280', 'BNP', 'NAIRIERE', '7896', 1),
(267, 278, 1, '140', 'CM', 'GUERIN', '962', 1),
(268, 279, 1, '280', 'CM', 'POIRRIER JOEL', 'CM', 1),
(269, 280, 1, '140', 'CM', 'GALLET', '968', 1),
(270, 281, 1, '140', 'CM', 'MENARD', '856', 1),
(271, 282, 1, '140', 'CM', 'BRUN', '844', 1),
(272, 283, 1, '140', 'CM', 'BARBOT', '125', 1),
(273, 284, 1, '140', 'PO', 'FOQUERAULT', '854', 1),
(274, 285, 1, '140', 'CA', 'DOMINGUEZ', '8541', 1),
(275, 286, 1, '140', 'PO', 'POIRRIER', '636', 1),
(276, 287, 1, '140', 'CE', 'BRIAND', '789', 1),
(277, 288, 1, '280', 'CP', 'CLEMENT JP', '4566', 1),
(278, 289, 1, '280', 'CM', 'BLANCHART', '896', 1),
(279, 290, 1, '140', 'CM', 'ROCHER', '856', 1),
(280, 291, 1, '280', 'CM', 'ROUFFIAC', '962', 1),
(281, 292, 1, '280', 'PO', 'PORRIER', '452', 1),
(282, 293, 1, '187', 'CM', 'BELLOIN', '681', 1),
(283, 294, 1, '39', 'CM', 'KERJCI', '942', 1),
(284, 295, 1, '59', 'CIC', 'MACKOWSKI', '2763', 1),
(285, 296, 1, '47', 'CA', 'GUERRIAU', '3837', 1),
(286, 297, 1, '88', 'CA', 'BRIAND', '531', 1),
(287, 298, 1, '70', 'CM', 'RAGUIN', '202', 1),
(288, 299, 1, '47', 'CM', 'BOUCHENOIR', '202', 1),
(289, 300, 1, '48', 'BP', 'PIERRE EMILE', '367', 1),
(290, 301, 1, '50', 'CA', 'SIETTE', '435', 1),
(291, 302, 1, '63', 'PO', 'ROCHE', '335', 1),
(292, 303, 1, '133', 'PO', 'MOREAU', '1246', 1),
(293, 304, 1, '69', 'CM', 'MONNIER', '409', 1),
(294, 305, 1, '145', 'BP', 'DESMARS', '567', 1),
(295, 306, 1, '117', 'CM', 'ONILLON', '864', 1),
(296, 307, 1, '140', 'CM', 'BOUCHARD', '456', 1),
(297, 308, 1, '140', 'BNP', 'VERMELUN', '872', 1),
(298, 309, 1, '140', 'BNP', 'MANCEAU', '747', 1),
(299, 310, 1, '280', 'BP', 'BOIVIN', '5008', 1),
(300, 311, 1, '140', 'CA', 'PECOT', '242', 1),
(301, 312, 1, '221', 'BP', 'DESMARS', '570', 1),
(302, 313, 1, '76', 'BP', 'DESMARS', '570', 1),
(303, 314, 1, '61', 'CA', 'FRESNEAU', '461', 1),
(304, 315, 1, '93', 'CA', 'GUYADER', '553', 1),
(305, 316, 1, '46', 'BP', 'FOUGERI', '874', 1),
(306, 317, 1, '64', 'BP', 'GAULTIER', '1847', 1),
(307, 318, 1, '96', 'CM', 'ROUSSEL', '333', 1),
(308, 319, 1, '56', 'CA', 'PECOT', '243', 1),
(309, 320, 1, '24', 'NON RENSEIGNE', 'NON RENSEIGNE', 'NON RENSEIGNE', 1),
(310, 321, 1, '24', 'NON RENSEIGNE', 'NON RENSEIGNE', 'NON RENSEIGNE', 1),
(311, 322, 1, '24', 'NON RENSEIGNE', 'NON RENSEIGNE', 'NON RENSEIGNE', 1),
(312, 323, 1, '24', 'NON RENSEIGNE', 'NON RENSEIGNE', 'NON RENSEIGNE', 1),
(313, 324, 1, '24', 'NON RENSEIGNE', 'NON RENSEIGNE', 'NON RENSEIGNE', 1),
(314, 325, 1, '30', 'NON RENSEIGNE', 'LUBIN', 'NON RENSEIGNE', 1),
(315, 326, 1, '24', 'NON RENSEIGNE', 'MARCHAIS ', 'NON RENSEIGNE', 1),
(316, 327, 1, '24', 'NON RENSEIGNE', 'BAULU', 'NON RENSEIGNE', 1),
(317, 328, 1, '30', 'NON RENSEIGNE', 'LUBIN', 'NON RENSEIGNE', 1),
(318, 329, 1, '24', 'NON RENSEIGNE', 'FRESNEAU', 'NON RENSEIGNE', 1),
(319, 330, 1, '24', 'NON RENSEIGNE', 'IDDER', 'NON RENSEIGNE', 1),
(320, 331, 1, '12', 'NON RENSEIGNE', 'POUPAULT', 'NON RENSEIGNE', 1),
(321, 332, 1, '12', 'NON RENSEIGNE', 'POUPAULT', 'NON RENSEIGNE', 1),
(322, 333, 1, '24', 'NON RENSEIGNE', 'RICHOMME', 'NON RENSEIGNE', 1),
(323, 334, 1, '18', 'NON RENSEIGNE', 'DOUILLY', 'NON RENSEIGNE', 1),
(324, 335, 1, '24', 'NON RENSEIGNE', 'GAULTIER', 'NON RENSEIGNE', 1),
(325, 336, 1, '30', 'NON RENSEIGNE', 'GARNIER', 'NON RENSEIGNE', 1),
(326, 337, 1, '48', 'NON RENSEIGNE', 'ROUFFIAC', 'NON RENSEIGNE', 1),
(327, 338, 1, '24', 'NON RENSEIGNE', 'MESLET', 'NON RENSEIGNE', 1),
(328, 339, 1, '18', 'NON RENSEIGNE', 'MILLION', 'NON RENSEIGNE', 1),
(329, 340, 1, '42', 'NON RENSEIGNE', 'ARMOURDOM', 'NON RENSEIGNE', 1),
(330, 341, 1, '24', 'NON RENSEIGNE', 'CLEMENT', 'NON RENSEIGNE', 1),
(331, 342, 1, '12', 'NON RENSEIGNE', 'RAGOT', 'NON RENSEIGNE', 1),
(332, 343, 1, '24', 'NON RENSEIGNE', 'JANIN', 'NON RENSEIGNE', 1),
(333, 344, 1, '24', 'NON RENSEIGNE', 'GUERRIAU', 'NON RENSEIGNE', 1),
(334, 345, 1, '24', 'NON RENSEIGNE', 'ROUAULT', 'NON RENSEIGNE', 1),
(335, 346, 1, '24', 'NON RENSEIGNE', 'MACKOWSKI', 'NON RENSEIGNE', 1),
(336, 347, 1, '24', 'NON RENSEIGNE', 'PECOT', 'NON RENSEIGNE', 1),
(337, 348, 1, '24', 'NON RENSEIGNE', 'BRANCHEREAU', 'NON RENSEIGNE', 1),
(338, 349, 1, '24', 'NON RENSEIGNE', 'MOTTEAU', 'NON RENSEIGNE', 1),
(339, 350, 1, '24', 'NON RENSEIGNE', 'CROS', 'NON RENSEIGNE', 1),
(340, 351, 1, '24', 'NON RENSEIGNE', 'ROUSSEL', 'NON RENSEIGNE', 1),
(341, 352, 3, '24', '', 'MORTIER', '199485052', 1),
(342, 353, 3, '18', 'AUDIC', 'AUDIC', '114241394', 1),
(343, 354, 3, '12', 'VALLEE', 'VALLEE', '138677975', 1),
(344, 355, 3, '24', 'GUERTIN', 'GUERTIN', '362392015', 1),
(345, 356, 3, '12', 'BARRIERES', 'BARRIERES', '484774929', 1),
(346, 357, 3, '24', 'BACHELOT', 'BACHELOT', '439891372', 1),
(347, 358, 3, '36', 'GUYADER', 'GUYADER', '610631139', 1),
(348, 359, 1, '24', 'NON RENSEIGNE', 'GAULTIER', 'NON RENSEIGNE', 1),
(349, 360, 1, '24', 'NON RENSEIGNE', 'ROUSSEL', 'NON RENSEIGNE', 1),
(350, 361, 1, '30', 'NON RENSEIGNE', 'CERIBAS FILIZ', 'NON RENSEIGNE', 1),
(351, 362, 1, '24', 'NON RENSEIGNE', 'CHALOPIN', 'NON RENSEIGNE', 1),
(352, 363, 1, '12', 'NON RENSEIGNE', 'BERGERET', 'NON RENSEIGNE', 1),
(353, 364, 1, '24', 'NON RENSEIGNE', 'ONILLON', 'NON RENSEIGNE', 1),
(354, 365, 1, '24', 'NON RENSEIGNE', 'MARCHAIS', 'NON RENSEIGNE', 1),
(355, 366, 1, '24', 'NON RENSEIGNE', 'AUDIC', 'NON RENSEIGNE', 1),
(356, 367, 1, '24', 'NON RENSEIGNE', 'DOUILLY', 'NON RENSEIGNE', 1),
(357, 368, 1, '24', 'NON RENSEIGNE', 'CROS', 'NON RENSEIGNE', 1),
(358, 369, 1, '24', 'NON RENSEIGNE', 'FOUGERI', 'NON RENSEIGNE', 1),
(359, 370, 1, '24', 'NON RENSEIGNE', 'GUERRIAU', 'NON RENSEIGNE', 1),
(360, 371, 1, '24', 'NON RENSEIGNE', 'HAULBERT', 'NON RENSEIGNE', 1),
(361, 372, 1, '12', 'NON RENSEIGNE', 'CRIBIER', 'NON RENSEIGNE', 1),
(362, 373, 1, '24', 'NON RENSEIGNE', 'DINGREVILLE', 'NON RENSEIGNE', 1),
(363, 374, 1, '24', 'NON RENSEIGNE', 'BERGERET', 'NON RENSEIGNE', 1),
(364, 375, 1, '36', 'NON RENSEIGNE', 'GUYADER', 'NON RENSEIGNE', 1),
(365, 376, 3, '12', 'BARRIERES', 'BARRIERES', '512381425', 1),
(366, 377, 3, '24', 'PECOT', 'PECOT', '248949677', 1),
(367, 378, 3, '24', 'ARMOURDOM', 'ARMOURDOM', '416160664', 1),
(368, 379, 1, '12', 'CIC', 'BOUVIER', '5493578', 1),
(369, 380, 1, '24', 'CA', 'GUYADER', '4679556', 1),
(370, 381, 1, '24', 'CE', 'IDDER', '5804364', 1),
(371, 382, 1, '24', 'CA', 'PECOT', '8463777', 1),
(372, 383, 1, '24', 'CIC', 'BERGERET', '4216966', 1),
(373, 384, 1, '24', 'CA', 'DAVID ARMEL', '6597143', 1),
(374, 385, 1, '24', 'CE', 'HAULBERT', '3919911', 1),
(375, 386, 1, '30', 'CE', 'LUBIN', '126', 1),
(376, 387, 1, '12', 'BNP', 'IDDER', '5969146', 1),
(377, 389, 3, '0', '', 'DAGUER Stephane', '489778466', 1),
(379, 391, 3, '12', '', 'espece', '570094615', 1),
(380, 392, 3, '24', '', 'garnier', '642105724', 1),
(381, 393, 3, '24', '', 'greffier', '482445835', 1),
(382, 394, 3, '36', '', 'meslet', '128296456', 1),
(383, 395, 3, '12', '', 'guertin', '787468522', 1),
(384, 396, 3, '12', '', 'rouffiac', '794457185', 1),
(385, 390, 3, '6', '', 'fournier', '155090529', 1),
(386, 402, 1, '24', 'bp', 'cros', '035', 1),
(387, 401, 1, '24', 'sg', 'motteau', '5204', 1),
(388, 400, 1, '24', 'cic', 'negri', '318', 1),
(389, 399, 1, '24', 'bnp', 'levron', '667', 1),
(390, 397, 1, '12', 'ca', 'joubert', '143', 1),
(391, 417, 1, '24', 'ce', 'baulu', '293', 1),
(392, 416, 1, '24', 'cm', 'armourdom', '228', 1),
(393, 415, 1, '24', 'bpa', 'gaultier', '1959', 1),
(394, 419, 1, '12', 'cic', 'bouvier', '603', 1),
(395, 413, 1, '30', 'ce', 'lubin', '130', 1),
(396, 411, 1, '24', 'bpa', 'branchereau', '213', 1),
(397, 410, 1, '24', 'ca', 'fresneau', '374', 1),
(398, 409, 1, '12', 'la poste', 'sureau', '022', 1),
(399, 408, 1, '24', 'bp', 'bachelot', '786', 1),
(400, 407, 1, '24', 'bp', 'kerbourch', '1192', 1),
(401, 406, 1, '24', 'ca', 'daguer', '606', 1),
(402, 405, 1, '24', 'ca', 'pecot', '812', 1),
(403, 404, 1, '24', 'cm', 'roussel', '337', 1),
(404, 403, 1, '24', 'ca', 'brunet', '102', 1),
(405, 426, 1, '6', 'ce', 'faucheux', '909', 1),
(406, 425, 1, '24', 'ce', 'mackowski', '2778', 1),
(407, 424, 1, '24', 'ca', 'pecot', '331', 1),
(408, 420, 1, '24', 'cm', 'greffier', '264', 1),
(409, 421, 1, '12', 'lbp', 'boivin', '037', 1),
(410, 423, 1, '24', 'ca', 'guerin', '781', 1),
(411, 422, 1, '24', 'lbp', 'poirrier', '019', 1),
(412, 427, 3, '0', '', 'RAGOT VIRGINIE', '394967458', 0),
(413, 428, 3, '0', '', 'MARCHAIS LAURENT', '882741359', 0),
(414, 429, 3, '0', '', 'POUPAULT ISABELLE', '768252412', 0),
(415, 430, 3, '0', '', 'LAURIOU MICKAEL', '316959642', 0),
(416, 431, 3, '0', '', 'DROUIN DIDIER', '868183281', 0),
(417, 432, 3, '0', '', 'LAURIOU MICKAEL', '802118274', 0),
(418, 433, 3, '0', '', 'DROUIN DIDIER', '292294948', 0),
(419, 434, 3, '0', '', 'CHAPEAU OLIVIER', '211493307', 0),
(420, 435, 3, '0', '', 'GAGUER STEPHANE', '713002529', 0),
(421, 436, 3, '0', '', 'ARMOURDOM LAURENT', '373889220', 0),
(422, 437, 3, '0', '', 'POUPAULT ISABELLE', '561172761', 0),
(423, 438, 3, '0', '', 'IDDER MEHDI', '586767443', 0),
(424, 439, 3, '0', '', 'NIANGORAN OURA SEVERIN', '815972340', 0),
(425, 440, 3, '0', '', 'IDDER MEHDI', '574306381', 0),
(426, 441, 3, '0', '', 'GAULTIER SEBASTIEN', '426634269', 0),
(427, 442, 3, '0', '', 'NIANGORAN OURA SEVERIN', '851992620', 0),
(428, 443, 3, '0', '', 'ARMOURDON LAURENT', '790780527', 0),
(429, 444, 3, '0', '', 'MARSAULT FRANCOISE', '956835029', 0),
(430, 445, 3, '0', '', 'DOUILLY OLIVIER', '448755844', 0),
(431, 446, 3, '0', '', 'DOUILLY OLIVIER', '213433727', 0),
(432, 447, 3, '0', '', 'MARCHAIS LAURENT', '760783390', 0),
(433, 448, 3, '0', '', 'CLEMENT OLIVIER', '492586662', 0),
(434, 449, 3, '0', '', 'MARSAULT FRANCOISE', '954917184', 0),
(435, 450, 3, '0', '', 'FAUCHEUX FREDDY', '916727203', 0),
(437, 452, 3, '0', '', 'FAUCHEUX FREDDY', '438231765', 0),
(438, 453, 3, '0', '', 'ARMOURDOM LAURENT', '456910356', 0),
(439, 454, 3, '0', '', 'LAURIOU MICKAEL', '581968698', 0),
(440, 455, 3, '0', '', 'DROUIN DIDIER', '802292304', 0),
(441, 456, 3, '0', '', 'POUPAULT ISABELLE', '104259186', 0),
(442, 457, 3, '0', '', 'IDDER MEHDI', '933802886', 0),
(443, 458, 3, '0', '', 'LEVRON Jean Louis', '643708158', 0),
(444, 459, 3, '0', '', 'VERMELUN CHRISTIAN', '794381394', 0),
(445, 460, 3, '0', '', 'LEVRON Jean Louis', '137379126', 0),
(446, 461, 3, '0', '', 'VERMELUN Christian', '677604315', 0),
(447, 451, 3, '0', '', 'RAGOT VIRGINIE', '329329224', 0),
(448, 462, 3, '12', '', 'MESLET', '585779957', 1),
(449, 465, 1, '24', 'CE', 'FOURNIER', '159', 1),
(450, 464, 1, '24', 'CA', 'marchais', '204', 1),
(451, 463, 1, '24', 'SG', 'motteau', '324', 1),
(452, 466, 1, '72', 'CA', 'GUERRIAU', '001', 1),
(453, 467, 1, '48', 'CA', 'DINGREVILLE', '002', 1),
(454, 468, 1, '36', 'CA', 'armourdom', '003', 1),
(455, 475, 1, '140', 'BNP', 'VERMELUN', '888', 1),
(456, 474, 1, '140', 'CM', 'CHAPLAIN', '187', 1),
(457, 473, 1, '280', 'CM', 'FREULON', '082', 1),
(458, 472, 1, '140', 'CA', 'DOUILLY', '732', 1),
(459, 471, 1, '140', 'BP', 'ROCHER', '041', 1),
(460, 470, 1, '140', 'BP', 'PECOT', '024', 1),
(461, 469, 1, '140', 'CA', 'RAPICAULT', '313', 1),
(462, 478, 3, '12', '', 'MESLET', '872591666', 1),
(463, 483, 3, '12', '', 'ONI', '202109556', 1),
(464, 482, 1, '12', 'CE', 'IDDER', '410', 1),
(465, 481, 1, '24', 'CM', 'GREFFIER', '542', 1),
(466, 480, 1, '24', 'CM', 'HAULBERT', '476', 1),
(467, 479, 1, '24', 'CE', 'MARTIN', '634', 1),
(468, 477, 1, '24', 'CA', 'GUERIN', '529', 1),
(469, 476, 1, '24', 'BP', 'CROS', '038', 1),
(470, 484, 1, '74', 'BP', 'bachelot', '792', 1),
(471, 485, 1, '47', 'sg', 'GUERRIAU', '909', 1),
(473, 486, 1, '79', 'ce', 'baulu', '308', 1),
(474, 487, 1, '106', 'ca', 'fresneau', '389', 1),
(475, 488, 1, '62', 'ca', 'onillon', '254', 1),
(476, 489, 1, '68', 'cm', 'GUERRIAU', '841', 1),
(477, 490, 1, '76', 'cm', 'roussel', '351', 1),
(478, 491, 1, '47', 'ce', 'boudaud', '587', 1),
(479, 492, 1, '187', 'cm', 'GUERRIAU', '931', 1),
(480, 493, 1, '436', 'BP', 'GUERRIAU', '615', 1),
(481, 494, 1, '102', 'cm', 'collet', '373', 1),
(482, 496, 1, '54', 'bnp', 'robichon', '212', 1),
(483, 497, 1, '87', 'ce', 'DOUILLY', '341', 1),
(484, 498, 1, '152', 'BP', 'ceribas', '256', 1),
(485, 499, 1, '244', 'bnp', 'serbouti', '982', 1),
(486, 500, 1, '71', 'lcl', 'pierre emile', '374', 1),
(487, 501, 1, '56', 'cm', 'marseault', '620', 1),
(488, 502, 1, '164', 'ca', 'simonneau', '350', 1),
(489, 503, 3, '24', '', 'poirrier ', '919559794', 1),
(490, 504, 3, '12', '', 'ROUAULT', '903705439', 1),
(491, 505, 3, '12', '', 'CHAPLAIN', '540218917', 1),
(492, 506, 3, '24', '', 'ESPECE', '774122063', 1),
(493, 507, 3, '24', '', 'armourdom', '397258536', 1),
(494, 508, 3, '12', '', 'audic', '445376889', 1),
(495, 509, 3, '30', '', 'garnier', '538720454', 1),
(496, 510, 3, '24', '', 'piou', '642107182', 1),
(497, 511, 3, '24', '', 'wada', '517398753', 1),
(498, 512, 1, '48', 'ce', 'rouffiac', '998', 1),
(499, 513, 1, '30', 'ca', 'ceribas', '668', 1),
(500, 514, 1, '24', 'cm', 'hanquart', '934', 1),
(501, 515, 1, '24', 'ca', 'richomme', '062', 1),
(502, 516, 1, '24', 'cm', 'HAULBERT', '481', 1),
(503, 517, 1, '12', 'cic', 'bouvier', '957', 1),
(504, 518, 1, '24', 'BP', 'CROS', '015', 1),
(505, 519, 1, '24', 'cm', 'marseault', '826', 1),
(506, 520, 1, '24', 'ce', 'vallee', '835', 1),
(507, 521, 1, '24', 'sg', 'GUERRIAU', '929', 1),
(508, 522, 1, '24', 'ce', 'MARTIN', '636', 1),
(509, 523, 1, '24', 'ce', 'IDDER', '305', 1);

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_remb_ayant_droit`
--

INSERT INTO `reg_remb_ayant_droit` (`idregrembayantdroit`, `idrembayantdroit`, `montant_reglement`, `num_chq`) VALUES
(1, 1, '50,00', '938'),
(2, 2, '50,00', '448'),
(3, 3, '50,00', '942'),
(4, 4, '50,00', '941'),
(5, 6, '50,00', '935'),
(6, 7, '50,00', '936'),
(7, 8, '50,00', '937'),
(8, 9, '33,50', '946'),
(9, 10, '50,00', '943'),
(10, 11, '50,00', '449'),
(11, 12, '50,00', '939'),
(12, 13, '50,00', '947'),
(13, 14, '50,00', '50'),
(14, 15, '50,00', '452'),
(15, 16, '50,00', '459'),
(16, 17, '50,00', '456'),
(17, 18, '50,00', '459'),
(18, 19, '49,80', '456'),
(19, 20, '50,00', '457'),
(20, 21, '42,00', '461'),
(21, 22, '50,00', '460'),
(22, 23, '50,00', '462'),
(23, 24, '50,00', '466'),
(24, 25, '50,00', '465'),
(25, 26, '50,00', '8181'),
(26, 27, '50,00', '471'),
(27, 28, '50,00', '470'),
(28, 29, '50,00', '205'),
(29, 30, '50,00', '204'),
(30, 31, '50,00', '203'),
(31, 32, '50,00', '202'),
(32, 33, '50,00', '210'),
(33, 34, '50,00', '209'),
(34, 35, '50,00', '215'),
(35, 36, '50,00', '216'),
(36, 37, '50,00', '217'),
(37, 38, '50,00', '225'),
(38, 39, '50,00', '226'),
(39, 40, '50,00', '333'),
(40, 42, '50,00', '338'),
(41, 41, '50,00', '338'),
(42, 43, '50,00', '341'),
(43, 44, '50,00', '340'),
(44, 45, '50,00', '346'),
(45, 46, '50,00', '50'),
(46, 47, '32,00', '229'),
(47, 48, '44,00', '230'),
(48, 49, '50,00', '231');

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_remb_salarie`
--

INSERT INTO `reg_remb_salarie` (`idregrembsalarie`, `idrembsalarie`, `montant_reglement`, `num_chq`) VALUES
(1, 1, '150,00', '459'),
(2, 2, '150,00', '455'),
(3, 3, '150,00', '458'),
(4, 4, '150,00', '464'),
(5, 5, '150,00', '463'),
(6, 6, '150,00', '8180'),
(7, 7, '150,00', '472'),
(8, 8, '150,00', '469'),
(9, 9, '150,00', '468'),
(10, 10, '150,00', '467'),
(11, 11, '150,00', '123'),
(12, 12, '150,00', '186'),
(13, 13, '150,00', '187'),
(14, 25, '150,00', '182'),
(15, 26, '150,00', '183'),
(16, 27, '150,00', '184'),
(17, 28, '150,00', '185'),
(18, 22, '150,00', '483'),
(19, 14, '150,00', '473'),
(20, 15, '150,00', '474'),
(21, 17, '150,00', '475'),
(22, 16, '150,00', '476'),
(23, 19, '150,00', '477'),
(24, 18, '150,00', '478'),
(25, 20, '150,00', '479'),
(26, 21, '150,00', '480'),
(27, 23, '150,00', '481'),
(28, 24, '150,00', '482'),
(29, 29, '150,00', '188'),
(30, 30, '150,00', '189'),
(31, 31, '150,00', '192'),
(32, 32, '150,00', '191'),
(33, 33, '150,00', '190'),
(34, 34, '150,00', '208'),
(35, 35, '150,00', '207'),
(36, 36, '150,00', '201'),
(37, 37, '150,00', '200'),
(38, 38, '150,00', '199'),
(39, 39, '150,00', '197'),
(40, 40, '150,00', '198'),
(41, 41, '150,00', '211'),
(42, 42, '150,00', '214'),
(43, 49, '140,28', '224'),
(44, 43, '150,00', '218'),
(45, 45, '150,00', '220'),
(46, 46, '150,00', '221'),
(47, 47, '150,00', '222'),
(48, 48, '150,00', '223'),
(49, 44, '150,00', '219'),
(50, 50, '150,00', '334'),
(51, 52, '150,00', '335'),
(52, 51, '150,00', '336'),
(53, 53, '150,00', '342'),
(54, 54, '150,00', '543'),
(55, 55, '79,30', '344'),
(56, 56, '150,00', '345'),
(57, 57, '130,00', '347'),
(58, 58, '150,00', '351'),
(59, 59, '80,32', '350'),
(60, 60, '150,00', '351');

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remb_ayant_droit`
--

INSERT INTO `remb_ayant_droit` (`idrembayantdroit`, `idayantdroit`, `prestation`, `date_vente`, `montant_prestation`, `part_ce`, `etat_facture`, `num_mouvement`) VALUES
(2, 234, 'PARTICIPATION CE AUX LOISIRS', '20-04-2015', '50', '50', 1, ''),
(3, 231, 'PARTICIPATION DU C.E AUX  LOISIRS', '17-02-2015', '50', '50', 1, ''),
(4, 253, 'PARTICIPATION DU C.E AUX LOISIRS', '01-02-2015', '50', '50', 1, ''),
(6, 181, 'PARTICIPATION DU C.E AUX LOISIRS', '12-01-2015', '50', '50', 1, ''),
(7, 227, 'PARTICIPATION DU C.E AUX LOISIRS', '13-01-2015', '50', '50', 1, ''),
(8, 239, 'PARTICIPATION DU C.E AUX LOISIRS', '15-01-2015', '50', '50', 1, ''),
(9, 194, 'PARTICIPATION DU C.E AUX LOISIRS', '17-02-2015', '33.50', '33.50', 1, ''),
(10, 229, 'PARTICIPATION DU C.E AUX LOISIRS', '17-02-2015', '50', '50', 1, ''),
(11, 199, 'PARTICIPATION DU C.E AUX LOISIRS', '20-04-2015', '50', '50', 1, ''),
(12, 233, 'PARTICIPATION DU C.E AUX LOISIRS', '13-01-2015', '50', '50', 1, ''),
(13, 192, 'PARTICIPATION DU C.E AUX LOISIRS', '17-02-2015', '50', '50', 1, ''),
(14, 169, 'PARTICIPATION DU C.E AUX LOISIRS', '15-01-2015', '50', '50', 1, ''),
(15, 213, 'ALLOCATION LOISIRS', '26-05-2015', '453', '50', 1, '1442206046'),
(18, 198, 'ALLOCATION LOISIRS', '02-06-2015', '73', '50', 1, '6984846322'),
(19, 238, 'ALLOCATION LOISIRS', '02-06-2015', '49.80', '49.80', 1, '5033455626'),
(20, 171, 'ALLOCATION LOISIRS', '02-06-2015', '54.50', '50', 1, '8280871194'),
(21, 182, 'ALLOCATION LOISIRS', '15-06-2015', '42', '42', 1, '8886342398'),
(22, 201, 'ALLOCATION LOISIRS', '15-06-2015', '70', '50', 1, '586332703'),
(23, 207, 'ALLOCATION LOISIRS', '15-06-2015', '110', '50', 1, '4950911482'),
(24, 236, 'ALLOC LOISIRS ', '24-06-2015', '94', '50', 1, '8836364937'),
(25, 178, 'ALLOC LOISIRS ', '24-06-2015', '86', '50', 1, '3693116345'),
(26, 175, 'allocation loisirs', '21-07-2015', '73', '50', 1, '4050343218'),
(27, 205, 'ALLOCATION LOISIRS', '28-07-2015', '95', '50', 1, '4209308610'),
(28, 222, 'ALLOCATION LOISIRS', '28-07-2015', '95', '50', 1, '2507952159'),
(29, 188, 'ALLOC LOISIRS ', '01-09-2015', '63', '50', 1, '705041090'),
(30, 193, 'ALLOC LOISIRS ', '01-09-2015', '180', '50', 1, '2741586822'),
(31, 180, 'ALLOCATION LOISIRS', '01-09-2015', '145', '50', 1, '1428685626'),
(32, 179, 'ALLOC LOISIRS ', '01-09-2015', '90', '50', 1, '4699004418'),
(33, 210, 'ALLOC LOISIRS ', '07-09-2015', '291', '50', 1, '6836895565'),
(34, 183, 'ALLOCATION LOISIRS', '08-09-2015', '155', '50', 1, '9294497575'),
(35, 215, 'ALLOCATION LOISIRS', '10-09-2015', '96', '50', 1, '6501609310'),
(36, 176, 'ALLOC LOISIRS ', '02-09-2015', '140', '50', 1, '8153159632'),
(37, 184, 'ALLOCATION LOISIRS', '03-09-2015', '130', '50', 1, '9475106336'),
(38, 191, 'ALLOCATION LOISIRS', '21-09-2015', '100', '50', 1, '9059728528'),
(39, 254, 'ALLOCATION LOISIRS', '21-09-2015', '122', '50', 1, '9348237318'),
(40, 208, 'ALLOCATION LOISIRS', '29-09-2015', '65', '50', 1, '3178855488'),
(41, 170, 'ALLOCATION LOISIRS', '29-09-2015', '215', '50', 1, '9789497838'),
(42, 209, 'ALLOCATION LOISIRS', '29-09-2015', '103', '50', 1, '709789256'),
(43, 221, 'ALLOC LOISIRS ', '02-10-2015', '57', '50', 1, '5949488841'),
(44, 186, 'ALLOC LOISIRS ', '02-10-2015', '245', '50', 1, '4050949277'),
(45, 251, 'ALLOCATION LOISIRS', '02-10-2015', '135', '50', 1, '8968575764'),
(46, 232, 'ALLOCATION LOISIRS', '20-10-2015', '73', '50', 1, '799871600'),
(47, 235, 'ALLOCATION LOISIRS', '20-10-2015', '32', '32', 1, '247338373'),
(48, 189, 'ALLOCATION LOISIRS', '20-10-2015', '44', '44', 1, '6609840537'),
(49, 224, 'ALLOCATION LOISIRS', '20-10-2015', '90', '50', 1, '404292350');

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remb_salarie`
--

INSERT INTO `remb_salarie` (`idrembsalarie`, `idsalarie`, `prestation`, `date_vente`, `montant_prestation`, `part_ce`, `etat_facture`, `num_mouvement`) VALUES
(2, 85, 'ALLOCATION VACANCE', '02-06-2015', '194', '150', 1, '889982583001'),
(3, 108, 'ALLOCATION VACANCE', '02-06-2015', '390', '150', 1, '612524654716'),
(4, 87, 'alllocation vacance ', '15-06-2015', '1584', '150', 1, '438415773213'),
(5, 91, 'alllocation vacance ', '15-06-2015', '241', '150', 1, '16831546091'),
(6, 113, 'alloc vacance', '12-07-2015', '611', '150', 1, '421351411846'),
(7, 76, 'alllocation vacance ', '28-07-2015', '1294', '150', 1, '903106779791'),
(8, 75, 'alllocation vacance ', '28-07-2015', '265', '150', 1, '400730542839'),
(9, 143, 'alllocation vacance ', '28-07-2015', '162', '150', 1, '685626462567'),
(10, 125, 'alllocation vacance ', '28-07-2015', '154', '150', 1, '999402718618'),
(11, 127, 'alllocation vacance ', '28-07-2015', '487', '150', 1, '323534653057'),
(12, 92, 'allocation vacance', '24-08-2015', '300', '150', 1, '644799424335'),
(13, 142, 'allocation vacance', '24-08-2015', '699', '150', 1, '99525161088'),
(14, 79, 'allocation vacance', '25-08-2015', '612', '150', 1, '565350872930'),
(15, 146, 'allocation vacance', '25-08-2015', '669', '150', 1, '420539968181'),
(16, 121, 'allocation vacance', '25-08-2015', '629', '150', 1, '312499290798'),
(17, 103, 'allocation vacance', '25-08-2015', '669', '150', 1, '513738993090'),
(18, 80, 'allocation vacance', '25-08-2015', '290', '150', 1, '625417531468'),
(19, 155, 'allocation vacance', '25-08-2015', '150', '150', 1, '87278132327'),
(20, 82, 'allocation vacance', '25-08-2015', '277', '150', 1, '679863286204'),
(21, 74, 'allocation vacance', '25-08-2015', '1212', '150', 1, '888595257420'),
(22, 111, 'allocation vacance', '25-08-2015', '682', '150', 1, '471647528932'),
(23, 140, 'allocation vacance', '25-08-2015', '677', '150', 1, '77512939461'),
(24, 116, 'allocation vacance', '25-08-2015', '944', '150', 1, '9936326650'),
(25, 95, 'allocation vacance', '25-08-2015', '297', '150', 1, '584448751993'),
(26, 97, 'allocation vacance', '25-08-2015', '643', '150', 1, '163545305841'),
(27, 90, 'allocation vacance', '25-08-2015', '1896', '150', 1, '40894807782'),
(28, 94, 'allocation vacance', '25-08-2015', '300', '150', 1, '239772253670'),
(29, 139, 'allocation vacance', '25-08-2015', '1827', '150', 1, '683775858953'),
(30, 100, 'allocation vacance', '01-09-2015', '432', '150', 1, '847594105638'),
(31, 86, 'allocation vacance', '02-09-2015', '693', '150', 1, '5751915742'),
(32, 105, 'allocation vacance', '02-09-2015', '575', '150', 1, '454039545264'),
(33, 123, 'allocation vacance', '01-09-2015', '186', '150', 1, '536473579705'),
(34, 89, 'allocation vacance', '01-09-2015', '183', '150', 1, '259158585221'),
(35, 126, 'allocation vacance', '02-09-2015', '2799', '150', 1, '40721359198'),
(36, 110, 'allocation vacance', '01-09-2015', '659', '150', 1, '780559918377'),
(37, 147, 'allocation vacance', '01-09-2015', '952', '150', 1, '319234014489'),
(38, 117, 'allocation vacance', '01-09-2015', '276', '150', 1, '571244949475'),
(39, 99, 'allocation vacance', '01-09-2015', '643', '150', 1, '481509226374'),
(40, 130, 'allocation vacance', '01-09-2015', '1808', '150', 1, '238586999011'),
(41, 136, 'allocation vacance', '07-09-2015', '157', '150', 1, '225719915238'),
(42, 88, 'allocation vacance', '03-09-2015', '636', '150', 1, '914618178736'),
(43, 77, 'allocation vacance', '21-09-2015', '340', '150', 1, '451765113510'),
(44, 114, 'allocation vacance', '21-09-2015', '299', '150', 1, '77137953137'),
(45, 102, 'allocation vacance', '21-09-2015', '750', '150', 1, '299420020543'),
(46, 132, 'allocation vacance', '21-09-2015', '419.70', '150', 1, '330027887132'),
(47, 107, 'allocation vacance', '21-09-2015', '567', '150', 1, '724870459176'),
(48, 144, 'allocation vacance', '21-09-2015', '532', '150', 1, '68782654591'),
(49, 129, 'allocation vacance', '21-09-2015', '140.28', '140.28', 1, '380398741458'),
(50, 149, 'allocation vacance', '29-09-2015', '660', '150', 1, '799762269947'),
(51, 84, 'allocation vacance', '29-09-2015', '400', '150', 1, '562917870469'),
(52, 81, 'allocation vacance', '29-09-2015', '400', '150', 1, '845400576014'),
(53, 104, 'allocation vacance', '02-10-2015', '690', '150', 1, '902611814905'),
(54, 115, 'allocation vacance', '02-10-2015', '530', '150', 1, '663407182321'),
(55, 158, '79.30', '02-10-2015', '79.30', '79.30', 1, '216121441685'),
(56, 138, 'allocation vacance', '01-10-2015', '417', '150', 1, '357426176779'),
(57, 83, 'allocation vacance', '03-10-2015', '130', '130', 1, '122393353843'),
(58, 124, 'allocation vacance', '02-11-2015', '649', '150', 1, '512463990133'),
(59, 106, 'alllocation vacance ', '02-11-2015', '80.32', '80.32', 1, '908418876119'),
(60, 98, 'allocation vacance', '01-11-2015', '938', '150', 1, '741440337151');

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque`
--

INSERT INTO `remise_banque` (`idremisebanque`, `date_remise`, `type_remise`, `num_remise`, `montant_remise`, `valid`) VALUES
(1, '27-02-2015', 1, '1741327', '50', 1),
(5, '03-03-2015', 2, '06987853', '9', 1),
(6, '03-03-2015', 2, '06988306', '144', 1),
(7, '03-03-2015', 2, '06987864', '325', 1),
(8, '03-03-2015', 2, 'REMISE EPURATRICE', '0', 1),
(9, '01-01-2015', 1, '3501417', '1260', 1),
(10, '01-01-2015', 1, '3501420', '484', 1),
(11, '15-01-2015', 1, '3501419', '1820', 1),
(12, '10-04-2015', 1, '3501421', '840', 1),
(13, '10-04-2015', 1, '3501422', '1680', 1),
(14, '19-05-2015', 1, '8089902', '1162', 1),
(15, '02-06-2015', 1, '8089903', '713', 1),
(16, '02-06-2015', 1, '8089904', '700', 1),
(17, '10-02-2015', 1, '3492672', '120', 1),
(18, '02-01-2015', 1, '343434', '204', 1),
(19, '03-03-2015', 1, '3492675', '456', 1),
(20, '03-03-2015', 2, '5725', '150', 1),
(21, '31-03-2015', 1, '3492677', '186', 1),
(22, '30-04-2015', 1, '3492679', '216', 1),
(23, '30-04-2015', 2, '6988295', '60', 1),
(24, '29-05-2015', 1, '3492681', '198', 1),
(25, '02-06-2015', 1, '3075905', '120', 1),
(27, '09-09-2015', 2, '6987794', '126', 1),
(28, '08-09-2015', 1, '3492682', '108', 1),
(29, '09-09-2015', 1, '3492688', '318', 1),
(30, '09-09-2015', 1, '3492689', '138', 1),
(31, '29-09-2015', 2, '6987783', '12', 1),
(32, '29-09-2015', 1, '3492764', '72', 1),
(33, '15-09-2015', 1, '3492763', '156', 1),
(34, '01-10-2015', 1, '8089906', '1120', 1),
(35, '6-10-2015', 2, '698772', '24', 1),
(36, '06-10-2015', 1, '3492690', '132', 1),
(37, '20-10-2015', 1, '8089905', '1425', 1),
(38, '20-10-2015', 1, '8089907', '687', 1),
(39, '4-11-2015', 2, '00012', '186', 1),
(40, '3-11-2015', 1, '3492692', '306', 1);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque_chq`
--

INSERT INTO `remise_banque_chq` (`idremisebanquechq`, `idremisebanque`, `idreglementventepresta`) VALUES
(1, 1, 163),
(2, 9, 254),
(3, 9, 257),
(4, 9, 255),
(5, 9, 256),
(6, 9, 258),
(7, 9, 253),
(8, 10, 252),
(9, 10, 251),
(10, 11, 274),
(11, 11, 273),
(12, 11, 271),
(13, 11, 270),
(14, 11, 263),
(15, 11, 259),
(16, 11, 260),
(17, 11, 268),
(18, 11, 296),
(19, 11, 267),
(20, 11, 275),
(21, 12, 266),
(22, 12, 264),
(23, 12, 272),
(24, 12, 265),
(26, 13, 262),
(27, 13, 279),
(28, 13, 276),
(29, 13, 269),
(30, 13, 278),
(31, 13, 277),
(32, 13, 280),
(33, 14, 295),
(34, 14, 289),
(35, 14, 290),
(36, 14, 282),
(37, 14, 283),
(38, 14, 288),
(39, 14, 284),
(40, 14, 286),
(41, 14, 294),
(42, 14, 285),
(43, 14, 287),
(44, 14, 293),
(45, 14, 291),
(46, 14, 292),
(47, 15, 301),
(48, 15, 302),
(49, 15, 303),
(50, 15, 304),
(51, 15, 305),
(52, 15, 306),
(53, 15, 307),
(54, 15, 308),
(55, 16, 297),
(56, 16, 299),
(57, 16, 298),
(58, 16, 300),
(59, 17, 309),
(60, 17, 310),
(61, 17, 311),
(62, 17, 312),
(63, 17, 313),
(64, 18, 314),
(65, 18, 315),
(66, 18, 316),
(67, 18, 317),
(68, 18, 318),
(69, 18, 319),
(70, 18, 320),
(71, 18, 321),
(72, 18, 322),
(73, 19, 323),
(74, 19, 324),
(75, 19, 325),
(76, 19, 326),
(77, 19, 327),
(78, 19, 328),
(79, 19, 329),
(80, 19, 330),
(81, 19, 331),
(82, 19, 332),
(83, 19, 333),
(84, 19, 334),
(85, 19, 335),
(86, 19, 336),
(87, 19, 337),
(88, 19, 338),
(89, 19, 339),
(90, 19, 340),
(91, 21, 348),
(92, 21, 349),
(93, 21, 350),
(94, 21, 351),
(95, 21, 352),
(96, 21, 353),
(97, 21, 354),
(98, 21, 355),
(99, 22, 356),
(100, 22, 357),
(101, 22, 358),
(102, 22, 359),
(103, 22, 360),
(104, 22, 361),
(105, 22, 362),
(106, 22, 363),
(107, 22, 364),
(108, 24, 368),
(109, 24, 369),
(110, 24, 370),
(111, 24, 371),
(112, 24, 372),
(113, 24, 373),
(114, 24, 374),
(115, 24, 375),
(116, 24, 376),
(117, 25, 250),
(118, 13, 281),
(119, 12, 261),
(120, 28, 390),
(121, 28, 389),
(122, 28, 388),
(123, 28, 387),
(124, 28, 386),
(125, 29, 404),
(126, 29, 403),
(127, 29, 402),
(128, 29, 401),
(129, 29, 400),
(130, 29, 399),
(131, 29, 398),
(132, 29, 397),
(133, 29, 395),
(134, 29, 396),
(135, 29, 391),
(136, 29, 392),
(137, 29, 393),
(138, 29, 394),
(139, 30, 405),
(140, 30, 411),
(141, 30, 407),
(142, 30, 408),
(143, 30, 409),
(144, 30, 410),
(145, 30, 406),
(146, 32, 449),
(147, 32, 450),
(148, 32, 451),
(149, 33, 452),
(150, 33, 453),
(151, 33, 454),
(152, 34, 455),
(153, 34, 457),
(154, 34, 456),
(155, 34, 458),
(156, 34, 459),
(157, 34, 460),
(158, 34, 461),
(159, 36, 464),
(160, 36, 465),
(161, 36, 466),
(162, 36, 467),
(163, 36, 468),
(164, 36, 469),
(165, 37, 470),
(166, 37, 471),
(167, 37, 473),
(168, 37, 474),
(169, 37, 475),
(170, 37, 476),
(171, 37, 477),
(172, 37, 478),
(173, 37, 479),
(174, 37, 480),
(175, 37, 481),
(176, 37, 482),
(177, 37, 483),
(178, 38, 484),
(179, 38, 485),
(180, 38, 486),
(181, 38, 487),
(182, 38, 488),
(183, 40, 498),
(184, 40, 499),
(185, 40, 500),
(186, 40, 501),
(187, 40, 502),
(188, 40, 503),
(189, 40, 504),
(190, 40, 505),
(191, 40, 506),
(192, 40, 507),
(193, 40, 508),
(194, 40, 509);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque_esp`
--

INSERT INTO `remise_banque_esp` (`idremisebanqueesp`, `idremisebanque`, `idreglementventepresta`) VALUES
(5, 5, 96),
(6, 5, 97),
(7, 6, 105),
(8, 6, 111),
(9, 6, 249),
(10, 6, 98),
(11, 6, 99),
(12, 6, 100),
(13, 6, 101),
(14, 6, 102),
(15, 6, 103),
(16, 6, 104),
(17, 6, 106),
(18, 6, 107),
(19, 6, 108),
(20, 6, 109),
(21, 6, 112),
(22, 6, 113),
(23, 6, 114),
(24, 7, 110),
(25, 7, 115),
(26, 7, 116),
(27, 7, 117),
(28, 7, 118),
(29, 7, 119),
(30, 7, 120),
(31, 7, 121),
(32, 7, 122),
(33, 7, 123),
(34, 7, 124),
(35, 7, 125),
(36, 7, 126),
(37, 7, 127),
(38, 7, 128),
(39, 7, 129),
(40, 7, 130),
(41, 7, 131),
(42, 7, 132),
(43, 7, 133),
(44, 7, 134),
(45, 7, 135),
(46, 7, 136),
(47, 7, 137),
(48, 7, 138),
(49, 7, 139),
(50, 7, 140),
(51, 7, 141),
(52, 7, 142),
(53, 7, 143),
(54, 7, 144),
(55, 7, 145),
(56, 7, 146),
(57, 7, 147),
(58, 7, 148),
(59, 7, 149),
(60, 7, 150),
(61, 7, 151),
(62, 7, 152),
(63, 7, 153),
(64, 7, 154),
(65, 7, 155),
(66, 7, 156),
(67, 7, 157),
(68, 7, 158),
(69, 7, 159),
(70, 7, 160),
(71, 7, 161),
(72, 7, 162),
(73, 8, 92),
(74, 8, 164),
(75, 8, 165),
(76, 8, 166),
(77, 8, 167),
(78, 8, 168),
(79, 8, 169),
(80, 8, 170),
(81, 8, 171),
(82, 8, 172),
(83, 8, 173),
(84, 8, 174),
(85, 8, 175),
(86, 8, 176),
(87, 8, 177),
(88, 8, 178),
(89, 8, 179),
(90, 8, 180),
(91, 8, 181),
(92, 8, 182),
(93, 8, 183),
(94, 8, 184),
(95, 8, 185),
(96, 8, 186),
(97, 8, 187),
(98, 8, 188),
(99, 8, 189),
(100, 8, 190),
(101, 8, 191),
(102, 8, 192),
(103, 8, 193),
(104, 8, 194),
(105, 8, 195),
(106, 8, 196),
(107, 8, 197),
(108, 8, 198),
(109, 8, 199),
(110, 8, 200),
(111, 8, 201),
(112, 8, 202),
(113, 8, 203),
(114, 8, 204),
(115, 8, 205),
(116, 8, 206),
(117, 8, 207),
(118, 8, 208),
(119, 8, 209),
(120, 8, 210),
(121, 8, 211),
(122, 8, 212),
(123, 8, 213),
(124, 8, 214),
(125, 8, 215),
(126, 8, 216),
(127, 8, 217),
(128, 8, 218),
(129, 8, 219),
(130, 8, 220),
(131, 8, 221),
(132, 8, 222),
(133, 8, 223),
(134, 8, 224),
(135, 8, 225),
(136, 8, 226),
(137, 8, 227),
(138, 8, 228),
(139, 8, 229),
(140, 8, 230),
(141, 8, 231),
(142, 8, 232),
(143, 8, 233),
(144, 8, 234),
(145, 8, 235),
(146, 8, 236),
(147, 8, 237),
(148, 8, 238),
(149, 8, 239),
(150, 8, 240),
(151, 8, 241),
(152, 8, 242),
(153, 8, 243),
(154, 8, 244),
(155, 8, 245),
(156, 8, 246),
(157, 8, 247),
(158, 8, 248),
(159, 20, 341),
(160, 20, 343),
(161, 20, 342),
(162, 20, 344),
(163, 20, 345),
(164, 20, 346),
(165, 20, 347),
(166, 23, 365),
(167, 23, 366),
(168, 23, 367),
(176, 27, 385),
(177, 27, 384),
(178, 27, 382),
(179, 27, 383),
(180, 27, 381),
(181, 27, 379),
(182, 27, 380),
(183, 31, 448),
(184, 35, 462),
(185, 35, 463),
(186, 39, 495),
(187, 39, 489),
(188, 39, 490),
(189, 39, 493),
(190, 39, 492),
(191, 39, 491),
(192, 39, 494),
(193, 39, 496),
(194, 39, 497);

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(72, '', 1, 'CARTRON', 'OLIVIER', '34 RUE MAIRIE', '', '49570', 'MONTJEAN SUR LOIRE', '', '', '', '', '03/06/1996', '', '', 'CHEF D''EQUIPE SENIOR', '', '', '', 1, '150'),
(73, '', 1, 'DROUIN', 'DIDIER', '13 rue du Plessis', '', '49350', 'ST CLEMENT DES LEVEES', '', '', '', '', '04/09/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(74, '', 1, 'MARCHAIS', 'LAURENT', '76 RUE JEAN JAURES', '', '49000', 'ANGERS', '', '', '', '', '02/09/1996', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(75, '', 1, 'LAURIOU', 'MICKAEL', '1 ALLEE DES CYPRES', '', '49140', 'MARCE', '', '', '', '', '04/09/1996', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(76, '', 1, 'GUERIN', 'JOHNNY', '4 RUE DE L''EGLANTIER', '', '49370', 'LA POUEZE', '', '', '', '', '04/09/1996', '', '', 'CHEF D''EQUIPE SENIOR', '', '', '', 1, '0'),
(77, '', 2, 'BRUNET', 'DOMINIQUE', '41 RUE DE LA VARIE', '', '49770', 'LA MEIGNANNE', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(78, '', 1, 'POIRRIER', 'THIERRY', '7 RUE DU FRAIS FOYER', '', '49000', 'ANGERS', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(79, '', 2, 'NEGRI', 'BRIGITTE', '6 CHEMIN DES HAUTS', '', '49140', 'MONTREUIL SUR LOIR', '', '', '', '', '04/09/1996', '', '', 'ASSISTANT TECHN. EXPL.& LOGISTIQUE', '', '', '', 1, '0'),
(80, '', 2, 'BAULU', 'CATHERINE', '154 RUE DE VILLESICARD', '', '49130', 'LES PONTS DE CE', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(81, '', 1, 'MORTIER', 'FREDERIC', '12, rue Val de Suine', '', '49460', 'FENEU', '', '', '', '', '04/09/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(82, '', 2, 'ROUSSEL', 'PASCALE', '15 RUE DES VIGNES', '', '49610', 'MURS ERIGNE', '', '', '', '', '04/09/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(83, '', 1, 'BADOUR', 'STEPHANE', '55 RUE DE LA REUX', '', '49124', 'ST BARTHELEMY D ANJOU', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '20'),
(84, '', 2, 'DAGUENE', 'FRANCOISE', '12 rue Val de Suine', '', '49460', 'FENEU', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(85, '', 3, 'MACKOWSKI', 'CORINE', 'RD 116 du Plessis Grammoire', 'La Morellerie', '49124', 'SAINT BARTHELEMY D''ANJOU', '', '', '', '', '09/09/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(86, '', 1, 'JANIN', 'SEBASTIEN', '25 rue Eug?ne Tessier', 'De la motte', '49350', 'LES ROSIERS SUR LOIRE', '', '', '', '', '19/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(87, '', 2, 'CHALOPIN', 'BERNADETTE', '12 RUE DE L''AUBANCE', '', '49320', 'LES ALLEUDS', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(88, '', 2, 'PILLARD', 'ISABELLE', '87 RUE DES BANCHAIS', 'RES. MOULIN DE BEAULIEU', '49100', 'ANGERS', '', '', '', '', '09/09/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(89, '', 2, 'KOCH', 'NATHALIE', 'LA PLAINE DES GRANGES', '', '72200', 'BAZOUGES SUR LE LOIR', '', '', '', '', '30/08/1996', '', '', 'SECRETAIRE DE DEPARTEMENT', '', '', '', 1, '0'),
(90, '', 3, 'CROS', 'SEVERINE', '6 AVENUE MARTIN LUTHER KING', '', '49240', 'AVRILLE', '', '', '', '', '16/09/1996', '', '', 'TECHNICIEN EXPLOITATION/LOGISTIQUE', '', '', '', 1, '0'),
(91, '', 1, 'ROUFFIAC', 'CHRISTOPHE', '131 RUE DE LA BARRE', '', '49100', 'ANGERS', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(92, '', 3, 'SUREAU', 'LYDIE', '18 CHEMIN DES MARINIERS', 'LOTISSEMENT DU BOIS MARIN', '49220', 'MONTREUIL SUR MAINE', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(93, '', 1, 'PIOU', 'BENOIT', '19 RUE DE L''HOTELLERIE', '', '49100', 'ANGERS', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(94, '', 3, 'JOUBERT', 'KARINE', 'LOTISSEMENT LE VIRIER', 'LOT 2', '49330', 'ETRICHE', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(95, '', 2, 'DESMARS', 'VERONIQUE', '67 AV JEAN XXIII', '', '49000', 'ANGERS', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(96, '', 1, 'DAVY', 'ANTOINE', 'LA FAVERIE', '', '49110', 'SAINT QUENTIN EN MAUGES', '', '', '', '', '30/08/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(97, '', 1, 'HAULBERT', 'VINCENT', '23 RUE NORBERT CASTERET', '', '49100', 'ANGERS', '', '', '', '', '09/09/1996', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(98, '', 2, 'BOIVIN', 'VERONIQUE', '33 RUE GESSE', '', '49080', 'BOUCHEMAINE', '', '', '', '', '30/09/1996', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(99, '', 1, 'ARMOURDOM', 'LAURENT', '115 Rue Fran&ccedil;ois Mauriac', '', '49800', 'TRELAZE', '0241695397', '0625059215', 'heline01@hotmail.com', '', '24/02/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(100, '', 1, 'DELPHIN', 'SEBASTIEN', 'ROUTE DE MARZELLES', 'LA ROCHE FOULQUES', '49140', 'SOUCELLES', '', '', '', '', '24/02/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(101, '', 1, 'GUERTIN', 'NOEL', '7 rue du Templa', '', '49124', 'LE PLESSIS GRAMMOIRE', '', '', '', '', '24/02/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(102, '', 2, 'HANQUART', 'SANDRA', '5 RUELLE DE LA VALLEE', 'LOTISSEMENT DERRIERE LA VILLE', '49250', 'BEAUFORT EN VALLEE', '', '', '', '', '24/02/1997', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(103, '', 1, 'MESLET', 'THIERRY', '1 SQUARE DES TREILLES', '', '49480', 'ST SYLVAIN D ANJOU', '', '', '', '', '24/02/1997', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(104, '', 3, 'VALLEE', 'KARINE', '13 RUE GILBERT POULIQUEN', '', '49100', 'ANGERS', '', '', '', '', '24/02/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(105, '', 2, 'GUERRIAU', 'MALIKA', '5 B RUE DU 8 MAI 1945', '', '49800', 'ANDARD', '', '', '', '', '24/02/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(106, '', 1, 'COSNIER', 'CHRISTOPHE', '25 RUE RAOUL PONCHON', '', '49100', 'ANGERS', '', '', '', '', '03/03/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '69.68'),
(107, '', 2, 'FOUGERI', 'ANNIE', '45 RUE MAURICE LANGLET', '', '49000', 'ANGERS', '', '', '', '', '03/03/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(108, '', 2, 'MARTIN', 'PATRICIA', '20 RUE ANDRE GIDE', '', '49130', 'LES PONTS DE CE', '', '', '', '', '03/03/1997', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(109, '', 1, 'ADAM', 'STEPHANE', 'RUE DES PETITS VAUX', '', '49150', 'ECHEMIRE', '', '', '', '', '28/06/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(110, '', 1, 'BRANCHEREAU', 'HERVE', '30 avenue Montaigne', '', '49100', 'ANGERS', '', '', '', '', '28/06/1999', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(111, '', 3, 'COUINET', 'SOLEN', 'Les Grands Bauchais', '', '49320', 'LES ALLEUDS', '', '', '', '', '28/06/1999', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(112, '', 1, 'DAVID', 'ARMEL', 'LA MONSELLERIE', '', '49330', 'SOEURDRES', '', '', '', '', '28/06/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(113, '', 1, 'DOUILLY', 'OLIVIER', '1 B ROUTE DE BRIOLLAY', '', '49460', 'SOULAIRE LE BOURG', '', '', '', '', '28/06/1999', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(114, '', 1, 'GAULTIER', 'SEBASTIEN', '10 SQUARE DES CALEIDES', '', '49000', 'ANGERS', '', '', '', '', '28/06/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(115, '', 1, 'RICHOMME', 'HERVE', '6 RUE DES CHARDONNERETS', '', '49250', 'BEAUFORT EN VALLEE', '', '', '', '', '28/06/1999', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(116, '', 2, 'BACHELOT', 'CHRISTELLE', '22 RUE ANDRE LE NOTRE', 'LOTIS. CLOS DU PLESSIS N? 87', '49800', 'TRELAZE', '', '', '', '', '12/07/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(117, '', 1, 'FAUCHEUX', 'FREDDY', '3 RUE DES NOISETIERS', '', '49800', 'BRAIN SUR L''AUTHION', '', '', '', '', '12/07/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(118, '', 2, 'FRESNEAU', 'VERONIQUE', '34 RUE TOUSSAINT CHALOU', '', '49130', 'STE GEMMES', '', '', '', '', '12/07/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(119, '', 2, 'GUERIN', 'HUGUETTE', '10 rue des Vignes', '', '49800', 'TRELAZE', '', '', '', '', '12/07/1999', '', '', 'AGENT DE PRODUCTION NIVEAU 2', '', '', '', 1, '150'),
(120, '', 1, 'FOURNIER', 'MARIO', '19 RUE HENRI ENGUEHARD', '', '49000', 'ANGERS', '', '', '', '', '26/07/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(121, '', 3, 'AUDIC', 'GAELLE', '1A RUE DE LIGNERIE', '', '49124', 'ST BARTHELEMY D ANJOU', '', '', '', '', '06/10/1999', '', '', 'ASSISTANT TECHN. EXPL.& LOGISTIQUE', '', '', '', 1, '0'),
(122, '', 1, 'GREFFIER', 'ARNAUD', '1 ALLEE DES SOURCES', 'LE PORAGE', '49640', 'DAUMERAY', '', '', '', '', '25/10/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(123, '', 1, 'BOUVIER', 'FREDERIC', '16 rue des Charmes', '', '49220', 'BRAIN SUR LONGUENEE', '', '', '', '', '18/11/1999', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '0'),
(124, '', 1, 'PECOT', 'THIERRY', '9 COTES DE BEAULIEU', 'LIEU DIT BEAULIEU', '49140', 'VILLEVEQUE', '', '', '', '', '22/11/1999', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(125, '', 3, 'CARUSO', 'SYLVANA', 'ROUTE DE LOUDUN', 'LA PETITE CHAMPAGNE', '49260', 'MONTREUIL BELLAY', '', '', '', '', '03/04/2000', '', '', 'CHEF DE CENTRE SBA', '', '', '', 1, '0'),
(126, '', 2, 'BOUDAUD', 'VIRGINIE', '21 RUE DES MARONNIERS', '', '49330', 'CHAMPIGNE', '', '', '', '', '20/11/2000', '', '', 'SECRETAIRE DE SERVICE', '', '', '', 1, '0'),
(127, '', 1, 'DASYLVA', 'JEAN-PIERRE', '3 AVENUE MONTAIGNE', '', '49000', 'ANGERS', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(128, '', 1, 'BOUFAQOUS', 'ABDELJALIL', '30 RUE DES TOURNEBELLES', '', '49000', 'ANGERS', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(129, '', 1, 'CLEMENT', 'CHRISTOPHE', '4 B ROUTE DU HUTREAU', '', '49130', 'SAINTE GEMMES SUR LOIRE', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '9.72'),
(130, '', 1, 'CLEMENT', 'OLIVIER', '32 B RUE DE LA BRISEPOTIERE', '', '49100', 'ANGERS', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(131, '', 1, 'GARNIER', 'DAVID', 'LOTISSEMENT LE PUITS HERVE', '6 RUE DU RUISSEAU', '49220', 'BRAIN SUR LONGUENEE', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(132, '', 3, 'ONILLON', 'PATRICIA', '87 BOULEVARD BEDIER', 'LES PEUPLIERS', '49000', 'ANGERS', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(133, '', 2, 'LEHOREAU WADA', 'VIRGINIE', '9 RUE MICHEL SEURAT', '', '49000', 'ANGERS', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(134, '', 1, 'BLEJAN', 'CHRISTIAN', '183 RUE SAUMUROISE', '', '49000', 'ANGERS', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(135, '', 2, 'RAGOT', 'VIRGINIE', 'LES DEUX CHENES', '', '49170', 'ST MARTIN DU FOUILLOUX', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION NIVEAU 2', '', '', '', 1, '150'),
(136, '', 1, 'BERGERET', 'STEPHANE', 'LES PERRES', '', '49140', 'SERMAISE', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(137, '', 2, 'POUPAULT', 'ISABELLE', '29 RTE DEPARTEMENTALE 347', '', '49630', 'CORNE', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION PRINCIPAL', '', '', '', 1, '150'),
(138, '', 1, 'CHAPEAU', 'OLIVIER', '2A RUE DU TERTRE', '', '49800', 'SARRIGNE', '', '', '', '', '04/06/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(139, '', 1, 'GALLET', 'STEPHANE', '21 RUE DU SORBIER', 'LOTISSEMENT LA CROIX BLANCHE', '49290', 'ST LAURENT DE LA PLAINE', '', '', '', '', '03/09/2001', '', '', 'CHEF D''EQUIPE SENIOR', '', '', '', 1, '0'),
(140, '', 1, 'LUBIN', 'MICHEL', '7 rue de l''Or?e du Bois', 'Lot. l''Or?e du Bois', '49140', 'BAUNE', '', '', '', '', '15/10/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(141, '', 1, 'GUYADER', 'YOHANN', 'LES EDELWEISS', 'LE PETIT BOIS', '49800', 'TRELAZE', '', '', '', '', '15/10/2001', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(142, '', 1, 'IDDER', 'MEHDI', '4 RUE DU BEZAIN', '', '49800', 'SARRIGNE', '', '', '', '', '29/07/2002', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(143, '', 1, 'ROUAULT', 'ANTHONY', '9 IMPASSE DES PUISATIERS', '', '49630', 'MAZE', '', '', '', '', '29/07/2002', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(144, '', 2, 'MARSAULT', 'FRANCOISE', '3 IMPASSE DES CERISES', 'LOTISSEMENT LES CERISES', '49170', 'SAINT GEORGES SUR LOIRE', '', '', '', '', '29/07/2002', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(145, '', 2, 'DINGREVILLE', 'ALINE', '38 Route de la Roche', '', '49630', 'MAZE', '', '', '', '', '29/07/2002', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(146, '', 1, 'KERBOURCH', 'FLORENT', '1 RUE GEORGES MELLIES', '', '49140', 'BAUNE', '', '', '', '', '03/01/2005', '', '', 'CHEF D''EQUIPE SENIOR', '', '', '', 1, '0'),
(147, '', 1, 'MOTTEAU', 'Thierry', 'Les Treilles', '', '49190', 'ROCHEFORT SUR LOIRE', '', '', '', '', '01/03/2005', '', '', 'CHEF DE SERVICE TECHNIQUE', '', '', '', 1, '0'),
(148, '', 2, 'CHAFFIN', 'Mireille', '39 ALLEE FRANCOIS LE VAILLANT', '', '49240', 'AVRILLE', '', '', '', '', '07/08/2005', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(149, '', 2, 'CHESNEL', 'Brigitte', '6 square des C?dres', '', '49000', 'ANGERS', '', '', '', '', '18/04/2005', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '0'),
(150, '', 2, 'CLOUET', 'Emilie', '53 RUE DES RABIERES', '', '49140', 'SEICHES SUR LE LOIR', '', '', '', '', '28/05/2005', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(151, '', 1, 'NIANGORAN', 'Oura Severin', '5 RUE PROSPER BIGEARD', '', '49100', 'ANGERS', '', '', '', '', '09/06/2005', '', '', 'AGENT DE PRODUCTION NIVEAU 2', '', '', '', 1, '150'),
(152, '', 1, 'DAGUER', 'St?phane', '16 SQUARE DU PAVILLON', 'LES IRIS', '49130', 'LES PONTS DE CE', '', '', '', '', '15/05/2005', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(153, '', 1, 'PASCAL', 'LIONEL', 'LE PETIT PRINCE', '', '49330', 'CHAMPIGNE', '', '', '', '', '09/10/2006', '', '', 'CHEF D''EQUIPE', '', '', '', 1, '150'),
(154, '', 3, 'CHAPLAIN', 'ANGELINA', '6 RUE PIERRE RUAIS', '', '49540', 'MARTIGNE BRIAND', '', '', '', '', '05/10/2006', '', '', 'AGENT DE MAINTENANCE', '', '', '', 1, '150'),
(155, '', 2, 'CRIBIER', 'EMILIE', '28 RUE HENRI CORMEAU', '', '49100', 'ANGERS', '', '', '', '', '29/08/2011', '', '', 'AGENT DE PRODUCTION NIVEAU 2', '', '', '', 1, '0'),
(156, '', 1, 'SALAUN', 'ANDRE', '1 AVENUE FRANCOIS MITTERAND', 'RESIDENCE LES FLORINS', '49130', 'LES PONTS DE CE', '', '', '', '', '06/08/2012', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(157, '', 3, 'BARRIERES', 'AMANDINE', '16 AVENUE DE GRESILLE', '', '49000', 'ANGERS', '', '', '', '', '06/08/2012', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(158, '', 2, 'PERGER', 'ASTRID', '71 AVENUE JEAN BUTTON', '', '49130', 'LES PONTS DE CE', '', '', '', '', '03/09/2012', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '70.7'),
(159, '', 2, 'CERIBAS', 'FILIZ', '41 BD AUGUSTE ALLONNEAU', '', '49100', 'ANGERS', '', '', '', '', '10/07/2012', '', '', 'AGENT DE PRODUCTION', '', '', '', 1, '150'),
(160, '', 1, 'LEVRON', 'Jean Louis', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'RETRAITE MLP', 1, ''),
(161, '', 1, 'VERMELUN', 'Christian', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'RETRAITE MLP', 1, '');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(97, '1427151600', '766913721', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ADAM StÃ©phane.', '', '0', 1),
(101, '1425942000', '104897766', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BADOUR.', '', '6', 1),
(102, '1425942000', '797541324', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par SALAUN .', '', '3', 1),
(103, '1425942000', '298064446', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CLOUET.', '', '6', 1),
(104, '1425942000', '977030626', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHAPEAU.', '', '6', 1),
(105, '1425942000', '394389083', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CLEMENT OLIVIER.', '', '3', 1),
(106, '1425942000', '152476817', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GARNIER.', '', '6', 1),
(107, '1425942000', '911071250', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARSEAULT.', '', '6', 1),
(108, '1425942000', '411485864', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LEHOREAU.', '', '3', 1),
(109, '1425942000', '592027465', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MESLET.', '', '6', 1),
(110, '1425942000', '523125745', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DOUILLY OLIVIER.', '', '15', 1),
(111, '1425942000', '543193829', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CLEMENT CHRISTOPHE.', '', '6', 1),
(112, '1425942000', '192632237', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LAURIOU.', '', '3', 1),
(113, '1425942000', '422362157', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par AMOURDOM.', '', '12', 1),
(114, '1425942000', '354694855', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par JANIN.', '', '6', 1),
(115, '1425942000', '622025983', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CARUSO.', '', '6', 1),
(116, '1425942000', '812637190', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERIN J.', '', '15', 1),
(117, '1425942000', '236792301', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par HAULBERT.', '', '3', 1),
(118, '1425942000', '112330733', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PERGER.', '', '6', 1),
(119, '1425942000', '281873541', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BACHELOT.', '', '6', 1),
(120, '1425942000', '583329484', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FOURNIER.', '', '6', 1),
(121, '1425942000', '872746796', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOUFAQOUS.', '', '3', 1),
(122, '1425942000', '145886889', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GAULTIER SEBASTIEN .', '', '15', 1),
(123, '1425942000', '386873173', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par COSNIER CHRISTOPHE .', '', '3', 1),
(124, '1425942000', '223114167', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ONILLON.', '', '6', 1),
(125, '1425942000', '380509489', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAVY ANTOINE .', '', '3', 1),
(126, '1425942000', '716914646', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ROUSSEL.', '', '6', 1),
(127, '1425942000', '662180566', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par SUREAU.', '', '6', 1),
(128, '1425942000', '403411754', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PECOT.', '', '6', 1),
(129, '1425942000', '902751593', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAGUER.', '', '6', 1),
(130, '1425942000', '885403846', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHALOPIN.', '', '6', 1),
(131, '1425942000', '440083101', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ROUAULT.', '', '6', 1),
(132, '1425942000', '414586393', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOIVIN.', '', '3', 1),
(133, '1425942000', '521540793', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DASYLVA.', '', '6', 1),
(134, '1425942000', '460706309', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERIN H.', '', '6', 1),
(135, '1425942000', '890059948', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LUBIN.', '', '3', 1),
(136, '1425942000', '995997985', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POUR VERMEULUN RETRAITE.', '', '6', 1),
(137, '1425942000', '789351199', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MORTIER FRED.', '', '6', 1),
(138, '1425942000', '844670349', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAGUENET FRANCOISE.', '', '6', 1),
(139, '1425942000', '350923409', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POIRRIER.', '', '3', 1),
(140, '1425942000', '521953889', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARTIN.', '', '3', 1),
(141, '1425942000', '392720217', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOUVIER.', '', '6', 1),
(142, '1425942000', '308847003', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par COUINET.', '', '6', 1),
(143, '1425942000', '410158386', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GALLET.', '', '6', 1),
(144, '1425942000', '325485797', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ROUFFIAC.', '', '6', 1),
(145, '1425942000', '831103717', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BRUNET.', '', '6', 1),
(146, '1425942000', '404232360', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FRESNEAU.', '', '6', 1),
(147, '1425942000', '759244341', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PILLARD.', '', '6', 1),
(148, '1425942000', '832273424', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FOUGERI.', '', '6', 1),
(149, '1425942000', '461467387', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERRIAU.', '', '6', 1),
(150, '1425942000', '617109972', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BEAULU.', '', '6', 1),
(151, '1425942000', '656563256', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DINGREVILLE.', '', '6', 1),
(152, '1425942000', '241293941', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par HANQUART.', '', '3', 1),
(153, '1425942000', '149558185', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARCHAIS .', '', '3', 1),
(154, '1425942000', '186024369', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par AUDIC.', '', '6', 1),
(155, '1425942000', '882957214', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par NEGRI.', '', '6', 1),
(156, '1425942000', '607343854', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par JOUBERT.', '', '6', 1),
(157, '1425942000', '384051438', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par RAGOT.', '', '6', 1),
(158, '1425942000', '157842225', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CROS.', '', '3', 1),
(159, '1425942000', '816292467', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHAPLAIN.', '', '3', 1),
(160, '1425942000', '355304580', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOUDAUD.', '', '6', 1),
(161, '1425942000', '173593721', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FAUCHEUX.', '', '6', 1),
(162, '1425942000', '131953357', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MOTTEAU.', '', '6', 1),
(163, '1425942000', '557096876', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CARTRON OLIVIER.', '', '6', 1),
(164, '1425942000', '853394655', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par KERBOURCH.', '', '6', 1),
(165, '1425942000', '994232917', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par VALLEE KARINE.', '', '3', 1),
(166, '1425942000', '378305914', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ADAM.', '', '6', 1),
(167, '1425942000', '230280355', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POUPAULT.', '', '64', 1),
(168, '1425942000', '', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de POUPAULT.', '', '50', 0),
(169, '1427151600', '424131378', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ARMOUDOM.', '', '0', 1),
(170, '1427151600', '862115431', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par AUDIC .', '', '0', 1),
(171, '1427151600', '395123788', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BACHELOT.', '', '0', 1),
(172, '1427151600', '625788347', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BADOUR.', '', '0', 1),
(173, '1427151600', '966770825', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BAULU.', '', '0', 1),
(174, '1427151600', '255802760', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BARRIERES.', '', '0', 1),
(175, '1427151600', '949694798', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BERGERET.', '', '0', 1),
(176, '1427151600', '538575797', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BLEJAN.', '', '0', 1),
(177, '1427151600', '681704076', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOIVIN.', '', '0', 1),
(178, '1427151600', '887661087', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOUDAUD.', '', '0', 1),
(179, '1427151600', '662237876', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOUFAQOUS.', '', '0', 1),
(180, '1427151600', '431846300', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BOUVIER.', '', '0', 1),
(181, '1427151600', '576939767', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BRANCHEREAU.', '', '0', 1),
(182, '1427151600', '957697386', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BRUNET.', '', '0', 1),
(183, '1427151600', '978733291', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CERIBAS.', '', '0', 1),
(184, '1427151600', '574746800', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CARTRON.', '', '0', 1),
(185, '1427151600', '360282895', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CARUSO.', '', '0', 1),
(186, '1427151600', '240423486', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHAPLAIN.', '', '0', 1),
(187, '1427151600', '994259658', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHALOPIN.', '', '0', 1),
(188, '1427151600', '457396337', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHAPEAU.', '', '0', 1),
(189, '1427151600', '717038642', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CLEMENT.', '', '0', 1),
(190, '1427151600', '348543307', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHAFFIN.', '', '0', 1),
(191, '1427151600', '556248914', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHESNEL.', '', '0', 1),
(192, '1427151600', '749898697', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CLEMENT OLIVIER.', '', '0', 1),
(193, '1427151600', '916776793', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par COSNIER.', '', '0', 1),
(194, '1427151600', '234847516', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par COUINET.', '', '0', 1),
(195, '1427151600', '824315112', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CRIBIER.', '', '0', 1),
(196, '1427151600', '504269207', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CROS.', '', '0', 1),
(197, '1427151600', '761116794', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DASYLVA.', '', '0', 1),
(198, '1427151600', '973423513', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAGUENE.', '', '0', 1),
(199, '1427151600', '631992934', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAVID.', '', '0', 1),
(200, '1427151600', '267353562', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAVY.', '', '0', 1),
(201, '1427151600', '444540781', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAGUER.', '', '0', 1),
(202, '1427151600', '142774062', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DELPHIN.', '', '0', 1),
(203, '1427151600', '448265166', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DESMARS.', '', '0', 1),
(204, '1427151600', '141557884', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DINGREVILLE.', '', '0', 1),
(205, '1427151600', '456005313', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DOUILLY.', '', '0', 1),
(206, '1427151600', '102151907', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DROUIN.', '', '0', 1),
(207, '1427151600', '350224335', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FAUCHEUX.', '', '0', 1),
(208, '1427151600', '912959411', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FOUGERI.', '', '0', 1),
(209, '1427151600', '387084197', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FOURNIER.', '', '0', 1),
(210, '1427151600', '663689511', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FRESNEAU.', '', '0', 1),
(211, '1427151600', '583470672', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GALLET.', '', '0', 1),
(212, '1427151600', '201952384', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GARNIER.', '', '0', 1),
(213, '1427151600', '374492890', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GAULITIER.', '', '0', 1),
(214, '1427151600', '487519573', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GREFFIER.', '', '0', 1),
(215, '1427151600', '440273151', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERIN Huguette.', '', '0', 1),
(216, '1427151600', '162037432', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERIN Johnny.', '', '0', 1),
(217, '1427151600', '194967553', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERRIAU Malika.', '', '0', 1),
(218, '1427151600', '609944795', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERTIN.', '', '0', 1),
(219, '1427151600', '828210490', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUYADER.', '', '0', 1),
(220, '1427151600', '148696587', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par HANQUART.', '', '0', 1),
(221, '1427151600', '452441518', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par HAULBERT.', '', '0', 1),
(222, '1427151600', '181188544', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par KOCH.', '', '0', 1),
(223, '1427151600', '928024384', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par IDDER MEHDI.', '', '0', 1),
(224, '1427151600', '884446455', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par JANIN.', '', '0', 1),
(225, '1427151600', '634814728', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par KERBOURCH.', '', '0', 1),
(226, '1427151600', '241446207', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par JOUBERT.', '', '0', 1),
(227, '1427151600', '518004305', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LAURIOU.', '', '0', 1),
(228, '1427151600', '139637656', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LEHOREAU.', '', '0', 1),
(229, '1427151600', '375057776', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LUBIN.', '', '0', 1),
(230, '1427151600', '792158708', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARCHAIS.', '', '0', 1),
(231, '1427151600', '984404511', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MACKOSKI.', '', '0', 1),
(232, '1427151600', '285943317', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARTIN.', '', '0', 1),
(233, '1427151600', '362128824', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARSAULT.', '', '0', 1),
(234, '1427151600', '559764482', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MOTTEAU.', '', '0', 1),
(235, '1427151600', '239791752', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MESLET.', '', '0', 1),
(236, '1427151600', '881597023', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MORTIER.', '', '0', 1),
(237, '1427151600', '532970310', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par NIANGORAN.', '', '0', 1),
(238, '1427151600', '388877479', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par NEGRI.', '', '0', 1),
(239, '1427151600', '233265766', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ONILLON.', '', '0', 1),
(240, '1427151600', '547099650', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PASCAL LIONEL.', '', '0', 1),
(241, '1427151600', '320599329', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PECOT.', '', '0', 1),
(242, '1427151600', '749010268', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PERGER.', '', '0', 1),
(243, '1427151600', '666146118', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PILLARD.', '', '0', 1),
(244, '1427151600', '859979942', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POIRRIER.', '', '0', 1),
(245, '1427151600', '373198785', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POUPAULT.', '', '0', 1),
(246, '1427151600', '276036180', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par RAGOT.', '', '0', 1),
(247, '1427151600', '799034307', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par RICHOMME.', '', '0', 1),
(248, '1427151600', '569295260', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ROUAULT.', '', '0', 1),
(249, '1427151600', '464988710', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ROUFFIAC.', '', '0', 1),
(250, '1427151600', '658479725', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ROUSSEL.', '', '0', 1),
(251, '1427151600', '545762463', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par VALLEE.', '', '0', 1),
(252, '1427151600', '540562995', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par SALAUN.', '', '0', 1),
(253, '1427151600', '166237657', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par SUREAU.', '', '0', 1),
(254, '1425942000', '578116979', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BRANCHEREAU.', '', '36', 1),
(255, '1424991600', '1741327', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 1741327 en date du 27-02-2015.', '50', '', 1),
(258, '1425337200', '06987853', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 06987853 en date du 03-03-2015.', '9', '', 1),
(259, '1425337200', '06988306', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 06988306 en date du 03-03-2015.', '144', '', 1),
(260, '1425337200', '06987864', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 06987864 en date du 03-03-2015.', '325', '', 1),
(261, '1425337200', 'REMISE EPURATRICE', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° REMISE EPURATRICE en date du 03-03-2015.', '0', '', 1),
(262, '1430776800', '234', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ONILLON.', '', '120', 0),
(263, '1424127600', '001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DESMARS.', '', '321', 0),
(264, '1424127600', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LEHOREAU.', '', '163', 0),
(265, '1420153200', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de POIRRIER.', '', '280', 0),
(266, '1420153200', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de JANIN.', '', '140', 0),
(267, '1420153200', '0001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CLEMENT.', '', '280', 0),
(268, '1420153200', '1526', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de COSNIER.', '', '140', 0),
(269, '1420153200', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BACHELOT.', '', '140', 0),
(270, '1420153200', '477', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DINGREVILLE.', '', '280', 0),
(271, '1429048800', '156', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CLOUET.', '', '140', 0),
(272, '1429048800', '125', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de JOUBERT.', '', '140', 0),
(273, '1421276400', '001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ONILLON.', '', '140', 0),
(274, '1428616800', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de COUINET.', '', '140', 0),
(275, '1421276400', '969', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MARCHAIS.', '', '280', 0),
(276, '1428616800', '0020', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CROS.', '', '140', 0),
(277, '1428616800', '456', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOURGEAIS.', '', '140', 0),
(278, '1428616800', '7896', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NAIRIERE.', '', '280', 0),
(279, '1421276400', '962', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERIN.', '', '140', 0),
(280, '1429048800', 'CM', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de POIRRIER JOEL.', '', '280', 0),
(281, '1429048800', '968', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GALLET.', '', '140', 0),
(282, '1429048800', '856', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MENARD.', '', '140', 0),
(283, '1429048800', '844', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BRUN.', '', '140', 0),
(284, '1429048800', '125', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BARBOT.', '', '140', 0),
(285, '1429048800', '854', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FOQUERAULT.', '', '140', 0),
(286, '1429048800', '8541', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DOMINGUEZ.', '', '140', 0),
(287, '1429048800', '636', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de POIRRIER.', '', '140', 0),
(288, '1429048800', '789', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BRIAND.', '', '140', 0),
(289, '1429048800', '4566', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CLEMENT JP.', '', '280', 0),
(290, '1429048800', '896', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BLANCHART.', '', '280', 0),
(291, '1429048800', '856', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROCHER.', '', '140', 0),
(292, '1429048800', '962', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUFFIAC.', '', '280', 0),
(293, '1429048800', '452', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PORRIER.', '', '280', 0),
(294, '1430517600', '681', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BELLOIN.', '', '187', 0),
(295, '1431208800', '942', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de KERJCI.', '', '39', 0),
(296, '1431208800', '2763', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MACKOWSKI.', '', '59', 0),
(297, '1431208800', '3837', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '47', 0),
(298, '1431208800', '531', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BRIAND.', '', '88', 0),
(299, '1431208800', '202', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de RAGUIN.', '', '70', 0),
(300, '1431208800', '202', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOUCHENOIR.', '', '47', 0),
(301, '1431208800', '367', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PIERRE EMILE.', '', '48', 0),
(302, '1431208800', '435', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de SIETTE.', '', '50', 0),
(303, '1431208800', '335', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROCHE.', '', '63', 0),
(304, '1431208800', '1246', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MOREAU.', '', '133', 0),
(305, '1431208800', '409', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MONNIER.', '', '69', 0),
(306, '1431208800', '567', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DESMARS.', '', '145', 0),
(307, '1431208800', '864', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ONILLON.', '', '117', 0),
(308, '1428962400', '456', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOUCHARD.', '', '140', 0),
(309, '1432072800', '872', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de VERMELUN.', '', '140', 0),
(310, '1431640800', '747', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MANCEAU.', '', '140', 0),
(311, '1431640800', '5008', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOIVIN.', '', '280', 0),
(312, '1431640800', '242', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PECOT.', '', '140', 0),
(313, '1431208800', '570', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DESMARS.', '', '221', 0),
(314, '1431208800', '570', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DESMARS.', '', '76', 0),
(315, '1431208800', '461', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FRESNEAU.', '', '61', 0),
(316, '1431208800', '553', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUYADER.', '', '93', 0),
(317, '1431208800', '874', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FOUGERI.', '', '46', 0),
(318, '1431208800', '1847', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GAULTIER.', '', '64', 0),
(319, '1431208800', '333', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUSSEL.', '', '96', 0),
(320, '1431208800', '243', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PECOT.', '', '56', 0),
(321, '1420066800', '3501417', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3501417 en date du 01-01-2015.', '1260', '', 1),
(322, '1420066800', '3501420', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3501420 en date du 01-01-2015.', '484', '', 1),
(323, '1421276400', '3501419', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3501419 en date du 15-01-2015.', '1820', '', 1),
(325, '1428616800', '3501422', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3501422 en date du 10-04-2015.', '1680', '', 1),
(326, '1431986400', '8089902', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 8089902 en date du 19-05-2015.', '1162', '', 1),
(327, '1433196000', '8089903', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 8089903 en date du 02-06-2015.', '713', '', 1),
(328, '1433196000', '8089904', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 8089904 en date du 02-06-2015.', '700', '', 1),
(329, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NON RENSEIGNE.', '', '24', 1),
(330, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NON RENSEIGNE.', '', '24', 1),
(331, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NON RENSEIGNE.', '', '24', 1),
(332, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NON RENSEIGNE.', '', '24', 1),
(333, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NON RENSEIGNE.', '', '24', 1),
(334, '1423522800', '3492672', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492672 en date du 10-02-2015.', '120', '', 1),
(335, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LUBIN.', '', '30', 1),
(336, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MARCHAIS .', '', '24', 1),
(337, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BAULU.', '', '24', 1),
(338, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LUBIN.', '', '30', 1),
(339, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FRESNEAU.', '', '24', 1),
(340, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de IDDER.', '', '24', 1),
(341, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de POUPAULT.', '', '12', 1),
(342, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de POUPAULT.', '', '12', 1),
(343, '1420066800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de RICHOMME.', '', '24', 1),
(344, '1420153200', '343434', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 343434 en date du 02-01-2015.', '204', '', 1),
(345, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DOUILLY.', '', '18', 1),
(346, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GAULTIER.', '', '24', 1),
(347, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GARNIER.', '', '30', 1),
(348, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUFFIAC.', '', '48', 0),
(349, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MESLET.', '', '24', 1),
(350, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MILLION.', '', '18', 1),
(351, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ARMOURDOM.', '', '42', 0),
(352, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CLEMENT.', '', '24', 1),
(353, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de RAGOT.', '', '12', 1),
(354, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de JANIN.', '', '24', 1),
(355, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '24', 1),
(356, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUAULT.', '', '24', 1),
(357, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MACKOWSKI.', '', '24', 1),
(358, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PECOT.', '', '24', 1),
(359, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BRANCHEREAU.', '', '24', 1),
(360, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MOTTEAU.', '', '24', 1),
(361, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CROS.', '', '24', 1),
(362, '1422745200', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUSSEL.', '', '24', 1),
(363, '1425337200', '3492675', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492675 en date du 03-03-2015.', '456', '', 1),
(364, '1423954800', '199485052', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MORTIER.', '', '24', 1),
(365, '1423954800', '114241394', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par AUDIC.', '', '18', 1),
(366, '1423954800', '138677975', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par VALLEE.', '', '12', 1),
(367, '1423954800', '362392015', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUERTIN.', '', '24', 1),
(368, '1423954800', '484774929', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BARRIERES.', '', '12', 1),
(369, '1423954800', '439891372', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BACHELOT.', '', '24', 1),
(370, '1423954800', '610631139', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GUYADER.', '', '36', 1),
(371, '1425337200', '5725', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 5725 en date du 03-03-2015.', '150', '', 1),
(372, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GAULTIER.', '', '24', 1),
(373, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUSSEL.', '', '24', 1),
(374, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CERIBAS FILIZ.', '', '30', 1),
(375, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CHALOPIN.', '', '24', 1),
(376, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BERGERET.', '', '12', 1),
(377, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ONILLON.', '', '24', 1),
(378, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MARCHAIS.', '', '24', 1),
(379, '1426374000', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de AUDIC.', '', '24', 1),
(380, '1427752800', '3492677', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492677 en date du 31-03-2015.', '186', '', 1),
(381, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DOUILLY.', '', '24', 1),
(382, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CROS.', '', '24', 1),
(383, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FOUGERI.', '', '24', 1),
(384, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '24', 1),
(385, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de HAULBERT.', '', '24', 1),
(386, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CRIBIER.', '', '12', 1),
(387, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DINGREVILLE.', '', '24', 1),
(388, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BERGERET.', '', '24', 1),
(389, '1429048800', 'NON RENSEIGNE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUYADER.', '', '36', 1),
(390, '1430344800', '3492679', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492679 en date du 30-04-2015.', '216', '', 1),
(391, '1429480800', '512381425', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par BARRIERES.', '', '12', 1),
(392, '1429480800', '248949677', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par PECOT.', '', '24', 1),
(393, '1429480800', '416160664', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ARMOURDOM.', '', '24', 1),
(394, '1430344800', '6988295', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 6988295 en date du 30-04-2015.', '60', '', 1),
(395, '1431640800', '5493578', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BOUVIER.', '', '12', 1),
(396, '1431640800', '4679556', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUYADER.', '', '24', 1),
(397, '1431640800', '5804364', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de IDDER.', '', '24', 1),
(398, '1431640800', '8463777', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PECOT.', '', '24', 1),
(399, '1431640800', '4216966', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BERGERET.', '', '24', 1),
(400, '1431640800', '6597143', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DAVID ARMEL.', '', '24', 1),
(401, '1431640800', '3919911', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de HAULBERT.', '', '24', 1),
(402, '1431640800', '126', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LUBIN.', '', '30', 1),
(403, '1431640800', '5969146', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de IDDER.', '', '12', 1),
(404, '1432850400', '3492681', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492681 en date du 29-05-2015.', '198', '', 1),
(405, '1433196000', '3075905', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3075905 en date du 02-06-2015.', '120', '', 1),
(406, '1428616800', '3501421', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3501421 en date du 10-04-2015.', '840', '', 1),
(407, '1441663200', '489778466', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DAGUER Stephane.', '', '0', 0),
(409, '1436479200', '570094615', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par espece.', '', '12', 1),
(410, '1436997600', '642105724', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par garnier.', '', '24', 1),
(411, '1437602400', '482445835', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par greffier.', '', '24', 1),
(412, '1438812000', '128296456', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par meslet.', '', '36', 1),
(413, '1438812000', '787468522', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par guertin.', '', '12', 1),
(414, '1440453600', '794457185', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par rouffiac.', '', '12', 1),
(415, '1433887200', '155090529', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par fournier.', '', '6', 1),
(416, '1441749600', '6987794', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 6987794 en date du 09-09-2015.', '126', '', 1),
(417, '1434924000', '035', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de cros.', '', '24', 1),
(418, '1434492000', '5204', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de motteau.', '', '24', 1),
(419, '1435183200', '318', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de negri.', '', '24', 1),
(420, '1433887200', '667', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de levron.', '', '24', 1),
(421, '1434060000', '143', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de joubert.', '', '12', 1),
(422, '1441663200', '3492682', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492682 en date du 08-09-2015.', '108', '', 1),
(423, '1437516000', '293', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de baulu.', '', '24', 1),
(424, '1437084000', '228', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de armourdom.', '', '24', 1),
(425, '1437084000', '1959', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de gaultier.', '', '24', 1),
(426, '1437084000', '603', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de bouvier.', '', '12', 1),
(427, '1436479200', '130', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de lubin.', '', '30', 1),
(428, '1436392800', '213', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de branchereau.', '', '24', 1),
(429, '1436392800', '374', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de fresneau.', '', '24', 1),
(430, '1436392800', '022', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de sureau.', '', '12', 1),
(431, '1436392800', '786', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de bachelot.', '', '24', 1),
(432, '1436392800', '1192', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de kerbourch.', '', '24', 1),
(433, '1436220000', '606', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de daguer.', '', '24', 1),
(434, '1436133600', '812', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de pecot.', '', '24', 1),
(435, '1435788000', '337', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de roussel.', '', '24', 1),
(436, '1435788000', '102', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de brunet.', '', '24', 1),
(437, '1441749600', '3492688', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492688 en date du 09-09-2015.', '318', '', 1),
(438, '1440712800', '909', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de faucheux.', '', '6', 0),
(439, '1440453600', '2778', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de mackowski.', '', '24', 1),
(440, '1439848800', '331', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de pecot.', '', '24', 1),
(441, '1438812000', '264', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de greffier.', '', '24', 1),
(442, '1438812000', '037', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de boivin.', '', '12', 1),
(443, '1439848800', '781', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de guerin.', '', '24', 1),
(444, '1439848800', '019', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de poirrier.', '', '24', 1),
(445, '1441749600', '3492689', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492689 en date du 09-09-2015.', '138', '', 1),
(446, '1441663200', '394967458', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par RAGOT VIRGINIE.', '', '0', 0),
(447, '1441663200', '882741359', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARCHAIS LAURENT.', '', '0', 0),
(448, '1441663200', '768252412', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POUPAULT ISABELLE.', '', '0', 0),
(449, '1441663200', '316959642', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LAURIOU MICKAEL.', '', '0', 0),
(450, '1441663200', '868183281', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DROUIN DIDIER.', '', '0', 0),
(451, '1441663200', '802118274', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LAURIOU MICKAEL.', '', '0', 0),
(452, '1441663200', '292294948', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DROUIN DIDIER.', '', '0', 0),
(453, '1441663200', '211493307', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHAPEAU OLIVIER.', '', '0', 0),
(454, '1441663200', '713002529', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GAGUER STEPHANE.', '', '0', 0),
(455, '1441663200', '373889220', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ARMOURDOM LAURENT.', '', '0', 0),
(456, '1441663200', '561172761', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POUPAULT ISABELLE.', '', '0', 0),
(457, '1441663200', '586767443', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par IDDER MEHDI.', '', '0', 0),
(458, '1441663200', '815972340', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par NIANGORAN OURA SEVERIN.', '', '0', 0),
(459, '1441663200', '574306381', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par IDDER MEHDI.', '', '0', 0),
(460, '1441663200', '426634269', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par GAULTIER SEBASTIEN.', '', '0', 0),
(461, '1441663200', '851992620', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par NIANGORAN OURA SEVERIN.', '', '0', 0),
(462, '1441663200', '790780527', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ARMOURDON LAURENT.', '', '0', 0),
(463, '1441663200', '956835029', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARSAULT FRANCOISE.', '', '0', 0),
(464, '1441663200', '448755844', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DOUILLY OLIVIER.', '', '0', 0),
(465, '1441663200', '213433727', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DOUILLY OLIVIER.', '', '0', 0),
(466, '1441663200', '760783390', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARCHAIS LAURENT.', '', '0', 0),
(467, '1441663200', '492586662', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CLEMENT OLIVIER.', '', '0', 0),
(468, '1441663200', '954917184', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MARSAULT FRANCOISE.', '', '0', 0),
(469, '1441663200', '916727203', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FAUCHEUX FREDDY.', '', '0', 0),
(471, '1441663200', '438231765', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par FAUCHEUX FREDDY.', '', '0', 0),
(472, '1441663200', '456910356', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ARMOURDOM LAURENT.', '', '0', 0),
(473, '1441663200', '581968698', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LAURIOU MICKAEL.', '', '0', 0),
(474, '1441663200', '802292304', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DROUIN DIDIER.', '', '0', 0),
(475, '1441663200', '104259186', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par POUPAULT ISABELLE.', '', '0', 0),
(476, '1441663200', '933802886', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par IDDER MEHDI.', '', '0', 0),
(477, '1441663200', '643708158', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LEVRON Jean Louis.', '', '0', 0);
INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(478, '1441663200', '794381394', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par VERMELUN CHRISTIAN.', '', '0', 0),
(479, '1441663200', '137379126', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LEVRON Jean Louis.', '', '0', 0),
(480, '1441663200', '677604315', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par VERMELUN Christian.', '', '0', 0),
(481, '1441663200', '329329224', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par RAGOT VIRGINIE.', '', '0', 0),
(482, '1442786400', '585779957', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MESLET.', '', '12', 1),
(483, '1443477600', '6987783', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 6987783 en date du 29-09-2015.', '12', '', 1),
(484, '1442786400', '159', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FOURNIER.', '', '24', 1),
(485, '1442786400', '204', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de marchais.', '', '24', 1),
(486, '1442786400', '324', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de motteau.', '', '24', 1),
(487, '1443477600', '3492764', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492764 en date du 29-09-2015.', '72', '', 1),
(488, '1441663200', '001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '72', 0),
(489, '1441663200', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DINGREVILLE.', '', '48', 0),
(490, '1441663200', '003', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de armourdom.', '', '36', 0),
(491, '1442268000', '3492763', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492763 en date du 15-09-2015.', '156', '', 1),
(492, '1443650400', '888', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de VERMELUN.', '', '140', 0),
(493, '1443650400', '187', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CHAPLAIN.', '', '140', 0),
(494, '1443650400', '082', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FREULON.', '', '280', 0),
(495, '1443650400', '732', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DOUILLY.', '', '140', 0),
(496, '1443650400', '041', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROCHER.', '', '140', 0),
(497, '1443650400', '024', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PECOT.', '', '140', 0),
(498, '1443650400', '313', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de RAPICAULT.', '', '140', 0),
(499, '1443650400', '8089906', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 8089906 en date du 01-10-2015.', '1120', '', 1),
(500, '1443736800', '872591666', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MESLET.', '', '12', 1),
(501, '1443736800', '202109556', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ONI.', '', '12', 1),
(502, '1444082400', '698772', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 698772 en date du 06-10-2015.', '24', '', 1),
(503, '1443736800', '410', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de IDDER.', '', '12', 1),
(504, '1443736800', '542', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GREFFIER.', '', '24', 1),
(505, '1443736800', '476', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de HAULBERT.', '', '24', 1),
(506, '1443736800', '634', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MARTIN.', '', '24', 1),
(507, '1443736800', '529', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERIN.', '', '24', 1),
(508, '1443736800', '038', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CROS.', '', '24', 1),
(509, '1444082400', '3492690', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492690 en date du 06-10-2015.', '132', '', 1),
(510, '1445292000', '792', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de bachelot.', '', '74', 0),
(511, '1445292000', '909', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '47', 0),
(513, '1445292000', '308', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de baulu.', '', '79', 0),
(514, '1445292000', '389', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de fresneau.', '', '106', 0),
(515, '1445292000', '254', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de onillon.', '', '62', 0),
(516, '1445292000', '841', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '68', 0),
(517, '1445292000', '351', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de roussel.', '', '76', 0),
(518, '1445292000', '587', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de boudaud.', '', '47', 0),
(519, '1445292000', '931', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '187', 0),
(520, '1445292000', '615', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '436', 0),
(521, '1445292000', '373', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de collet.', '', '102', 0),
(522, '1445292000', '212', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de robichon.', '', '54', 0),
(523, '1445292000', '341', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DOUILLY.', '', '87', 0),
(524, '1445292000', '8089905', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 8089905 en date du 20-10-2015.', '1425', '', 1),
(525, '1445292000', '256', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ceribas.', '', '152', 0),
(526, '1445292000', '982', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de serbouti.', '', '244', 0),
(527, '1445292000', '374', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de pierre emile.', '', '71', 0),
(528, '1445292000', '620', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de marseault.', '', '56', 0),
(529, '1445292000', '350', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de simonneau.', '', '164', 0),
(530, '1445292000', '8089907', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 8089907 en date du 20-10-2015.', '687', '', 1),
(531, '1444168800', '919559794', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par poirrier .', '', '24', 1),
(532, '1444687200', '903705439', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ROUAULT.', '', '12', 1),
(533, '1444082400', '540218917', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CHAPLAIN.', '', '12', 1),
(534, '1446332400', '774122063', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ESPECE.', '', '24', 1),
(535, '1446332400', '397258536', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par armourdom.', '', '24', 1),
(536, '1446332400', '445376889', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par audic.', '', '12', 1),
(537, '1446332400', '538720454', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par garnier.', '', '30', 1),
(538, '1446332400', '642107182', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par piou.', '', '24', 1),
(539, '1446332400', '517398753', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par wada.', '', '24', 1),
(540, '1446591600', '00012', 'Remise Bancaire', 'Remise de EspÃ¨ce', 'Remise en banque NÂ° 00012 en date du 04-11-2015.', '186', '', 1),
(541, '1446332400', '998', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de rouffiac.', '', '48', 0),
(542, '1446332400', '668', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ceribas.', '', '30', 0),
(543, '1446332400', '934', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de hanquart.', '', '24', 0),
(544, '1446332400', '062', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de richomme.', '', '24', 0),
(545, '1446332400', '481', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de HAULBERT.', '', '24', 0),
(546, '1446332400', '957', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de bouvier.', '', '12', 0),
(547, '1446332400', '015', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CROS.', '', '24', 0),
(548, '1446332400', '826', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de marseault.', '', '24', 0),
(549, '1446332400', '835', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de vallee.', '', '24', 0),
(550, '1446332400', '929', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUERRIAU.', '', '24', 0),
(551, '1446332400', '636', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MARTIN.', '', '24', 0),
(552, '1446332400', '305', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de IDDER.', '', '24', 0),
(553, '1446505200', '3492692', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 3492692 en date du 03-11-2015.', '306', '', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=258;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=720;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=524;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=720;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=520;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=510;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=554;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
