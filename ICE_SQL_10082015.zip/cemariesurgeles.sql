-- phpMyAdmin SQL Dump
-- version 4.4.9
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Lun 10 Août 2015 à 09:46
-- Version du serveur :  5.5.44-0ubuntu0.14.04.1
-- Version de PHP :  5.5.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cemariesurgeles`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE IF NOT EXISTS `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ayant_droit`
--

INSERT INTO `ayant_droit` (`idayantdroit`, `idsalarie`, `nom_ayant_droit`, `prenom_ayant_droit`, `date_naissance_ayant_droit`, `solde_ayant_droit`) VALUES
(2, 37, 'CORNILLEAU', 'JULES JOSEPH MICHEL', '15/04/2009', '99999999'),
(3, 37, 'CORNILLEAU', 'MALO', '04/09/2013', '99999999'),
(4, 11, 'BARZIC', 'CAMILLE MARC MAXIME', '23/10/2014', '99999999'),
(5, 11, 'BARZIC', 'GABRIEL BARNABE DAVI', '02/10/2010', '99999999'),
(6, 24, 'BOURREAU', 'ALEXIA', '24/06/1996', '99999999'),
(7, 24, 'BOURREAU', 'CYRIL', '18/06/1999', '99999999'),
(8, 58, 'FOURNIER', 'CYRIL', '17/08/1976', '99999999'),
(9, 58, 'FOURNIER', 'SINDY', '15/06/1981', '99999999'),
(10, 85, 'LETETREL', 'LOUIS', '31/12/2011', '99999999'),
(11, 22, 'BOUQUET', 'ANAIS KARINE RACHEL CHARLIE', '08/01/2015', '99999999'),
(12, 22, 'BOUQUET', 'LENA PATRICIA MICHELE', '15/03/2013', '99999999'),
(13, 51, 'DUBIER', 'ANTONIN', '16/06/2006', '99999999'),
(14, 51, 'DUBIER', 'LEO', '06/04/1994', '99999999'),
(15, 98, 'MENARD', 'EVA CASSANDRA', '02/06/2012', '99999999'),
(16, 98, 'MENARD', 'MELISSA CLARA', '18/04/2014', '99999999'),
(17, 139, 'VIOU', 'ALEXENDRA', '08/09/1978', '99999999'),
(18, 139, 'VIOU', 'JOCELYN', '31/08/1992', '99999999'),
(19, 139, 'VIOU', 'MANON', '30/11/1993', '99999999'),
(20, 139, 'VIOU', 'TEDDY', '08/02/1980', '99999999'),
(21, 139, 'VIOU', 'YORICK', '19/08/1989', '99999999'),
(22, 66, 'JACQUET', 'BENJAMIN', '23/11/2005', '99999999'),
(23, 40, 'COURLIVANT', 'MELVIN', '19/07/1997', '99999999'),
(24, 100, 'AGUILLON', 'MICKAEL', '21/07/1979', '99999999'),
(25, 41, 'COURLIVANT', 'ADELAIDE', '28/01/1990', '99999999'),
(26, 41, 'COURLIVANT', 'ANGELINA', '26/07/1993', '99999999'),
(27, 42, 'COURLIVANT', 'ADELAIDE', '28/01/1990', '99999999'),
(28, 42, 'COURLIVANT', 'ANGELINA', '26/07/1993', '99999999'),
(29, 70, 'JOURDAINE', 'ALEXANDRE', '02/11/1994', '99999999'),
(30, 70, 'JOURDAINE', 'AUDREY', '07/11/1991', '99999999'),
(31, 70, 'JOURDAINE', 'MANON', '03/03/2002', '99999999'),
(32, 70, 'JOURDAINE', 'ROMAIN', '01/03/1988', '99999999'),
(33, 17, 'BIGOT', 'JONATHAN', '19/07/1993', '99999999'),
(34, 17, 'BIGOT-GACHET', 'LUCAS FERNAND JULIEN', '16/07/2013', '99999999'),
(35, 17, 'BIGOT-GACHET', 'NOAH LAURENT GILLES', '30/07/2011', '99999999'),
(36, 17, 'BIGOT-GACHET', 'TH?O LOUIS GILLES', '20/07/2006', '99999999'),
(37, 105, 'FOURRIER', 'JESSIE MYRIAM MAGALIE', '07/05/2012', '99999999'),
(38, 105, 'FOURRIER', 'TITO BRUNO PATRICE', '12/09/2008', '99999999'),
(39, 67, 'JARSON', 'BORIS', '12/12/2012', '99999999'),
(40, 67, 'JARSON', 'CHRISTEL', '24/05/2007', '99999999'),
(41, 4, 'ANDOUARD', 'AURELIEN', '20/03/1993', '99999999'),
(42, 4, 'ANDOUARD', 'CORALIE', '25/03/1991', '99999999'),
(43, 4, 'ANDOUARD', 'FLAVIE', '10/02/1989', '99999999'),
(44, 5, 'ANDOUARD', 'JULIEN', '14/01/1986', '99999999'),
(45, 5, 'ANDOUARD', 'SEVERINE', '16/05/1990', '99999999'),
(46, 7, 'AUBOURG', 'LUCIE', '11/08/1979', '99999999'),
(47, 34, 'CHAUVEAU', 'JEREMY', '19/02/1989', '99999999'),
(48, 34, 'CHAUVEAU', 'TONY', '23/02/1985', '99999999'),
(49, 8, 'BARDET', 'JONATHAN', '28/05/1991', '99999999'),
(50, 8, 'BARDET', 'MAXIME', '25/12/1995', '99999999'),
(51, 8, 'BARDET', 'PRISCILLA', '19/08/1998', '99999999'),
(52, 10, 'BARRET', 'ADELE CLOTILDE MARIE', '24/12/2006', '99999999'),
(53, 10, 'BARRET', 'AMBRE GEORGINA CELINE', '09/09/2011', '99999999'),
(54, 10, 'BARRET', 'ARTHUR MALO LEON', '13/05/2005', '99999999'),
(55, 9, 'BARETEAU', 'MARIE', '21/01/1986', '99999999'),
(56, 9, 'BARETEAU', 'THOMAS', '09/12/1982', '99999999'),
(57, 12, 'BATTAIS', 'ANAIS', '13/04/1988', '99999999'),
(58, 12, 'BATTAIS', 'ANTHONY', '08/09/1985', '99999999'),
(59, 12, 'BATTAIS', 'LAURA LISA MANON', '25/11/2003', '99999999'),
(60, 93, 'MARIET', 'ALEXENDRA JULIE AURE', '06/11/2000', '99999999'),
(61, 93, 'MARIET', 'NICOLAS', '21/11/1996', '99999999'),
(62, 93, 'MARIET', 'SEBASTIEN', '26/11/1993', '99999999'),
(63, 14, 'DUGUEE', 'LISE', '30/04/1991', '99999999'),
(64, 13, 'BAZANTE', 'JUSTINE', '21/10/1995', '99999999'),
(65, 13, 'RENAULT', 'EDWIGE', '27/06/1985', '99999999'),
(66, 13, 'RENAULT', 'MATHIEU', '28/12/1987', '99999999'),
(67, 15, 'BENOIT', 'OCEANE', '03/03/1994', '99999999'),
(68, 16, 'BERTHELOT', 'KATIA', '19/04/1980', '99999999'),
(69, 16, 'BERTHELOT', 'SONIA', '25/11/1982', '99999999'),
(70, 19, 'BOISSEAU', 'ANGELINA', '29/07/1983', '99999999'),
(71, 19, 'BOISSEAU', 'MICKAEL', '12/02/1990', '99999999'),
(72, 21, 'BOUFFET', 'ANAIS', '24/12/1989', '99999999'),
(73, 21, 'BOUFFET', 'BORIS', '16/04/1987', '99999999'),
(74, 21, 'BOUFFET', 'LUDOVIC', '24/03/1983', '99999999'),
(75, 23, 'BOURLIERE', 'ALEXIS', '04/07/1988', '99999999'),
(76, 23, 'BOURLIERE', 'ANTHONY', '06/05/1986', '99999999'),
(77, 23, 'BOURLIERE', 'CINDY', '06/05/1980', '99999999'),
(78, 23, 'BOURLIERE', 'MALLORIE', '11/10/1982', '99999999'),
(79, 26, 'BRUNEAU', 'JONATHAN', '28/05/1985', '99999999'),
(80, 26, 'BRUNEAU', 'STEPHANIE', '02/09/1980', '99999999'),
(81, 26, 'BRUNEAU', 'TONY', '19/06/1982', '99999999'),
(82, 25, 'BRONDEAU', 'CHRISTOPHER', '04/04/1995', '99999999'),
(83, 25, 'LEONARDI', 'CEDRIC', '15/04/1986', '99999999'),
(84, 28, 'CAILLEAUD', 'LUCIE LEA', '22/03/2000', '99999999'),
(85, 28, 'CAILLEAUD', 'MALORIE', '08/09/1985', '99999999'),
(86, 28, 'CAILLEAUD', 'MAUD', '13/10/1991', '99999999'),
(87, 29, 'GAMELAS', 'CINDY', '07/08/1986', '99999999'),
(88, 29, 'GAMELAS', 'JULIEN', '19/09/1991', '99999999'),
(89, 30, 'CALMET', 'ALICE', '30/10/1985', '99999999'),
(90, 30, 'CALMET', 'ALLAN', '28/09/1989', '99999999'),
(91, 30, 'CALMET', 'CATHY', '24/05/1981', '99999999'),
(92, 112, 'PASQUIER', 'BENJAMIN', '27/10/1990', '99999999'),
(93, 112, 'PASQUIER', 'BRUNO', '19/03/1977', '99999999'),
(94, 112, 'PASQUIER', 'STEPHANE', '19/10/1982', '99999999'),
(95, 83, 'LELIEVRE', 'LAURA', '06/05/1988', '99999999'),
(96, 83, 'LELIEVRE', 'NICOLAS', '11/08/1984', '99999999'),
(97, 83, 'LELIEVRE', 'STEPHANIE', '30/08/1981', '99999999'),
(98, 32, 'CHAIGNEAU', 'HONORINE MARIE LUCIE', '08/03/2001', '99999999'),
(99, 32, 'CHAIGNEAU', 'LAURA MARIE NICOLE', '10/04/1993', '99999999'),
(100, 32, 'CHAIGNEAU', 'MARINE MARIE LAURA', '21/05/1997', '99999999'),
(101, 32, 'CHAIGNEAU', 'YOHANN YANNICK GUY', '04/01/1995', '99999999'),
(102, 33, 'CHASSEPORT', 'CHARLOTTE', '13/11/1987', '99999999'),
(103, 33, 'CHASSEPORT', 'MAXIME', '02/04/1995', '99999999'),
(104, 33, 'CHASSEPORT', 'VINCENT HUGO ARTHUR', '10/06/2002', '99999999'),
(105, 36, 'CHICOISNE', 'GUILLAUME', '05/08/1991', '99999999'),
(106, 36, 'CHICOISNE', 'GWENDOLINE', '17/04/1988', '99999999'),
(107, 36, 'CHICOISNE', 'TIPHANY', '25/06/1994', '99999999'),
(108, 39, 'VEGER', 'ALISSON', '05/02/1983', '99999999'),
(109, 39, 'VEGER', 'EMILIE', '25/08/1986', '99999999'),
(110, 39, 'VEGER', 'YANNIS', '03/05/1988', '99999999'),
(111, 44, 'DA COSTA', 'BENJAMIN', '07/06/1992', '99999999'),
(112, 44, 'DA COSTA', 'LORY LUNA', '11/10/2001', '99999999'),
(113, 44, 'DA COSTA', 'STACY', '31/01/1995', '99999999'),
(114, 46, 'DELIGNE', 'CLEMENCE', '10/09/1995', '99999999'),
(115, 46, 'DELIGNE', 'JULIEN', '23/07/1992', '99999999'),
(116, 47, 'DERBANNE', 'ESTELLE', '23/09/1990', '99999999'),
(117, 47, 'DERBANNE', 'NICOLAS', '22/07/1998', '99999999'),
(118, 47, 'MEUNIER', 'AURELIEN', '03/11/1988', '99999999'),
(119, 47, 'MEUNIER', 'MARINA', '13/07/1986', '99999999'),
(120, 46, 'DAVID', 'JOHANNA', '12/03/1996', '99999999'),
(121, 46, 'DAVID', 'LAURA', '28/09/1991', '99999999'),
(122, 49, 'DEZE', 'AMANDINE', '25/06/1991', '99999999'),
(123, 49, 'DEZE', 'BAPTISTE HENRI ERIC', '08/07/2002', '99999999'),
(124, 49, 'DEZE', 'J.FRANCOIS', '28/06/1988', '99999999'),
(125, 49, 'DEZE', 'THEO', '15/01/1996', '99999999'),
(126, 48, 'DEVEAUX', 'FLORIAN', '22/11/1996', '99999999'),
(127, 53, 'FUMOLEAU', 'MELANIE LAURENCE JUS', '08/03/1998', '99999999'),
(128, 54, 'LACOSTE', 'EMMA', '25/12/2003', '99999999'),
(129, 54, 'LACOSTE', 'THIBAUT', '18/04/2000', '99999999'),
(130, 55, 'ETAVARD', 'LYDIE', '02/06/1979', '99999999'),
(131, 55, 'ETAVARD', 'TEDDY', '03/10/1985', '99999999'),
(132, 56, 'FERRAULT', 'ANTOINE', '25/04/1994', '99999999'),
(133, 56, 'FERRAULT', 'JULIE', '27/05/1987', '99999999'),
(134, 57, 'FORGET', 'ALEXANDRE', '03/03/1993', '99999999'),
(135, 57, 'FORGET', 'ANGELIQUE', '12/01/1985', '99999999'),
(136, 57, 'FORGET', 'JEROME', '11/12/1982', '99999999'),
(137, 60, 'FOURRIER', 'JESSIE MYRIAM MAGALIE', '07/05/2012', '99999999'),
(138, 60, 'FOURRIER', 'TITO BRUNO PATRICE', '12/09/2008', '99999999'),
(139, 61, 'DERBANNE', 'ESTELLE', '23/09/1990', '99999999'),
(140, 61, 'GIRARD', 'AURELIEN', '29/06/1990', '99999999'),
(141, 62, 'HUPONT', 'EMILIE', '20/01/1987', '99999999'),
(142, 62, 'HUPONT', 'JUSTINE', '06/07/1988', '99999999'),
(143, 62, 'HUPONT', 'MATHIEU', '07/07/1992', '99999999'),
(144, 62, 'HUPONT', 'YOHAN', '10/06/1983', '99999999'),
(145, 63, 'GRABKO', 'AURELIE', '19/11/1984', '99999999'),
(146, 63, 'GRABKO', 'VIRGINIE', '17/05/1981', '99999999'),
(147, 127, 'GROISET', 'ROMAIN', '23/01/1986', '99999999'),
(148, 71, 'JOUSSE', 'DAMIEN FREDERIC', '25/09/2003', '99999999'),
(149, 71, 'JOUSSE', 'DORIAN', '11/12/1996', '99999999'),
(150, 64, 'HAMELIN', 'AXEL FRANCOIS MICHEL', '27/03/1997', '99999999'),
(151, 64, 'HAMELIN', 'EMMA ANNIE CHRISTINE', '26/10/2000', '99999999'),
(152, 64, 'HAMELIN', 'ETHAN AXEL CYRILLE', '19/04/2004', '99999999'),
(153, 65, 'DELAVEAU', 'MATHEO YANNICK', '17/12/2004', '99999999'),
(154, 65, 'DELAVEAU', 'PRESCILLIA', '23/11/1994', '99999999'),
(155, 65, 'HERSARD', 'KEVIN', '14/08/1990', '99999999'),
(156, 65, 'HERSARD', 'YONNI', '14/08/1990', '99999999'),
(157, 68, 'JAULON', 'ANDY PHILIPPE MAURIC', '14/03/1999', '99999999'),
(158, 68, 'JAULON', 'ETHAN PHILIPPE NICOL', '22/09/2004', '99999999'),
(159, 68, 'JAULON', 'QUENTIN', '21/11/1991', '99999999'),
(160, 69, 'JAUNEAU', 'CELINE', '16/11/1992', '99999999'),
(161, 69, 'JAUNEAU', 'VIRGINIE', '31/03/1990', '99999999'),
(162, 103, 'MIGNOT', 'DEBORAH', '09/03/1985', '99999999'),
(163, 103, 'MIGNOT', 'DOROTHEE', '07/04/1987', '99999999'),
(164, 103, 'MIGNOT', 'ROMAIN', '13/07/1989', '99999999'),
(165, 72, 'JOUSSE', 'ANTHONY', '30/07/1996', '99999999'),
(166, 72, 'JOUSSE', 'EMERICK', '13/12/2001', '99999999'),
(167, 73, 'JUBERT', 'JEREMY', '25/06/1994', '99999999'),
(168, 73, 'JUBERT', 'JULIE', '12/10/1989', '99999999'),
(169, 73, 'JUBERT', 'LUCILE', '12/04/1993', '99999999'),
(170, 75, 'LACHAT', 'CLAIRE ODILE MARCELL', '26/02/1998', '99999999'),
(171, 75, 'LACHAT', 'VALENTIN', '06/03/1993', '99999999'),
(172, 76, 'LACQUEMENT', 'CEDRIC', '15/01/1980', '99999999'),
(173, 76, 'LACQUEMENT', 'JULIEN', '13/11/1987', '99999999'),
(174, 76, 'LACQUEMENT', 'MIGUEL', '09/12/1976', '99999999'),
(175, 77, 'BLANDIN', 'JULIEN', '20/03/1989', '99999999'),
(176, 77, 'LAFRANCE', 'CINDY', '03/06/1983', '99999999'),
(177, 78, 'LAFRANCE', 'JENNIFER', '05/05/1987', '99999999'),
(178, 80, 'LEBLED', 'CHARLES', '06/06/1981', '99999999'),
(179, 50, 'DROUINEAU', 'LAETITIA', '11/09/1989', '99999999'),
(180, 50, 'DROUINEAU', 'MARINE', '28/06/1995', '99999999'),
(181, 81, 'FOVET', 'AMELIE CORALIE FIONA', '05/09/1998', '99999999'),
(182, 81, 'FOVET', 'DORINE', '24/09/1990', '99999999'),
(183, 86, 'LETROUX', 'CEDRIC', '05/07/1979', '99999999'),
(184, 86, 'LETROUX', 'DAMIEN', '01/04/1983', '99999999'),
(185, 87, 'LIHOREAU', 'EDWIGE', '25/07/1984', '99999999'),
(186, 87, 'LIHOREAU', 'REMI', '31/01/1989', '99999999'),
(187, 88, 'LIPHARDT', 'GAETAN', '05/05/1986', '99999999'),
(188, 88, 'LIPHARDT', 'LUCIE', '02/02/1983', '99999999'),
(189, 84, 'LEROUX', 'AMANDINE', '23/05/1985', '99999999'),
(190, 84, 'LEROUX', 'FABIEN', '01/04/1982', '99999999'),
(191, 84, 'LEROUX', 'LAURENCE', '03/06/1977', '99999999'),
(192, 84, 'LEROUX', 'NATHALIE', '16/04/1979', '99999999'),
(193, 89, 'LORMIER', 'DAVID', '26/07/1982', '99999999'),
(194, 89, 'LORMIER', 'LUCIE', '15/06/1986', '99999999'),
(195, 89, 'LORMIER', 'NICOLAS', '10/11/1980', '99999999'),
(196, 89, 'LORMIER', 'XAVIER', '29/08/1989', '99999999'),
(197, 90, 'LORMIER', 'LUCAS MAURICE', '21/04/2007', '99999999'),
(198, 142, 'WANGON', 'DORIAN FRANCOIS', '18/09/2003', '99999999'),
(199, 142, 'WANGON', 'THOMAS DIDIER PATRIC', '23/03/1999', '99999999'),
(200, 141, 'MARMIN', 'NATACHA', '15/03/1980', '99999999'),
(201, 94, 'MARMIN', 'JEROME JACQUES RAYMO', '11/01/2001', '99999999'),
(202, 94, 'MARMIN', 'THEOPHILE JEAN-CLAUD', '17/11/2005', '99999999'),
(203, 95, 'MARTIN', 'ALICE ALBANE', '24/05/2006', '99999999'),
(204, 95, 'MARTIN', 'MAXENCE SIMON', '15/12/2003', '99999999'),
(205, 96, 'MASSON', 'BRICE LOUIS MATTIEU', '25/06/1997', '99999999'),
(206, 97, 'MASSON', 'ALEXANDRE', '12/07/1997', '99999999'),
(207, 97, 'MASSON', 'AURELIE', '15/01/1992', '99999999'),
(208, 97, 'MASSON', 'ROMAIN HENRI', '12/11/2003', '99999999'),
(209, 138, 'DERBANNE', 'NICOLAS', '22/07/1998', '99999999'),
(210, 138, 'MEUNIER', 'AURELIEN', '03/11/1988', '99999999'),
(211, 138, 'MEUNIER', 'MARINA', '13/07/1986', '99999999'),
(212, 52, 'DUMESNIL', 'JULIE', '15/06/1985', '99999999'),
(213, 104, 'MONJAL', 'JULIE', '16/02/1988', '99999999'),
(214, 104, 'MONJAL', 'MAXIME', '09/06/1990', '99999999'),
(215, 106, 'MOREAU', 'DAMYEN RAPHAEL AUREL', '08/12/1998', '99999999'),
(216, 106, 'MOREAU', 'JULYEN', '26/01/1996', '99999999'),
(217, 106, 'MOREAU', 'LYSA MANON JUSTYNE', '11/10/2001', '99999999'),
(218, 43, 'CREPEAU', 'EMILIE', '13/01/1986', '99999999'),
(219, 43, 'CREPEAU', 'JENNY', '13/01/1983', '99999999'),
(220, 108, 'NAUDIN', 'EMELINE', '08/02/1994', '99999999'),
(221, 108, 'NAUDIN', 'LUCIE EMELINE LEA', '28/04/1999', '99999999'),
(222, 111, 'DUVEAU', 'CHRISTOPHER', '28/01/1985', '99999999'),
(223, 111, 'DUVEAU', 'JONATHAN', '08/09/1982', '99999999'),
(224, 111, 'DUVEAU', 'MARION', '09/11/1990', '99999999'),
(225, 111, 'DUVEAU', 'PRISCILLA', '29/03/1988', '99999999'),
(226, 111, 'OLIVIER', 'DAVID', '01/01/1982', '99999999'),
(227, 111, 'OLIVIER', 'KAREN MELODY', '04/11/1999', '99999999'),
(228, 111, 'OLIVIER', 'MATHIEU', '29/11/1989', '99999999'),
(229, 111, 'OLIVIER', 'THOMAS', '17/11/1987', '99999999'),
(230, 113, 'PELTIER', 'DAVID', '22/09/1982', '99999999'),
(231, 113, 'PELTIER', 'NICOLAS', '19/03/1989', '99999999'),
(232, 113, 'PELTIER', 'PAULINE', '25/01/1994', '99999999'),
(233, 20, 'BORBEAU', 'NICOLAS', '11/09/1981', '99999999'),
(234, 20, 'BORBEAU', 'THOMAS', '12/11/1985', '99999999'),
(235, 110, 'PHELIPOT', 'AUDREY', '22/01/1986', '99999999'),
(236, 114, 'PHELIPOT', 'AUDREY', '22/01/1986', '99999999'),
(237, 115, 'PIEDOIS', 'LILOU AURELIE JULIE', '18/06/2008', '99999999'),
(238, 115, 'PIEDOIS', 'TOM NICOLAS', '12/02/2003', '99999999'),
(239, 117, 'POUPARD', 'BERENGERE', '02/10/1988', '99999999'),
(240, 117, 'POUPARD', 'FLORENT', '27/09/1983', '99999999'),
(241, 118, 'PRUNIER', 'ADRIEN', '26/11/1990', '99999999'),
(242, 118, 'PRUNIER', 'ANTOINE', '31/01/1987', '99999999'),
(243, 119, 'REDUREAU', 'ADELINE', '15/02/1988', '99999999'),
(244, 119, 'REDUREAU', 'CINDY', '16/07/1980', '99999999'),
(245, 123, 'RICHARD', 'AUDREY MAEVA', '03/02/1997', '99999999'),
(246, 123, 'RICHARD', 'FABRICE ERIC SERGE', '19/06/1979', '99999999'),
(247, 123, 'RICHARD', 'SABRINA CHANTAL FRAN', '08/07/1981', '99999999'),
(248, 123, 'RICHARD', 'VANESSA DEBORAH STEP', '27/02/1987', '99999999'),
(249, 120, 'REDUREAU', 'ADELINE', '15/02/1988', '99999999'),
(250, 120, 'REDUREAU', 'CINDY', '16/07/1980', '99999999'),
(251, 121, 'REMY', 'EMILIE CECILE DESIRE', '20/02/1997', '99999999'),
(252, 31, 'CESBRON', 'AURELIE', '02/11/1980', '99999999'),
(253, 31, 'CESBRON', 'LUDIVINE', '18/12/1990', '99999999'),
(254, 31, 'CESBRON', 'SABRINA', '07/01/1983', '99999999'),
(255, 124, 'FRADIN', 'SAMUEL', '16/05/1976', '99999999'),
(256, 124, 'FRADIN', 'SEBASTIEN', '06/12/1973', '99999999'),
(257, 124, 'RICHARD', 'CHARLENE', '22/04/1982', '99999999'),
(258, 124, 'RICHARD', 'JONATHAN', '22/02/1981', '99999999'),
(259, 125, 'RICHARD', 'HELO?SE', '15/05/2013', '99999999'),
(260, 125, 'RICHARD', 'LILIA MARIE CHRISTIA', '30/03/2006', '99999999'),
(261, 125, 'RICHARD', 'NATHAN MICHEL MARC', '24/05/2010', '99999999'),
(262, 126, 'RICHER', 'ANTHONY', '03/11/1989', '99999999'),
(263, 126, 'RICHER', 'BETTY', '19/07/1986', '99999999'),
(264, 126, 'RICHER', 'EMILIE', '14/06/1983', '99999999'),
(265, 128, 'ROBINEAU', 'CHRISTOPHER', '26/01/1983', '99999999'),
(266, 128, 'ROBINEAU', 'JULIEN', '23/07/1985', '99999999'),
(267, 128, 'ROBINEAU', 'YANN', '27/02/1990', '99999999'),
(268, 129, 'ROCHE', 'CEDRIC', '23/06/1993', '99999999'),
(269, 129, 'ROCHE', 'JULIEN', '12/12/1990', '99999999'),
(270, 129, 'ROCHE', 'SANDY', '13/10/1995', '99999999'),
(271, 130, 'ROCHE', 'ANAIS NICOLE MARIE', '18/05/2000', '99999999'),
(272, 130, 'ROCHE', 'EVANN JACQUES GERARD', '27/09/2005', '99999999'),
(273, 130, 'ROCHE', 'VINCENT CHARLES LEON', '02/09/2002', '99999999'),
(274, 132, 'RUEL', 'JEREMY', '18/12/1989', '99999999'),
(275, 132, 'RUEL', 'NICOLAS', '30/01/1987', '99999999'),
(276, 133, 'TESSIER', 'VANESSA', '07/04/1982', '99999999'),
(277, 134, 'THIERRY', 'LAETITIA', '16/03/1985', '99999999'),
(278, 134, 'THIERRY', 'YOANN', '22/07/1987', '99999999'),
(279, 136, 'TRAVERS', 'ALEXANDRE ERIC FLORI', '16/12/2001', '99999999'),
(280, 136, 'TRAVERS', 'ESTELLE', '06/02/1997', '99999999'),
(281, 137, 'VERGER', 'ALEXIS PIERRE LEONAR', '28/10/1999', '99999999'),
(282, 137, 'VERGER', 'LUCIE MARIE', '23/02/2003', '99999999'),
(283, 140, 'ROCHARD', 'MAEVA', '21/07/1990', '99999999'),
(284, 143, 'WANGON', 'DORIAN FRANCOIS MARC', '18/09/2003', '99999999'),
(285, 143, 'WANGON', 'MARINE', '11/03/1988', '99999999'),
(286, 143, 'WANGON', 'THOMAS DIDIER PATRIC', '23/03/1999', '99999999'),
(287, 143, 'WANGON', 'VIOLAINE', '04/01/1991', '99999999'),
(288, 144, 'WENZLER', 'XAVIER', '11/12/1984', '99999999'),
(289, 145, 'XIONG', 'ALAIN', '28/02/1986', '99999999'),
(290, 145, 'XIONG', 'BOUNMY', '21/04/1987', '99999999'),
(291, 145, 'XIONG', 'BY', '25/08/1978', '99999999'),
(292, 145, 'XIONG', 'KARINE', '12/07/1981', '99999999'),
(293, 145, 'XIONG', 'KAU SU', '21/08/1993', '99999999'),
(294, 145, 'XIONG', 'MAY DOUA', '03/02/1977', '99999999'),
(295, 145, 'XIONG', 'MAY TONG', '25/08/1979', '99999999'),
(296, 145, 'XIONG', 'TIFFANIE', '07/07/1995', '99999999'),
(297, 146, 'YVON', 'AURELIE', '03/03/1979', '99999999'),
(298, 146, 'YVON', 'YOHAN', '28/08/1982', '99999999'),
(299, 116, 'PORTIER', 'GAETAN', '15/09/1989', '99999999'),
(300, 116, 'PORTIER', 'JUSTINE', '03/10/1992', '99999999'),
(301, 122, 'RENARD', 'DYLAN', '15/10/2002', '99999999'),
(302, 122, 'RENARD', 'FLORIANE', '23/10/1997', '99999999');

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE IF NOT EXISTS `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(13, 2, 'Ajout du produit fixe: VIR MARIESURGELES ASSURANCE CIVIC', '', '101.7', '2741955430'),
(14, 2, 'Vente de Billetterie: FERRAULT CHRISTOPHE pour la prestation cin&eacute;ma', '', '17.4', '94847558'),
(15, 2, 'Vente de Billetterie: JOURDAINE FREDERIC pour la prestation cin&eacute;ma', '', '23.2', '20887783'),
(16, 2, 'Vente de Billetterie: BARZIC AURELIEN pour la prestation cin&eacute;ma', '', '23.2', '44465138'),
(17, 2, 'Vente de Billetterie: VIOU ERIC pour la prestation cin&eacute;ma', '', '23.2', '79468733'),
(18, 2, 'Vente de Billetterie: NAUDIN PHILIPPE pour la prestation cin&eacute;ma', '', '23.2', '52528470'),
(19, 2, 'Vente de Billetterie: CALMET FABIENNE pour la prestation cin&eacute;ma', '', '23.2', '4366088'),
(20, 2, 'Vente de Billetterie: HAMELIN CYRILLE pour la prestation cin&eacute;ma', '', '17.4', '54326099'),
(21, 2, 'Vente de Billetterie: MONJAL DANIEL pour la prestation cin&eacute;ma', '', '23.2', '66821791'),
(22, 2, 'Vente de Billetterie: YVON MARIE LINE pour la prestation cin&eacute;ma', '', '23.2', '37200966'),
(23, 2, 'Vente de Billetterie: TIJOU E1ILIE pour la prestation cin&eacute;ma', '', '23.2', '57257205'),
(24, 2, 'Vente de Billetterie: LIPHARDT BRIGITTE pour la prestation cin&eacute;ma', '', '23.2', '46150312'),
(25, 2, 'Vente de Billetterie: ROBERT BRIGITTE pour la prestation cin&eacute;ma', '', '11.6', '16637023'),
(27, 2, 'Vente de Billetterie: 1ETAIS RAPHAEL pour la prestation cin&eacute;ma', '', '11.6', '86238121'),
(28, 2, 'Vente de Billetterie: HERSARD VERONIQUE pour la prestation cin&eacute;ma', '', '23.2', '20758269'),
(29, 2, 'Vente de Billetterie: CESBRON BEATRICE pour la prestation cin&eacute;ma', '', '11.6', '94857957'),
(30, 2, 'Vente de Billetterie: 1ETAIS RAPHAEL pour la prestation cin&eacute;ma', '', '5.8', '2463938'),
(32, 2, 'Vente de Billetterie: NUTTA YOAN pour la prestation cin&eacute;ma', '', '11.6', '8136161'),
(33, 2, 'Vente de Billetterie: ALIX PATRICIA pour la prestation cin&eacute;ma', '', '17.4', '70169403'),
(34, 2, 'Vente de Billetterie: ALIX PATRICIA pour la prestation cin&eacute;ma', '', '11.6', '84551883'),
(35, 2, 'Vente de Billetterie: TESSIER LEOCADIE pour la prestation cin&eacute;ma', '', '11.6', '52298982'),
(36, 2, 'Vente de Billetterie: DAVID JEREMIE pour la prestation piscine', '', '44', '15192580'),
(37, 2, 'Vente de Billetterie: ETAVARD ANITA pour la prestation Zoo dou&eacute; adulte', '', '33', '69650215'),
(38, 2, 'Vente de Billetterie: DA COSTA E SILVA FRANCOIS pour la prestation Zoo dou&eacute; adulte', '', '49.5', '7520023');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE IF NOT EXISTS `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`, `num_mouvement`) VALUES
(6, 56, '28-04-2015', 3, '17.4', 1, '94847558'),
(7, 70, '28-04-2015', 3, '23.2', 1, '20887783'),
(8, 11, '28-04-2015', 3, '23.2', 1, '44465138'),
(9, 139, '28-04-2015', 3, '23.2', 1, '79468733'),
(10, 108, '28-04-2015', 3, '23.2', 1, '52528470'),
(11, 30, '28-04-2015', 3, '23.2', 1, '4366088'),
(12, 64, '28-04-2015', 3, '17.4', 1, '54326099'),
(13, 104, '28-04-2015', 3, '23.2', 1, '66821791'),
(14, 146, '28-04-2015', 3, '23.2', 1, '37200966'),
(15, 135, '28-04-2015', 3, '23.2', 1, '57257205'),
(16, 88, '28-04-2015', 3, '23.2', 1, '46150312'),
(17, 101, '28-04-2015', 3, '11.6', 1, '86238121'),
(18, 127, '28-04-2015', 3, '11.6', 1, '16637023'),
(19, 65, '28-04-2015', 3, '23.2', 1, '20758269'),
(20, 31, '28-04-2015', 3, '11.6', 1, '94857957'),
(21, 101, '28-04-2015', 3, '5.8', 1, '2463938'),
(22, 3, '28-04-2015', 3, '17.4', 1, '70169403'),
(23, 109, '28-04-2015', 3, '11.6', 1, '8136161'),
(24, 3, '28-04-2015', 3, '11.6', 1, '84551883'),
(25, 133, '28-04-2015', 3, '11.6', 1, '52298982'),
(26, 45, '28-04-2015', 3, '44', 1, '15192580'),
(27, 55, '28-04-2015', 3, '33', 1, '69650215'),
(28, 44, '28-04-2015', 3, '49.5', 1, '7520023');

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE IF NOT EXISTS `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE IF NOT EXISTS `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '0', '0'),
(81, 2, '', ''),
(82, 3, '25560.87', '2841.25'),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '2409.2', '21.5'),
(87, 8, '39175.22', '20620'),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '23866.09', '70008.04'),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '0', '166.84'),
(113, 34, '', ''),
(114, 35, '', ''),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', '16.5'),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '1060.26', '0'),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '687.48', ''),
(134, 55, '', ''),
(135, 56, '277.68', ''),
(136, 57, '90.16', '0'),
(137, 58, '0', '0'),
(138, 59, '19.27', ''),
(139, 60, '390', ''),
(140, 61, '329.9', ''),
(141, 62, '', ''),
(142, 63, '8', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', '200'),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE IF NOT EXISTS `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_banque`
--

INSERT INTO `compta_banque` (`idcomptabanque`, `date_bq`, `desc_bq`, `idcomptaplan`, `debit`, `credit`) VALUES
(31, '1427925600', 'REMBOURSEMENT FRAIS DEPLACEMENT M METAIS CHQ 7036394', 3, '', '74.52'),
(32, '1427925600', 'ASF SESSION CFDT CARTE BANCAIRE', 3, '', '9.20'),
(33, '1427925600', 'COFIROUTE CB ', 3, '', '9.20'),
(34, '1427925600', 'SGT FRAIS BANCAIRE PAR PRLV', 3, '', '2.50'),
(35, '1428357600', 'MACIF ASSURANCE PRLV', 3, '', '687.48'),
(36, '1428357600', 'EUROPCAR CHQ 7036404', 3, '', '99.42'),
(37, '1428357600', 'EUROPCAR CHQ 7036405', 3, '', '129.42'),
(39, '1428616800', 'ENTREPRISE MARIE VIREMENT', 3, '16.50', ''),
(41, '1428962400', 'prlv SFR fixe ADSL', 3, '', '28.91'),
(44, '1429480800', 'cession CFDT CHQ 7036406', 3, '', '650'),
(45, '1429567200', 'vin feder', 3, '166.84', ''),
(46, '1429826400', 'europcar CHQ 7036409', 3, '', '48.84'),
(47, '1430085600', 'resto cafÃ© du centre CHQ 7036408', 3, '', '83.2'),
(48, '1430258400', 'resto cafÃ© du centre CB', 3, '', '85.2'),
(49, '1427839200', 'carburant intermarche CB', 3, '', '33.26'),
(58, '1430690400', 'prlv SFR', 3, '', '29.98'),
(59, '1430690400', 'cb autoroute sud', 3, '', '3.9'),
(60, '1430690400', 'cb intermarche carburant', 3, '', '17.55'),
(61, '1430690400', 'cb st fulgent le relais', 3, '', '27.7'),
(62, '1430776800', 'SGT frais bancaire', 3, '', '3.27'),
(65, '1431468000', 'cb caf&eacute; du centre', 3, '', '97.8'),
(66, '1431640800', 'prlv SFR', 3, '', '31.27'),
(67, '1431640800', 'frais de route chq 7683081', 3, '', '18'),
(68, '1431900000', 'CDT gestion logiciel et formation 7036412', 3, '', '390'),
(70, '1432245600', 'cb cofiroute', 3, '', '4.7'),
(71, '1432245600', 'cb autoroute sud', 3, '', '6.2'),
(72, '1432245600', 'cb cofiroute', 3, '', '17.3'),
(73, '1432245600', 'cb intermarche carburant', 3, '', '9.91'),
(74, '1432504800', 'cb europcar 3 factures location', 3, '', '206.52'),
(75, '1432764000', 'cb caf&eacute; du centre', 3, '', '36'),
(78, '1431468000', 'VIR COMPTE LIVRET VERS BANQUE', 3, '20620', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_actif`
--

INSERT INTO `compta_bilan_actif` (`idcptbilanactif`, `idcomptaplan`, `montant`) VALUES
(19, 3, '4757.53'),
(21, 7, '2209.20'),
(27, 8, '39175.22');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_passif`
--

INSERT INTO `compta_bilan_passif` (`idcptbilanpassif`, `idcomptaplan`, `montant`) VALUES
(15, 28, '46141.95');

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE IF NOT EXISTS `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE IF NOT EXISTS `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_compte`
--

INSERT INTO `compta_compte` (`idcomptacompte`, `idcomptaplan`, `debit`, `credit`) VALUES
(94, 51, '74.52', ''),
(96, 51, '9.20', ''),
(98, 51, '9.20', ''),
(100, 59, '2.50', ''),
(102, 54, '687.48', ''),
(104, 56, '99.42', ''),
(106, 56, '129.42', ''),
(108, 39, '', '16.50'),
(114, 0, '', ''),
(120, 57, '28.91', ''),
(123, 51, '650', ''),
(127, 33, '', '166.84'),
(128, 56, '48.84', ''),
(129, 61, '83.20', ''),
(130, 61, '85.20', ''),
(135, 3, '4757.53', ''),
(138, 51, '33.26', ''),
(139, 3, '', '33.26'),
(164, 28, '', '46141.95'),
(165, 66, '', '100'),
(166, 66, '', '100'),
(167, 7, '100', ''),
(168, 7, '100', ''),
(177, 59, '13.5', ''),
(178, 7, '', '13.5'),
(179, 7, '', '8'),
(185, 63, '8', ''),
(186, 57, '29.98', ''),
(187, 51, '3.9', ''),
(188, 51, '17.55', ''),
(189, 61, '27.7', ''),
(190, 59, '3.27', ''),
(192, 3, '', '29.98'),
(193, 3, '', '3.9'),
(194, 3, '', '17.55'),
(195, 3, '', '27.7'),
(196, 3, '', '3.27'),
(198, 61, '97.8', ''),
(199, 57, '31.27', ''),
(200, 51, '18', ''),
(201, 60, '390', ''),
(204, 3, '', '97.8'),
(205, 3, '', '31.27'),
(206, 3, '', '18'),
(207, 3, '', '390'),
(209, 51, '4.7', ''),
(210, 51, '6.2', ''),
(211, 51, '17.3', ''),
(212, 51, '9.91', ''),
(213, 51, '206.52', ''),
(214, 61, '36', ''),
(215, 3, '', '4.7'),
(216, 3, '', '6.2'),
(217, 3, '', '17.3'),
(218, 3, '', '9.91'),
(219, 3, '', '206.52'),
(220, 3, '', '36'),
(223, 8, '39175.22', ''),
(224, 8, '', '20620.00'),
(226, 3, '20620', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE IF NOT EXISTS `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_livret`
--

INSERT INTO `compta_livret` (`idcomptalivret`, `date_livret`, `desc_livret`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '1431468000', 'VIREMENT SUR LA BANQUE', 8, '', '20620.00');

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE IF NOT EXISTS `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_mvm`
--

INSERT INTO `compta_mvm` (`idcomptamvm`, `date_mvm`, `desc_mvm`, `idcomptaplan`, `debit`, `credit`) VALUES
(38, '1427925600', 'REMBOURSEMENT FRAIS DE ROUTE  M METAIS CHQ 7036394', 51, '74.52', ''),
(39, '1427925600', 'ASF SESSION CFDT CARTE BANCAIRE', 51, '9.20', ''),
(40, '1427925600', 'COFIROUTE CB ', 51, '9.20', ''),
(41, '1427925600', 'SGT FRAIS BANCAIRE PAR PRLV', 59, '2.50', ''),
(42, '1428357600', 'MACIF ASSURANCE PRLV', 54, '687.48', ''),
(43, '1428357600', 'EUROPCAR CHQ 7036404', 56, '99.42', ''),
(44, '1428357600', 'EUROPCAR CHQ 7036405', 56, '129.42', ''),
(45, '1428616800', 'ENTREPRISE MARIE VIREMENT', 39, '', '16.50'),
(49, '1429567200', '', 0, '', ''),
(55, '1428962400', 'prlv   SFR fixe adsl', 57, '28.91', ''),
(56, '1429480800', 'cession CFDT', 51, '650', ''),
(57, '1429567200', 'vin feder', 33, '', '166.84'),
(58, '1429826400', 'europcar location', 56, '48.84', ''),
(59, '1430085600', 'resto cafÃ© du centre CHQ 7036408', 61, '83.20', ''),
(60, '1430258400', 'resto cafÃ© du centre CB', 61, '85.20', ''),
(61, '1427839200', 'carburant intermarche CB ', 51, '33.26', ''),
(67, '1428357600', 'rem cheq pret wanderstein', 66, '', '100'),
(68, '1431640800', 'rem cheq pret wanderstein', 66, '', '100'),
(73, '1431986400', 'FRAIS LETTRE INFORMATION', 59, '13.5', ''),
(77, '1431986400', 'FRAIS COMM INTERVENTION', 63, '8', ''),
(78, '1430690400', 'prlv SFR', 57, '29.98', ''),
(79, '1430690400', 'cb autoroute du sud', 51, '3.9', ''),
(80, '1430690400', 'cb intermarche carburant', 51, '17.55', ''),
(81, '1430690400', 'cb st fulgent le relais', 61, '27.7', ''),
(82, '1430776800', 'SGT frais bancaire', 59, '3.27', ''),
(84, '1431468000', 'cb caf&eacute; du centre', 61, '97.8', ''),
(85, '1431640800', 'prlv SFR', 57, '31.27', ''),
(86, '1431640800', 'frais de route CHQ 7683081', 51, '18', ''),
(87, '1431900000', 'CDT gestion comptabilit&eacute; logiciel et formation', 60, '390', ''),
(89, '1432245600', 'cb cofiroute', 51, '4.7', ''),
(90, '1432245600', 'cb autoroute du sud', 51, '6.2', ''),
(91, '1432245600', 'cb cofiroute', 51, '17.3', ''),
(92, '1432245600', 'cb intermarche carburant', 51, '9.91', ''),
(93, '1432504800', 'cb europcar location 3 factures', 51, '206.52', ''),
(94, '1432764000', 'cb caf&eacute; du centre', 61, '36', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE IF NOT EXISTS `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', 'CrÃ©ances Client'),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', 'Compte de pret'),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', 'Remboursement Entreprise RESTAURATION'),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'Virement Cpte de pret vets Banque ASC'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', 'Remboursement Entreprise CARBURANT'),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', ''),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Postaux'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'Location vÃ©hicules automobile et matÃ©riel'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achat de matÃ©riel '),
(61, 6, 'Autre Charge d''exploitation 1', 'Restauration'),
(62, 6, 'Autre Charge d''exploitation 2', 'Hotellerie'),
(63, 6, 'Autre Charge d''exploitation 3', 'Frais bancaires'),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', 'Remboursement Pret Par Salari&eacute;'),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_pret`
--

CREATE TABLE IF NOT EXISTS `compta_pret` (
  `idcomptapret` int(13) NOT NULL,
  `date_pret` varchar(255) NOT NULL,
  `desc_pret` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `compta_pret`
--

INSERT INTO `compta_pret` (`idcomptapret`, `date_pret`, `desc_pret`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '1430949600', 'rem cheq pret wanderstein', 7, '100', ''),
(2, '1431640800', 'rem cheq pret wanderstein', 7, '100', ''),
(7, '1431986400', 'FRAIS COMM INTERVENTION', 7, '', '13.5'),
(8, '1432072800', 'FRAIS COMM INTERVENTION', 7, '', '8');

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE IF NOT EXISTS `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_resultat`
--

INSERT INTO `compta_resultat` (`idresultat`, `idcomptaplan`, `debit`, `credit`) VALUES
(37, 51, '74.52', ''),
(38, 51, '9.20', ''),
(39, 51, '9.20', ''),
(40, 59, '2.50', ''),
(41, 54, '687.48', ''),
(42, 56, '99.42', ''),
(43, 56, '129.42', ''),
(44, 39, '', '16.50'),
(48, 0, '', ''),
(54, 57, '28.91', ''),
(55, 51, '650', ''),
(56, 33, '', '166.84'),
(57, 56, '48.84', ''),
(58, 61, '83.20', ''),
(59, 61, '85.20', ''),
(60, 51, '33.26', ''),
(66, 66, '', '100'),
(67, 66, '', '100'),
(72, 59, '13.5', ''),
(76, 63, '8', ''),
(77, 57, '29.98', ''),
(78, 51, '3.9', ''),
(79, 51, '17.55', ''),
(80, 61, '27.7', ''),
(81, 59, '3.27', ''),
(83, 61, '97.8', ''),
(84, 57, '31.27', ''),
(85, 51, '18', ''),
(86, 60, '390', ''),
(88, 51, '4.7', ''),
(89, 51, '6.2', ''),
(90, 51, '17.3', ''),
(91, 51, '9.91', ''),
(92, 51, '206.52', ''),
(93, 61, '36', '');

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE IF NOT EXISTS `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'COMITE D''ENTREPRISE MARIE SURGELES', '', '', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE IF NOT EXISTS `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(13, '2741955430', '1429221600', 'VIR MARIESURGELES ASSURANCE CIVIC', '', '101.7'),
(14, '94847558', '1430172000', 'Vente de Billetterie: FERRAULT CHRISTOPHE pour la prestation cin&eacute;ma', '', '17.4'),
(15, '20887783', '1430172000', 'Vente de Billetterie: JOURDAINE FREDERIC pour la prestation cin&eacute;ma', '', '23.2'),
(16, '44465138', '1430172000', 'Vente de Billetterie: BARZIC AURELIEN pour la prestation cin&eacute;ma', '', '23.2'),
(17, '79468733', '1430172000', 'Vente de Billetterie: VIOU ERIC pour la prestation cin&eacute;ma', '', '23.2'),
(18, '52528470', '1430172000', 'Vente de Billetterie: NAUDIN PHILIPPE pour la prestation cin&eacute;ma', '', '23.2'),
(19, '4366088', '1430172000', 'Vente de Billetterie: CALMET FABIENNE pour la prestation cin&eacute;ma', '', '23.2'),
(20, '54326099', '1430172000', 'Vente de Billetterie: HAMELIN CYRILLE pour la prestation cin&eacute;ma', '', '17.4'),
(21, '66821791', '1430172000', 'Vente de Billetterie: MONJAL DANIEL pour la prestation cin&eacute;ma', '', '23.2'),
(22, '37200966', '1430172000', 'Vente de Billetterie: YVON MARIE LINE pour la prestation cin&eacute;ma', '', '23.2'),
(23, '57257205', '1430172000', 'Vente de Billetterie: TIJOU E1ILIE pour la prestation cin&eacute;ma', '', '23.2'),
(24, '46150312', '1430172000', 'Vente de Billetterie: LIPHARDT BRIGITTE pour la prestation cin&eacute;ma', '', '23.2'),
(25, '16637023', '1430172000', 'Vente de Billetterie: ROBERT BRIGITTE pour la prestation cin&eacute;ma', '', '11.6'),
(27, '86238121', '1430172000', 'Vente de Billetterie: 1ETAIS RAPHAEL pour la prestation cin&eacute;ma', '', '11.6'),
(28, '20758269', '1430172000', 'Vente de Billetterie: HERSARD VERONIQUE pour la prestation cin&eacute;ma', '', '23.2'),
(29, '94857957', '1430172000', 'Vente de Billetterie: CESBRON BEATRICE pour la prestation cin&eacute;ma', '', '11.6'),
(30, '2463938', '1430172000', 'Vente de Billetterie: 1ETAIS RAPHAEL pour la prestation cin&eacute;ma', '', '5.8'),
(32, '8136161', '1430172000', 'Vente de Billetterie: NUTTA YOAN pour la prestation cin&eacute;ma', '', '11.6'),
(33, '70169403', '1430172000', 'Vente de Billetterie: ALIX PATRICIA pour la prestation cin&eacute;ma', '', '17.4'),
(34, '84551883', '1430172000', 'Vente de Billetterie: ALIX PATRICIA pour la prestation cin&eacute;ma', '', '11.6'),
(35, '52298982', '1430172000', 'Vente de Billetterie: TESSIER LEOCADIE pour la prestation cin&eacute;ma', '', '11.6'),
(36, '15192580', '1430172000', 'Vente de Billetterie: DAVID JEREMIE pour la prestation piscine', '', '44'),
(37, '69650215', '1430172000', 'Vente de Billetterie: ETAVARD ANITA pour la prestation Zoo dou&eacute; adulte', '', '33'),
(38, '7520023', '1430172000', 'Vente de Billetterie: DA COSTA E SILVA FRANCOIS pour la prestation Zoo dou&eacute; adulte', '', '49.5');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE IF NOT EXISTS `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(1, 'LOISIRS ET SORTIES'),
(3, 'VOYAGES'),
(4, 'BILLETTERIE');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`) VALUES
(7, 6, 2, '3', '17.4', '3.9', 0),
(8, 7, 2, '4', '23.2', '5.2', 0),
(9, 8, 2, '4', '23.2', '5.2', 0),
(10, 9, 2, '4', '23.2', '5.2', 0),
(11, 10, 2, '4', '23.2', '5.2', 0),
(12, 11, 2, '4', '23.2', '5.2', 0),
(13, 12, 2, '3', '17.4', '3.9', 0),
(14, 13, 2, '4', '23.2', '5.2', 0),
(15, 14, 2, '4', '23.2', '5.2', 0),
(16, 15, 2, '4', '23.2', '5.2', 0),
(17, 16, 2, '4', '23.2', '5.2', 0),
(18, 18, 2, '2', '11.6', '2.6', 0),
(20, 17, 2, '2', '11.6', '2.6', 0),
(21, 19, 2, '4', '23.2', '5.2', 0),
(22, 20, 2, '2', '11.6', '2.6', 0),
(23, 21, 2, '1', '5.8', '1.3', 0),
(25, 23, 2, '2', '11.6', '2.6', 0),
(26, 22, 2, '3', '17.4', '3.9', 0),
(27, 24, 2, '2', '11.6', '2.6', 0),
(28, 25, 2, '2', '11.6', '2.6', 0),
(29, 26, 1, '2', '44', '0', 0),
(30, 27, 6, '2', '33', '0', 0),
(31, 28, 6, '3', '49.5', '0', 0);

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE IF NOT EXISTS `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE IF NOT EXISTS `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.6.1', '15315-PREM');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE IF NOT EXISTS `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'Administrateur', '25f9e794323b453885f5181f1b624d0b', 1),
(5, 'CEMARIE', 'b55cbb9b2915c8d8df38ea62ee320ab5', 1),
(6, 'raphael', 'aa622d1829f3f68127c00e2df48320b5', 2),
(7, 'fredo', '7aec5e35a56630ecc364ad842ffad9de', 2),
(8, 'jerome', '2bb010060d682fee5ad19d973a9a4d2a', 2);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '0'),
(3, 'vente_direct', '0');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE IF NOT EXISTS `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`) VALUES
(1, 1, 'piscine', '01-01-2015', '01-04-2016', '22', '0', '22', '100', '14', 0),
(2, 1, 'cin&eacute;ma', '01-01-2015', '29-02-2016', '5.8', '1.30', '7.1', '4', '138', 0),
(4, 4, 'AQUARIUM MINI CHATEAU', '01-05-2015', '09-04-2016', '15', '0', '15', '100', '10', 0),
(5, 4, 'La mine bleu adulte', '01-01-2015', '01-04-2016', '8.5', '0', '8.5', '100', '14', 0),
(6, 4, 'Zoo dou&eacute; adulte', '01-01-2015', '01-04-2016', '16.5', '0', '16.5', '100', '9', 0),
(7, 4, 'La mine bleu enfant', '01-01-2015', '01-04-2016', '5.31', '0', '5.31', '100', '5', 0),
(8, 4, 'Zoo dou&eacute; enfant', '01-01-2015', '01-04-2016', '12', '0', '12', '100', '17', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE IF NOT EXISTS `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `produit_fixe`
--

INSERT INTO `produit_fixe` (`idproduitfixe`, `designation`, `date_produit_fixe`, `montant_produit`, `num_mouvement`) VALUES
(3, 'VIR MARIESURGELES ASSURANCE CIVIC', '17-04-2015', '101.7', '2741955430');

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(5, 17, 3, '11.6', '', '', '121876337', 0),
(6, 6, 1, '17.4', 'LA POSTE', 'FERRAULT', '0001', 1),
(7, 7, 1, '23.2', 'CE', 'JOURDAINE', '002', 1),
(8, 8, 1, '23.2', 'BP', 'BARZIC', '003', 1),
(9, 9, 1, '23.2', 'LA POSTE', 'VIOU', '004', 1),
(10, 10, 1, '23.2', 'CE', 'NAUDIN', '005', 1),
(11, 11, 1, '23.2', 'CE', 'CALMET', '006', 1),
(12, 12, 1, '17.4', 'CE', 'HAMELIN', '007', 1),
(13, 13, 1, '23.2', 'BNP', 'MONJAL', '001', 1),
(14, 14, 1, '23.2', 'LCL', 'YVON', '002', 1),
(15, 15, 1, '23.2', 'CA', 'TIJOU', '003', 1),
(16, 16, 1, '23.2', 'SG', 'LIPHART', '004', 1),
(17, 19, 3, '23.2', '', 'HERSARD', '604948060', 1),
(18, 20, 3, '11.6', '', 'CESBRON', '694883366', 0),
(19, 21, 3, '5.8', '', 'METAIS', '283752599', 0),
(20, 22, 3, '17.4', '', 'ALIX', '168468722', 0),
(21, 23, 3, '11.6', '', 'NUTTA', '616667463', 0),
(22, 24, 3, '11.6', '', 'ALIX', '729356196', 0),
(23, 25, 3, '11.6', '', 'TESSIER', '464513148', 0),
(24, 26, 1, '44', 'cic', 'audouin', '001', 1),
(25, 27, 1, '33', 'ca', 'etavard', '001', 1),
(26, 28, 1, '49.5', 'CA', 'DACOSTA', '002', 1);

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE IF NOT EXISTS `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE IF NOT EXISTS `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE IF NOT EXISTS `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque`
--

INSERT INTO `remise_banque` (`idremisebanque`, `date_remise`, `type_remise`, `num_remise`, `montant_remise`, `valid`) VALUES
(3, '28-04-2015', 1, '5010908', '150.8', 1),
(4, '28-04-2015', 1, '5010910', '92.8', 1),
(6, '28-04-2015', 2, '', '23.2', 1),
(8, '28-04-2015', 1, '5010904', '44', 1),
(9, '28-04-2015', 1, '5010905', '82.5', 1);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE IF NOT EXISTS `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque_chq`
--

INSERT INTO `remise_banque_chq` (`idremisebanquechq`, `idremisebanque`, `idreglementventepresta`) VALUES
(3, 3, 6),
(4, 3, 7),
(5, 3, 8),
(6, 3, 9),
(7, 3, 10),
(8, 3, 11),
(9, 3, 12),
(10, 4, 13),
(11, 4, 14),
(12, 4, 15),
(13, 4, 16),
(14, 8, 24),
(15, 9, 25),
(16, 9, 26);

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE IF NOT EXISTS `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remise_banque_esp`
--

INSERT INTO `remise_banque_esp` (`idremisebanqueesp`, `idremisebanque`, `idreglementventepresta`) VALUES
(2, 6, 17);

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE IF NOT EXISTS `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(3, '6371018', 2, 'ALIX', 'PATRICIA', '179 RUE DOCTEUR SCHWEITZER', '', '49400', 'SAU1UR', '', '', '', '29/03/1960', '01/09/1977', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(4, '6371064', 1, 'ANDOUARD', 'ALBERT', '1 RUE DES TULIPES', '', '49160', 'LONGUE', '', '', '', '28/01/1961', '01/10/1979', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(5, '6371065', 1, 'ANDOUARD', 'CLAUDE', '4 RUE JEAN DE LA BRETE', '', '49700', 'CIZAY LA 1ADELEINE', '', '', '', '17/02/1960', '01/10/1988', '', 'OUV', 'OPERATEUR NETTOYAGE', '', '', 'CDI', 1, '999999999'),
(6, '6371022', 1, 'AUBIN', 'PHILIPPE', '9 RUE DE LA POSTE', '', '49400', 'CHACE', '', '', '', '24/02/1964', '01/10/1985', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(7, '6371198', 2, 'AUBOURG', 'JEANINE', '1 ALL DES ERABLES', '', '49400', 'CHACE', '', '', '', '24/01/1961', '01/10/1977', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(8, '6371337', 1, 'BARDET', 'OLIVIER', '16 RUE DES BELLES CAVES', '', '49260', 'BREZE', '', '', '', '12/04/1968', '01/04/1989', '', 'OUV', 'PREPARATEUR FABRICATION', '', '', 'CDI', 1, '999999999'),
(9, '6371462', 2, 'BARETEAU', 'JOSIANE', '22 RUE DU CLOS CRISTAL', '', '49400', 'SOUZAY CHA1PIGNY', '', '', '', '01/03/1959', '01/08/1978', '', 'OUV', 'CARISTE CHA1BRE FROIDE NEGATIVE', '', '', 'CDI', 1, '999999999'),
(10, '6371341', 1, 'BARRET', 'PATRICE', '1 RUE DE L ENCLAVE', '', '49160', 'ST 1ARTIN DE LA PLACE', '', '', '', '08/06/1968', '01/01/1993', '', 'OUV', 'COORDINATEUR PREPARATION NUIT', '', '', 'CDI', 1, '999999999'),
(11, '6300413', 1, 'BARZIC', 'AURELIEN', '6 RUE L ARGURAY - CHAVANNES', '', '49260', 'LE PUY NOTRE DA1E', '', '', '', '31/10/1979', '21/11/2005', '', 'A1T', 'CHEF D''EQUIPE', '', '', 'CDI', 1, '999999999'),
(12, '6371485', 1, 'BATTAIS', 'STEPHANE', '2 RTE DU BOIS SAU1OUSSAY', '', '49260', 'BREZE', '', '', '', '19/02/1965', '01/06/1985', '', 'OUV', 'CARISTE', '', '', 'CDI', 1, '999999999'),
(13, '6371672', 1, 'BAZANTE', 'HUBERT', '4 RUE LES PORTES NEUVES', '', '86120', 'ROIFFE', '', '', '', '20/10/1970', '01/05/1991', '', 'OUV', 'PILOTE EQUIPE LOGISTIQUE', '', '', 'CDI', 1, '999999999'),
(14, '6371585', 1, 'BENOIST', 'PATRICK', '37  CLOS DU PAVE1ENT', '', '49400', 'CHACE', '', '', '', '13/01/1965', '01/03/1986', '', 'OUV', 'COORDINATEUR PREPARATION NUIT', '', '', 'CDI', 1, '999999999'),
(15, '6371688', 1, 'BENOIT', 'EMMANUEL', '28 RTE DES VINS', '', '49730', 'PARNAY', '', '', '', '12/01/1969', '01/10/1988', '', 'OUV', 'CARISTE PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(16, '6371745', 2, 'BERTHELOT', 'MARIE BERNARD', '3 RUE DES VARENNES', '', '49260', 'BREZE', '', '', '', '05/07/1957', '01/10/1973', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(17, '6302258', 1, 'BIGOT', 'LOUIS', '16 RUE DE LA PIERRE FICHE', '', '49400', 'BAGNEUX', '', '', '', '19/08/1971', '01/05/1992', '', 'OUV', 'CONDUCTEUR DE 1ACHINE', '', '', 'CDI', 1, '999999999'),
(18, '6372055', 2, 'BODIN', 'BRIGITTE', '71 RUE DES VENDANGES', '', '49400', 'SAU1UR', '', '', '', '20/10/1960', '01/02/1989', '', 'OUV', 'OPERATEUR FAB/E1BALL', '', '', 'CDI', 1, '999999999'),
(19, '6372072', 2, 'BOISSEAU', 'CATHERINE', '22 RUE DE L EAU VIVE', '', '49400', 'BAGNEUX', '', '', '', '25/08/1961', '01/05/1978', '', 'OUV', 'CONDUCTEUR DE 1ACHINE', '', '', 'CDI', 1, '999999999'),
(20, '6377922', 2, 'BORBEAU', 'MARIE NOELLE', '430 RUE LAMARTINE', '', '49400', 'SAUMUR', '', '', '', '24/06/1960', '01/06/1978', '', 'OUV', 'PREPARATEUR FABRICATION', '', '', 'CDI', 1, '999999999'),
(21, '6372244', 1, 'BOUFFET', 'PHILIPPE', '79 RUE DE LA PALEINE', '', '49260', 'ST CYR EN BOURG', '', '', '', '02/01/1961', '01/06/1982', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(22, '6300657', 1, 'BOUQUET', 'SAMUEL', '63 RUE DU PARC', '', '49400', 'SAU1UR', '', '', '', '19/12/1976', '19/06/2007', '', 'CAD', 'DIRECTEUR USINE', '', '', 'CDI', 1, '999999999'),
(23, '6372379', 1, 'BOURLIERE', 'JOEL', '174 RUE CLAUDE BERNARD', '', '49400', 'SAU1UR', '', '', '', '02/07/1959', '01/08/1978', '', 'OUV', 'OPERATEUR NETTOYAGE', '', '', 'CDI', 1, '999999999'),
(24, '6300566', 2, 'BOURREAU', 'CHANTAL', '2 LD PALLUAU', '', '86200', 'LOUDUN', '', '', '', '11/12/1966', '01/11/1987', '', 'A1T', 'TECHNICIENNE QUALITE CLIENT', '', '', 'CDI', 1, '999999999'),
(25, '6372717', 2, 'BRONDEAU', 'MARTINE', '3 RUE DES NOYERS', '', '49400', 'CHACE', '', '', '', '24/12/1960', '01/07/1977', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(26, '6372666', 1, 'BRUNEAU', 'PAUL', ' LD LA TOURETTE', '', '86120', 'SAIX', '', '', '', '25/05/1955', '01/04/1992', '', 'OUV', 'OPERATEUR NETTOYAGE', '', '', 'CDI', 1, '999999999'),
(27, '6301307', 2, 'CADU', '1ARJORIE', '19  CLOS DES TILLEULS', '', '49700', 'DOUE LA FONTAINE', '', '', '', '08/04/1988', '01/03/2011', '', 'A1T', 'ASSISTANTE RH', '', '', 'CDI', 1, '999999999'),
(28, '6372741', 1, 'CAILLEAUD', 'PHILIPPE', ' LD LES PISSONNIERES', '', '49400', 'ST HILAIRE ST FLORENT', '', '', '', '05/05/1961', '01/05/1980', '', 'OUV', 'APPROVISIONNEUR', '', '', 'CDI', 1, '999999999'),
(29, '6372742', 2, 'CALMET', 'GINETTE', '32 RUE DU PRIEURE', '', '49260', 'ST CYR EN BOURG', '', '', '', '17/03/1963', '01/09/1979', '', 'OUV', 'PREPARATEUR FABRICATION', '', '', 'CDI', 1, '999999999'),
(30, '6372744', 2, 'CALMET', 'FABIENNE', '41 RTE DE SAU1UR', '', '49730', 'PARNAY', '', '', '', '03/04/1960', '01/03/1978', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(31, '6378415', 2, 'CESBRON', 'BEATRICE', '2 RUE DU BOIS SAUMOUSSAY', '', '49260', 'BREZE', '', '', '', '25/06/1961', '01/09/1979', '', 'OUV', 'PREPARATEUR FABRICATION', '', '', 'CDI', 1, '999999999'),
(32, '6373040', 1, 'CHAIGNEAU', 'YANNICK', '28 RUE DES CAVES', '', '49400', 'VARRAINS', '', '', '', '08/06/1969', '01/08/1993', '', 'A1T', 'TECHNICIEN TRAVAUX NEUFS', '', '', 'CDI', 1, '999999999'),
(33, '6373068', 1, 'CHASSEPORT', 'DIDIER', '8 RUE ROBERT D ARBRISSEL', '', '49400', 'SAU1UR', '', '', '', '15/07/1966', '01/10/1988', '', 'A1T', 'CHEF D''EQUIPE', '', '', 'CDI', 1, '999999999'),
(34, '6371241', 2, 'CHAUVEAU', 'BERNADETTE', '16 RUE JULES A1IOT', '', '49400', 'ST HILAIRE ST FLORENT', '', '', '', '27/04/1960', '01/08/1981', '', 'A1T', 'RESP. LABO ANALYSES', '', '', 'CDI', 1, '999999999'),
(35, '6373187', 2, 'CHEVAL', 'JOCELYNE', '7 ALL DES 1ARCASSINS', '', '49400', 'DISTRE', '', '', '', '05/06/1960', '01/10/1978', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(36, '6373261', 1, 'CHICOISNE', 'PASCAL', '20 RUE DES 1ENHIRS', '', '49400', 'BAGNEUX', '', '', '', '01/05/1967', '01/12/1990', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(37, '6300063', 1, 'CORNILLEAU', 'JEREMY', '82 RUE DE ROUEN', '', '49400', 'SAU1UR', '', '', '', '06/09/1981', '02/03/2005', '', 'A1T', 'RESPONSABLE AI ET COORDINATEUR SECURITE', '', '', 'CDI', 1, '999999999'),
(38, '6374706', 2, 'COUANNET', 'DANIELLE', '65 RUE FOUCAULT', '', '49260', 'SAINT CYR EN BOURG', '', '', '', '19/02/1962', '01/09/1979', '', 'E1P', 'LABORANTINE 1ER ECHE', '', '', 'CDI', 1, '999999999'),
(39, '6373587', 2, 'COUET', 'MARIE CLAIRE', ' RUE CHARLES DE GAULLE - LES ALGUES APPT 8', '', '49260', '1ONTREUIL BELLAY', '', '', '', '25/08/1962', '01/09/1979', '', 'OUV', 'CARISTE DE LIGNE', '', '', 'CDI', 1, '999999999'),
(40, '6300940', 1, 'COURLIVANT', 'EMMANUEL', '8 RTE DE LA SEIGNEURIE', '', '86330', 'SAINT JEAN DE SAUVES', '', '', '', '20/10/1971', '01/10/1990', '', 'A1T', 'CUISINIER FOR1ULATEUR', '', '', 'CDI', 1, '999999999'),
(41, '6301256', 1, 'COURLIVANT', 'ALAIN', '3 RTE DE CHA1PIGNY', '', '49730', 'PARNAY', '', '', '', '03/06/1959', '01/03/1987', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(42, '6301344', 2, 'COURLIVANT', 'NATHALIE', '3 RTE DE CHA1PIGNY', '', '49730', 'PARNAY', '', '', '', '01/10/1968', '01/02/1988', '', 'OUV', 'OPERATEUR NETTOYAGE', '', '', 'CDI', 1, '999999999'),
(43, '6377630', 2, 'CREPEAU', 'REGINE', '12 RUE DE LA BEDAUDIERE', '', '49730', 'TURQUANT', '', '', '', '04/09/1958', '01/02/1978', '', 'OUV', 'OPERATEUR FAB 1ER EC', '', '', 'CDI', 1, '999999999'),
(44, '6373730', 1, 'DA COSTA E SILVA', 'FRANCOIS', '21 RUE DES VIGNES', '', '49260', 'BREZE', '', '', '', '29/07/1969', '01/01/1992', '', 'OUV', '1AGASINIER 1ATIERES PRE1IERES', '', '', 'CDI', 1, '999999999'),
(45, '6374100', 1, 'DAVID', 'JEREMIE', '20 RUE LUCIEN DO1UREAU', '', '49400', 'SAINT LA1BERT DES LEVEES', '', '', '', '04/10/1963', '01/05/1992', '', 'OUV', 'CARISTE DE NETTOYAGE', '', '', 'CDI', 1, '999999999'),
(46, '6373912', 1, 'DELIGNE', 'RICHARD', '235 RUE D ANJOU', '', '49260', 'ARTANNES SUR THOUET', '', '', '', '23/07/1964', '04/04/1992', '', 'OUV', 'CARISTE-PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(47, '6374031', 1, 'DERBANNE', 'OLIVIER', '19 AVE JEAN 1ER1OZ - LES 1ESANGES', '', '49400', 'ST HILAIRE ST FLORENT', '', '', '', '24/07/1960', '01/05/1980', '', 'OUV', 'CARISTE-PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(48, '6374129', 2, 'DEVEAUX', 'VERONIQUE', '67 RUE DU BELLAY', '', '49260', 'ST JUST SUR DIVE', '', '', '', '07/03/1969', '01/10/1988', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(49, '6374120', 1, 'DEZE', 'ERIC', '11 RUE SOUS L OR1EAU', '', '49260', 'ST CYR EN BOURG', '', '', '', '10/08/1961', '01/04/1992', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(50, '6376669', 2, 'DROUINEAU', 'PATRICIA', '46 CHE DES RIVIERES', '', '49400', 'VARRAINS', '', '', '', '18/01/1959', '01/02/1978', '', 'OUV', 'OPERATEUR FAB 1ER EC', '', '', 'CDI', 1, '999999999'),
(51, '6300704', 1, 'DUBIER', 'HERVE', '189 RUE DU PONT FOUCHARD', '', '49400', 'BAGNEUX', '', '', '', '16/03/1966', '10/02/2004', '', 'OUV', 'ELECTRO1ECANICIEN 2E1E NIVEAU', '', '', 'CDI', 1, '999999999'),
(52, '6377510', 2, 'DUMESNIL', 'MARIE LAURE', '29 RUE DES ROGELINS', '', '49400', 'VARRAINS', '', '', '', '16/09/1957', '01/04/1978', '', 'E1P', 'PREPARATRICE EPICES', '', '', 'CDI', 1, '999999999'),
(53, '6374268', 2, 'DUPONT', 'MARIE LAURE', '8 RUE DU CLOS MOREAU', '', '49260', 'EPIEDS', '', '', '', '17/12/1967', '01/02/1989', '', 'OUV', 'CONDUCTEUR DE 1ACHINE', '', '', 'CDI', 1, '999999999'),
(54, '6374270', 2, 'DUPOUTS', 'MONIQUE', '38 RUE DES FAUVETTES', '', '49400', 'ST LA1BERT DES LEVEES', '', '', '', '12/07/1968', '01/02/1993', '', 'CAD', 'RESP. ASSURANCE QUALITE', '', '', 'CDI', 1, '999999999'),
(55, '6374432', 2, 'ETAVARD', 'ANITA', '447 RUE DES FLEURS', '', '49260', 'BALLOIRE', '', '', '', '31/10/1959', '01/11/1977', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(56, '6374472', 1, 'FERRAULT', 'CHRISTOPHE', '39 RUE JULES DUPERRAY', '', '49400', 'BAGNEUX', '', '', '', '04/02/1963', '01/10/1992', '', 'OUV', 'COORDINATEUR PREPARATION NUIT', '', '', 'CDI', 1, '999999999'),
(57, '6374519', 1, 'FORGET', 'JEAN MICHEL', '4 CIT DE L EVEQUE', '', '86120', 'ROIFFE', '', '', '', '18/08/1959', '01/09/1981', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(58, '6300580', 2, 'FOURNIER', 'FRANCOISE', ' RTE DE PARCAY LES PINS', '', '49390', 'VERNOIL', '', '', '', '15/06/1959', '26/02/2007', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(59, '6374649', 1, 'FOURREAU', 'MICHEL', ' RUE DE LA PATROCHE', '', '49260', 'BREZE', '', '', '', '15/10/1959', '01/03/1978', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(60, '6374652', 1, 'FOURRIER', 'BRUNO', '31 RUE DU BOURG JOLY', '', '79290', 'SAINT 1ARTIN DE SANZAY', '', '', '', '07/09/1974', '13/05/2004', '', 'OUV', 'COORDINATEUR 1AGASIN', '', '', 'CDI', 1, '999999999'),
(61, '6375055', 1, 'GIRARD', 'ALAIN', '134 RUE DU 08 1AI 1945', '', '49260', '1ONTREUIL BELLAY', '', '', '', '20/01/1963', '01/12/1985', '', 'OUV', 'PREPARATEUR FABRICATION', '', '', 'CDI', 1, '999999999'),
(62, '6375277', 2, 'GODINEAU', 'YOLANDE', '9 RES PLEIN SOLEIL', '', '49400', 'CHACE', '', '', '', '07/12/1961', '01/01/1978', '', 'OUV', 'CONDUCTEUR DE 1ACHINE', '', '', 'CDI', 1, '999999999'),
(63, '6375368', 1, 'GRABKO', 'ALAIN', '30 RUE DES PETITES HAIES', '', '49260', 'LE VAUDELNAY', '', '', '', '19/04/1959', '01/01/1980', '', 'OUV', '1ECANICIEN FLUIDES', '', '', 'CDI', 1, '999999999'),
(64, '6375553', 1, 'HAMELIN', 'CYRILLE', '41 RUE VALBRUN', '', '49730', 'PARNAY', '', '', '', '19/04/1965', '01/07/1984', '', 'OUV', 'PILOTE EQUIPE LOGISTIQUE', '', '', 'CDI', 1, '999999999'),
(65, '6375673', 2, 'HERSARD', 'VERONIQUE', '5 CHE DES CAROSSES', '', '49260', 'EPIEDS', '', '', '', '29/04/1969', '01/02/1989', '', 'E1P', 'Pr?parateur d''analyses et pr?l?ve1ents', '', '', 'CDI', 1, '999999999'),
(66, '6300826', 1, 'JACQUET', 'FREDERIC', '12 RTE DU 1OULIN DE RASLAY', '', '86120', 'RASLAY', '', '', '', '02/02/1973', '28/04/2008', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(67, '6304056', 1, 'JARSON', 'MICKAEL', '19 RUE E1ILE LANDAIS', '', '49400', 'CHACE', '', '', '', '28/06/1980', '01/04/2001', '', 'OUV', 'CARISTE APPROVISIONNE1ENT', '', '', 'CDI', 1, '999999999'),
(68, '6375913', 1, 'JAULON', 'PHILIPPE', '7 RUE TRAVERSIERE', '', '49160', 'LONGUE', '', '', '', '25/12/1968', '01/01/1989', '', 'OUV', 'COORDINATEUR PREPARATION NUIT', '', '', 'CDI', 1, '999999999'),
(69, '6375918', 1, 'JAUNEAU', 'PATRICK', ' LD RAVAUX', '', '49160', 'LONGUE JU1ELLES', '', '', '', '03/03/1961', '01/04/1989', '', 'OUV', 'CARISTE', '', '', 'CDI', 1, '999999999'),
(70, '6302250', 1, 'JOURDAINE', 'FREDERIC', '19 RUE DES CHAR1ES', '', '79100', 'LOUZY', '', '', '', '31/10/1963', '01/10/1985', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(71, '6375542', 2, 'JOUSSE', 'KATIE', '6 RUE VERCINGETORIX', '', '49400', 'BAGNEUX', '', '', '', '02/03/1969', '01/09/1988', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(72, '6376097', 1, 'JOUSSE', 'SEBASTIEN', '19 RUE JULES DUPERRAY', '', '49400', 'BAGNEUX', '', '', '', '23/08/1971', '01/03/1992', '', 'OUV', 'COORDINATEUR PREPARATION NUIT', '', '', 'CDI', 1, '999999999'),
(73, '6376118', 1, 'JUBERT', 'DOMINIQUE', '572 RTE DE FONTEVRAUD', '', '49400', 'SAU1UR', '', '', '', '06/03/1969', '01/05/1989', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(74, '6376201', 1, 'KADI', 'DJA1EL', '15 RUE DU 1AL JOFFRE', '', '49400', 'SAU1UR', '', '', '', '24/11/1969', '01/07/1989', '', 'OUV', 'OPERATEUR NETTOYAGE', '', '', 'CDI', 1, '999999999'),
(75, '6376252', 1, 'LACHAT', 'LIONEL', '86 CHE DE 1ANIERES', '', '49400', 'ST HILAIRE ST FLORENT', '', '', '', '21/01/1965', '01/01/1985', '', 'OUV', 'PILOTE EQUIPE LOGISTIQUE', '', '', 'CDI', 1, '999999999'),
(76, '6376277', 2, 'LACQUEMENT', 'MIREILLE', '1 RUE BASSES RUES', '', '49730', 'VARENNES SUR LOIRE', '', '', '', '23/03/1958', '01/10/1974', '', 'E1P', 'CONTROLEUR QUALITE UNITE ET 1CE', '', '', 'CDI', 1, '999999999'),
(77, '6376322', 2, 'LAFRANCE', 'FRANCOISE', '59 RUE DES VIGNES', '', '49400', 'SAU1UR', '', '', '', '30/01/1962', '01/03/1978', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(78, '6376324', 1, 'LAFRANCE', 'JEAN CLAUDE', '35 RUE DES ROCHES NEUVES', '', '49400', 'VARRAINS', '', '', '', '04/07/1959', '01/02/1978', '', 'OUV', 'CARISTE-PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(79, '6376471', 2, 'LANGER', '1ARYLENE', '254 RUE D ANJOU', '', '49260', 'ARTANNES SUR THOUET', '', '', '', '23/06/1956', '01/06/1972', '', 'OUV', 'OPERATEUR FAB 1ER EC', '', '', 'CDI', 1, '999999999'),
(80, '6376639', 2, 'LEBLED', 'GHISLAINE', '2 RTE DE BROSSAY', '', '49700', 'CIZAY LA 1ADELEINE', '', '', '', '16/07/1957', '01/07/1973', '', 'E1P', 'PREPARATEUR DEGUSTATION', '', '', 'CDI', 1, '999999999'),
(81, '6376681', 2, 'LECOMTE', 'MONIQUE', '6 RUE MILLOCHEAU', '', '49400', 'SAUMUR', '', '', '', '03/01/1963', '01/09/1979', '', 'OUV', 'OPERATEUR FAB 1ER EC', '', '', 'CDI', 1, '999999999'),
(82, '6376575', 1, 'LEDEUIL', 'PHILIPPE', '80 RUE GRAND RUE', '', '49400', 'VARRAINS', '', '', '', '07/06/1957', '01/01/1986', '', 'OUV', 'CARISTE DE LIGNE', '', '', 'CDI', 1, '999999999'),
(83, '6372824', 2, 'LELIEVRE', 'MARTINE', '56 RUE DU 1OUTIER', '', '49260', 'ST CYR EN BOURG', '', '', '', '12/07/1958', '01/02/1976', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(84, '6376931', 1, 'LEROUX', 'ANDRE', '3 RUE DES EAUX BUES', '', '49400', 'CHACE', '', '', '', '28/03/1957', '01/03/1991', '', 'A1T', 'CHEF D''EQUIPE', '', '', 'CDI', 1, '999999999'),
(85, '6300597', 1, 'LETETREL', 'CESAR', '27 RUE GRAND RUE', '', '49250', 'BRION', '', '', '', '18/12/1979', '28/03/2007', '', 'CAD', 'RESPONSABLE FLUX', '', '', 'CDI', 1, '999999999'),
(86, '6376871', 1, 'LETROUX', 'MARC', '19 RUE DU LOTISSEMENT', '', '49260', 'EPIEDS', '', '', '', '10/08/1957', '01/05/1979', '', 'OUV', 'CARISTE APPROVISIONNE1ENT', '', '', 'CDI', 1, '999999999'),
(87, '6376909', 2, 'LIHOREAU', 'CHANTAL', '11 ALL DE LA MAILLETERIE', '', '37140', 'BOURGUEIL', '', '', '', '09/04/1960', '01/07/1979', '', 'E1P', 'CONTROLEUR QUALITE/1CE UNITE', '', '', 'CDI', 1, '999999999'),
(88, '6376916', 2, 'LIPHARDT', 'BRIGITTE', '8 RES PLEIN SOLEIL', '', '49400', 'CHACE', '', '', '', '09/04/1960', '01/01/1978', '', 'A1T', 'TECHNICIENNE CONT.GESTION', '', '', 'CDI', 1, '999999999'),
(89, '6376992', 2, 'LORMIER', 'LORETTE', '3 CHE DES CARREAUX', '', '49400', 'DISTRE', '', '', '', '06/07/1961', '01/07/1978', '', 'OUV', 'CARISTE CHA1BRE FROIDE', '', '', 'CDI', 1, '999999999'),
(90, '6376993', 1, 'LORMIER', 'JEROME', '142 RUE DE DOUE', '', '49400', 'BAGNEUX', '', '', '', '31/08/1972', '01/12/1992', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(91, '6377012', 2, '1ABILLEAU', 'ROSELYNE', '135 RUE LOUVET', '', '49400', 'SAU1UR', '', '', '', '09/09/1956', '01/01/1978', '', 'OUV', 'CONDUCTEUR PETRIN TARTES', '', '', 'CDI', 1, '999999999'),
(92, '6377013', 2, '1ABILLEAU', 'FRANCINE', '139 RUE LOUVET', '', '49400', 'SAU1UR', '', '', '', '18/05/1958', '01/01/1978', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(93, '6371584', 2, 'MARIET', 'SOPHIE', '3 RTE DES ROSIERS', '', '49160', 'LONGUE', '', '', '', '05/05/1969', '01/10/1989', '', 'E1P', 'LABORANTINE 1ER ECHE', '', '', 'CDI', 1, '999999999'),
(94, '6377171', 1, 'MARMIN', 'MICKAEL', '6 RUE DU PRIEURE', '', '49260', 'ST CYR EN BOURG', '', '', '', '22/11/1970', '01/12/1992', '', 'OUV', '1ECANICIEN NIVEAU 2', '', '', 'CDI', 1, '999999999'),
(95, '6377200', 1, 'MARTIN', 'HUGUES', '49 RUE THEOPHILE VAUGOUIN', '', '49400', 'SAINT HILAIRE ST FLORENT', '', '', '', '11/05/1974', '01/07/2000', '', 'A1T', 'TECHNICIEN TRAVAUX NEUFS', '', '', 'CDI', 1, '999999999'),
(96, '6377334', 1, 'MASSON', 'JACQUES', ' RUE D ANJOU', '', '49260', 'ARTANNES SUR THOUET', '', '', '', '06/10/1967', '01/05/1989', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(97, '6377337', 1, 'MASSON', 'STEPHANE', '14 CHE DU PARADIS', '', '49400', 'VILLEBERNIER', '', '', '', '29/11/1968', '01/01/1990', '', 'OUV', 'AIDE PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(98, '6300715', 2, 'MENARD', 'LUCIA', '2 RUE DES PA1PRES', '', '49400', 'CHACE', '', '', '', '25/02/1982', '01/12/2006', '', 'A1T', 'ASSISTANTE SCE TECHNIQUE', '', '', 'CDI', 1, '999999999'),
(99, '6360008', 1, '1EQUINION', 'PIERRE', '10 RES L OREE D HASTINGS', '', '14000', 'CAEN', '', '', '', '13/04/1994', '13/04/2015', '', 'OUV', 'STAGIAIRE QUALITE', '', '', 'STG', 1, '999999999'),
(100, '6300964', 2, 'MESMIN', 'PATRICIA', '19 RUE ISAAC DE RAZILLY', '', '86120', 'ROIFFE', '', '', '', '03/10/1959', '01/01/1990', '', 'OUV', 'CONDUCTEUR DE 1ACHINE', '', '', 'CDI', 1, '999999999'),
(101, '6304030', 1, '1ETAIS', 'RAPHAEL', '8 I1P JEANNE D ARC', '', '49400', 'SAINT HILAIRE ST FLORENT', '', '', '', '05/09/1974', '01/05/2000', '', 'OUV', 'ELECTRO1ECANICIEN', '', '', 'CDI', 1, '999999999'),
(102, '6360009', 1, '1ICHIELS', 'CHARLES', '53 AVE DU 14 JUILLET', '', '59139', 'WATTIGNIES', '', '', '', '29/12/1993', '01/06/2015', '', 'OUV', 'STAGIAIRE PRODUCTION', '', '', 'STG', 1, '999999999'),
(103, '6376003', 2, 'MIGNOT', 'NADINE', '16 RES PLEIN SOLEIL', '', '49400', 'CHACE', '', '', '', '15/01/1960', '01/05/1980', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(104, '6377526', 1, 'MONJAL', 'DANIEL', '21B RUE DE LA POSTE', '', '49400', 'CHACE', '', '', '', '17/08/1962', '01/06/1983', '', 'A1T', 'ELECTRO1ECANICIEN N2 (RELAIS)', '', '', 'CDI', 1, '999999999'),
(105, '6304021', 2, 'MONORY', 'MYRIAM', '31 RUE DU BOURG JOLY - PASSAY', '', '79290', 'SAINT 1ARTIN DE SANZAY', '', '', '', '25/06/1978', '01/03/2000', '', 'E1P', 'ASSISTANTE  GESTION', '', '', 'CDI', 1, '999999999'),
(106, '6377613', 1, 'MOREAU', 'DAVID', '37 RUE DES VARENNES', '', '49400', 'ROU 1ARSON', '', '', '', '17/05/1969', '01/11/1988', '', 'OUV', 'AIDE PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(107, '6377700', 1, '1UREAU', 'FRANCOIS', '59 RUE DES VIGNES - APPT 18', '', '49400', 'SAU1UR', '', '', '', '04/12/1965', '01/08/1988', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(108, '6377720', 1, 'NAUDIN', 'PHILIPPE', ' LD LES JOUANNEAUX', '', '49680', 'NEUILLE', '', '', '', '02/08/1966', '01/09/1988', '', 'OUV', 'CARISTE DE LIGNE', '', '', 'CDI', 1, '999999999'),
(109, '6300793', 1, 'NUTTA', 'YOAN', '1 RUE DE LA FIDELITE', '', '49400', 'SAU1UR', '', '', '', '26/04/1982', '01/11/2005', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(110, '6377930', 2, 'OLIVE', 'SYLVIE', '19 RUE DES VIOLETTES', '', '49260', 'BREZE', '', '', '', '16/01/1962', '01/01/1978', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(111, '6377765', 1, 'OLIVIER', 'PASCAL', '40 RUE DU CLOS POINTU', '', '49400', 'SAU1UR', '', '', '', '20/06/1959', '01/10/1981', '', 'OUV', '1ECANICIEN/REGLEUR 2', '', '', 'CDI', 1, '999999999'),
(112, '6372807', 2, 'PASQUIER', 'BRIGITTE', '19 RUE DE LA POSTE', '', '49400', 'CHACE', '', '', '', '20/07/1956', '01/05/1980', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(113, '6377889', 1, 'PELTIER', 'THIERRY', '30 RES PLEIN SOLEIL', '', '49400', 'CHACE', '', '', '', '14/02/1961', '01/01/1980', '', 'OUV', 'CONDUCTEUR DE CUISEUR', '', '', 'CDI', 1, '999999999'),
(114, '6377931', 1, 'PHELIPOT', 'THIERRY', '11 RUE DE LA CHAPELLE', '', '49700', 'BROSSAY', '', '', '', '26/03/1961', '01/05/1980', '', 'OUV', 'PREPARATEUR FABRICATION', '', '', 'CDI', 1, '999999999'),
(115, '6377933', 1, 'PIEDOIS', 'NICOLAS', '26 RUE DE L EGALITE', '', '86120', '1ORTON', '', '', '', '25/10/1973', '01/07/1993', '', 'OUV', 'COORDINATEUR DE LIGNE', '', '', 'CDI', 1, '999999999'),
(116, '6383838', 1, 'PORTIER', 'ALAIN', '28 RUE POINTEL', '', '35400', 'SAINT 1ALO', '', '', '', '18/03/1959', '01/06/1981', '', 'A1T', 'RESPONSABLE 1AGASIN ET LOGISTIQUE', '', '', 'CDI', 1, '999999999'),
(117, '6378080', 1, 'POUPARD', 'PIERRE', '10 RUE DE LA MEUNERIE', '', '49400', 'BAGNEUX', '', '', '', '23/01/1960', '01/12/1988', '', 'OUV', 'ELECTRO1ECANICIEN N2', '', '', 'CDI', 1, '999999999'),
(118, '6378134', 1, 'PRUNIER', 'ERIC', '4 CHE DE LA SEGUINIERE', '', '49400', 'VILLEBERNIER', '', '', '', '17/02/1963', '01/02/1982', '', 'OUV', 'AGENT STATION EPURATION ET SERVICE GENERAUX', '', '', 'CDI', 1, '999999999'),
(119, '6378393', 1, 'REDUREAU', 'ALAIN', '36 RUE DE LA POTERNE', '', '49400', 'VARRAINS', '', '', '', '26/09/1958', '01/03/1978', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(120, '6378399', 2, 'REDUREAU', 'MARYSE', '36 RUE DE LA POTERNE', '', '49400', 'VARRAINS', '', '', '', '19/07/1961', '01/03/1978', '', 'OUV', 'CONDUCTEUR DE 1ACHINE', '', '', 'CDI', 1, '999999999'),
(121, '6378410', 1, 'REMY', 'DIDIER', '4 RUE DE 1ONTAGLAND', '', '49400', 'BAGNEUX', '', '', '', '26/07/1966', '01/06/1988', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(122, '6384001', 1, 'RENARD', 'ERIC', '12 RUE LESPAGNEUL DE LA PLANT', '', '49650', 'ALLONNES', '', '', '', '18/01/1966', '01/10/1986', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(123, '6378395', 2, 'RICHARD', 'CHANTAL', '9 RUE WALDECK ROUSSEAU', '', '49400', 'SAU1UR', '', '', '', '28/11/1960', '01/04/1978', '', 'OUV', 'OPERATEUR FAB 1ER EC', '', '', 'CDI', 1, '999999999'),
(124, '6378613', 1, 'RICHARD', 'GILLES', '3 RUE DE L ABREUVOIR', '', '49400', 'SOUZAY CHA1PIGNY', '', '', '', '08/01/1961', '01/12/1979', '', 'OUV', 'PILOTE EQUIPE LOGISTIQUE', '', '', 'CDI', 1, '999999999'),
(125, '6378624', 1, 'RICHARD', 'YANN', '3 RUE DU BOURNEAU', '', '49700', 'CIZAY LA 1ADELEINE', '', '', '', '31/05/1972', '01/04/1992', '', 'OUV', 'CARISTE APPROVISIONNE1ENT', '', '', 'CDI', 1, '999999999'),
(126, '6378693', 1, 'RICHER', 'PHILIPPE', '73 RUE DU CHATEAU', '', '49260', '1ONTREUIL BELLAY', '', '', '', '16/04/1962', '01/05/1978', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(127, '6375396', 2, 'ROBERT', 'BRIGITTE', '19 BLD JOLY LETER1E', '', '49400', 'SAU1UR', '', '', '', '17/07/1958', '01/08/1976', '', 'OUV', 'OPERATEUR E1BALLAGE', '', '', 'CDI', 1, '999999999'),
(128, '6378773', 2, 'ROBINEAU', 'GHISLAINE', '102 RUE DES VIGNES', '', '49260', 'COURCHA1PS', '', '', '', '01/08/1959', '01/09/1979', '', 'OUV', 'OPERATEUR FAB 1ER EC', '', '', 'CDI', 1, '999999999'),
(129, '6378878', 1, 'ROCHE', 'GILLES', '44 RUE DE L ABREUVOIR', '', '49400', 'BAGNEUX', '', '', '', '05/01/1964', '01/09/1984', '', 'OUV', 'CHARGEUR / PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(130, '6378882', 1, 'ROCHE', 'JEROME', '23 RUE DES SABOTIERS', '', '49400', 'ST LA1BERT DES LEVEES', '', '', '', '01/03/1971', '01/02/1991', '', 'OUV', 'CARISTE DE NETTOYAGE', '', '', 'CDI', 1, '999999999'),
(131, '6300795', 1, 'ROUSSIASSE', 'AURELIEN', ' LD LA BARAUDIERE', '', '49390', 'LA BREILLE LES PINS', '', '', '', '28/05/1987', '01/07/2007', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(132, '6379092', 1, 'RUEL', 'ROLAND', '43 RUE DE LA 1ETAIRIE', '', '49400', 'ST LA1BERT DES LEVEES', '', '', '', '30/03/1964', '01/03/1986', '', 'OUV', 'PREPARATEUR FABRICATION', '', '', 'CDI', 1, '999999999'),
(133, '6379471', 2, 'TESSIER', 'LEOCADIE', '31 RUE DES COTEAUX', '', '49400', 'BAGNEUX', '', '', '', '04/07/1960', '01/02/1978', '', 'OUV', 'CONDUCTEUR DE PETRIN TARTES', '', '', 'CDI', 1, '999999999'),
(134, '6379474', 1, 'THIERRY', 'JEAN MARC', '26 RES PLEIN SOLEIL', '', '49400', 'CHACE', '', '', '', '25/05/1962', '01/09/1981', '', 'OUV', 'CONDUCTEUR DE LIGNE AUTO1ATISEE', '', '', 'CDI', 1, '999999999'),
(135, '6360005', 2, 'TIJOU', 'E1ILIE', '688 RUE DE LA SALLE', '', '49260', '1ONTREUIL BELLAY', '', '', '', '13/02/1987', '01/08/2012', '', 'A1T', 'RESPONSABLE QUALITE ET A1ELIORATION CONTINUE', '', '', 'CDI', 1, '999999999'),
(136, '6379552', 1, 'TRAVERS', 'ERIC', '327 RUE DU CHEMIN VERT', '', '49400', 'SAU1UR', '', '', '', '20/07/1965', '01/04/1990', '', 'OUV', 'PETRISSEUR', '', '', 'CDI', 1, '999999999'),
(137, '6379600', 1, 'VERGER', 'FRANCOIS', '8 RUE LOUIS CHOUTEAU', '', '49400', 'CHACE', '', '', '', '12/10/1974', '01/10/1999', '', 'A1T', 'RESPONSABLE PRODUCTION', '', '', 'CDI', 1, '999999999'),
(138, '6377444', 2, 'VIOLEAU', 'MONIQUE', '12 RUE LOUIS ROBINEAU', '', '49400', 'CHACE', '', '', '', '09/03/1962', '01/02/1989', '', 'OUV', 'CARISTE CHA1BRE FROIDE NEGATIVE', '', '', 'CDI', 1, '999999999'),
(139, '6300716', 1, 'VIOU', 'ERIC', '2 RES PLEIN SOLEIL', '', '49400', 'CHACE', '', '', '', '16/11/1958', '01/11/2001', '', 'OUV', 'ELECTRO1ECANICIEN 2?1E NIVEAU', '', '', 'CDI', 1, '999999999'),
(140, '6379717', 1, 'WAHO', 'TONY', '30B RUE MARCEAU', '', '49400', 'SAU1UR', '', '', '', '31/07/1966', '01/05/1992', '', 'OUV', 'CARISTE NETTOYAGE NUIT', '', '', 'CDI', 1, '999999999'),
(141, '6377170', 2, 'WANDERSTEIN', 'PATRICIA', ' LD LES SABLONS NORD', '', '49400', 'ST LA1BERT DES LEVEES', '', '', '', '27/11/1957', '01/08/1977', '', 'OUV', 'OPERATEUR FAB 1ER EC', '', '', 'CDI', 1, '999999999'),
(142, '6377030', 2, 'WANGON', 'CHRISTELLE', '3 RUE DES VERNES', '', '49400', 'CHACE', '', '', '', '20/08/1967', '01/10/1988', '', 'OUV', 'PREPARATRICE EPICES', '', '', 'CDI', 1, '999999999'),
(143, '6379718', 1, 'WANGON', 'PATRICK', '3 RUE DES VERNES', '', '49400', 'CHACE', '', '', '', '11/05/1964', '01/06/1987', '', 'CAD', 'RESPONSABLE TECHNIQUE USINE', '', '', 'CDI', 1, '999999999'),
(144, '6379724', 2, 'WENZLER', 'MICHELE', '35 RUE ROBERT D ARBRISSEL', '', '49590', 'FONTEVRAUD', '', '', '', '29/06/1961', '01/12/1978', '', 'OUV', 'CONDUCTEUR DE 1ACHINE', '', '', 'CDI', 1, '999999999'),
(145, '6379762', 1, 'XIONG', 'SAO', '36 RUE JULES DUPERRAY', '', '49400', 'BAGNEUX', '', '', '', '21/07/1957', '01/06/1982', '', 'OUV', 'PREPARATEUR', '', '', 'CDI', 1, '999999999'),
(146, '6379788', 2, 'YVON', 'MARIE LINE', '26 RUE LOUIS CHOUTEAU', '', '49400', 'CHACE', '', '', '', '04/03/1961', '01/05/1978', '', 'A1T', 'CHARGEE D''ORDONNANCE1ENT', '', '', 'CDI', 1, '999999999');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE IF NOT EXISTS `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(6, '1430172000', '121876337', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par .', '', '11.6', 0),
(7, '1430172000', '0001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de FERRAULT.', '', '17.4', 0),
(8, '1430172000', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de JOURDAINE.', '', '23.2', 1),
(9, '1430172000', '003', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BARZIC.', '', '23.2', 1),
(10, '1430172000', '004', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de VIOU.', '', '23.2', 1),
(11, '1430172000', '005', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NAUDIN.', '', '23.2', 1),
(12, '1430172000', '006', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de CALMET.', '', '23.2', 1),
(13, '1430172000', '007', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de HAMELIN.', '', '17.4', 0),
(14, '1430172000', '5010908', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 5010908 en date du 28-04-2015.', '150.8', '', 1),
(15, '1430172000', '001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MONJAL.', '', '23.2', 1),
(16, '1430172000', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de YVON.', '', '23.2', 1),
(17, '1430172000', '003', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de TIJOU.', '', '23.2', 1),
(18, '1430172000', '004', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LIPHART.', '', '23.2', 1),
(19, '1430172000', '604948060', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par HERSARD.', '', '23.2', 1),
(20, '1430172000', '694883366', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CESBRON.', '', '11.6', 0),
(21, '1430172000', '283752599', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par METAIS.', '', '5.8', 0),
(22, '1430172000', '168468722', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ALIX.', '', '17.4', 0),
(23, '1430172000', '616667463', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par NUTTA.', '', '11.6', 0),
(24, '1430172000', '729356196', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par ALIX.', '', '11.6', 0),
(25, '1430172000', '464513148', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par TESSIER.', '', '11.6', 0),
(26, '1430172000', '5010910', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 5010910 en date du 28-04-2015.', '92.8', '', 1),
(27, '1430172000', '001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de audouin.', '', '44', 0),
(28, '1430172000', '5010904', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 5010904 en date du 28-04-2015.', '44', '', 1),
(29, '1430172000', '001', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de etavard.', '', '33', 0),
(30, '1430172000', '002', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DACOSTA.', '', '49.5', 0),
(31, '1430172000', '5010905', 'Remise Bancaire', 'Remise de ChÃ¨que', 'Remise en banque NÂ° 5010905 en date du 28-04-2015.', '82.5', '', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  ADD PRIMARY KEY (`idcomptapret`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=303;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=227;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  MODIFY `idcomptapret` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=147;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
