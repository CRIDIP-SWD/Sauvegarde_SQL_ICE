-- phpMyAdmin SQL Dump
-- version 4.4.9
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Lun 13 Juillet 2015 à 11:06
-- Version du serveur :  5.5.41-0ubuntu0.14.04.1
-- Version de PHP :  5.5.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cecaib`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE IF NOT EXISTS `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `achat_presta`
--

INSERT INTO `achat_presta` (`idachatpresta`, `date_achat`, `idprestation`, `qte`, `total_achat`) VALUES
(3, '30-06-2015', 2, '16', '315.2'),
(4, '30-06-2015', 1, '40', '272');

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE IF NOT EXISTS `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(12, 1, 'Achat: PISCINE PASS 5 ENTREES', '315.2', '', ''),
(13, 1, 'Achat: CINEMA CINEMOVIDA', '272', '', ''),
(14, 2, 'Vente de Billetterie: BRIATTE Paola pour la prestation PISCINE PASS 5 ENTREES', '', '15', '30535137'),
(15, 2, 'Vente de Billetterie: GERMAIN Jacques pour la prestation PISCINE PASS 5 ENTREES', '', '15', '44742020'),
(16, 2, 'Vente de Billetterie: RIMBAULT Céline pour la prestation PISCINE PASS 5 ENTREES', '', '15', '35943502'),
(17, 2, 'Vente de Billetterie: BERSON Meddy pour la prestation PATINOIRE PASS 5 ENTREES SANS PATINS', '', '24', '14597509'),
(18, 2, 'Vente de Billetterie: GODINEAU Pierre pour la prestation CINEMA CINEMOVIDA', '', '20', '36704772'),
(19, 2, 'Vente de Billetterie: PIOU Stéphanie pour la prestation CINEMA CINEMOVIDA', '', '20', '92761460'),
(20, 2, 'Vente de Billetterie: GERMAIN Jacques pour la prestation CINEMA CINEMOVIDA', '', '20', '40148648'),
(21, 2, 'Vente de Billetterie: RODOLPHE Angélique pour la prestation CINEMA CINEMOVIDA', '', '20', '54316775'),
(22, 2, 'Vente de Billetterie: DEFOIS Christian pour la prestation CINEMA CINEMOVIDA', '', '20', '76330150'),
(24, 2, 'Vente de Billetterie: BROSSET Bertrand pour la prestation grand parc du puy du fou  tarif adulte', '', '153.6', '69619821'),
(26, 2, 'Vente de Billetterie: BROSSET Bertrand pour la prestation grand parc du puy du fou  tarif adulte', '', '153.6', '29965660');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE IF NOT EXISTS `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`, `num_mouvement`) VALUES
(7, 67, '30-06-2015', 3, '15', 1, '30535137'),
(8, 183, '30-06-2015', 3, '15', 1, '44742020'),
(9, 360, '30-06-2015', 3, '15', 1, '35943502'),
(10, 33, '30-06-2015', 3, '24', 0, '14597509'),
(11, 191, '23-06-2015', 3, '20', 0, '36704772'),
(12, 332, '30-06-2015', 3, '20', 1, '92761460'),
(13, 183, '23-06-2015', 3, '20', 1, '40148648'),
(14, 364, '30-06-2015', 3, '20', 1, '54316775'),
(15, 126, '30-06-2015', 3, '20', 1, '76330150'),
(16, 74, '30-06-2015', 3, '0', 1, '78712781'),
(17, 74, '30-06-2015', 3, '0', 1, '122838');

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE IF NOT EXISTS `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE IF NOT EXISTS `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '', ''),
(81, 2, '', ''),
(82, 3, '', ''),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '', ''),
(87, 8, '', ''),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '', ''),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', ''),
(113, 34, '', ''),
(114, 35, '', ''),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '', ''),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '', ''),
(134, 55, '', ''),
(135, 56, '', ''),
(136, 57, '', ''),
(137, 58, '', ''),
(138, 59, '', ''),
(139, 60, '', ''),
(140, 61, '', ''),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE IF NOT EXISTS `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE IF NOT EXISTS `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE IF NOT EXISTS `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE IF NOT EXISTS `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE IF NOT EXISTS `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE IF NOT EXISTS `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', 'DOCUMENTATION'),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', 'CrÃ©ances Client'),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', ''),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', ''),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Postaux'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'Frais d''administration'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achat de matÃ©riel '),
(61, 6, 'Autre Charge d''exploitation 1', ''),
(62, 6, 'Autre Charge d''exploitation 2', ''),
(63, 6, 'Autre Charge d''exploitation 3', ''),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE IF NOT EXISTS `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE IF NOT EXISTS `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'COMITE D''ENTREPRISE CAIB', '0', '0', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE IF NOT EXISTS `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(12, '', '1435615200', 'Achat - PISCINE PASS 5 ENTREES', '315.2', ''),
(13, '', '1435615200', 'Achat - CINEMA CINEMOVIDA', '272', ''),
(14, '30535137', '1435615200', 'Vente de Billetterie: BRIATTE Paola pour la prestation PISCINE PASS 5 ENTREES', '', '15'),
(15, '44742020', '1435615200', 'Vente de Billetterie: GERMAIN Jacques pour la prestation PISCINE PASS 5 ENTREES', '', '15'),
(16, '35943502', '1435615200', 'Vente de Billetterie: RIMBAULT Céline pour la prestation PISCINE PASS 5 ENTREES', '', '15'),
(17, '14597509', '1435615200', 'Vente de Billetterie: BERSON Meddy pour la prestation PATINOIRE PASS 5 ENTREES SANS PATINS', '', '24'),
(18, '36704772', '1435010400', 'Vente de Billetterie: GODINEAU Pierre pour la prestation CINEMA CINEMOVIDA', '', '20'),
(19, '92761460', '1435615200', 'Vente de Billetterie: PIOU Stéphanie pour la prestation CINEMA CINEMOVIDA', '', '20'),
(20, '40148648', '1435010400', 'Vente de Billetterie: GERMAIN Jacques pour la prestation CINEMA CINEMOVIDA', '', '20'),
(21, '54316775', '1435615200', 'Vente de Billetterie: RODOLPHE Angélique pour la prestation CINEMA CINEMOVIDA', '', '20'),
(22, '76330150', '1435615200', 'Vente de Billetterie: DEFOIS Christian pour la prestation CINEMA CINEMOVIDA', '', '20'),
(24, '69619821', '1435615200', 'Vente de Billetterie: BROSSET Bertrand pour la prestation grand parc du puy du fou  tarif adulte', '', '153.6'),
(26, '29965660', '1435615200', 'Vente de Billetterie: BROSSET Bertrand pour la prestation grand parc du puy du fou  tarif adulte', '', '153.6');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE IF NOT EXISTS `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(1, 'ACTIVITES FAMILIALES'),
(2, 'LOCATIONS MOBILHOME'),
(3, 'CADEAUX ET BONS D''ACHATS'),
(4, 'CONCERTS ET SPECTACLES'),
(5, 'Festival de Poupet ');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`) VALUES
(6, 7, 2, '1', '15', '4.7', 0),
(7, 8, 2, '1', '15', '4.7', 0),
(8, 9, 2, '1', '15', '4.7', 0),
(9, 10, 3, '2', '24', '9.4', 0),
(10, 11, 1, '4', '20', '7.2', 0),
(11, 12, 1, '4', '20', '7.2', 0),
(12, 13, 1, '4', '20', '7.2', 0),
(13, 14, 1, '4', '20', '7.2', 0),
(14, 15, 1, '4', '20', '7.2', 0);

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE IF NOT EXISTS `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE IF NOT EXISTS `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.6.1', '15315-PREM');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE IF NOT EXISTS `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'Administrateur', '25f9e794323b453885f5181f1b624d0b', 1),
(6, 'CAIB49', 'b750f74544cb00c138079607276995e9', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '0'),
(3, 'vente_direct', '0');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE IF NOT EXISTS `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`) VALUES
(1, 1, 'CINEMA CINEMOVIDA', '01-01-2015', '31-12-2015', '5', '1.80', '6.8', '4', '36', 0),
(2, 1, 'PISCINE PASS 5 ENTREES', '01-06-2015', '31-12-2015', '15', '4.70', '19.7', '100', '14', 0),
(3, 1, 'PATINOIRE PASS 5 ENTREES SANS PATINS', '01-06-2015', '31-12-2015', '12', '4.70', '16.7', '100', '1', 0),
(4, 1, 'PATINOIRE PASS 5 ENTREES AVEC PATINS', '03-06-2015', '31-12-2015', '25', '5.5', '30.5', '100', '4', 0),
(5, 3, 'COLIS DE NOEL', '01-01-2015', '31-12-2015', '0', '28', '28', '1', '450', 0),
(10, 1, 'KIDI MUNDI enfants de 1 &agrave; 3 ans ', '30-06-2015', '30-06-2015', '5.50', '1â‚¬', '6.5', '100', '1', 0),
(11, 1, 'KIDI MUNDI enfants de 4 &agrave; 12ans ', '30-06-2015', '30-06-2015', '6.50', '2â‚¬', '8.5', '100', '10', 0),
(13, 4, 'grand parc du puy du fou  tarif adulte', '11-06-2015', '27-09-2015', '25.60', '2â‚¬', '27.6', '100', '100', 0),
(14, 4, 'grand parc du puy du fou  tarif enfant', '11-04-2015', '27-09-2015', '16.40', '2â‚¬', '18.4', '100', '98', 0),
(15, 4, 'cinesc&eacute;nie du puy du fou tarif adulte ', '03-07-2015', '12-09-2015', '22.70', '2â‚¬', '24.7', '100', '100', 0),
(16, 4, 'cinesc&eacute;nie du puy du fou tarif enfant', '03-07-2015', '12-09-2015', '15.10', '2â‚¬', '17.1', '100', '100', 0),
(17, 4, 'int&eacute;grale cinesc&eacute;nie du puy du fou tarif adulte  + Grand parc  tarif adulte ', '03-07-2015', '12-09-2015', '42.65', '2â‚¬', '44.65', '100', '100', 0),
(18, 4, 'int&eacute;grale cinesc&eacute;nie du puy du fou tarif adulte  + Grand parc  tarif enfant', '03-07-2015', '12-09-2015', '25.55', '2â‚¬', '27.55', '100', '100', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE IF NOT EXISTS `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(5, 7, 1, '15', 'credit mutuel', 'briatte paola ', '8917946', 0),
(7, 8, 1, '15', 'credit agricole', 'germain jacques', '0625463', 0),
(8, 9, 1, '15', 'banque populaire atlantique ', 'rimbault david', '0000130', 0),
(9, 12, 1, '20', 'credit agricole', 'piou stephane ', '6252535', 0),
(10, 13, 1, '20', 'credit agricole', 'germain jacques', '0625465', 0),
(11, 14, 1, '20', 'credit agricole', 'rodolphe angelique', '7131748', 0),
(12, 15, 1, '20', 'credit agricole', 'defois christian', '4000159', 0);

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE IF NOT EXISTS `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE IF NOT EXISTS `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE IF NOT EXISTS `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE IF NOT EXISTS `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE IF NOT EXISTS `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE IF NOT EXISTS `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=416 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(2, '', 0, 'ABBA', 'Sohaib', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(3, '', 0, 'ADAM', 'Florian', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(4, '', 0, 'AHMED OSMAN', 'Abderraouf', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(5, '', 0, 'ALLARD', 'Marie-France', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(6, '', 0, 'ANDRE', 'Marie-Rose', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(7, '', 0, 'ANGEVIN', 'Pascal', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(8, '', 0, 'AUBINEAU', 'Daniel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(9, '', 0, 'AUDIGANE', 'Frédéric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(10, '', 0, 'AUGEREAU', 'Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(11, '', 0, 'AUGEREAU', 'Rachel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(12, '', 0, 'AUNAI', 'Christian', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(13, '', 0, 'AUVINET', 'Antoine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(14, '', 0, 'BABONNEAU', 'Jean-François', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(15, '', 0, 'BABY', 'Patrick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(16, '', 0, 'BACONNAIS', 'Tanguy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(17, '', 0, 'BAFFET', 'Nicolas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(18, '', 0, 'BALUTAUD', 'Romain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(19, '', 0, 'BARANGER', 'Franck', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(20, '', 0, 'BARBOT', 'Joseph', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(21, '', 0, 'BARBOT', 'Magali', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(22, '', 0, 'BARON', 'Jacques', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(23, '', 0, 'BARREAU', 'Julien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(24, '', 0, 'BAUDON', 'Franck', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(25, '', 0, 'BAUDOUIN', 'Michel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(26, '', 0, 'BAZIN', 'Thomas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(27, '', 0, 'BECHU', 'Nadine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(28, '', 0, 'BECOT', 'Emmanuel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(29, '', 0, 'BELIARD', 'Jean-Marie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(30, '', 0, 'BELLANGER', 'Sophie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(31, '', 0, 'BERNARD', 'Luc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(32, '', 0, 'BERNIER', 'Alain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(33, '', 0, 'BERSON', 'Meddy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(34, '', 0, 'BIBOLLET', 'Aurélie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(35, '', 0, 'BICHON', 'Nathalie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(36, '', 0, 'BIDET', 'Godefroy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(37, '', 0, 'BIGOT', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(38, '', 0, 'BILBOT', 'Laurent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(39, '', 0, 'BIRAUD', 'Hélène', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(40, '', 0, 'BITEAU', 'Yannick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(41, '', 0, 'BIZON', 'Jérémy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(42, '', 0, 'BIZON', 'Loïc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(43, '', 0, 'BLANCHARD', 'François', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(44, '', 0, 'BLOUIN', 'Jean-Michel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(45, '', 0, 'BLOUIN', 'Jean-Paul', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(46, '', 0, 'BLOUIN', 'Régis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(47, '', 0, 'BODY', 'Patricia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(48, '', 0, 'BOISSEAU', 'Romain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(49, '', 0, 'BOLTEAU CHEVET', 'Catherine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(50, '', 0, 'BONDU', 'Jean-Claude', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(51, '', 0, 'BONDY', 'Patrice', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(52, '', 0, 'BORDET', 'Sébastien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(53, '', 0, 'BORGMANN', 'Cédric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(54, '', 0, 'BOSSARD', 'Claudie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(55, '', 0, 'BOSSARD', 'Jean-Louis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(56, '', 0, 'BOSSEAU', 'Christel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(57, '', 0, 'BOUCHET', 'Lucie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(58, '', 0, 'BOUDEAU', 'Thierry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(59, '', 0, 'BOULAY', 'Vincent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(60, '', 0, 'BOURCIER', 'Jacquelin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(61, '', 0, 'BOURCIER', 'Nelly', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(62, '', 0, 'BOUTET', 'Christelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(63, '', 0, 'BOUTET', 'Philippe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(64, '', 0, 'BRAM DIT SAINT AMAND', 'Pierre Olivier', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(65, '', 0, 'BRANGEON', 'Bastien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(66, '', 0, 'BRETON', 'Karine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(67, '', 0, 'BRIATTE', 'Paola', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(68, '', 0, 'BRIAUD', 'Olivier', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(69, '', 0, 'BRIERE', 'Matthieu', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(70, '', 0, 'BROCHARD', 'Anthony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(71, '', 0, 'BROCHARD', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(72, '', 0, 'BRONDY', 'Romain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(73, '', 0, 'BROSSARD', 'Nathalie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(74, '', 0, 'BROSSET', 'Bertrand', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(75, '', 0, 'BROSSET', 'Claudine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(76, '', 0, 'BROUSSEAU', 'Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(77, '', 0, 'BUFFARD', 'Laurent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(78, '', 0, 'BURON', 'Mickaël', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(79, '', 0, 'CABALLERO', 'WILLIAM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(80, '', 0, 'CAILLEAU', 'Ingrid', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(81, '', 0, 'CAILLET', 'Caroline', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(82, '', 0, 'CALATAYUD', 'Audrey', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(83, '', 0, 'CANTEAU', 'Yann', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(84, '', 0, 'CAOUREN', 'Sébastien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(85, '', 0, 'CASSIN', 'Catherine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(86, '', 0, 'CASTELLA', 'Manuel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(87, '', 0, 'CESBRON', 'Corinne', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(88, '', 0, 'CHALAYE', 'Eric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(89, '', 0, 'CHALON', 'Julien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(90, '', 0, 'CHAMPAIN', 'Anabelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(91, '', 0, 'CHARPENTIER', 'Thierry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(92, '', 0, 'CHARRIAT', 'Antoine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(93, '', 0, 'CHARUAUD', 'Catherine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(94, '', 0, 'CHASSELOUP', 'Marie-Renée', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(95, '', 0, 'CHASSERIAU', 'Stessy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(96, '', 0, 'CHAUVEAUX', 'Tony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(97, '', 0, 'CHAUVIN', 'Jean-Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(98, '', 0, 'CHERBONNIER', 'Samuel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(99, '', 0, 'CHEVALIER', 'François', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(100, '', 0, 'CHIKHOUNE', 'Jean-Pierre', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(101, '', 0, 'CHIRON', 'Christine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(102, '', 0, 'CHOISNET', 'Edith', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(103, '', 0, 'CHOMEZ', 'Jean-Pierre', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(104, '', 0, 'CHOUPIN', 'Antoine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(105, '', 0, 'CHUPIN', 'Alain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(106, '', 0, 'CHUPIN', 'Séverine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(107, '', 0, 'CHUPIN', 'Sophie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(108, '', 0, 'CLAIR', 'Marie Christine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(109, '', 0, 'CLAVIER', 'Pascal', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(110, '', 0, 'COINDET', 'Kristell', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(111, '', 0, 'COUFLEAU', 'Thomas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(112, '', 0, 'COURANT', 'Dolorès', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(113, '', 0, 'COUSIN', 'Valérie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(114, '', 0, 'COUTANT', 'Rémi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(115, '', 0, 'COUTAUD', 'Isabelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(116, '', 0, 'COYAC', 'Alain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(117, '', 0, 'CRIBIER', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(118, '', 0, 'DABIN', 'Luc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(119, '', 0, 'Daniel', 'Véronique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(120, '', 0, 'DAVIET', 'Yohan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(121, '', 0, 'DE FREITAS NUNES', 'Bruno', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(122, '', 0, 'DE HARO', 'Frank', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(123, '', 0, 'DE OLIVEIRA', 'Monica', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(124, '', 0, 'DEBIEN', 'Mickaël', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(125, '', 0, 'DEBORDE', 'Benoît', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(126, '', 0, 'DEFOIS', 'Christian', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(127, '', 0, 'DEFONTAINE', 'Alain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(128, '', 0, 'DELACOUR', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(129, '', 0, 'DELAUNAY', 'Laurent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(130, '', 0, 'DELFORGE', 'Gérald', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(131, '', 0, 'DENAT', 'Isabelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(132, '', 0, 'DESCHAMPS', 'Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(133, '', 0, 'DESCHAMPS', 'Yoann', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(134, '', 0, 'DESHAIES', 'Nathalie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(135, '', 0, 'DIAS', 'Yohann', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(136, '', 0, 'DIOUBATE', 'Amadou', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(137, '', 0, 'DJAMA', 'Thomas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(138, '', 0, 'DOKTAS', 'Camledi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(139, '', 0, 'DOKTAS', 'Halil', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(140, '', 0, 'DOUANGPANGNA', 'Alexis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(141, '', 0, 'DOUCET', 'Daniel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(142, '', 0, 'DROUET', 'Dominique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(143, '', 0, 'DROUET', 'Laurent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(144, '', 0, 'DROUET', 'Sylvie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(145, '', 0, 'DUBILLOT', 'Estelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(146, '', 0, 'DUHAMEL', 'François', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(147, '', 0, 'DUPE', 'Sophie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(148, '', 0, 'DURAND', 'Julien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(149, '', 0, 'DURAND', 'Marjorie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(150, '', 0, 'EL HOUTI', 'Ahmed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(151, '', 0, 'EN NOUJOUMI', 'Omar', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(152, '', 0, 'ENFREIN', 'Thierry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(153, '', 0, 'ERCEAU', 'Pauline', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(154, '', 0, 'FAUCHET', 'Monique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(155, '', 0, 'FER', 'Philippe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(156, '', 0, 'FERRERE', 'Vincent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(157, '', 0, 'FIEVET', 'Antoine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(158, '', 0, 'FIEVRE', 'Myriam', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(159, '', 0, 'FIEVRE', 'Yannick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(160, '', 0, 'FILLAUDEAU', 'Joël', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(161, '', 0, 'FONTENEAU', 'Catherine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(162, '', 0, 'FONTENEAU', 'Fabrice', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(163, '', 0, 'FONTENEAU', 'Hélène', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(164, '', 0, 'FONTENEAU', 'Sylvain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(165, '', 0, 'FOUCAUD', 'Dominique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(166, '', 0, 'FOURRIER', 'Jean-Paul', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(167, '', 0, 'FROUIN', 'Amélie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(168, '', 0, 'FUSEAU', 'Sarah', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(169, '', 0, 'GABORIAU', 'Corentin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(170, '', 0, 'GABORIAU', 'Jean-Louis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(171, '', 0, 'GABORIT', 'Sébastien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(172, '', 0, 'GALLARD', 'Jean-Louis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(173, '', 0, 'GALLOT', 'Pascal', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(174, '', 0, 'GASCOIN', 'Séverine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(175, '', 0, 'GAUDU', 'Nicolas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(176, '', 0, 'GAUTHIER', 'Nadine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(177, '', 0, 'GAUTIER', 'Anthony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(178, '', 0, 'GAUTIER', 'Benoît', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(179, '', 0, 'GAUTIER', 'Elisabeth', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(180, '', 0, 'GAUTIER', 'Gabriel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(181, '', 0, 'GAUTIER', 'Pauline', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(182, '', 0, 'GAY', 'Vincent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(183, '', 0, 'GERMAIN', 'Jacques', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(184, '', 0, 'GIRARD', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(185, '', 0, 'GIRARDEAU', 'Dominique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(186, '', 0, 'GIRARDEAU', 'Paula', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(187, '', 0, 'GIRAUD', 'Marcel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(188, '', 0, 'GODET', 'Sébastien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(189, '', 0, 'GODEY', 'Pascal', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(190, '', 0, 'GODINEAU', 'Alexandre', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(191, '', 0, 'GODINEAU', 'Pierre', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(192, '', 0, 'GODINEAU', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(193, '', 0, 'GOICHON', 'Thierry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(194, '', 0, 'GOMBERT', 'Emeline', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(195, '', 0, 'GORGET', 'Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(196, '', 0, 'GOURDON', 'Cyndie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(197, '', 0, 'GOURMAUD', 'Françoise', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(198, '', 0, 'GOUSSEAU', 'David', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(199, '', 0, 'GRAVELEAU', 'Armelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(200, '', 0, 'GRELET', 'Arnaud', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(201, '', 0, 'GRETEAU', 'Manuella', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(202, '', 0, 'GRIFFON', 'Jonathan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(203, '', 0, 'GRIVES', 'Florian', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(204, '', 0, 'GROLLEAU', 'Benoist', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(205, '', 0, 'GROLLEAU', 'Yannick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(206, '', 0, 'GUEDON', 'Hélène', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(207, '', 0, 'GUERIN', 'Alain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(208, '', 0, 'GUERIN', 'Jérome', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(209, '', 0, 'GUICHETEAU', 'Marie-Christine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(210, '', 0, 'GUIET', 'Jean-Pierre', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(211, '', 0, 'GUILLARD', 'Marina', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(212, '', 0, 'GUILLEMAIN', 'Frédéric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(213, '', 0, 'GUILLET', 'Didier', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(214, '', 0, 'GUILLOT', 'Olivier', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(215, '', 0, 'GUIMBRETIERE', 'Hervé', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(216, '', 0, 'GUINE', 'Sullivan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(217, '', 0, 'GUYOT', 'Steve', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(218, '', 0, 'HAVAS', 'Sandy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(219, '', 0, 'HERVOCHON', 'Franck', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(220, '', 0, 'HOEPPE', 'François', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(221, '', 0, 'HOGDAY', 'Jannick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(222, '', 0, 'HORTALA', 'Nathalie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(223, '', 0, 'HOUEIX', 'Philippe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(224, '', 0, 'HOUMADI', 'Houtoibou', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(225, '', 0, 'HUET', 'Sébastien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(226, '', 0, 'HULLIN', 'Benoît', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(227, '', 0, 'HUMEAU', 'Philippe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(228, '', 0, 'HURTAUD', 'Claude', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(229, '', 0, 'HUVELIN', 'Dominique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(230, '', 0, 'IBRAHIM', 'Ayouba', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(231, '', 0, 'ISSHAK OUSSMAN', 'Ahmed', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(232, '', 0, 'JACQUET', 'Yannick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(233, '', 0, 'JAME', 'Emily', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(234, '', 0, 'JAMONNEAU', 'Martine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(235, '', 0, 'JAOUEN', 'Christian', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(236, '', 0, 'JARDIN', 'Didier', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(237, '', 0, 'JAUNASSE', 'David', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(238, '', 0, 'JEANNEAU', 'Sabrina', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(239, '', 0, 'JEANNIERE', 'Alain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(240, '', 0, 'JEZEGOU', 'GAUTIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(241, '', 0, 'JOBARD', 'Gilles', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(242, '', 0, 'JOBARD', 'Jean-Luc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(243, '', 0, 'JOLY', 'Damien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(244, '', 0, 'JOREL', 'Benjamin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(245, '', 0, 'JOTTREAU', 'Damien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(246, '', 0, 'JOUTEAU', 'Philippe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(247, '', 0, 'JUBIN', 'Nicolas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(248, '', 0, 'JUTON', 'Eric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(249, '', 0, 'KENSI', 'Jean Baptiste', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(250, '', 0, 'KHAMMANY', 'Cathy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(251, '', 0, 'KHONGTHONG', 'Lay', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(252, '', 0, 'KHUN', 'Chanpisith', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(253, '', 0, 'KONDOMBO', 'Malik', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(254, '', 0, 'KUPPEROTH', 'Mickaël', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(255, '', 0, 'LACAZE', 'Benjamin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(256, '', 0, 'LANDAIS', 'Frédérick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(257, '', 0, 'LANDREAU', 'Frédéric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(258, '', 0, 'LANDREAU', 'Jérôme', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(259, '', 0, 'LATERZA', 'Willy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(260, '', 0, 'LE CREFF', 'Nathalie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(261, '', 0, 'LE ROCH', 'Marie-Hélène', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(262, '', 0, 'LEBLOND', 'Mickaël', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(263, '', 0, 'LECOMTE', 'Frédéric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(264, '', 0, 'LEDROIT', 'André', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(265, '', 0, 'LEFORT', 'Sophie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(266, '', 0, 'LEFRICHE', 'Nadège', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(267, '', 0, 'LELAURE', 'Béatrice', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(268, '', 0, 'LEMAIRE', 'Marc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(269, '', 0, 'LEMOINE', 'Nicolas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(270, '', 0, 'LETERTRE', 'Julien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(271, '', 0, 'LEVRON', 'Cathy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(272, '', 0, 'LISKA', 'Dominique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(273, '', 0, 'LIZICSKA', 'Jérémie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(274, '', 0, 'LOIZEAU', 'Annie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(275, '', 0, 'LOUISSAINT', 'Réginald', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(276, '', 0, 'MAFOULOU', 'ARMAND MESMIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(277, '', 0, 'MALEINGE', 'Ludovic', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(278, '', 0, 'MALEINGE', 'Mathias', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(279, '', 0, 'MALY', 'Vieng Say', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(280, '', 0, 'MANCEAU', 'Jonathan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(281, '', 0, 'MANCEAU', 'Nathalie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(282, '', 0, 'MARCHAND', 'Isabelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(283, '', 0, 'MARTIN', 'Blandine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(284, '', 0, 'MARTINS', 'Maria', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(285, '', 0, 'MATHE', 'Charlène', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(286, '', 0, 'MATIGNON', 'Clément', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(287, '', 0, 'MATRINGHEN', 'CAROLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(288, '', 0, 'MAURILLE', 'Laurent', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(289, '', 0, 'MELEUC', 'Françoise', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(290, '', 0, 'MELLIET', 'Eric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(291, '', 0, 'MENARD', 'Didier', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(292, '', 0, 'MENGUY', 'Ronan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(293, '', 0, 'MENOIR', 'Omar', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(294, '', 0, 'MESSE', 'Jérôme', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(295, '', 0, 'MEUNIER', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(296, '', 0, 'MEUNIER', 'Caroline', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(297, '', 0, 'MEVEL', 'Yann', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(298, '', 0, 'MICHAUD', 'Françoise', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(299, '', 0, 'MONJEAUD', 'Dylan', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(300, '', 0, 'MORANDEAU', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(301, '', 0, 'MOREAU', 'Julien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(302, '', 0, 'MOREAU', 'Murielle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(303, '', 0, 'MOREAU', 'Patrick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(304, '', 0, 'MORILLE', 'Thierry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(305, '', 0, 'MORISSET', 'Stevie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(306, '', 0, 'MOUA', 'Seng', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(307, '', 0, 'MOUHCENE', 'Abdelfattah', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(308, '', 0, 'MOUILLE', 'Jacques', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(309, '', 0, 'MOUMINE', 'Yacine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(310, '', 0, 'MOUNSAVENG', 'Virada', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(311, '', 0, 'MUSSET', 'Mickaël', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(312, '', 0, 'NAUD', 'Catherine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(313, '', 0, 'NAUDOT', 'Romuald', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(314, '', 0, 'NGUYEN', 'Van Hoa', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(315, '', 0, 'OGER', 'Adélia', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(316, '', 0, 'ONILLON', 'Richard', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(317, '', 0, 'ORCONNEAU', 'Catherine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(318, '', 0, 'OUVRARD', 'Ghislain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(319, '', 0, 'PALLARD', 'Alice', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(320, '', 0, 'PAPAPI', 'MARTIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(321, '', 0, 'PAPIN', 'Albert', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(322, '', 0, 'PAUCHET', 'Victorien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(323, '', 0, 'PELASCINI', 'Maxime', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(324, '', 0, 'PELLETIER', 'Nicolas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(325, '', 0, 'PERPINA', 'Thomas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(326, '', 0, 'PERROCHON', 'Marylène', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(327, '', 0, 'PICHON', 'Emmanuel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(328, '', 0, 'PIGEARD', 'Florian', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(329, '', 0, 'PINEAU', 'Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(330, '', 0, 'PINEAU', 'Eric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(331, '', 0, 'PINEAU', 'Luc', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(332, '', 0, 'PIOU', 'Stéphanie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(333, '', 0, 'PIVETEAU', 'Daniel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(334, '', 0, 'PIVETEAU', 'Régis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(335, '', 0, 'POINTU', 'Cédric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(336, '', 0, 'POIRIER', 'Mickaël', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(337, '', 0, 'POITIERS', 'Arnauld', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(338, '', 0, 'POTIER', 'Franck', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(339, '', 0, 'POTIER', 'Frédéric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(340, '', 0, 'POUPLIN', 'Tony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(341, '', 0, 'POUREAU', 'Alain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(342, '', 0, 'PRIOULT', 'David', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(343, '', 0, 'PUISSET', 'Arnaud', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(344, '', 0, 'RAGUENEAU', 'Cyril', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(345, '', 0, 'RAMPILLON', 'Stéphanie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(346, '', 0, 'RAVELEAU', 'Lucie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(347, '', 0, 'RETAILLEAU', 'Tania', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(348, '', 0, 'RETHORE', 'Bernadette', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(349, '', 0, 'RETHORE', 'Grégory', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(350, '', 0, 'RETIERE', 'Alexis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(351, '', 0, 'REVERT', 'Sandra', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(352, '', 0, 'REYNET', 'Ronald', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(353, '', 0, 'RIAULT', 'Gérald', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(354, '', 0, 'Richard', 'Josselin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(355, '', 0, 'Richard', 'Nicolas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(356, '', 0, 'RICHAUDEAU', 'Guylain', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(357, '', 0, 'RICHOU', 'Isabelle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(358, '', 0, 'RIETHMULLER', 'Franck', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(359, '', 0, 'RIMAN', 'Stéphane', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(360, '', 0, 'RIMBAULT', 'Céline', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(361, '', 0, 'RISKOFF', 'Patrick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(362, '', 0, 'RIVAL', 'Line', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(363, '', 0, 'ROBINEAU', 'Yohann', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(364, '', 0, 'RODOLPHE', 'Angélique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(365, '', 0, 'RONDE', 'Anouchka', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(366, '', 0, 'ROULET', 'Maryvonne', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(367, '', 0, 'ROUXEL', 'Pierrick', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(368, '', 0, 'RUIZ', 'Teddy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(369, '', 0, 'SALOUX', 'Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(370, '', 0, 'SECHET', 'Dominique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(371, '', 0, 'SEGUIN', 'Jérôme', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(372, '', 0, 'SESSEGNON', 'Dako Francis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(373, '', 0, 'SILVA', 'Andréa', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(374, '', 0, 'SOULARD', 'Anthony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(375, '', 0, 'SOULARD', 'Damien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(376, '', 0, 'SOULARD', 'Jean-Vianney', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(377, '', 0, 'SOULARD', 'Thierry', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(378, '', 0, 'SUN', 'Van', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(379, '', 0, 'SUPIOT', 'Colette', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(380, '', 0, 'SUPIOT', 'Freddy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(381, '', 0, 'SUPIOT', 'Maxime', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(382, '', 0, 'SUREAU', 'Sylvie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(383, '', 0, 'SUROT', 'Charles-Eric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(384, '', 0, 'TABUADA', 'Rémy', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(385, '', 0, 'TESSIER', 'Denis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(386, '', 0, 'TESTARD', 'Nolwenn', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(387, '', 0, 'THAO', 'Mayla', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(388, '', 0, 'Thierry', 'Jean-Pierre', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(389, '', 0, 'Thomas', 'Anthony', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(390, '', 0, 'Thomas', 'Julien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(391, '', 0, 'TIGNON', 'Marine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(392, '', 0, 'TIGNON', 'Pascal', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(393, '', 0, 'TIJOU', 'Lionel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(394, '', 0, 'TISON', 'Leslie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(395, '', 0, 'TOUBRENDE', 'Olivier', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(396, '', 0, 'TOUCHE', 'Antoine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(397, '', 0, 'TOUCHET', 'Claudie', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(398, '', 0, 'TRICHET', 'Alexandra', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(399, '', 0, 'TRICOT', 'David', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(400, '', 0, 'TRICOT', 'Fabien', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(401, '', 0, 'TURMEAU', 'Anne Joëlle', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(402, '', 0, 'UVENARD', 'Régis', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(403, '', 0, 'VALLET', 'Fabienne', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(404, '', 0, 'VANDENBROECKE', 'Christophe', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(405, '', 0, 'VANG', 'Seng Cha', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(406, '', 0, 'VANMARCKE', 'Nicolas', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(407, '', 0, 'VENDE', 'Catherine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(408, '', 0, 'VIAUD', 'Dominique', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(409, '', 0, 'VILLENEUVE', 'Mathieu', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(410, '', 0, 'Vincent', 'Manuel', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(411, '', 0, 'VIOLLEAU', 'Eric', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(412, '', 0, 'WIESNIEWSKA', 'Ghislaine', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(413, '', 0, 'YOK', 'Yanirath', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(414, '', 0, 'YOU', 'Benoit', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, ''),
(415, '', 0, 'ZARKI', 'Khalid', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE IF NOT EXISTS `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(5, '1435615200', '8917946', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de briatte paola .', '', '15', 0),
(7, '1435615200', '0625463', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de germain jacques.', '', '15', 0),
(8, '1435615200', '0000130', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de rimbault david.', '', '15', 0),
(9, '1435615200', '6252535', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de piou stephane .', '', '20', 0),
(10, '1435010400', '0625465', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de germain jacques.', '', '20', 0),
(11, '1435615200', '7131748', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de rodolphe angelique.', '', '20', 0),
(12, '1435615200', '4000159', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de defois christian.', '', '20', 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=416;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
