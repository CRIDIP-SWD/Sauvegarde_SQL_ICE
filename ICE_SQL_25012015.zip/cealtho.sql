-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Lun 25 Janvier 2016 à 09:31
-- Version du serveur :  5.5.46-0+deb7u1
-- Version de PHP :  5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cealtho`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `achat_presta`
--

INSERT INTO `achat_presta` (`idachatpresta`, `date_achat`, `idprestation`, `qte`, `total_achat`, `num_mouvement`) VALUES
(10, '11-01-2016', 1, '50', '310', '1522441190');

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(46, 2, 'Vente de Billetterie: LE DAMANY JULIEN pour la prestation CINEMA LE REX', '', '24', '857344214'),
(47, 1, 'Ajout de la charge Fixe: Fleurs (d&eacute;c&egrave;s de la maman de Mme Le Tadic)', '50', '', '4637148702'),
(48, 1, 'Ajout de la charge Fixe: OUEST FRANCE', '25.3', '', '5156068811'),
(49, 1, 'Ajout de la charge Fixe: T&eacute;l&eacute;gramme', '18.98', '', '2944841027'),
(50, 2, 'Ajout du produit fixe: solde du compte n&deg;53166608510', '', '56187.81', '1107068416'),
(51, 2, 'Vente de Billetterie: NICOLAS VINCENT pour la prestation CINEMA LE REX', '', '24', '264493447'),
(52, 1, 'Achat: CINEMA LE REX', '310', '', '1522441190'),
(54, 1, 'Ajout de la charge Fixe: Frais bancaires', '7.75', '', '8893213304'),
(55, 1, 'Ajout de la charge Fixe: Carte CE', '275.88', '', '8302040784'),
(56, 2, 'Ajout du produit fixe: cotisation ALTHO', '', '8309.97', '5256059086'),
(57, 1, 'Ajout de la charge Fixe: OUEST FRANCE journal', '25.30', '', '7645986774'),
(58, 2, 'Vente de Billetterie: RELO YANN pour la prestation CINEMA LE REX', '', '8', '22867920'),
(59, 2, 'Vente de Billetterie: DENIS CAROLE pour la prestation SPADIUM', '', '30', '382854884'),
(60, 2, 'Vente de Billetterie: LE TADIC SYLVIE pour la prestation CINEMA LE REX', '', '12', '53354565'),
(61, 2, 'Vente de Billetterie: ROSSIGNOL SONIA pour la prestation CINEMA LE REX', '', '40', '538969478'),
(62, 2, 'Vente de Billetterie: KOUROU MICHELLE pour la prestation HAPPY PARK', '', '60', '521556713'),
(63, 2, 'Vente de Billetterie: GUILLEMOT VINCENT pour la prestation CINEMA LE REX', '', '8', '255327354'),
(64, 2, 'Vente de Billetterie: LE DENMAT FRANCOIS pour la prestation BOWLING', '', '24', '474334037'),
(65, 2, 'Vente de Billetterie: DELAUNEY MELINDA pour la prestation CINEMA LE REX', '', '8', '83324079'),
(66, 2, 'Vente de Billetterie: JULE BENOIT pour la prestation CINEMA LE REX', '', '4', '812365170'),
(67, 1, 'Ajout de la charge Fixe: Tombola', '1098.89', '', '3380562561'),
(68, 1, 'Ajout de la charge Fixe: emap (tshirt)', '144', '', '5585740162'),
(69, 1, 'Ajout de la charge Fixe: repas Gueltas', '6818.01', '', '7629237808'),
(70, 1, 'Ajout de la charge Fixe: tombola (repas Guelta)', '1098.89', '', '7476335754'),
(71, 1, 'Ajout de la charge Fixe: cin&eacute;ma', '310', '', '3426043336'),
(72, 1, 'Ajout de la charge Fixe: cin&eacute;ma REX', '310', '', '1205128320'),
(73, 1, 'Ajout de la charge Fixe: frais bancaires', '7.75', '', '1175317145'),
(74, 1, 'Ajout de la charge Fixe: location de salle', '445', '', '47353963'),
(75, 1, 'Ajout de la charge Fixe: graph impress', '8.64', '', '3189410251');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `decremente` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `decremente` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`, `num_mouvement`, `decremente`) VALUES
(29, 103, '1452124800', 3, '24', 1, '857344214', 1),
(30, 173, '1452124800', 3, '24', 1, '264493447', 1),
(32, 192, '1453244400', 3, '8', 0, '22867920', 0),
(33, 38, '1453417200', 3, '30', 1, '382854884', 1),
(34, 145, '1453417200', 3, '12', 1, '53354565', 1),
(35, 197, '1452553200', 3, '40', 1, '538969478', 1),
(36, 85, '1453244400', 3, '60', 1, '521556713', 1),
(37, 63, '1453417200', 3, '8', 1, '255327354', 1),
(39, 104, '1453417200', 3, '24', 1, '474334037', 1),
(40, 37, '1453071600', 3, '8', 1, '83324079', 1),
(41, 80, '1452812400', 3, '4', 1, '812365170', 1);

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `charge_fixe`
--

INSERT INTO `charge_fixe` (`idchargefixe`, `designation`, `date_charge_fixe`, `montant_charge`, `num_mouvement`) VALUES
(8, 'Fleurs (d&eacute;c&egrave;s de la maman de Mme Le Tadic)', '05/01/2016', '50', '4637148702'),
(10, 'T&eacute;l&eacute;gramme', '06/01/2016', '18.98', '2944841027'),
(11, 'Frais bancaires', '08/01/2016', '7.75', '8893213304'),
(12, 'Carte CE', '12/01/2016', '275.88', '8302040784'),
(13, 'OUEST FRANCE journal', '08/01/2016', '25.30', '7645986774'),
(15, 'emap (tshirt)', '', '144', '5585740162'),
(16, 'repas Gueltas', '', '6818.01', '7629237808'),
(17, 'tombola (repas Guelta)', '', '1098.89', '7476335754'),
(19, 'cin&eacute;ma REX', '15/01/2016', '310', '1205128320'),
(20, 'frais bancaires', '02/01/2016', '7.75', '1175317145'),
(21, 'location de salle', '15/01/2016', '445', '47353963'),
(22, 'graph impress', '22/01/2016', '8.64', '3189410251');

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '132.5', ''),
(81, 2, '', ''),
(82, 3, '40500.52', '898.54'),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '700', '100'),
(87, 8, '10000', ''),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '39399.06', '52331.56'),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', '400'),
(113, 34, '', ''),
(114, 35, '', '38000.52'),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '100', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '', ''),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '', ''),
(134, 55, '835.32', ''),
(135, 56, '', ''),
(136, 57, '63.22', '0'),
(137, 58, '', ''),
(138, 59, '', ''),
(139, 60, '', ''),
(140, 61, '', ''),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_banque`
--

INSERT INTO `compta_banque` (`idcomptabanque`, `num_mouvement`, `date_bq`, `desc_bq`, `idcomptaplan`, `debit`, `credit`) VALUES
(36, '9319239', '1420066800', 'SUBVENTION ANNUEL', 3, '38000.52', ''),
(37, '8599421', '1421622000', 'SFR Facture 1', 3, '', '63.22'),
(38, '1398213', '1422745200', 'Abonnement CE-INFO.net', 3, '', '835.32');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_actif`
--

INSERT INTO `compta_bilan_actif` (`idcptbilanactif`, `num_mouvement`, `idcomptaplan`, `montant`) VALUES
(17, '5699458', 1, '132.50'),
(18, '6375530', 3, '2500'),
(19, '1777720', 7, '300'),
(20, '8605503', 8, '10000');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_passif`
--

INSERT INTO `compta_bilan_passif` (`idcptbilanpassif`, `num_mouvement`, `idcomptaplan`, `montant`) VALUES
(8, '6037205', 28, '12932.50');

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_compte`
--

INSERT INTO `compta_compte` (`idcomptacompte`, `num_mouvement`, `idcomptaplan`, `debit`, `credit`) VALUES
(96, '5699458', 1, '132.50', ''),
(97, '6375530', 3, '2500', ''),
(98, '1777720', 7, '300', ''),
(99, '8605503', 8, '10000', ''),
(100, '6037205', 28, '', '12932.50'),
(101, '7476901', 35, '', '38000.52'),
(102, '8607451', 57, '63.22', ''),
(103, '3582399', 55, '835.32', ''),
(104, '6198610', 33, '', '400'),
(105, '7797494', 44, '100', ''),
(107, '9319239', 3, '38000.52', ''),
(108, '8599421', 3, '', '63.22'),
(109, '1398213', 3, '', '835.32'),
(111, '1132375', 7, '400', ''),
(112, '9313238', 7, '', '100');

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_mvm`
--

INSERT INTO `compta_mvm` (`idcomptamvm`, `num_mouvement`, `date_mvm`, `desc_mvm`, `idcomptaplan`, `debit`, `credit`) VALUES
(33, '7476901', '1420066800', 'SUBVENTION ANNUEL', 35, '', '38000.52'),
(34, '8607451', '1421622000', 'SFR Facture 1', 57, '63.22', ''),
(35, '3582399', '1422745200', 'Abonnement CE INFO.net', 55, '835.32', ''),
(36, '6198610', '1425250800', 'Remboursement Pret 1', 33, '', '400'),
(37, '7797494', '1425337200', 'Emprunt Pret 1', 44, '100', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', ''),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', 'Compte de Pret'),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', 'Charges Divers'),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Taxes'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', ''),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achats de matÃ©riel et logiciels informatiques'),
(61, 6, 'Autre Charge d''exploitation 1', 'Divers'),
(62, 6, 'Autre Charge d''exploitation 2', 'FRAIS HOTELIERS'),
(63, 6, 'Autre Charge d''exploitation 3', 'FRAIS RESTAURATION'),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_pret`
--

CREATE TABLE `compta_pret` (
  `idcomptapret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_pret` varchar(255) NOT NULL,
  `desc_pret` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `compta_pret`
--

INSERT INTO `compta_pret` (`idcomptapret`, `num_mouvement`, `date_pret`, `desc_pret`, `idcomptaplan`, `debit`, `credit`) VALUES
(1, '1132375', '1425250800', 'Remboursement pret 1', 7, '400', ''),
(2, '9313238', '1425337200', 'Emprunt pret 1', 7, '', '100');

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_resultat`
--

INSERT INTO `compta_resultat` (`idresultat`, `num_mouvement`, `idcomptaplan`, `debit`, `credit`) VALUES
(34, '7476901', 35, '', '38000.52'),
(35, '8607451', 57, '63.22', ''),
(36, '3582399', 55, '835.32', ''),
(37, '6198610', 33, '', '400'),
(38, '7797494', 44, '100', '');

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'C.E ALTHO', '0', '0', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '31-12-2015', '31-12-2016');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(46, '857344214', '1452121200', 'Vente de Billetterie: LE DAMANY JULIEN pour la prestation CINEMA LE REX', '', '24'),
(47, '4637148702', '1462053600', 'Fleurs (d&eacute;c&egrave;s de la maman de Mme Le Tadic)', '50', ''),
(49, '2944841027', '1464732000', 'T&eacute;l&eacute;gramme', '18.98', ''),
(50, '1107068416', '1451602800', 'solde du compte n&deg;53166608510', '', '56187.81'),
(51, '264493447', '1452121200', 'Vente de Billetterie: NICOLAS VINCENT pour la prestation CINEMA LE REX', '', '24'),
(52, '1522441190', '1452466800', 'Achat - CINEMA LE REX', '310', ''),
(54, '8893213304', '1470002400', 'Frais bancaires', '7.75', ''),
(55, '8302040784', '1480546800', 'Carte CE', '275.88', ''),
(56, '5256059086', '1451602800', 'cotisation ALTHO', '', '8309.97'),
(57, '7645986774', '1470002400', 'OUEST FRANCE journal', '25.30', ''),
(58, '22867920', '1453244400', 'Vente de Billetterie: RELO YANN pour la prestation CINEMA LE REX', '', '8'),
(59, '382854884', '1453417200', 'Vente de Billetterie: DENIS CAROLE pour la prestation SPADIUM', '', '30'),
(60, '53354565', '1453417200', 'Vente de Billetterie: LE TADIC SYLVIE pour la prestation CINEMA LE REX', '', '12'),
(61, '538969478', '1452553200', 'Vente de Billetterie: ROSSIGNOL SONIA pour la prestation CINEMA LE REX', '', '40'),
(62, '521556713', '1453244400', 'Vente de Billetterie: KOUROU MICHELLE pour la prestation HAPPY PARK', '', '60'),
(63, '255327354', '1453417200', 'Vente de Billetterie: GUILLEMOT VINCENT pour la prestation CINEMA LE REX', '', '8'),
(64, '474334037', '1453417200', 'Vente de Billetterie: LE DENMAT FRANCOIS pour la prestation BOWLING', '', '24'),
(65, '83324079', '1453071600', 'Vente de Billetterie: DELAUNEY MELINDA pour la prestation CINEMA LE REX', '', '8'),
(66, '812365170', '1452812400', 'Vente de Billetterie: JULE BENOIT pour la prestation CINEMA LE REX', '', '4'),
(68, '5585740162', '', 'emap (tshirt)', '144', ''),
(69, '7629237808', '', 'repas Gueltas', '6818.01', ''),
(70, '7476335754', '', 'tombola (repas Guelta)', '1098.89', ''),
(72, '1205128320', '', 'cin&eacute;ma REX', '310', ''),
(73, '1175317145', '1454281200', 'frais bancaires', '7.75', ''),
(74, '47353963', '', 'location de salle', '445', ''),
(75, '3189410251', '', 'graph impress', '8.64', '');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(1, 'BILLETTERIE INTERNE DU C.E'),
(2, 'FOURNISSEURS EXTERIEURS AU C.E'),
(3, 'ACTIONS SOCIALES');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`, `commentaire`) VALUES
(26, 29, 1, '6', '24', '13.2', 0, ''),
(27, 30, 1, '6', '24', '13.2', 0, ''),
(28, 32, 1, '2', '8', '4.4', 0, ''),
(29, 33, 13, '1', '30', '8', 0, ''),
(30, 34, 1, '3', '12', '6.6', 0, ''),
(31, 35, 1, '10', '40', '22', 0, ''),
(32, 36, 12, '10', '60', '19', 0, ''),
(33, 37, 1, '2', '8', '4.4', 0, ''),
(34, 39, 14, '6', '24', '10.8', 0, ''),
(35, 40, 1, '2', '8', '4.4', 0, ''),
(36, 41, 1, '1', '4', '2.2', 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.9.0', '191015-EVO');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'administrateur', '882baf28143fb700b388a87ef561a6e5', 1),
(3, 'CEALTHO', '4e36609fabca9e6aaafbbb742f31d05f', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '1'),
(3, 'vente_direct', '1'),
(4, 'decrement_solde', '1');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`) VALUES
(1, 1, 'CINEMA LE REX', '', '30-06-2016', '4', '2.2', '6.2', '100', '33', 0),
(2, 1, 'KARTING ADULTE', '', '31-01-2017', '10', '2', '12', '100', '88', 0),
(3, 1, 'KARTING ENFANT', '', '30-04-2017', '7', '3', '10', '100', '25', 0),
(4, 2, 'PRADEL', '', '26-03-2019', '1', '0', '1', '1000', '9839.28', 0),
(5, 2, 'BIJOU', '', '21-02-2016', '1', '0', '1', '1000', '9764.36', 0),
(6, 3, 'NAISSANCE', '', '31-12-2016', '0', '100', '100', '1', '5', 0),
(7, 3, 'CHEQUES CADEAUX NOEL ADULTES', '', '31-03-2016', '0', '80', '80', '1', '99', 0),
(8, 3, 'CHEQUE CADEAUX NOEL ENFANTS', '', '31-03-2016', '0', '40', '40', '8', '197', 0),
(9, 2, 'LE STER (g&acirc;teau)', '02-01-2016', '30-04-2019', '1', '0', '1', '1000', '1000', 0),
(10, 2, 'GAILLARD (g&acirc;teau)', '02-01-2016', '31-07-2019', '1', '0', '1', '1000', '575', 0),
(11, 2, 'chocolats ORDISCOM', '01-12-2015', '28-04-2018', '1', '0', '1', '10000', '500', 0),
(12, 1, 'HAPPY PARK', '01-01-2016', '09-03-2019', '6', '1.9', '7.9', '100', '7', 0),
(13, 1, 'SPADIUM', '01-01-2016', '02-03-2019', '30', '8', '38', '100', '11', 0),
(14, 1, 'BOWLING', '01-01-2016', '06-07-2019', '4', '1.8', '5.8', '100', '187', 0),
(15, 1, 'ZOO ENFANT', '01-01-2016', '06-07-2019', '7', '3', '10', '', '', 0),
(16, 1, 'ZOO ADULTE', '01-01-2016', '06-04-2019', '12', '2.5', '14.5', '', '', 0),
(17, 1, 'KINGOLAND', '01-01-2016', '05-04-2019', '10', '3.5', '13.5', '', '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `produit_fixe`
--

INSERT INTO `produit_fixe` (`idproduitfixe`, `designation`, `date_produit_fixe`, `montant_produit`, `num_mouvement`) VALUES
(5, 'solde du compte n&deg;53166608510', '01/01/2016', '56187.81', '1107068416'),
(7, 'cotisation ALTHO', '01/01/2016', '8309.97', '5256059086');

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(26, 29, 1, '24', 'caisse epargne', 'LE DAMANY Julien', '0106', 0),
(27, 30, 1, '24', 'CAISSE EPARGNE', 'NICOLAS VINCENT', '0000133', 0),
(28, 33, 1, '30', 'CAISSE D EPARGNE', 'DENIS CAROLE', '0564', 0),
(29, 34, 1, '12', 'CMB', 'LE TADIC ', '1462', 0),
(30, 35, 1, '40', 'CAISSE D EPARGNE', 'ROSSIGNOL ', '9203', 0),
(31, 36, 1, '60', 'CMB', 'KOUROU MICHELLE', '0875', 0),
(32, 37, 1, '8', 'CREDIT AGRICOLE', 'GUILLEMOT VINCENT', '0669', 0),
(33, 39, 1, '24', 'CMB', 'LE DENMAT FRANCOIS', '8162', 0),
(34, 40, 1, '8', 'CREDIT AGRICOLE', 'DELAUNEY MELINDA', '5457', 0),
(35, 41, 3, '4', '', 'JULE BENOIT', '671534477', 0);

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(2, '', 2, 'ASSET', 'MARIE JEANNE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '156'),
(3, '', 1, 'AUDRAIN', 'ERWAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(4, '', 1, 'AUFFRET', 'JEAN LUC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '99'),
(5, '', 1, 'BAUCHER', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(6, '', 3, 'BAUDOIN', 'FABIOLA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '153'),
(7, '', 3, 'BEAUCHENE', 'GERALDINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(8, '', 2, 'BELANDRES', 'DIONISIA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(9, '', 1, 'BELLEC', 'RONAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '149.4'),
(10, '', 1, 'BERNA', 'YANN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(11, '', 2, 'BERNARD', 'NATHALIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(12, '', 2, 'BERNARD', 'VALERIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(13, '', 1, 'BLANCHARD', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(14, '', 1, 'BORROMEE', 'CEDRIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '87'),
(15, '', 1, 'BOSCHER', 'JULIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(16, '', 1, 'BOUCICAUD', 'DIDIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(17, '', 2, 'BOUFFAUT', 'ROZENN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '156.6'),
(18, '', 3, 'BOUFFAUT', 'VALERIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(19, '', 3, 'BOULEAU JAMOIS', 'ANDREA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(20, '', 2, 'BOUYAT', 'BRIGITTE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(21, '', 2, 'CARREE', 'STEPHANIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(22, '', 1, 'CHATELIER', 'SYLVAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(23, '', 1, 'CHEREL', 'GAETAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(24, '', 1, 'CHEREL', 'JEAN NOEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(25, '', 2, 'CHEVILLARD', 'MARIELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(26, '', 1, 'COBIGO', 'XAVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(27, '', 1, 'CONAN', 'MICHEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(28, '', 1, 'CONTINI', 'PAUL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(29, '', 1, 'COPPENS', 'FREDERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '156.6'),
(30, '', 1, 'COQUELIN', 'THOMAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(31, '', 1, 'COUDRIN', 'CHRISTIAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(32, '', 2, 'CREHIM', 'MARIE-LAURE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(33, '', 2, 'CROISIER', 'ANNE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(34, '', 3, 'DARCEL', 'NATACHA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(35, '', 3, 'DAVID', 'ARLETTE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(36, '', 3, 'DELACOURT', 'LYDIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(37, '', 3, 'DELAUNEY', 'MELINDA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '154.6'),
(38, '', 2, 'DENIS', 'CAROLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '151'),
(39, '', 1, 'DERO', 'CHRISTIAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(40, '', 1, 'DIAZ', 'LUC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(41, '', 3, 'DONVAL', 'AMANDINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(42, '', 1, 'DUARTE', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(43, '', 1, 'DUCLOS', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(44, '', 2, 'DUMAINE', 'CHRISTELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(45, '', 1, 'DUPUIS', 'FABIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(46, '', 2, 'ELLIAS', 'MARTINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(47, '', 3, 'FAURE', 'MATHILDE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(48, '', 1, 'FERON', 'PASCAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(49, '', 3, 'FLORIS', 'STEPHANIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(50, '', 1, 'GAUDICHON', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(51, '', 3, 'GAUTHIER', 'ANGELIQUE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(52, '', 1, 'GENTILHOMME', 'MICHEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(53, '', 1, 'GIDEL', 'AYMERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(54, '', 1, 'GIQUEL', 'PATRICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(55, '', 1, 'GOIBIER', 'MICKAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(56, '', 1, 'GORAIN', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(57, '', 3, 'GUEGAN', 'BRIGITTE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(58, '', 3, 'GUEGUIN', 'EMMANUELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(59, '', 1, 'GUEHENNEUX', 'NATHANAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(60, '', 1, 'GUENARD', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(61, '', 3, 'GUENO', 'BRIGITTE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(62, '', 1, 'GUILLAUME', 'PATRICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(63, '', 1, 'GUILLEMOT', 'VINCENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '154.6'),
(64, '', 1, 'GUILLOME', 'FABRICE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(65, '', 1, 'HAMONIC', 'BERTRAND', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(66, '', 1, 'HEMONIC', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(67, '', 2, 'HERVIO', 'ROSELINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(68, '', 1, 'HEUZE', 'MICKAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(69, '', 1, 'IKHEDDACHENE', 'RACHID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(70, '', 1, 'JACQUES', 'BERTRAND', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(71, '', 1, 'JAFFRY', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(72, '', 3, 'JAN', 'SEVERINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(73, '', 3, 'JEGO', 'MARYLINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(74, '', 2, 'JEGOREL', 'CELINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(75, '', 1, 'JEHANNO', 'EMMANUEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(76, '', 1, 'JEHANNO', 'ERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(77, '', 1, 'JEHANNO', 'LIONEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(78, '', 1, 'JOUBIER', 'PIERRICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(79, '', 2, 'JOUINI', 'ELODIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(80, '', 1, 'JULE', 'BENOIT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '156.8'),
(81, '', 3, 'KALESINSKA', 'EWA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(82, '', 1, 'KERLEAU', 'LUDOVIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(83, '', 3, 'KHAIRANI', 'STEPHANIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(84, '', 3, 'KHAMAR', 'MYRIAM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(85, '', 2, 'KOUROU', 'MICHELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '140'),
(86, '', 1, 'LAMOUR', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(87, '', 2, 'LE BAIL', 'NOLWENN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(88, '', 1, 'LE BAS', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(89, '', 3, 'LE BELLER', 'CHANTAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(90, '', 1, 'LE BELLER', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(91, '', 2, 'LE BIHAN', 'CHANTAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(92, '', 1, 'LE BOLAY', 'CHARLES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(93, '', 1, 'LE BOURHIS', 'FLORIAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(94, '', 2, 'LE BRAZIDEC', 'MICHELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(95, '', 1, 'LE BRETON', 'ROMAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(96, '', 1, 'LE CAER', 'YANN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(97, '', 1, 'LE COGUIC', 'JACQUES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(98, '', 1, 'LE COQ', 'JEAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(99, '', 1, 'LE CORRE', 'GUENAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(100, '', 3, 'LE CORRE', 'MARIE PIERRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(101, '', 1, 'LE CORRE', 'PASCAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(102, '', 2, 'LE CORRONC', 'LAURENCE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(103, '', 1, 'LE DAMANY', 'JULIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '145.8'),
(104, '', 1, 'LE DENMAT', 'FRANCOIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '148.2'),
(105, '', 1, 'LE DOUAIRON', 'YANNICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(106, '', 1, 'LE DUC', 'CLAUDE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(107, '', 2, 'LE FEE', 'ISABELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(108, '', 3, 'LE FORESTIER', 'GUENAELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(109, '', 1, 'LE GAL', 'MICKAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(110, '', 2, 'LE GALL', 'CLAUDINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(111, '', 2, 'LE GALLIARD', 'CHRISTELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(112, '', 1, 'LE GENDRE', 'XAVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(113, '', 3, 'LE GENTIL', 'CELINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(114, '', 3, 'LE GOANVIC', 'KARINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(115, '', 3, 'LE GOFF', 'CLAIRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(116, '', 1, 'LE GOFF', 'SYLVAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(117, '', 1, 'LE GOVIC', 'JEROME', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(118, '', 3, 'LE GUELLAUT', 'MANUELA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(119, '', 2, 'LE GUELLEC', 'FLORENCE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(120, '', 1, 'LE GUENNEC', 'GAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(121, '', 1, 'LE GUENNEC', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(122, '', 1, 'LE GUERNEVE', 'BRUNO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(123, '', 2, 'LE GUYADEC', 'NICOLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(124, '', 2, 'LE HENANFF', 'LELEBIT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(125, '', 1, 'LE HIR', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(126, '', 2, 'LE JOSSEC', 'SOLENE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(127, '', 1, 'LE MAREC', 'CEDRIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(128, '', 1, 'LE MESTRE', 'MIKAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(129, '', 2, 'LE METAYER', 'MARIE PIERRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(130, '', 1, 'LE METAYER', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(131, '', 1, 'LE MEUDEC', 'ANTHONY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(132, '', 2, 'LE MEUR', 'CATHERINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(133, '', 1, 'LE MOULLEC', 'FERDINAND', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(134, '', 2, 'LE NEAL', 'NELLY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(135, '', 2, 'LE NORCY', 'CHRISTINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(136, '', 2, 'LE PABIC', 'PATRICIA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(137, '', 2, 'LE PETITCORPS', 'MARTINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(138, '', 1, 'LE PRE', 'LIONEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(139, '', 2, 'LE RAY', 'NELLY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(140, '', 1, 'LE REOUR', 'ARNAUD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(141, '', 1, 'LE REOUR', 'BRUNO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(142, '', 2, 'LE RUYET', 'PATRICIA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(143, '', 1, 'LE SAUCE', 'ERWAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(144, '', 2, 'LE TADIC', 'JULIET', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(145, '', 2, 'LE TADIC', 'SYLVIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '152.4'),
(146, '', 2, 'LE TENAFF', 'PASCALE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(147, '', 3, 'LE TONQUEZE', 'VALERIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(148, '', 1, 'LE TREPUEC', 'ARNAUD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(149, '', 1, 'LEGER', 'MATTHIEU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(150, '', 1, 'LEROY', 'GREGORY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(151, '', 2, 'LEVEQUE', 'ANNIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(152, '', 3, 'LIGER', 'MALIKA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(153, '', 2, 'LORANS', 'MARIE NOELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(154, '', 3, 'LORANS', 'MORGANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(155, '', 1, 'LOSTANLEN', 'MATHIEU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(156, '', 1, 'LUCAS', 'ARNAUD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(157, '', 1, 'MADORE', 'FREDERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(158, '', 1, 'MATHE', 'CYRIL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(159, '', 2, 'MOISAN', 'ISABELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(160, '', 1, 'MOLLARD', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(161, '', 1, 'MONNERAYE', 'CHRISTOPHE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(162, '', 1, 'MOREAU', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(163, '', 1, 'MORVAN', 'ERWANN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(164, '', 3, 'MUROS', 'EMMANUELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(165, '', 1, 'N''DION', 'PATRICE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(166, '', 1, 'NAGA', 'ARNAUD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(167, '', 1, 'NAPOLEONI', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(168, '', 1, 'NEVEU', 'PIERRE OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(169, '', 1, 'NEVOT', 'SAMUEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(170, '', 3, 'NICOL', 'VANESSA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(171, '', 1, 'NICOL', 'VINCENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(172, '', 1, 'NICOLAS', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '59'),
(173, '', 1, 'NICOLAS', 'VINCENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '145.8'),
(174, '', 2, 'OLLIVIER', 'MARYVONNE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(175, '', 2, 'OLLIVIER', 'VALERIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(176, '', 2, 'ORINEL', 'TRISHA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(177, '', 1, 'ORJUBIN', 'RONAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(178, '', 1, 'PATARD', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(179, '', 3, 'PELLETIER', 'KARINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(180, '', 2, 'PENAULT PETRO', 'VALERIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(181, '', 2, 'PERU', 'MICHELE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(182, '', 1, 'PIZON', 'GUILLAUME', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(183, '', 2, 'POQUET', 'VIRGINIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(184, '', 1, 'POULET', 'LUDOVIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(185, '', 1, 'QUENNEMET', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(186, '', 1, 'RAULT', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(187, '', 1, 'RAULT', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(188, '', 1, 'RAULT', 'YOHANN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(189, '', 1, 'RAVIART', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(190, '', 2, 'REBELLER', 'MARINA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(191, '', 3, 'REDO', 'ANDREA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(192, '', 1, 'RELO', 'YANN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(193, '', 1, 'RITUIT', 'ROMUALD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(194, '', 2, 'RIZIO', 'DORIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(195, '', 2, 'ROBINO', 'STEPHANIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(196, '', 1, 'ROLLET', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(197, '', 2, 'ROSSIGNOL', 'SONIA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '137'),
(198, '', 1, 'RUELLO', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(199, '', 1, 'RUNIGO', 'JEROME', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(200, '', 1, 'SALLE DE CHOU', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(201, '', 2, 'SAMSON', 'CAROLINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(202, '', 2, 'SAMSON', 'GENEVIEVE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(203, '', 3, 'SAMYN', 'CELINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(204, '', 1, 'SCHAUSI', 'JEROME', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(205, '', 2, 'STEPHAN', 'NOELLA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(206, '', 2, 'STILLEN', 'GAELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(207, '', 2, 'TANGUY', 'DELPHINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(208, '', 1, 'THOMAS', 'FRANCK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(209, '', 2, 'THOMAS', 'HELENE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(210, '', 2, 'THUILLIER', 'MARIELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(211, '', 1, 'TOURNEMINE', 'GEOFFREY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(212, '', 1, 'TREGOUET', 'JEROME', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(213, '', 1, 'VERNOUX', 'ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(214, '', 3, 'VERTOT', 'SANDRINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '159'),
(215, '', 3, 'VINCENDEAU', 'JULIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '141');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(31, '1452121200', '0106', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LE DAMANY Julien.', '', '24', 0),
(32, '1452121200', '0000133', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de NICOLAS VINCENT.', '', '24', 0),
(33, '1453417200', '0564', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DENIS CAROLE.', '', '30', 0),
(34, '1453417200', '1462', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LE TADIC .', '', '12', 0),
(35, '1452553200', '9203', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROSSIGNOL .', '', '40', 0),
(36, '1453244400', '0875', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de KOUROU MICHELLE.', '', '60', 0),
(37, '1453417200', '0669', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de GUILLEMOT VINCENT.', '', '8', 0),
(38, '1453417200', '8162', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LE DENMAT FRANCOIS.', '', '24', 0),
(39, '1453071600', '5457', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DELAUNEY MELINDA.', '', '8', 0),
(40, '1452812400', '671534477', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par JULE BENOIT.', '', '4', 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  ADD PRIMARY KEY (`idcomptapret`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  MODIFY `idcomptapret` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
