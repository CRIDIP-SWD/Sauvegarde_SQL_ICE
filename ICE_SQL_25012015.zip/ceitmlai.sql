-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Lun 25 Janvier 2016 à 09:39
-- Version du serveur :  5.5.46-0+deb7u1
-- Version de PHP :  5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ceitmlai`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `achat_presta`
--

INSERT INTO `achat_presta` (`idachatpresta`, `date_achat`, `idprestation`, `qte`, `total_achat`, `num_mouvement`) VALUES
(2, '18-01-2016', 1, '100', '570', '6994194514'),
(3, '01-01-2016', 3, '10', '67', '3033713824'),
(4, '01-01-2016', 4, '15', '58.5', '8545865118'),
(5, '01-01-2016', 6, '10', '67', '3063105447');

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(3, 2, 'Vente de Billetterie: CAZADIEU NADINE pour la prestation LE CLUB', '', '9', '61853064'),
(4, 2, 'Vente de Billetterie: DEZELU JULIEN pour la prestation LE CLUB', '', '4.5', '8278321'),
(5, 2, 'Vente de Billetterie: DOUSSY MATHIEU pour la prestation LE CLUB', '', '27', '41995939'),
(6, 2, 'Vente de Billetterie: VOGELGESANG ANDRE pour la prestation LE CLUB', '', '13.5', '65538118'),
(7, 2, 'Vente de Billetterie: MOREAU JAMES pour la prestation LE CLUB', '', '27', '49209663'),
(8, 2, 'Vente de Billetterie: VELLARD JONATHAN pour la prestation LE CLUB', '', '27', '28342983'),
(9, 2, 'Vente de Billetterie: VOGELGESANG ANDRE pour la prestation LE CLUB', '', '4.5', '11954203'),
(10, 2, 'Vente de Billetterie: BUCETA NICOLAS pour la prestation LE CLUB', '', '18', '48543747'),
(11, 2, 'Vente de Billetterie: LABOUYRIE NATHALIE pour la prestation LE CLUB', '', '9', '77356315'),
(12, 2, 'Vente de Billetterie: DUFOURCQ FREDERIC pour la prestation LE CLUB', '', '9', '76052563'),
(14, 2, 'Vente de Billetterie: MORNET RICHARD pour la prestation LE CLUB', '', '27', '98250283'),
(15, 2, 'Vente de Billetterie: JAY PASCAL pour la prestation LE CLUB', '', '27', '81122071'),
(16, 2, 'Vente de Billetterie: DE SA DAVID pour la prestation LE CLUB', '', '27', '38738648'),
(17, 2, 'Vente de Billetterie: TARDITS ALAIN pour la prestation LE CLUB', '', '22.5', '84833259'),
(18, 1, 'Achat: LE CLUB', '570', '', '6994194514'),
(19, 1, 'Ajout de la charge Fixe: UCPM LE CLUB', '30', '', '2846613713'),
(20, 2, 'Vente de Billetterie: THEYS THIERRY pour la prestation LE CLUB', '', '27', '49100647'),
(21, 2, 'Vente de Billetterie: REIJASSE SEBASTIEN pour la prestation LE CLUB', '', '18', '4680026'),
(22, 2, 'Vente de Billetterie: COURCIER PHILIPPE pour la prestation LE CLUB', '', '9', '7818935'),
(23, 2, 'Vente de Billetterie: ROUX SEBASTIEN pour la prestation LE CLUB', '', '27', '46637345'),
(24, 2, 'Vente de Billetterie: PRAT VINCENT pour la prestation LE CLUB', '', '18', '10482241'),
(27, 2, 'Vente de Billetterie: PEREZ FRANCISCO pour la prestation TOUT FOURNISSEUR EXTERIEUR - ETS DESTRIBATS', '', '139.66', '18473981'),
(28, 2, 'Vente de Billetterie: TOURNIER STEPHANE pour la prestation LE CLUB', '', '27', '57414991'),
(29, 2, 'Vente de Billetterie: SELMES LAURENT pour la prestation AYGUE BLUE ADULTE', '', '18', '16674774'),
(30, 1, 'Achat: AYGUEBLUE BE', '67', '', '3033713824'),
(31, 1, 'Achat: AYGUE BLUE ADULTE', '58.5', '', '8545865118'),
(32, 2, 'Vente de Billetterie: DEZELU JULIEN pour la prestation LE CLUB', '', '22.5', '61714444'),
(34, 1, 'Remboursement de la prestation: PARTICIPATION LICENCE FOOTBALL pour MIRAMBEAU DAVID', '30', '', '37685182412'),
(35, 2, 'Vente de Billetterie: DE SA DAVID pour la prestation PART SALARIALE ANCV - 1 ER VERSEMENT', '', '120', '8066763'),
(36, 2, 'Vente de Billetterie: LECHAUDEE-CORBAY STEPHANE pour la prestation PART SALARIALE ANCV', '', '180', '61293628'),
(37, 2, 'Vente de Billetterie: LECHAUDEE-CORBAY STEPHANE pour la prestation CHARGE CE ANCV ', '', '0', '40522797'),
(38, 2, 'Vente de Billetterie: DE SA DAVID pour la prestation CHARGE CE ANCV ', '', '0', '61981184'),
(39, 2, 'Vente de Billetterie: LABORDE THIERRY pour la prestation PART SALARIALE ANCV', '', '280', '74739459'),
(40, 2, 'Vente de Billetterie: LABORDE THIERRY pour la prestation CHARGE CE ANCV ', '', '0', '69854968'),
(41, 2, 'Ajout du produit fixe: SOLDE BANQUE ', '', '7195.15', '6825878257'),
(42, 2, 'Ajout du produit fixe: SUBVENTION 01', '', '3490.79', '7568727648');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `decremente` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `decremente` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`, `num_mouvement`, `decremente`) VALUES
(1, 39, '1451948400', 3, '9', 1, '61853064', 0),
(2, 73, '1451948400', 3, '4.5', 1, '8278321', 0),
(3, 78, '1451948400', 3, '27', 1, '41995939', 0),
(4, 218, '1452207600', 3, '13.5', 1, '65538118', 0),
(5, 170, '1452207600', 3, '27', 1, '49209663', 0),
(6, 215, '1452553200', 3, '27', 1, '28342983', 0),
(7, 218, '1452553200', 3, '4.5', 1, '11954203', 0),
(8, 26, '1452553200', 3, '18', 1, '48543747', 0),
(9, 126, '1452553200', 3, '9', 1, '77356315', 0),
(10, 82, '1452812400', 3, '9', 1, '76052563', 0),
(12, 172, '1452812400', 3, '27', 1, '98250283', 0),
(13, 119, '1452812400', 3, '27', 1, '81122071', 0),
(14, 61, '1452812400', 3, '27', 1, '38738648', 0),
(15, 206, '1453158000', 3, '22.5', 1, '84833259', 0),
(16, 207, '1453417200', 3, '27', 1, '49100647', 0),
(17, 186, '1452812400', 3, '18', 0, '4680026', 0),
(18, 47, '1453158000', 3, '9', 1, '7818935', 0),
(19, 195, '1453330800', 3, '27', 1, '46637345', 0),
(20, 184, '1453417200', 3, '18', 1, '10482241', 0),
(22, 176, '1453417200', 3, '139.66', 1, '18473981', 0),
(23, 214, '1453417200', 3, '27', 1, '57414991', 0),
(24, 202, '1453417200', 3, '18', 1, '16674774', 0),
(25, 73, '1453417200', 3, '22.5', 0, '61714444', 0),
(26, 61, '1452812400', 3, '120', 1, '8066763', 0),
(27, 149, '1452726000', 3, '180', 1, '61293628', 0),
(28, 149, '1452726000', 3, '0', 0, '40522797', 0),
(29, 61, '1452726000', 3, '0', 0, '61981184', 0),
(30, 124, '1452812400', 3, '280', 1, '74739459', 0),
(31, 124, '1452812400', 3, '0', 0, '69854968', 0);

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `charge_fixe`
--

INSERT INTO `charge_fixe` (`idchargefixe`, `designation`, `date_charge_fixe`, `montant_charge`, `num_mouvement`) VALUES
(2, 'UCPM LE CLUB', '18-01-2016', '30', '2846613713');

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '', ''),
(81, 2, '', ''),
(82, 3, '6523.88', '2089.47'),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '16223.76', ''),
(87, 8, '9586.38', '3000'),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '5089.47', '34423.49'),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', ''),
(113, 34, '', ''),
(114, 35, '', ''),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '', ''),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '', ''),
(134, 55, '', ''),
(135, 56, '301.04', ''),
(136, 57, '', ''),
(137, 58, '', ''),
(138, 59, '', ''),
(139, 60, '', ''),
(140, 61, '', ''),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '958', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '830.43', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_banque`
--

INSERT INTO `compta_banque` (`idcomptabanque`, `num_mouvement`, `date_bq`, `desc_bq`, `idcomptaplan`, `debit`, `credit`) VALUES
(47, '5823898', '1453417200', 'VIREMENT LIVRET VERS BANQUE', 3, '3000', ''),
(48, '5250305', '1451602800', 'SODAC', 3, '', '245.64'),
(49, '6388316', '1451602800', 'MADELEINE BIJOU', 3, '', '55.40'),
(50, '4351881', '1451602800', 'VERSEMENT CCE', 3, '', '958'),
(51, '5493015', '1452553200', 'REGUL SODAC', 3, '', '830.43');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_actif`
--

INSERT INTO `compta_bilan_actif` (`idcptbilanactif`, `num_mouvement`, `idcomptaplan`, `montant`) VALUES
(28, '8699988', 3, '3523.88'),
(29, '2145921', 8, '9586.38'),
(30, '9746390', 7, '16223.76');

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_bilan_passif`
--

INSERT INTO `compta_bilan_passif` (`idcptbilanpassif`, `num_mouvement`, `idcomptaplan`, `montant`) VALUES
(11, '7975878', 28, '29334.02');

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_compte`
--

INSERT INTO `compta_compte` (`idcomptacompte`, `num_mouvement`, `idcomptaplan`, `debit`, `credit`) VALUES
(137, '5462175', 8, '', '3000'),
(138, '5823898', 3, '3000', ''),
(139, '8699988', 3, '3523.88', ''),
(140, '2145921', 8, '9586.38', ''),
(141, '9746390', 7, '16223.76', ''),
(142, '7975878', 28, '', '29334.02'),
(143, '7670754', 56, '245.64', ''),
(144, '2815281', 56, '55.40', ''),
(145, '3081797', 64, '958', ''),
(146, '3845628', 70, '830.43', ''),
(147, '5250305', 3, '', '245.64'),
(148, '6388316', 3, '', '55.40'),
(149, '4351881', 3, '', '958'),
(150, '5493015', 3, '', '830.43');

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_livret`
--

INSERT INTO `compta_livret` (`idcomptalivret`, `num_mouvement`, `date_livret`, `desc_livret`, `idcomptaplan`, `debit`, `credit`) VALUES
(2, '5462175', '1453417200', 'VIREMENT VERS BANQUE', 8, '', '3000');

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_mvm`
--

INSERT INTO `compta_mvm` (`idcomptamvm`, `num_mouvement`, `date_mvm`, `desc_mvm`, `idcomptaplan`, `debit`, `credit`) VALUES
(44, '7670754', '1451602800', 'SODAC', 56, '245.64', ''),
(45, '2815281', '1451602800', 'MADELEINE BIJOU', 56, '55.40', ''),
(46, '3081797', '1451602800', 'VERSEMENT CCE', 64, '958', ''),
(47, '3845628', '1452553200', 'REGUL SODAC', 70, '830.43', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', ''),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', 'Compte de Pret'),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', 'Charges Divers'),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Taxes'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'ACHAT RESTAURATION A EMPORTER'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achats de matÃ©riel et logiciels informatiques'),
(61, 6, 'Autre Charge d''exploitation 1', 'Divers'),
(62, 6, 'Autre Charge d''exploitation 2', 'FRAIS HOTELIERS'),
(63, 6, 'Autre Charge d''exploitation 3', 'FRAIS RESTAURATION'),
(64, 6, 'Autre Charge d''exploitation 4', 'VERSEMENT CCE'),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', 'VIREMENT VERS ASC'),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_pret`
--

CREATE TABLE `compta_pret` (
  `idcomptapret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_pret` varchar(255) NOT NULL,
  `desc_pret` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_resultat`
--

INSERT INTO `compta_resultat` (`idresultat`, `num_mouvement`, `idcomptaplan`, `debit`, `credit`) VALUES
(45, '7670754', 56, '245.64', ''),
(46, '2815281', 56, '55.40', ''),
(47, '3081797', 64, '958', ''),
(48, '3845628', 70, '830.43', '');

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'C.E  ITMLAI CASTETS', '0', '0', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '01-01-2016', '31-12-2016');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(3, '61853064', '1451948400', 'Vente de Billetterie: CAZADIEU NADINE pour la prestation LE CLUB', '', '9'),
(4, '8278321', '1451948400', 'Vente de Billetterie: DEZELU JULIEN pour la prestation LE CLUB', '', '4.5'),
(5, '41995939', '1451948400', 'Vente de Billetterie: DOUSSY MATHIEU pour la prestation LE CLUB', '', '27'),
(6, '65538118', '1452207600', 'Vente de Billetterie: VOGELGESANG ANDRE pour la prestation LE CLUB', '', '13.5'),
(7, '49209663', '1452207600', 'Vente de Billetterie: MOREAU JAMES pour la prestation LE CLUB', '', '27'),
(8, '28342983', '1452553200', 'Vente de Billetterie: VELLARD JONATHAN pour la prestation LE CLUB', '', '27'),
(9, '11954203', '1452553200', 'Vente de Billetterie: VOGELGESANG ANDRE pour la prestation LE CLUB', '', '4.5'),
(10, '48543747', '1452553200', 'Vente de Billetterie: BUCETA NICOLAS pour la prestation LE CLUB', '', '18'),
(11, '77356315', '1452553200', 'Vente de Billetterie: LABOUYRIE NATHALIE pour la prestation LE CLUB', '', '9'),
(12, '76052563', '1452812400', 'Vente de Billetterie: DUFOURCQ FREDERIC pour la prestation LE CLUB', '', '9'),
(14, '98250283', '1452812400', 'Vente de Billetterie: MORNET RICHARD pour la prestation LE CLUB', '', '27'),
(15, '81122071', '1452812400', 'Vente de Billetterie: JAY PASCAL pour la prestation LE CLUB', '', '27'),
(16, '38738648', '1452812400', 'Vente de Billetterie: DE SA DAVID pour la prestation LE CLUB', '', '27'),
(17, '84833259', '1453158000', 'Vente de Billetterie: TARDITS ALAIN pour la prestation LE CLUB', '', '22.5'),
(18, '6994194514', '1453071600', 'Achat - LE CLUB', '570', ''),
(19, '2846613713', '1453071600', 'UCPM LE CLUB', '30', ''),
(20, '49100647', '1453417200', 'Vente de Billetterie: THEYS THIERRY pour la prestation LE CLUB', '', '27'),
(21, '4680026', '1452812400', 'Vente de Billetterie: REIJASSE SEBASTIEN pour la prestation LE CLUB', '', '18'),
(22, '7818935', '1453158000', 'Vente de Billetterie: COURCIER PHILIPPE pour la prestation LE CLUB', '', '9'),
(23, '46637345', '1453330800', 'Vente de Billetterie: ROUX SEBASTIEN pour la prestation LE CLUB', '', '27'),
(24, '10482241', '1453417200', 'Vente de Billetterie: PRAT VINCENT pour la prestation LE CLUB', '', '18'),
(27, '18473981', '1453417200', 'Vente de Billetterie: PEREZ FRANCISCO pour la prestation TOUT FOURNISSEUR EXTERIEUR - ETS DESTRIBATS', '', '139.66'),
(28, '57414991', '1453417200', 'Vente de Billetterie: TOURNIER STEPHANE pour la prestation LE CLUB', '', '27'),
(29, '16674774', '1453417200', 'Vente de Billetterie: SELMES LAURENT pour la prestation AYGUE BLUE ADULTE', '', '18'),
(30, '3033713824', '1451602800', 'Achat - AYGUEBLUE BE', '67', ''),
(31, '8545865118', '1451602800', 'Achat - AYGUE BLUE ADULTE', '58.5', ''),
(32, '61714444', '1453417200', 'Vente de Billetterie: DEZELU JULIEN pour la prestation LE CLUB', '', '22.5'),
(34, '37685182412', '1451602800', 'Remboursement de la Prestation pour MIRAMBEAU DAVID - PARTICIPATION LICENCE FOOTBALL', '30', ''),
(35, '8066763', '1452812400', 'Vente de Billetterie: DE SA DAVID pour la prestation PART SALARIALE ANCV - 1 ER VERSEMENT', '', '120'),
(36, '61293628', '1452726000', 'Vente de Billetterie: LECHAUDEE-CORBAY STEPHANE pour la prestation PART SALARIALE ANCV', '', '180'),
(37, '40522797', '1452726000', 'Vente de Billetterie: LECHAUDEE-CORBAY STEPHANE pour la prestation CHARGE CE ANCV ', '', '0'),
(38, '61981184', '1452726000', 'Vente de Billetterie: DE SA DAVID pour la prestation CHARGE CE ANCV ', '', '0'),
(39, '74739459', '1452812400', 'Vente de Billetterie: LABORDE THIERRY pour la prestation PART SALARIALE ANCV', '', '280'),
(40, '69854968', '1452812400', 'Vente de Billetterie: LABORDE THIERRY pour la prestation CHARGE CE ANCV ', '', '0'),
(41, '6825878257', '1451516400', 'SOLDE BANQUE ', '', '7195.15'),
(42, '7568727648', '1452121200', 'SUBVENTION 01', '', '3490.79');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(1, 'CINEMA'),
(3, 'FOURNISSEURS EXTERIEURS'),
(4, 'UCPM'),
(5, 'ANCV');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`, `commentaire`) VALUES
(1, 1, 1, '2', '9', '2.4', 0, ''),
(2, 2, 1, '1', '4.5', '1.2', 0, ''),
(3, 3, 1, '6', '27', '7.2', 0, ''),
(4, 4, 1, '3', '13.5', '3.6', 0, ''),
(5, 5, 1, '6', '27', '7.2', 0, ''),
(6, 6, 1, '6', '27', '7.2', 0, ''),
(7, 7, 1, '1', '4.5', '1.2', 0, ''),
(8, 8, 1, '4', '18', '4.8', 0, ''),
(9, 9, 1, '2', '9', '2.4', 0, ''),
(10, 10, 1, '2', '9', '2.4', 0, ''),
(12, 12, 1, '6', '27', '7.2', 0, ''),
(13, 13, 1, '6', '27', '7.2', 0, ''),
(14, 14, 1, '6', '27', '7.2', 0, ''),
(15, 15, 1, '5', '22.5', '6', 0, ''),
(16, 16, 1, '6', '27', '7.2', 0, ''),
(17, 17, 1, '4', '18', '4.8', 0, ''),
(18, 18, 1, '2', '9', '2.4', 0, ''),
(19, 19, 1, '6', '27', '7.2', 0, ''),
(20, 20, 1, '4', '18', '4.8', 0, ''),
(23, 22, 2, '139.66', '139.66', '0', 0, 'ETS DESTRIBATS'),
(24, 23, 1, '6', '27', '7.2', 0, ''),
(25, 24, 4, '6', '18', '5.4', 0, ''),
(26, 25, 1, '5', '22.5', '6', 0, ''),
(27, 26, 7, '120', '120', '0', 0, '1 ER VERSEMENT'),
(28, 27, 7, '180', '180', '0', 0, ''),
(29, 28, 8, '120', '0', '120', 0, ''),
(30, 29, 8, '80', '0', '80', 0, ''),
(31, 30, 7, '280', '280', '0', 0, ''),
(32, 31, 8, '120', '0', '120', 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.9.0', '191015-EVO');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'administrateur', '882baf28143fb700b388a87ef561a6e5', 1),
(2, 'pascalebareyt', '532373ca2406c71bdc89e6e734ff6c2b', 1),
(3, 'Jean Louis', '2c1010a215bd9e8f3c6f33f58a03402a', 1),
(4, 'bruno', '2ed7faa84750ce856ca75a2b60b8a712', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '1'),
(3, 'vente_direct', '1'),
(4, 'decrement_solde', '1');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`) VALUES
(1, 1, 'LE CLUB', '01-01-2016', '15-07-2016', '4.5', '1.2', '5.7', '6', '76', 0),
(2, 3, 'TOUT FOURNISSEUR EXTERIEUR', '01-01-2016', '31-12-2016', '1', '0', '1', '10000', '999860.34', 0),
(4, 4, 'AYGUE BLUE ADULTE', '01-01-2016', '31-12-2016', '3', '0.90', '3.9', '6', '3', 0),
(5, 4, 'AYGUEBLUE  14 ANS MAXI', '01-01-2016', '31-12-2016', '2', '0.70', '2.7', '6', '17', 0),
(6, 4, 'AYGUE BLUE BE', '01-01-2016', '31-12-2016', '6', '0.70', '6.7', '6', '10', 0),
(7, 5, 'PART SALARIALE ANCV', '01-01-2016', '31-12-2016', '1', '0', '1', '1000', '999420', 0),
(8, 5, 'CHARGE CE ANCV ', '01-01-2016', '31-12-2016', '0', '1', '1', '1000', '99680', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `produit_fixe`
--

INSERT INTO `produit_fixe` (`idproduitfixe`, `designation`, `date_produit_fixe`, `montant_produit`, `num_mouvement`) VALUES
(1, 'SOLDE BANQUE ', '31-12-2015', '7195.15', '6825878257'),
(2, 'SUBVENTION 01', '07-01-2016', '3490.79', '7568727648');

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(1, 1, 3, '9', '', 'CAZADIEU NADINE', '756662418', 0),
(2, 3, 1, '27', 'NON RELEVE', 'DOUSSY MATHIEU', 'NON RELEVE', 0),
(3, 2, 1, '4.5', 'NON RELEVE', 'DEZELU JULIEN', 'NON RELEVE', 0),
(4, 4, 3, '13.5', '', 'VOGELGESANG ANDRE', '698747102', 0),
(5, 5, 1, '27', 'NON RELEVE', 'MOREAU JAMES', 'NON ', 0),
(6, 7, 3, '4.5', '', 'VOGELGESANG ANDRE', '182475906', 0),
(7, 6, 1, '27', 'LA POSTE', 'VELLARD JONATHAN', '133467029 G', 0),
(8, 9, 3, '9', '', 'LABOUYRIE NATHALIE', '478844383', 0),
(10, 8, 1, '18', 'LA BANQUE POSTALE', 'BUCETA NICOLAS', '14 4442037 F', 0),
(11, 10, 3, '9', '', 'DUFOURCQ FREDERIC', '370226029', 0),
(14, 12, 3, '27', '', 'MORNET RICHARD', '987523941', 0),
(15, 13, 1, '27', 'ING DIRECT', 'JAY PASCAL', '2795760', 0),
(16, 14, 1, '27', 'SOCIETE GENERALE', 'DE SA DAVID', '0000353', 0),
(17, 16, 3, '27', '', 'THEYS THIERRY', '920272880', 0),
(18, 18, 3, '9', '', 'COURCIER PHILIPPE', '327561334', 0),
(20, 19, 1, '27', 'SOCIETE GENERALE', 'ROUX SEBASTIEN', '0001182', 0),
(21, 20, 1, '18', 'CREDIT AGRICOLE', 'PRAT VINCENT', '0000683', 0),
(22, 15, 3, '22.5', '', 'TARDITS ALAIN', '564477314', 0),
(24, 22, 1, '139.66', 'CREDIT AGRICOLE', 'PEREZ FRANCISCO', '3194759', 0),
(25, 23, 1, '27', 'BANQUE POPULAIRE', 'TOURNIER STEPHANE', '0273727', 0),
(26, 24, 3, '18', '', 'SELMES LAURENT', '435543705', 0),
(27, 26, 1, '120', 'SG', 'DE SA DAVID', '0000352', 0),
(28, 27, 1, '180', 'BANQUE POPULAIRE', 'LECHAUDEE-CORBAY STEPHANE', '000259', 0),
(29, 30, 1, '280', 'SOCIETE GENERALE', 'LABORDE THIERRY', '0003614', 0);

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_remb_salarie`
--

INSERT INTO `reg_remb_salarie` (`idregrembsalarie`, `idrembsalarie`, `montant_reglement`, `num_chq`) VALUES
(1, 1, '30,00', '1793688');

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `remb_salarie`
--

INSERT INTO `remb_salarie` (`idrembsalarie`, `idsalarie`, `prestation`, `date_vente`, `montant_prestation`, `part_ce`, `etat_facture`, `num_mouvement`) VALUES
(1, 167, 'PARTICIPATION LICENCE FOOTBALL', '01-01-2016', '50', '30', 1, '37685182412');

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(2, '', 0, 'ADIEMOFF', 'VAHE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(3, '', 0, 'AKNIN', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(4, '', 0, 'ALBERTINI', 'DIDIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(5, '', 0, 'ANDRE', 'PAUL ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(6, '', 0, 'ARREGUI', 'FRANCOIS-XAVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(7, '', 0, 'AUZEMERY', 'ERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(8, '', 0, 'BAHURLET', 'DANIEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(9, '', 0, 'BAREYT', 'PASCALE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(10, '', 0, 'BATS', 'ARNAUD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(11, '', 0, 'BAUVY', 'BRUNO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(12, '', 0, 'BELIN', 'DAMIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(13, '', 0, 'BERBILLE', 'KARINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(14, '', 0, 'BERLON', 'JORDAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(15, '', 0, 'BERNACHOT', 'JACQUES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(16, '', 0, 'BERNARD', 'ROMAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(17, '', 0, 'BIREMONT', 'JEAN PATRICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(18, '', 0, 'BONNEL', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(19, '', 0, 'BORTOLUZZI', 'EMILIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(20, '', 0, 'BOUISSET', 'FREDERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(21, '', 0, 'BOUNAB', 'RACHID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(22, '', 0, 'BRACHET', 'GILLES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(23, '', 0, 'BRAVI', 'ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(24, '', 0, 'BRUNAUD', 'JEAN MARC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(25, '', 0, 'BUCETA', 'JOSE LUIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(26, '', 0, 'BUCETA', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(27, '', 0, 'BUSQUET', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(28, '', 0, 'CAETANO MARTINS', 'JOSE VANTUIR', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(29, '', 0, 'CAPES', 'PIERRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(30, '', 0, 'CARIO', 'PASCAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(31, '', 0, 'CARRASCO', 'FREDERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(32, '', 0, 'CARRASCO', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(33, '', 0, 'CASSEGRAIN', 'PASCALE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(34, '', 0, 'CASTEL', 'ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(35, '', 0, 'CASTERA', 'MICHAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(36, '', 0, 'CATOIRE', 'MARC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(37, '', 0, 'CAULE', 'JEAN PAUL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(38, '', 0, 'CAZADE', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(39, '', 0, 'CAZADIEU', 'NADINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(40, '', 0, 'CAZENAVE', 'JEROME', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(41, '', 0, 'CAZENAVE', 'PATRICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(42, '', 0, 'CHARRIEAU', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(43, '', 0, 'CHARRIEAU', 'MATHIEU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(44, '', 0, 'CHAUTARD', 'JULIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(45, '', 0, 'CHEVALLEY', 'CHRISTOPHE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(46, '', 0, 'CHINESTRA', 'MICHEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(47, '', 0, 'COURCIER', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(48, '', 0, 'COUSIN', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(49, '', 0, 'COUSSAU', 'JEAN LOUIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(50, '', 0, 'CRABANAT', 'ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(51, '', 0, 'CUZACQ', 'GREGORY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(52, '', 0, 'DA CONCEICAO', 'PASCAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(53, '', 0, 'DA SILVA', 'JOSE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(54, '', 0, 'DANTHEZ', 'RICHARD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(55, '', 0, 'DARJO', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(56, '', 0, 'DARRIAU', 'MAX ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(57, '', 0, 'DARRICAU', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(58, '', 0, 'DAVERAT', 'MARIE-JOSEE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(59, '', 0, 'DE ABREU PEREIRA', 'MANUEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(60, '', 0, 'DE LA HOS', 'GILLES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(61, '', 0, 'DE SA', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(62, '', 0, 'DEGOS', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(63, '', 0, 'DEHEZ', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(64, '', 0, 'DEJEAN', 'CYRIL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(65, '', 0, 'DELAS', 'VALERIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(66, '', 0, 'DELGADO', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(67, '', 0, 'DELPECH', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(68, '', 0, 'DELSOL', 'JEAN-BERNARD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(69, '', 0, 'DESCAZAUX', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(70, '', 0, 'DESSARPS', 'THIBAULT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DD', 1, '30'),
(71, '', 0, 'DESTENAVE', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(72, '', 0, 'DEYRES', 'JOEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(73, '', 0, 'DEZELU', 'JULIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(74, '', 0, 'DIDIER', 'THIBAUD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(75, '', 0, 'DINET', 'MICKAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DD', 1, '30'),
(76, '', 0, 'DONTENWILL', 'FABRICE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(77, '', 0, 'DOUET', 'ANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(78, '', 0, 'DOUSSY', 'MATHIEU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(79, '', 0, 'DUCASSE', 'ERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(80, '', 0, 'DUCROS', 'ALAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(81, '', 0, 'DUFILLON', 'NICOLAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(82, '', 0, 'DUFOURCQ', 'FREDERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(83, '', 0, 'DURU', 'JEAN-PIERRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(84, '', 0, 'DUSSAUBAT', 'LUIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(85, '', 0, 'DUVIGNEAU', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(86, '', 0, 'DUVIGNEAU', 'MARIE HELENE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(87, '', 0, 'ESSIOMLE', 'FREDERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(88, '', 0, 'FABRE', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(89, '', 0, 'FAISANCIEU', 'JEAN MARC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(90, '', 0, 'FAURENS', 'ALAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(91, '', 0, 'FERNANDES', 'JOELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(92, '', 0, 'FERNANDES', 'FRANCIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(93, '', 0, 'FEZANCIEUX', 'ERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(94, '', 0, 'FOMBELLIDA', 'JEAN MICHEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(95, '', 0, 'FONTAINE', 'GERVAIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(96, '', 0, 'FOUGERAY', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(97, '', 0, 'FRERE', 'PIERRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(98, '', 0, 'GADOU', 'VALERIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(99, '', 0, 'GARAT', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(100, '', 0, 'GAUTHIER', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(101, '', 0, 'GELEZ', 'MICHAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(102, '', 0, 'GERARD', 'PASCAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(103, '', 0, 'GOLVEN', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(104, '', 0, 'GONZALEZ', 'YVES-ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(105, '', 0, 'GRAFFI', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(106, '', 0, 'GRENTE-LENGAGNE', 'CATHERINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(107, '', 0, 'GUICHEMERRE', 'DIDIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(108, '', 0, 'GUICHENEY', 'BRUNO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(109, '', 0, 'GUILHAUME', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(110, '', 0, 'GUINGANT', 'YANN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(111, '', 0, 'GUYONNAUD', 'BERNARD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(112, '', 0, 'HERNANDEZ', 'NOEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(113, '', 0, 'HERVANT', 'JEAN JACQUES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(114, '', 0, 'HOURDEBAIGT', 'JOEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(115, '', 0, 'HOURQUET', 'JEAN MARC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(116, '', 0, 'ICIAGA', 'GAETAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(117, '', 0, 'ILHARRAGORRY', 'STEPHANIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DD', 1, '30'),
(118, '', 0, 'INACIO', 'VICTOR', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(119, '', 0, 'JAY', 'PASCAL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(120, '', 0, 'JUNCA', 'PATRICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(121, '', 0, 'KENNEL', 'REMY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(122, '', 0, 'KERVELLEC', 'HERVE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(123, '', 0, 'KLEWAIS', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(124, '', 0, 'LABORDE', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(125, '', 0, 'LABORDE', 'ALINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(126, '', 0, 'LABOUYRIE', 'NATHALIE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(127, '', 0, 'LAFITTE', 'JEAN JOSEPH', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(128, '', 0, 'LAFOURCADE', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(129, '', 0, 'LALAGUE', 'BERTRAND', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(130, '', 0, 'LALANDE', 'JEAN PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(131, '', 0, 'LAMAGNERE', 'VINCENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DD', 1, '30'),
(132, '', 0, 'LAMAGNERE', 'LUCIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(133, '', 0, 'LANUSSE', 'THOMAS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(134, '', 0, 'LANUSSE', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(135, '', 0, 'LAPARADE', 'XAVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(136, '', 0, 'LAPENU', 'CLAUDE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(137, '', 0, 'LAPEYRE', 'DOMINIQUE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(138, '', 0, 'LARRERE', 'ISABELLE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(139, '', 0, 'LARRIEU', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(140, '', 0, 'LASSALLE', 'CHRISTOPHE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(141, '', 0, 'LASSALLE', 'HUGUETTE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(142, '', 0, 'LASSERRE', 'YVES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(143, '', 0, 'LAUDIERES', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(144, '', 0, 'LAUSSU', 'ALAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(145, '', 0, 'LAUSSU', 'DENIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(146, '', 0, 'LAVIELLE', 'BERTRAND', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(147, '', 0, 'LE NAOUR', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(148, '', 0, 'LEBEGUE', 'JEAN CLAUDE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(149, '', 0, 'LECHAUDEE-CORBAY', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(150, '', 0, 'LEFEBVRE', 'JEAN MARC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(151, '', 0, 'LEGROS', 'JOHNNY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(152, '', 0, 'LEROUX', 'SYLVAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(153, '', 0, 'LIETARD', 'GREGORY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(154, '', 0, 'LOUBERE', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(155, '', 0, 'LUCIDO', 'JEAN LUC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(156, '', 0, 'LUCIDO', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(157, '', 0, 'MACHADO', 'ANTONIO JOSE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(158, '', 0, 'MALET', 'NORMAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(159, '', 0, 'MAOCEC', 'JEAN-LOUIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(160, '', 0, 'MARCHESAN', 'ROMAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(161, '', 0, 'MARTIN', 'ERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(162, '', 0, 'MARTINS ADAO', 'ADRIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(163, '', 0, 'MEDINA', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(164, '', 0, 'MEIRINHO', 'FRANCIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(165, '', 0, 'MILLION', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(166, '', 0, 'MIMEAU', 'ANTOINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(167, '', 0, 'MIRAMBEAU', 'DAVID', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '0'),
(168, '', 0, 'MONDI', 'DIDIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(169, '', 0, 'MORA', 'JEAN LUC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(170, '', 0, 'MOREAU', 'JAMES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(171, '', 0, 'MOREIRA', 'ANTERO MANUEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(172, '', 0, 'MORNET', 'RICHARD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(173, '', 0, 'NAMBLARD', 'JEAN-PIERRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(174, '', 0, 'NANTES', 'CEDRIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(175, '', 0, 'PEREZ', 'JEAN-JACQUES', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(176, '', 0, 'PEREZ', 'FRANCISCO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(177, '', 0, 'PETITPIERRE', 'BRUNO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(178, '', 0, 'PICHENET', 'JEAN-FRANCOIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(179, '', 0, 'POILPRE', 'YANNICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(180, '', 0, 'POIRET', 'FREDERIC', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(181, '', 0, 'POMBIEILH', 'JEROME', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(182, '', 0, 'PONTET', 'ALBIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(183, '', 0, 'PORTELA', 'MANUEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(184, '', 0, 'PRAT', 'VINCENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(185, '', 0, 'PUEYO', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(186, '', 0, 'REIJASSE', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(187, '', 0, 'REIMMEL', 'RAOUL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(188, '', 0, 'REVET', 'ALAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(189, '', 0, 'RIBEIRO', 'RAPHAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(190, '', 0, 'RICAU', 'JEAN-PIERRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(191, '', 0, 'RICHAUD', 'JEAN CLAUDE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(192, '', 0, 'RIEFFEL', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(193, '', 0, 'RODRIGUES', 'CHRISTOPHE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(194, '', 0, 'ROSEMBLY', 'MICHAEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(195, '', 0, 'ROUX', 'SEBASTIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(196, '', 0, 'SAINT-JEAN', 'JOEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(197, '', 0, 'SANTOS', 'JEAN LOUIS', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(198, '', 0, 'SANTOS', 'CHRISTIAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(199, '', 0, 'SAVIO', 'BRUNO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DD', 1, '30'),
(200, '', 0, 'SBAA', 'MOULAY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(201, '', 0, 'SEGUIN', 'FABIENNE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(202, '', 0, 'SELMES', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(203, '', 0, 'SEPZ', 'SERGE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(204, '', 0, 'SIMAO DIAS MATEUS', 'DANIEL', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(205, '', 0, 'SINTRA NEVES', 'PAULO ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(206, '', 0, 'TARDITS', 'ALAIN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(207, '', 0, 'THEYS', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(208, '', 0, 'THEYS', 'XAVIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(209, '', 0, 'THOMAS', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(210, '', 0, 'THOORIS', 'DIDIER', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(211, '', 0, 'TOUHANE', 'ABDERRAHIM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(212, '', 0, 'TOULET', 'ALINE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(213, '', 0, 'TOUMI', 'ZOHRA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(214, '', 0, 'TOURNIER', 'STEPHANE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(215, '', 0, 'VELLARD', 'JONATHAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(216, '', 0, 'VEYRET', 'PATRICK', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(217, '', 0, 'VIGNAU', 'JULIEN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30'),
(218, '', 0, 'VOGELGESANG', 'ANDRE', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'DI', 1, '30');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(1, '1451948400', '756662418', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par CAZADIEU NADINE.', '', '9', 0),
(2, '1451948400', 'NON RELEVE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DOUSSY MATHIEU.', '', '27', 0),
(3, '1451948400', 'NON RELEVE', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DEZELU JULIEN.', '', '4.5', 0),
(4, '1452207600', '698747102', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par VOGELGESANG ANDRE.', '', '13.5', 0),
(5, '1452207600', 'NON ', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de MOREAU JAMES.', '', '27', 0),
(6, '1452553200', '182475906', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par VOGELGESANG ANDRE.', '', '4.5', 0),
(7, '1452553200', '133467029 G', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de VELLARD JONATHAN.', '', '27', 0),
(8, '1452553200', '478844383', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par LABOUYRIE NATHALIE.', '', '9', 0),
(10, '1452553200', '14 4442037 F', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de BUCETA NICOLAS.', '', '18', 0),
(11, '1452812400', '370226029', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par DUFOURCQ FREDERIC.', '', '9', 0),
(14, '1452812400', '987523941', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par MORNET RICHARD.', '', '27', 0),
(15, '1452812400', '2795760', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de JAY PASCAL.', '', '27', 0),
(16, '1452812400', '0000353', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DE SA DAVID.', '', '27', 0),
(17, '1453417200', '920272880', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par THEYS THIERRY.', '', '27', 0),
(18, '1453158000', '327561334', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par COURCIER PHILIPPE.', '', '9', 0),
(20, '1453330800', '0001182', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de ROUX SEBASTIEN.', '', '27', 0),
(21, '1453417200', '0000683', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PRAT VINCENT.', '', '18', 0),
(22, '1453158000', '564477314', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par TARDITS ALAIN.', '', '22.5', 0),
(24, '1453417200', '3194759', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de PEREZ FRANCISCO.', '', '139.66', 0),
(25, '1453417200', '0273727', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de TOURNIER STEPHANE.', '', '27', 0),
(26, '1453417200', '435543705', 'Reglement Client', 'EspÃ¨ce', 'Reglement de la prestation en espÃ¨ce par SELMES LAURENT.', '', '18', 0),
(27, '1452812400', '0000352', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de DE SA DAVID.', '', '120', 0),
(28, '1452726000', '000259', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LECHAUDEE-CORBAY STEPHANE.', '', '180', 0),
(29, '1452812400', '0003614', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de LABORDE THIERRY.', '', '280', 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  ADD PRIMARY KEY (`idcomptapret`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  MODIFY `idcomptapret` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
