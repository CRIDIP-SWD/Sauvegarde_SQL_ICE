-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Lun 18 Janvier 2016 à 15:28
-- Version du serveur :  5.5.46-0+deb7u1
-- Version de PHP :  5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cebarilla`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `achat_presta`
--

INSERT INTO `achat_presta` (`idachatpresta`, `date_achat`, `idprestation`, `qte`, `total_achat`, `num_mouvement`) VALUES
(1, '', 0, '', '0', '7633948810'),
(2, '', 0, '', '0', '7640112471');

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ayant_droit`
--

INSERT INTO `ayant_droit` (`idayantdroit`, `idsalarie`, `nom_ayant_droit`, `prenom_ayant_droit`, `date_naissance_ayant_droit`, `solde_ayant_droit`) VALUES
(1, 144, 'GRIMAUD', 'LUCAS', '09-06-2001', '999999999999999999'),
(2, 144, 'GRIMAUD', 'LOUIS', '12-01-2005', '999999999999999999'),
(3, 2, 'Fontaine', 'Quentin', '21-08-1995', '999999999999999999'),
(4, 3, 'Almand', 'Jonathan', '16-01-2002', '999999999999999999'),
(5, 4, 'Andrade de Freitas', 'Jordan', '12-03-1993', '999999999999999999'),
(6, 5, 'Angonin', 'Tom', '04-02-2015', '999999999999999999'),
(7, 3, 'Almand', 'Alexis', '09-07-2004', '999999999999999999'),
(8, 4, 'Andrade de Freitas', 'Andy', '14-03-1995', '999999999999999999'),
(9, 4, 'Andrade de Freitas', 'Tania', '26-10-2000', '999999999999999999'),
(10, 4, 'Andrade de Freitas', 'Enzo', '22-02-2007', '999999999999999999'),
(11, 6, 'Antin', 'Julie', '12-05-1988', '999999999999999999'),
(12, 6, 'Antin', 'Arnaud', '14-03-2002', '999999999999999999'),
(13, 7, 'Aubrun', 'Frederic', '26-03-1978', '999999999999999999'),
(14, 7, 'Aubrun', 'Emmanuelle', '19-05-1982', '999999999999999999'),
(15, 7, 'Aubrun', 'Tommy', '20-07-1983', '999999999999999999'),
(16, 326, 'Babineau', 'Lea', '01-05-2002', '999999999999999999'),
(17, 326, 'Babineau', 'Victor', '20-09-2006', '999999999999999999'),
(18, 13, 'Chantraine', 'Celia', '29-09-2010', '999999999999999999'),
(19, 348, 'Bachini', 'Ilyas', '05-07-2010', '999999999999999999'),
(20, 348, 'Bachini', 'janane', '18-05-2012', '999999999999999999'),
(21, 22, 'Batard', 'Christine', '12-09-1991', '999999999999999999'),
(22, 22, 'Batard', 'Yohann', '19-06-1999', '999999999999999999'),
(23, 22, 'Batard', 'Aurelien', '22-06-2004', '999999999999999999'),
(24, 23, 'Bauchet', 'Maxime', '06-10-2009', '999999999999999999'),
(25, 327, 'Beauger', 'Cynthia', '01-10-1995', '999999999999999999'),
(26, 327, 'Beauger', 'Jordan', '17-02-1997', '999999999999999999'),
(27, 327, 'Beauger', 'Steven', '05-06-1999', '999999999999999999'),
(28, 25, 'Beguin', 'Laetitia', '22-04-1987', '999999999999999999'),
(29, 28, 'Benali', 'Kais', '10-04-2011', '999999999999999999'),
(30, 345, 'Teles Ferreira', 'Kevin', '08-08-1994', '999999999999999999'),
(31, 345, 'Feirreira', 'Bryan', '21-10-2002', '999999999999999999'),
(32, 350, 'Teles Ferreira', 'Kevin', '08-08-1994', '999999999999999999'),
(33, 350, 'Feirreira', 'Bryan', '21-10-2002', '999999999999999999'),
(34, 34, 'Reinie', 'Estelle', '01-04-1978', '999999999999999999'),
(35, 34, 'Reinie', 'Vanessa', '22-10-1979', '999999999999999999'),
(36, 34, 'Reinie', 'Kevin', '20-01-1995', '999999999999999999'),
(37, 34, 'Reinie', 'Kelly', '04-02-1997', '999999999999999999'),
(38, 373, 'Beuche', 'Lea', '01-02-2006', '999999999999999999'),
(39, 373, 'Jouhannet', 'Chloe', '01-06-2001', '999999999999999999'),
(40, 373, 'Beuche', 'Aurore', '23-03-1999', '999999999999999999'),
(41, 37, 'Martins', 'Vanessa', '21-06-1989', '999999999999999999'),
(42, 37, 'Bidron', 'Valentin', '07-11-1993', '999999999999999999'),
(43, 41, 'Blazy', 'Killian', '12-03-1998', '999999999999999999'),
(44, 41, 'Blazy', 'Dimitri', '10-03-2001', '999999999999999999'),
(45, 41, 'Blazy', 'Jason', '24-10-2003', '999999999999999999'),
(46, 41, 'Blazy', 'Gabriel', '07-07-2011', '999999999999999999'),
(47, 42, 'Bodin', 'Killian', '12-03-2010', '999999999999999999'),
(48, 42, 'Bodin', 'Bastien', '27-03-2011', '999999999999999999'),
(49, 387, 'Bodin', 'Timeo', '15-03-2014', '999999999999999999'),
(50, 49, 'Mercier', 'Antoine', '14-06-1995', '999999999999999999'),
(51, 49, 'Mercier', 'Frederic', '08-04-1999', '999999999999999999'),
(52, 49, 'Mercier', 'Samuel', '27-06-2000', '999999999999999999'),
(53, 50, 'Brissaud', 'Teo', '04-04-2002', '999999999999999999'),
(54, 51, 'Desabres', 'Anais', '12-12-1995', '999999999999999999'),
(55, 51, 'Brissaud', 'Teo', '04-04-2002', '999999999999999999'),
(56, 52, 'Brisset', 'Aurelie', '20-03-1992', '999999999999999999'),
(57, 52, 'Brisset', 'Alicia', '22-09-1995', '999999999999999999'),
(58, 52, 'Brisset', 'Marion', '14-05-1997', '999999999999999999'),
(59, 53, 'Brouard', 'Melanie', '20-11-1992', '999999999999999999'),
(60, 53, 'Brouard', 'Eva', '12-02-2001', '999999999999999999'),
(61, 56, 'Dufrene', 'Romain', '10-04-1991', '999999999999999999'),
(62, 56, 'Larmignat', 'Dylan', '18-10-1996', '999999999999999999'),
(63, 56, 'Larmignat', 'Hugo', '06-09-2001', '999999999999999999'),
(64, 68, 'Charlon', 'Noemie', '04-11-2005', '999999999999999999');

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `bilan`
--

INSERT INTO `bilan` (`idcasebilan`, `type_bilan`, `libelle_mouvement`, `debit`, `credit`, `num_mouvement`) VALUES
(2, 1, 'Achat: ', '0', '', '7633948810'),
(3, 1, 'Achat: ', '0', '', '7640112471'),
(4, 2, 'Vente de Billetterie: MARSOLLIER                     JEROME               pour la prestation BANQUET INVITES', '', '70', '3982758');

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `billet_salarie`
--

INSERT INTO `billet_salarie` (`idbilletsalarie`, `idsalarie`, `date_vente`, `idtypetraitement`, `total_vente`, `etat_billet_salarie`, `num_mouvement`) VALUES
(1, 198, '02-11-2015', 3, '70', 1, '3982758');

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '', ''),
(81, 2, '', ''),
(82, 3, '', ''),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '', ''),
(87, 8, '', ''),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '', ''),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', ''),
(113, 34, '', ''),
(114, 35, '', ''),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '', ''),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '', ''),
(134, 55, '', ''),
(135, 56, '', ''),
(136, 57, '', ''),
(137, 58, '', ''),
(138, 59, '', ''),
(139, 60, '', ''),
(140, 61, '', ''),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', 'CrÃ©ances Client'),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', ''),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', ''),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Postaux'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'Frais d''administration'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achat de matÃ©riel '),
(61, 6, 'Autre Charge d''exploitation 1', ''),
(62, 6, 'Autre Charge d''exploitation 2', ''),
(63, 6, 'Autre Charge d''exploitation 3', ''),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_pret`
--

CREATE TABLE `compta_pret` (
  `idcomptapret` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_pret` varchar(255) NOT NULL,
  `desc_pret` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'COMITE D''ENTREPRISE BARILLA MALTERIE', '', '', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cpt_resultat`
--

INSERT INTO `cpt_resultat` (`idcptresultat`, `num_mouvement`, `date_mouvement`, `designation`, `debit`, `credit`) VALUES
(2, '7633948810', '', 'Achat - ', '0', ''),
(3, '7640112471', '', 'Achat - ', '0', ''),
(4, '3982758', '1446418800', 'Vente de Billetterie: MARSOLLIER                     JEROME               pour la prestation BANQUET INVITES', '', '70');

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `famille_prestation`
--

INSERT INTO `famille_prestation` (`idfamilleprestation`, `designation_famille`) VALUES
(17, 'EVENEMENTS SOCIAUX '),
(18, 'EVENEMENTS FAMILIAUX'),
(19, 'CHEQUES VACANCES'),
(20, 'SORTIES DIVERSES'),
(21, 'BILLETTERIES'),
(22, 'ETANG MOBILHOME'),
(23, 'CLUB BARILLA'),
(24, 'VENTES DIVERSES');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL,
  `commentaire` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ligne_billet_salarie`
--

INSERT INTO `ligne_billet_salarie` (`idlignebilletsalarie`, `idbilletsalarie`, `idprestation`, `qte`, `part_salarie`, `part_ce`, `hors_quota`, `commentaire`) VALUES
(1, 1, 3, '2', '70', '0', 0, '');

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.6.1', '15315-PREM');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'administrateur', '882baf28143fb700b388a87ef561a6e5', 1),
(2, 'barilla36', '48042b1dae4950fef2bd2aafa0b971a1', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '0'),
(3, 'vente_direct', '0');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prestation`
--

INSERT INTO `prestation` (`idprestation`, `idfamilleprestation`, `designation`, `debut_validite`, `fin_validite`, `part_salarie`, `part_ce`, `cout_presta`, `nb_max_salarie`, `nb_stock`, `hors_quota`) VALUES
(1, 17, 'BANQUET SALARIE', '01-01-2015', '31-12-2015', '0', '35', '35', '1', '260', 0),
(2, 17, 'BANQUET CONJOINT', '01-01-2015', '31-12-2015', '10', '25', '35', '5', '1000', 0),
(3, 17, 'BANQUET INVITES', '01-01-2015', '31-12-2015', '35', '0', '35', '5', '258', 0),
(4, 17, 'CONCOURS DE BOULES', '09-09-2015', '09-09-2015', '0', '40', '40', '1000', '100000', 0),
(5, 17, 'INSCRIPTION CONCOURS DE BOULE SALARIE', '01-01-2015', '31-12-2015', '6', '0', '6', '5', '1000', 0),
(6, 17, 'INSCRIPTION CONCOURS DE BOULES CONJOINT', '01-01-2015', '31-12-2015', '10', '0', '10', '5', '1000', 0),
(8, 17, 'INSCRIPTION CONCOURS DE PECHE SALARIE', '01-01-2015', '31-12-2015', '6', '0', '6', '1', '1000', 0),
(9, 17, 'INSCRIPTION CONCOURS PECHE CONJOINT ET ENFANTS', '01-01-2015', '31-12-2015', '10', '0', '10', '10', '1000', 0),
(11, 21, 'Cinema Chateauroux', '', '', '5', '1.8', '6.8', '2', '100', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reg_billet_salarie`
--

INSERT INTO `reg_billet_salarie` (`idregbilletsalarie`, `idbilletsalarie`, `type_reglement`, `montant_reglement`, `banque_chq`, `porteur_chq`, `num_chq`, `pointe`) VALUES
(2, 1, 1, '70', 'ca', 'marsollier', '123', 0);

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(2, '', 2, 'ALI BEN HADJ', 'KARINE              ', 'LES PETITS GIRAUDONS', '', '36120', 'SAINT AOUT', '', '', '', '', '01-07-2003', '', '', '', '', '', 'CDI', 1, '10000'),
(3, '', 2, 'MATHEN', 'MARYSE', 'DES ETATS UNIS', '', '36000', 'CHATEAUROUX', '', '', '', '', '01-08-2007', '', '', '', '', '', '', 1, '10000'),
(4, '', 1, 'ANDRADE DE FREITAS', 'RUI MANUEL', 'DE LA CATICHE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(5, '', 2, 'ANGONIN', 'DELPHINE', 'DES LILAS', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(6, '', 1, 'ANTIN                         ', 'THIERRY             ', 'DU MONTET', 'APPT 31', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(7, '', 2, 'AUBRUN                        ', 'MARIE-CHRISTINE     ', 'DES PERRIERES', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(8, '', 2, 'AUGENDRE', 'DANIELLE', 'LES LOGES BERNARD L''AIGUILLON', '', '36230', 'NEUVY ST SEPULCHRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(10, '', 1, 'AUSSOURD                      ', 'RAPHAEL             ', 'LES PREAUX', '                                ', '36230', 'MONTIPOURET', '', '', '', '', '01-01-2001', '', '', 'ELECTROMECANICIEN', '', '', 'CDI', 1, '10000'),
(11, '', 1, 'AUTIN                         ', 'JEAN MICHEL          ', 'DU COLONEL PICHENET    ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(12, '', 1, 'BABILLOT                      ', 'CHRISTOPHE          ', 'LES COTEAUX', '                                ', '36250', 'SAINT MAUR                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(13, '', 2, 'BABUCHON', 'JOCELYNE', 'LE CHAMP  DU PONT', '', '36330', 'ARTHON                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(14, '', 2, 'BALOUX', 'JOSETTE', 'DE SAINT AMAND', '', '18170', 'LE CHATELET', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(15, '', 1, 'BARBAT                        ', 'ALAIN               ', 'ROLAND GARROS         ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(16, '', 1, 'BARBOT                        ', 'DANIEL              ', 'CECILE SOREL          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(18, '', 0, 'BARON                         ', 'PATRICK             ', 'DE LA CROIX DES BARRES', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(19, '', 0, 'BARRE', 'ANTHONY', 'LES THOMASSES', '', '36200', 'MOSNAY', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(20, '', 0, 'BARREAU                       ', 'JACQUES             ', 'DES BAUDICHONNES      ', '                                ', '36700', 'CHATILLON SUR INDRE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(21, '', 0, 'BARTHELEMY                    ', 'YANNICK             ', 'DES PRES DE DERRIERE', '                                ', '36250', 'VILLERS LES ORMES         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(22, '', 0, 'BATARD                        ', 'PASCAL              ', 'DE MARBAN', 'LE PRESSOIR', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(23, '', 0, 'BAUCHET                       ', 'FRANCK              ', 'DU SEQUOIA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(24, '', 0, 'BEAUCHENAT                    ', 'MICKAEL             ', 'DE LA GARE            ', '                                ', '36240', 'ECUEILLE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(25, '', 0, 'BEGUIN                        ', 'MARIE CHRISTINE          ', 'DU DOCTEUR LAMAZE     ', 'APPT 103                 ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(26, '', 0, 'BELLET                        ', 'THIERRY             ', 'HECTOR BERLIOZ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(28, '', 0, 'BENALI                        ', 'NOEL                ', 'DES PORNINS', ' ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(29, '', 0, 'BERGER', 'DIDIER              ', 'DE LA TOUCHE', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(32, '', 0, 'BERNARD                       ', 'ALAIN               ', 'JACQUES PREVERT       ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(33, '', 0, 'BERNARD                       ', 'MICHEL              ', 'DU BLANC              ', 'BENAVENT', '36300', 'POULIGNY ST PIERRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(34, '', 0, 'BERNIER', 'RAYMONDE            ', 'DE LA GRANDE CROIX    ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(35, '', 0, 'BERTHON                       ', 'ERIC                ', 'DU PETIT PONT', 'LA TOUCHE PASQUIER              ', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(36, '', 0, 'BERTON                        ', 'DAMIEN              ', 'DES JONCS', ' ', '36110', 'SAINT MARTIN DE LAMPS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(37, '', 0, 'BIDRON                        ', 'NATHALIE            ', 'DE CHATEAUROUX        ', '                                ', '36500', 'VENDOEUVRES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(39, '', 0, 'BILLARD', 'SEBASTIEN           ', 'DE VENDOEUVRES        ', '', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(40, '', 0, 'BINOT                         ', 'JEAN MARC           ', 'DE LA GARE            ', '                                ', '36110', 'VINEUIL                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(41, '', 0, 'BLAZY                         ', 'DAVID               ', 'DU JARDIN', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(42, '', 0, 'BODIN                         ', 'GUY NOEL            ', 'ANDRE REULAND', '                                ', '36800', 'LE PONT CHRETIEN CHABENET', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(43, '', 0, 'BONJEAN', 'DAVID               ', 'DES SAULES', '', '36130', 'DIORS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(44, '', 0, 'BONNISSEAU                    ', 'JACKY               ', 'DU RUISSEAU', ' ', '36500', 'SAINT GENOU', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(45, '', 0, 'BOULIOL                       ', 'JEAN-MICHEL         ', 'DU 90 EME REGIMENT D''INFANTERIE', '                                ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(47, '', 1, 'BOURDEAU                      ', 'JEAN-PAUL           ', 'LE CHAMPS CADEAU', ' ', '36400', 'LA CHATRE                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(48, '', 0, 'BOUTARD                       ', 'JEAN-PIERRE         ', 'DES MAISONS BRULEES   ', '                                ', '36400', 'LA CHATRE                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(49, '', 0, 'BRILLAUD                      ', 'FRANCIS             ', 'FOSSE BELLOT          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(50, '', 0, 'BRISSAUD                      ', 'FREDERIC            ', 'DES CAPUCINES         ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(51, '', 0, 'BRISSAUD                      ', 'CHRISTELE', 'DES CAPUCINES', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(52, '', 0, 'BRISSET                       ', 'DIDIER              ', 'DES GROUAILLES        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(53, '', 0, 'BROUARD                       ', 'BRUNO               ', 'CAMILLE ST SAENS', ' ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(54, '', 0, 'BRUNEAU', 'JEAN MARY', 'DES AMANDIERS', '', '36130', 'DEOLS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(56, '', 0, 'BRUNET                        ', 'MARIE THERESE       ', 'MARCEL CACHIN         ', 'APPT 70', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(57, '', 0, 'BURBAUD                       ', 'PHILIPPE            ', 'DE LA VOUIVRE         ', 'VILLIERS                        ', '36370', 'MAUVIERES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(59, '', 0, 'CAMUS                         ', 'PATRICK             ', 'DU TECQ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(60, '', 0, 'CAUMON                        ', 'LUDOVIC             ', 'DU LAVOIR             ', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(61, '', 0, 'CAZY                          ', 'JEAN CHRISTOPHE     ', 'DES AMANDIERS', '                                ', '36320', 'VILLEDIEU                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(62, '', 0, 'CHABOCHE                      ', 'STEPHANE            ', 'EDITH PIAF', 'APPT 198                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(63, '', 0, 'CHAILLER', 'SEBASTIEN           ', 'PAUL VALERY           ', 'APPT 145', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(64, '', 0, 'CHAMPIOT                      ', 'LAURENT             ', 'DU CLOU               ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(65, '', 0, 'CHANTRAINE                    ', 'DIDIER              ', 'LE CHAMP DU PONT', '                                ', '36330', 'ARTHON                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(66, '', 0, 'CHARBONNIER', 'YANNICK', 'DE REUILLY', '', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(67, '', 0, 'CHARDON                       ', 'JEAN LUC            ', 'ANNA DE NOAILLE       ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(68, '', 1, 'CHARLON                       ', 'PASCAL              ', 'BAUDELAIRE           ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(69, '', 0, 'CHASSEAU                      ', 'THIERRY             ', 'BASCOULARD            ', 'LE COUDRAY                      ', '18290', 'CIVRAY                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(70, '', 0, 'CHATONNET                     ', 'DOMINIQUE           ', 'DE LA CHAMPENOISE', '                                ', '36100', 'NEUVY- PAILLOUX            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(71, '', 0, 'CHAUVIN', 'ANGELINA', 'DE LA FLEURANDERIE', '', '36130', 'DEOLS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(72, '', 0, 'CHAUVIN                       ', 'MARIE-FRANCOISE          ', 'D''ARGENTON            ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(75, '', 0, 'CHOQUET                       ', 'THIERRY             ', 'DE PROVENCE           ', 'APPT 136', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(76, '', 0, 'CHUFFART                      ', 'CLAUDETTE           ', 'DES JARDINS', ' ', '36120', 'ARDENTES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(78, '', 0, 'COANUS                        ', 'MARIANNE            ', 'DES DRYADES', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(79, '', 0, 'COCHEREAU                     ', 'ALEXANDRE           ', 'DE PROVENCE           ', 'APPT 134                      ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(80, '', 0, 'COCLIN', 'VIVIANE', 'DE VERDUN', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(81, '', 0, 'COLIN', 'JACKY               ', 'BLAISE PASCAL         ', 'APPT 3354', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(82, '', 0, 'COMBAUD                       ', 'THIERRY             ', 'DE CHATEAUNEUF', '                                ', '36200', 'ARGENTON SUR CREUSE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(83, '', 0, 'CORIAN                        ', 'MARIO               ', 'TERRES FORTES         ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(84, '', 0, 'COUET                         ', 'LUDOVIC             ', 'DES BOUVREUILS', '                                ', '36100', 'SAINT FAUSTE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(85, '', 0, 'COUNILLET                     ', 'BEATRICE            ', 'DE L''ECOLE   ', '                                ', '36130', 'DIORS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(86, '', 0, 'COUNILLET                     ', 'JEAN PHILIPPE       ', 'DE L''ECOLE   ', '                                ', '36130', 'DIORS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(87, '', 0, 'COUNILLET                     ', 'DAVID               ', 'DES ORANGERS', '                                ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(88, '', 0, 'CROUZY                        ', 'MICHEL              ', 'DES BAS               ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(89, '', 0, 'CRUVELLIER                    ', 'BERENGERE           ', 'DU GENERAL DE GAULLE  ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(90, '', 0, 'DA SILVA                      ', 'CARLOS              ', 'MARCEL CACHIN         ', 'APPT 68', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(92, '', 0, 'DAURIOL                       ', 'ERIC                ', 'DU GUE DE LA CHAPELLE    ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(93, '', 0, 'DAVAILLON                     ', 'DAMIEN              ', 'DE CHATEAUROUX        ', '                                ', '36500', 'VENDOEUVRES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(94, '', 0, 'DAVIER', 'CATHERINE           ', 'ANTOINE DE ST EXUPERY', '', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(95, '', 0, 'DAVIET', 'CHRISTOPHE          ', 'LA CHAUME NERAULT', '', '36230', 'NEUVY-SAINT SEPULCHRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(96, '', 0, 'DEBENEST', 'PATRICK             ', 'DE MONTLUCON', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(97, '', 0, 'DEBRIS                        ', 'CHRISTOPHE          ', 'DES COURS', ' ', '36250', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(98, '', 0, 'DECHENE                       ', 'PATRICK             ', 'DE NIHERNE            ', '                                ', '36250', 'VILLERS LES ORMES         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(99, '', 0, 'DECHENE                       ', 'DOMINIQUE           ', 'DES AMANDIERS', ' ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(100, '', 0, 'DEJOIE                        ', 'STEPHANE            ', 'DES GLYCINES', '', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(101, '', 0, 'DEJOIE                        ', 'LAURENT             ', 'JUST VEILLAT          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(102, '', 0, 'DELETANG                      ', 'FRANCOIS            ', 'D''AQUITAINE', 'APPT 207                         ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(103, '', 0, 'DEMELLIER                     ', 'DOMINIQUE           ', '                      ', 'LE BOULONNAIS                   ', '36320', 'VILLEDIEU         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(104, '', 0, 'DENAES                        ', 'JEAN PAUL           ', 'DES AUBRAYS', 'APPT 75', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(105, '', 0, 'DESRIER                       ', 'THIERRY             ', 'EISENHOWER            ', 'APPT 153', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(106, '', 0, 'DEVILLIERS                    ', 'PATRICK             ', 'DU CLERGE             ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(107, '', 0, 'DORANGEON', 'JACQUES             ', 'VASSON', '', '36120', 'JEU LES BOIS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(108, '', 0, 'DOUCHE                        ', 'CYRIL               ', 'GENERAL BERTRAND', ' ', '36100', 'SAINT VALENTIN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(109, '', 0, 'DUBREUIL', 'DENIS', 'PRINCIPALE', '', '36400', 'LE MAGNY', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(110, '', 0, 'DUCHEMIN', 'FLORENCE', 'LES VIGNES DE LA CHAUM', '', '36800', 'CHASSENEUIL', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(111, '', 0, 'DUPLAN                        ', 'PASCAL              ', 'DU ROTISSANT', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(112, '', 0, 'DURIS', 'FRANCK              ', 'ANDRE REULAND', ' ', '36800', 'LE PONT CHRETIEN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(113, '', 0, 'DUVAL                         ', 'ERICK                ', 'DE LA METAIRIE', '                                ', '36100', 'LA CHAMPENOISE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(114, '', 0, 'EL ALAMI                      ', 'DRISS               ', 'ANDRE LE NOTRE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(115, '', 0, 'EL MALKI                      ', 'ABDELHAMID          ', 'ANDRE GIDE            ', 'APPT 2839', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(116, '', 0, 'FADIL                         ', 'JAMAL               ', 'DES SAUNEES', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(117, '', 0, 'FANDRE', 'STEPHANE            ', 'LE FRESNE', '', '36320', 'VILLEDIEU SUR INDRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(118, '', 0, 'FANDRE                        ', 'YANNICK             ', 'DE L''ABREUVOIR', '                                ', '36320', 'VILLEDIEU', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(119, '', 0, 'FAVEREAU                      ', 'YANNICK             ', 'DES ROSES', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(120, '', 0, 'FERRANDIERE', 'CAROLE              ', 'DU CH?TEAU ', '                                ', '36100', 'NEUVY- PAILLOUX            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(121, '', 0, 'FILLION                       ', 'JACKY               ', 'LOUIS BRAILLE', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(122, '', 0, 'FONTAINE                      ', 'MARIE-JEANNE        ', 'DU GENERAL DE GAULLE  ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(123, '', 0, 'FOREST                        ', 'PATRICK             ', 'EUGENE GRILLON        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(124, '', 0, 'FOREST                        ', 'HERVE               ', 'PAUL VALERY           ', 'APPT 34/56                      ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(125, '', 0, 'FOUCHER', 'PIERRE-YVES', 'DU SEQUOIA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(126, '', 0, 'FOUCRET                       ', 'JEAN CLAUDE          ', 'BLAISE PASCAL         ', 'APPT 462', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(127, '', 0, 'FOULATIER                     ', 'LAURENT             ', 'LES ETANGS BRISSE', '                                ', '36400', 'SAINT CHARTIER            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(128, '', 0, 'FRADET                        ', 'BERNARD             ', 'FLANDRES DUNKERQUE', 'APPT 1', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(129, '', 0, 'FRENAIZON                     ', 'MICHELINE           ', 'DE CHATELLERAULT      ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(130, '', 0, 'GABLIN                        ', 'ERIC                ', 'DU BLANC              ', '                                ', '36220', 'TOURNON ST MARTIN         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(131, '', 0, 'GAGNERAULT                    ', 'DIDIER              ', 'DES BRUYERES', 'BRASSIOUX                       ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(132, '', 0, 'GAILLOCHON                    ', 'CYRIL               ', 'DU QUARTIER LATIN     ', '                                ', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(133, '', 0, 'GARCEAULT', 'HERVE               ', 'PAUL VALERY           ', 'APPT 139', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(134, '', 0, 'GATEFOIN                      ', 'SILVINA             ', 'SAINT DENIS           ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(135, '', 0, 'GAUDAIS                       ', 'ALAIN               ', 'DES LUZERNES', ' ', '36250', 'VILLERS LES ORMES         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(136, '', 0, 'GAUTHIER                      ', 'LUDOVIC             ', 'LE LARREE', ' ', '36200', 'ARGENTON SUR CREUSE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(137, '', 0, 'GAUTHIER                      ', 'CLAUDE              ', 'CELON                 ', '                                ', '36320', 'VILLEDIEU                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(138, '', 0, 'GAUTIER', 'PASCAL', 'DE VERNEUIL', '', '36200', 'LE PECHEREAU', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(139, '', 0, 'GAUTRON                       ', 'FREDERIC            ', 'RATZ LA PEROUILLE     ', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(140, '', 0, 'GAUTRON                       ', 'MICHEL', 'LA PLAINE DES CHEZEAUX', '', '36800', 'SAINT GAULTIER            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(141, '', 0, 'GENDRON', 'FABIENNE ', 'DE ROSNAY', '', '36500', 'VENDOEUVRES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(142, '', 0, 'GODET                         ', 'SYLVIE              ', 'LOT LONGEROLLE       ', 'ARTHON                          ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(143, '', 0, 'GRASON                        ', 'ADRIEN              ', 'DU FOSSE ROUGE', '                                ', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(144, '', 0, 'GRIMAUD                       ', 'JEROME              ', 'DU GENERAL DE GAULLE  ', ' ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(145, '', 0, 'GUILLEMAIN                    ', 'JEAN YVES           ', '                      ', 'LE PETIT PLESSIS                ', '36330', 'VELLES                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(146, '', 0, 'GUILLOTON                     ', 'SEBASTIEN           ', 'DE LA BARONNERIE', 'CERE', '36130', 'COINGS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(147, '', 0, 'GUINCETRE                     ', 'CHRISTOPHE          ', 'LOUIS BLANC           ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(148, '', 0, 'GUYONNET                      ', 'LUDOVIC             ', 'DES ORANGERS', '                                ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(149, '', 0, 'HALLARY                       ', 'MAX                 ', 'DES CHAMPS            ', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(150, '', 0, 'HAMMOU OU ALI                 ', 'MOSTAFA             ', 'ARISTIDE BRIAND', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(152, '', 0, 'HERAULT                       ', 'CHRISTOPHE          ', 'LINO VENTURA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(153, '', 0, 'HERAULT                       ', 'CHRISTOPHE          ', 'DE LA VRILLE', 'APPT 5', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(154, '', 0, 'HERGAULT                      ', 'PATRICE             ', 'D''ARPHEUILLES         ', 'LES CHIRONS                     ', '36290', 'SAULNAY                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(155, '', 0, 'HERMANN', 'MARIE JOSE', 'DU GENERAL LECLERC', '', '36200', 'ARGENTON SUR CREUSE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(156, '', 0, 'HERMITE                       ', 'FREDERIC            ', 'GERARD PHILIPPE', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(157, '', 0, 'HIBOIS                        ', 'DIDIER              ', 'LE MOULIN NEUF', '                                ', '36200', 'LE MENOUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(158, '', 0, 'HILAIRE', 'CYRIL               ', 'CHARLES PERRAULT      ', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(161, '', 0, 'JAMIN                         ', 'EDOUARD             ', 'DE FASLAY', ' ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(162, '', 0, 'JAMIN                         ', 'BERNADETTE          ', ' DE LA CROIX FASLEY', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(163, '', 0, 'JARDIN                        ', 'THIERRY             ', 'LA VERDURE', '                                ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(164, '', 0, 'JOLY', 'LAETITIA            ', 'JEAN MOULIN', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(165, '', 0, 'JOUBERT                       ', 'JEAN LUC            ', 'GRANDE                ', '                                ', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(166, '', 0, 'JOURNAULT                     ', 'JEAN RENE           ', 'DE BELLE ISLE         ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(167, '', 0, 'JOURNAUX                      ', 'PHILIPPE            ', 'DU LAVOIR             ', '                                ', '36700', 'ARPHEUILLES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(168, '', 0, 'JOUSSE', 'MICKAEL             ', 'DE LA LIBERTE', '', '36150', 'VATAN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(169, '', 0, 'KABUL                         ', 'OMUR                ', 'GUSTAVE FLAUBERT', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(170, '', 0, 'KHATTAB', 'AHMED', 'DES Etats-Unis', 'APPT 5', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(173, '', 0, 'LAMIREL', 'CORINNE             ', 'VICTOR HUGO', '', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(174, '', 0, 'LAMY                          ', 'KARINE              ', 'DE VERDUN', '                                ', '36250', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(175, '', 0, 'LANDILLON                     ', 'PAULETTE            ', 'DU PORTUGAL           ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(176, '', 0, 'LARMIGNAT                     ', 'MICHEL      ', 'DES CAPUCINES         ', 'BRASSIOUX                       ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(178, '', 0, 'LATHIERE', 'PHILIPPE            ', 'FONTBON', '', '36150', 'LA CHAPELLE ST LAURIAN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(179, '', 0, 'LE CLEAC''H                    ', 'PATRICK             ', 'POUSSE PENIL', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(180, '', 0, 'LE SAUX', 'JEROME              ', 'LE BOURG              ', '', '36290', 'SAULNAY                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(181, '', 0, 'LEBEAU                        ', 'CHANTAL             ', 'JEAN D''ALEMBERT', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(182, '', 0, 'LECHENE                       ', 'PATRICIA            ', 'DE LA GARE            ', 'MONTIERCHAUME                   ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(183, '', 0, 'LECHOWSKI                     ', 'FABIEN              ', 'DU VAL DE L''INDRE     ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(184, '', 0, 'LEGAGNEUX                     ', 'HERVE               ', 'DES ORMES             ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(185, '', 0, 'LEMOINE                       ', 'DIDIER              ', 'VILLEGINAIS', ' ', '36340', 'MALICORNAY                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(186, '', 0, 'LIMOUSIN                      ', 'CHRISTIAN           ', 'COSNAY', '', '36400', 'LACS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(187, '', 0, 'LIVERNETTE                    ', 'CHRISTOPHE          ', 'CHARLES PERRAULT      ', 'APPT 3502                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(188, '', 0, 'LLEDO                         ', 'BERNADETTE          ', 'DES AUBRAYS', 'APPART 1                       ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(189, '', 0, 'LLEDO                         ', 'RICHARD             ', 'DU PRESIDENT ALLENDE', '                                ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(190, '', 0, 'LLINARES', 'NADIA', 'PAUL VERLAINE', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(192, '', 2, 'LORY                          ', 'CHANTAL             ', 'LE PETIT PLESSIS      ', 'LES GAYATS                      ', '36120', 'ST AOUT                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(193, '', 0, 'LOUIS                         ', 'FRANCK              ', 'MARCEL BOUILLON', ' ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(194, '', 0, 'LOUREIRO                      ', 'JOAQUIM             ', 'LOTISSEMENT LES ORMES ', 'VINEUIL                         ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(195, '', 0, 'MARANDON                      ', 'ISABELLE            ', 'DES PORNINS', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(197, '', 0, 'MARINET                       ', 'BRIGITTE            ', 'DE L''EGLISE', '                                ', '36150', 'LINIEZ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(198, '', 1, 'MARSOLLIER                    ', 'JEROME              ', '1 RUE DES ORMES             ', 'PIOU', '36120', 'MARON                     ', '', '0603707813', 'jemarsol@gmail.com', '19-04-1968', '29-09-1991', '', '', 'Ã©lÃ©ctro mÃ©canicien', '', '', 'cdi', 1, '10000'),
(199, '', 0, 'MARTEAU                       ', 'CHRISTOPHE          ', 'DE LA BOETIE          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(200, '', 0, 'MARTELLO                      ', 'JEAN FRANCOIS          ', 'FRANCOIS FENELON      ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(201, '', 0, 'MARTELLO                      ', 'SYLVIE              ', 'FRANCOIS FENELON      ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(202, '', 0, 'MARTIN                        ', 'CHRISTOPHE          ', 'PTIT FAUBOURG CHAMPAGN', '                                ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(203, '', 0, 'MARTINAT', 'CYRIL               ', 'LES ROGEAIS', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(204, '', 0, 'MASSON                        ', 'MARIE CLAUDE          ', 'DU CHATEAU FORT / SURINS', 'NIHERNE                         ', '36250', 'SAINT MAUR                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(205, '', 0, 'MASSON                        ', 'PATRICK             ', 'DE LA GRANDE CROIX    ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(206, '', 0, 'MEDARD                        ', 'OLIVIER             ', 'DU CORBUSIER          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(207, '', 0, 'MERCIER                       ', 'SEBASTIEN           ', 'D''ISSOUDUN', '                                ', '36100', 'MEUNET-PLANCHES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(208, '', 0, 'MESNARD                       ', 'SEBASTIEN           ', 'DES ROCS', '                                ', '18570', 'LA CHAPELLE ST URSIN      ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(209, '', 0, 'METENIER                      ', 'SEBASTIEN           ', 'DE LA PETITE FADETTE', ' ', '36400', 'LA CHATRE                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(210, '', 0, 'MEUNIER                       ', 'ELISABETH           ', 'DE L''ECOLE   ', '                                ', '36100', 'LES BORDES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(212, '', 0, 'MEZIANI', 'MOHAMED', 'MARCEL PROUST', 'APPT 3345', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(213, '', 0, 'MICHENET                      ', 'PATRICK             ', 'BLAISE PASCAL         ', 'APPARTEMENT 559                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(214, '', 0, 'MICHENET                      ', 'FRANCK              ', 'DES PEPINIERES        ', 'APPARTEMENT 136                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(215, '', 0, 'MILLIET                       ', 'CLAIRE              ', 'CHATRE                ', 'SASSIERGE ST GERMAIN            ', '36120', 'ARDENTES                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(216, '', 0, 'MIRANDA                       ', 'THIERRY             ', 'J PATUREAU FRANCOEUR', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(217, '', 0, 'MONNIER                       ', 'JULIEN              ', 'DE LA CHATRE', ' ', '36230', 'NEUVY- ST  SEPULCHRE        ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(218, '', 0, 'MOREAU', 'SEBASTIEN', 'JACQUES MASSONNEAU', '', '36250', 'ST MAUR', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(219, '', 0, 'MOREAU                        ', 'ERIC                ', 'DE LA FOSSE BELO', '', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(220, '', 0, 'MOREAU                        ', 'MICKAEL             ', 'DES EGLANTIERS', ' ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(221, '', 0, 'MOREAU                        ', 'YANNICK             ', 'DES PETITS CHAMPS', ' ', '36120', 'MARON                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(222, '', 0, 'MORELET', 'CHANTAL             ', 'DES MESANGES', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(224, '', 0, 'MOUAOUYA                      ', 'OMAR                ', 'JEAN JAURES', ' ', '36120', 'ARDENTES                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(227, '', 0, 'NGUYEN                        ', 'JEAN-PASCAL         ', 'PIERRE FRESNAY        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(228, '', 0, 'NGUYEN                        ', 'VAN THANH           ', 'PIERRE FRESNAY        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(229, '', 0, 'NIVERT', 'JULIEN              ', 'JACQUES COPEAU', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(230, '', 0, 'NIVET                         ', 'KARIM               ', 'DE LA TUILERIE        ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(231, '', 0, 'OUZDI                         ', 'AHMED               ', 'CHATEAUBRIAND', 'APPT 86', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(232, '', 0, 'OVIDE                         ', 'MIREILLE            ', 'CHAMBLAY              ', '                                ', '36110', 'MOULINS SUR CEPHONS        ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(233, '', 0, 'PAGE                          ', 'SEBASTIEN           ', 'ALFRED DE MUSSET', ' ', '36800', 'LE PONT CHRETIEN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(234, '', 0, 'PAILLOUX                      ', 'LYDIE               ', 'DES MADRONS', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(235, '', 0, 'PAINCHAULT                    ', 'SYLVIE              ', 'ALFRED NOBEL          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(236, '', 0, 'PAQUET                        ', 'TEDDY', 'DE LA VALLEE DE CHAMBON', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(237, '', 0, 'PAQUET                        ', 'JEAN PAUL           ', 'DES BERGERES          ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(238, '', 0, 'PASDELOUP                     ', 'PHILIPPE            ', 'DES GROUAILLES        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(239, '', 0, 'PATTIER                       ', 'DIDIER              ', 'DE METZ               ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(240, '', 0, 'PAULET                        ', 'JOEL                ', 'FERDINAND DE LESSEPS', '', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(241, '', 0, 'PELTIER                       ', 'NICOLAS             ', 'DE LA PROCESSION', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(242, '', 0, 'PENAULT                       ', 'ERIC                ', 'DU CARROIR', 'LE GRAND VILLEMONGIN  ', '36120', 'MARON                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(243, '', 0, 'PERICAT                       ', 'ISABELLE            ', 'BASSET                ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(244, '', 0, 'PERICAT                       ', 'CORINNE             ', 'DU PORTUGAL           ', ' ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(245, '', 0, 'PERICAT                       ', 'STEPHANE            ', 'DU 3EME RAC', '                                ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(246, '', 0, 'PERIOLAT                      ', 'SEBASTIEN           ', 'SANGUILLES            ', '                                ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(248, '', 0, 'PERRIOT                       ', 'CHRISTIAN           ', 'DE SAINT LACTENCIN', 'FOUILLEREAU', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(249, '', 0, 'PETIT', 'SYLVIE              ', 'AMABLE VIVIER', '                                ', '36110', 'MOULINS SUR CEPHONS       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(250, '', 0, 'PICOT                         ', 'MICHEL              ', 'DU 19 MARS 1962', 'APPT 158', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(251, '', 0, 'PIERRE                        ', 'DIDIER              ', 'DE LA CONCORDE', ' ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(252, '', 0, 'PIERRY                        ', 'FREDERIC            ', 'DE LA GARE            ', 'MONTIERCHAUME                   ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(253, '', 0, 'PILLIOT', 'DELPHINE', 'DE LA SENECHALE', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(255, '', 0, 'PILORGET                      ', 'JEAN MICHE          ', 'SARAH BERNHARDT       ', 'LA POINTERIE                    ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(256, '', 0, 'PINEAU                        ', 'WILLIAM             ', 'LE PETIT FOURCHAUD    ', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(257, '', 0, 'PINON', 'FRANCK              ', 'LE PRIEURE', '', '36240', 'JEU MALOCHES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(258, '', 0, 'PIOT                          ', 'FABIEN              ', 'CARNOT                ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(259, '', 0, 'PIROT                         ', 'DANIEL              ', 'AMEDEE MARCHAND', 'ROSIERES', '18400', 'LUNERY', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(260, '', 0, 'PIROT                         ', 'STEPHANE            ', 'D''ARDENTES', ' ', '36100', 'VOUILLON', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(261, '', 0, 'PLANTEUR', 'AURELIE', 'DES GREDILLES', '', '36130', 'DEOLS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(262, '', 0, 'POMMIER                       ', 'BERNARD             ', 'DE LA MANUFACTURE', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(263, '', 0, 'POMMIER                       ', 'HERVE               ', 'DU RABOT              ', 'CREVANT                         ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(264, '', 0, 'POQUEREAU                     ', 'SYLVIE              ', 'DE LA PAIX            ', '                                ', '36320', 'VILLEDIEU         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(265, '', 0, 'POQUEREAU                     ', 'VALERIE             ', 'DU VAL DE L''INDRE     ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(267, '', 0, 'POURNIN                       ', 'EVELYNE             ', 'DU PORTUGAL           ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(268, '', 0, 'POURNIN                       ', 'DAVID               ', 'DU CENTRE', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(269, '', 0, 'PRAK                          ', 'BERNARD             ', 'DES NATIONS           ', 'APPT 31', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(270, '', 0, 'PUYBERTIER                    ', 'FABRICE             ', 'DES TILLEULS', ' ', '36160', 'POULIGNY NOTRE DAME', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(271, '', 0, 'RABILLE                       ', 'FRANCIS             ', 'LA SAIGNE             ', '                                ', '36400', 'BRIANTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(272, '', 0, 'RAGOT                         ', 'CATHERINE           ', 'DE L''ECOLE   ', 'APPT 51', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(273, '', 0, 'RAT                           ', 'ERIC                ', 'ROUGET DE L''ISLE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(274, '', 0, 'REICHMUTH                      ', 'WILLIAM             ', 'DE BUZANCAIS', 'LA BARRE                        ', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(275, '', 0, 'RENARD', 'ANNE', 'ESPACE MENDES France', 'APPT 106', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(276, '', 0, 'RENAUD                        ', 'MICHELE             ', 'BEAUMONT DE LA PREUGNE', '                                ', '36400', 'SAINT CHARTIER            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(277, '', 0, 'RENAUD                        ', 'DANIEL              ', 'CHEMIN VERT           ', '                                ', '36110', 'VINEUIL                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(278, '', 0, 'RENAUD                        ', 'DOMINIQUE           ', 'DE LIGNIERES          ', '                                ', '36120', 'PRUNIERS                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000');
INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(279, '', 0, 'RENAUD                        ', 'GILLES              ', 'DE CHATEAUROUX        ', '                                ', '36700', 'FLERE LA RIVIERE          ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(280, '', 0, 'ROCHER                        ', 'ALAIN               ', 'DU 19 MARS 1962', 'APPT 134', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(281, '', 0, 'ROGER                         ', 'SEBASTIEN           ', '                      ', 'SANGUILLES                      ', '36120', 'ETRECHET                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(282, '', 0, 'ROGER                         ', 'MARIE HELENE          ', 'DU BOIS RAVEAU        ', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(283, '', 0, 'ROGER                         ', 'RICHARD             ', 'DU PALIS', 'CHEZ MR ROGER MAURICE', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(284, '', 0, 'ROSIER                        ', 'NADINE              ', 'DE TOURS              ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(285, '', 0, 'ROUAN', 'PATRICIA', 'LA VALLEE DE CHAMBON', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(286, '', 0, 'ROUAN                         ', 'MICHEL              ', 'LA VALLEE DE CHAMBON  ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(287, '', 0, 'ROUX                          ', 'ALAIN               ', 'LT CL PICHENE         ', 'LOT. LE LYS                     ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(288, '', 0, 'SALLE                         ', 'MARIE-FRANCE          ', 'DES GREDILLES', 'CHEMIN DES MALGRAPPES', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(289, '', 0, 'SALLE                         ', 'FREDERIC            ', 'DE LA MEDIOLANE', ' ', '36110', 'MOULINS SUR CEPHONS        ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(291, '', 0, 'SALLE                         ', 'JEAN PIERRE          ', 'BORDESOULE            ', '                                ', '36330', 'VELLES                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(292, '', 0, 'SEGELLE                       ', 'FRANCK              ', 'CHATRE', '                                ', '36120', 'SASSIERGES SAINT GERMAIN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(293, '', 0, 'SEGUIN                        ', 'CHRISTIAN           ', 'D''ARGENTON            ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(294, '', 0, 'SINOPLE                       ', 'HUBERT              ', 'DE VILLEGONGIS        ', 'ST CHRISTOPHE', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(295, '', 0, 'SOUPLET                       ', 'DAVID               ', 'DES CHAMPS DU PARE', '                                ', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(296, '', 0, 'STERN                         ', 'GEORGES             ', 'DE VARENNES', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(297, '', 0, 'SUBIRATS                      ', 'ALAIN               ', 'DU RETOUR', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(298, '', 0, 'TCHA', 'APOLO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(300, '', 0, 'THEILLAUMAS                   ', 'PHILIPPE            ', 'VICTOR HUGO', ' ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(301, '', 0, 'THERET                        ', 'PHILIPPE            ', 'SAINT PIERRE', 'RCS GEORGES SAND', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(302, '', 0, 'POMMIER                       ', 'ANGELIQUE', 'DE LA MANUFACTURE', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(304, '', 0, 'THIVET                        ', 'LAURENT             ', 'DE SAVOIE', 'APPT 17                         ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(306, '', 0, 'TIBOEUF                       ', 'SEVERINE            ', 'DU SEQUOIA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(307, '', 0, 'TIEURCELIN                    ', 'MURIELLE            ', 'POUSSE PENIL', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(308, '', 0, 'TOURNIER                      ', 'PATRICE             ', 'BLAISE PASCAL         ', 'APPT 374                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(309, '', 0, 'TOURTE                        ', 'PATRICK             ', 'LA POINTE DU JOUR     ', '                                ', '36110', 'VINEUIL                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(310, '', 0, 'TOUZET                        ', 'PATRICE             ', 'COMTESSE DE SEGUR     ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(311, '', 0, 'VACHER', 'CYRIL               ', 'DU MARECHAL DE LATTRE', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(312, '', 0, 'VACHET                        ', 'BEATRICE            ', 'DE VILLERS            ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(313, '', 0, 'VERGER', 'ROBERT', 'PAUL ELUARD', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(314, '', 0, 'VERGNOLLE                     ', 'MARINETTE           ', 'DE LA ROCHETTE', 'APPT 7 ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(315, '', 0, 'VERGNOLLE                     ', 'DOMINIQUE           ', 'DE L EGALITE          ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(316, '', 0, 'VERHELST                      ', 'JOEL                ', 'DU GRAND EPOT         ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(317, '', 0, 'VIEIRA DE ALMEDIA             ', 'ANTONIO             ', 'FOUILLEREAU           ', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(318, '', 0, 'VIGNOLET                      ', 'PASCAL              ', 'DES MARINS            ', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(320, '', 0, 'VOLLEREAUX                    ', 'CHANTAL             ', 'DE LA CROIX BLANCHE', 'CORNACAY', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(321, '', 0, 'WALTON                        ', 'WILLIAM             ', 'DE CORBILLY           ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(322, '', 0, 'WATISSEE                      ', 'FABRICE             ', 'GEORGE SAND', '                                ', '36200', 'SAINT MARCEL', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(323, '', 0, 'WATISSEE                      ', 'JEROME              ', 'DES JONQUILLES', '                                ', '36100', 'NEUVY- PAILLOUX            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(324, '', 0, 'WATISSEE                      ', 'DAVID               ', 'DE LA METAIRIE', ' ', '36100', 'LA CHAMPENOISE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(325, '', 1, 'YELALDI                       ', 'KEMAL               ', 'ESPACE MENDES FRANCE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(326, '', 1, 'BABINEAU', 'ERIC', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', 'cdi', 1, ''),
(327, '', 2, 'BEAUGER', 'NATHALIE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(328, '', 1, 'CHAPIOTIN', 'FABRICE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(329, '', 2, 'DOMALAIN', 'CORINE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(330, '', 1, 'ENFERT', 'CHRISTOPHE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(331, '', 1, 'FORICHON', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(332, '', 1, 'GIRAULT', 'BENOIT', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(333, '', 1, 'GORGEON', 'DENIS', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(334, '', 1, 'HAMMOU OU ALI', 'KARIM', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(335, '', 2, 'MARANGER', 'VERONIQUE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(336, '', 1, 'MOHAMED', 'KARIM', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(337, '', 2, 'PENOT', 'SANDRA', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(338, '', 1, 'PRENOIS', 'DAMIEN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(339, '', 1, 'PRENOIS', 'JEROME', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(340, '', 1, 'SALOMON', 'RENAUD', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(341, '', 1, 'SARTON', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(342, '', 1, 'STERN', 'LUC', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(343, '', 1, 'THORIN', 'FRANCK-ADONIS', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(344, '', 1, 'VERPOORT', 'VALENTINI', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(345, '', 1, 'ANCIAES FERREIRA', 'LUIS', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(346, '', 2, 'MASSOURI', 'ALLIA', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(347, '', 1, 'DEVILLIERES', 'ALAIN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(348, '', 1, 'BACHINI', 'KAMAL', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(349, '', 1, 'FAUCHET', 'PATRICK', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(350, '', 2, 'ANCIAES FERREIRA', 'SUZANA', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(351, '', 1, 'NORBERT', 'LAURENT', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(352, '', 2, 'GUILLOT', 'SANDRA', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(353, '', 1, 'GOURMELEN', 'BORIS', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(354, '', 2, 'LOUREIRO', 'ANTONIETA', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(355, '', 2, 'LAVIGNE', 'ANDREE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(356, '', 1, 'CARDHEILLAC', 'PHILIPPE', '7 rue du portail', '', '36000', 'Chateauroux', '', '', '', '', '01-10-2007', '', '1', '', '', '', '', 1, ''),
(357, '', 2, 'JARREAU', 'BERNARDETTE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(358, '', 1, 'RIDET', 'GERARD', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(359, '', 1, 'PORCHER', 'BRUNO', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(360, '', 1, 'BIABAUD', 'DAVID', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(361, '', 1, 'BERTHOMIERS', 'PHILIPPE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(362, '', 1, 'BOURGUIGNON', 'ALAIN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(363, '', 1, 'MOTTEAU', 'DAVID', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(364, '', 1, 'CAUMON', 'FRANCK', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(365, '', 1, 'SOLANGE', 'LIONEL', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(366, '', 2, 'VERITE', 'DOMINIQUE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(367, '', 2, 'SAUMUROT', 'SYLVIE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(368, '', 2, 'JEFFRARD', 'SYLVIE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(369, '', 2, 'ANTIN', 'CHRISTELLE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(370, '', 1, 'AAMIRA', 'ANASS', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(371, '', 1, 'BAUD', 'MOHAMED', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(372, '', 1, 'VORZAIS', 'CHARLES EDOUARD', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(373, '', 1, 'BEUCHE', 'JEAN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(374, '', 1, 'DELAIR', 'CHRISTOPHE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(375, '', 1, 'FRADET', 'HERVE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(376, '', 1, 'ALLEE', 'JULIEN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(377, '', 1, 'VILLATTE', 'OLIVIER', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(378, '', 1, 'LE FRAPPER', 'DIDIER', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(379, '', 1, 'SANTOS', 'ALEXANDRE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(380, '', 1, 'MAURY', 'DANIEL', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(381, '', 1, 'BUISSON', 'DENIS', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(382, '', 1, 'WATISSEE', 'JAMES', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(383, '', 1, 'DESRIER', 'KEVIN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(384, '', 2, 'LE GRIGUER', 'CELINE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(385, '', 1, 'POULTIER', 'YANNICK', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(386, '', 1, 'LARCHEVEQUE', 'EMMANUEL', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(387, '', 1, 'BODIN', 'JEREMIE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(388, '', 2, 'LARCHEVEQUE', 'CHRISTELLE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(389, '', 1, 'AUPRETRE', 'JEAN-LUC', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(390, '', 2, 'PION', 'MYRIAM', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(391, '', 1, 'MESLIN', 'KEVIN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(392, '', 1, 'THAYAPARAN', 'SELLIAH-KANDIAH', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(393, '', 1, 'BORGET', 'LUDOVIC', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(394, '', 1, 'CHAMPAGNE', 'JONATHAN', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(395, '', 1, 'THIMONET', 'THIERRY', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, ''),
(396, '', 2, 'TAUVY', 'FLORENCE', '', '', '', '', '', '', '', '', '', '', '1', '', '', '', '', 1, '');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `solde_caisse`
--

INSERT INTO `solde_caisse` (`idsoldecaisse`, `date_mouvement`, `num_mouvement`, `type_mouvement`, `type_solde`, `libelle_mouvement`, `debit`, `credit`, `point_caisse`) VALUES
(2, '1446418800', '123', 'Reglement Client', 'ChÃ¨que', 'Reglement de la prestation par chÃ¨que au nom de marsollier.', '', '70', 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  ADD PRIMARY KEY (`idcomptapret`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_pret`
--
ALTER TABLE `compta_pret`
  MODIFY `idcomptapret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=397;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
