-- phpMyAdmin SQL Dump
-- version 4.4.9
-- http://www.phpmyadmin.net
--
-- Client :  localhost:3306
-- Généré le :  Mar 08 Septembre 2015 à 15:01
-- Version du serveur :  5.5.44-0+deb7u1
-- Version de PHP :  5.5.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cebarilla`
--

-- --------------------------------------------------------

--
-- Structure de la table `achat_presta`
--

CREATE TABLE IF NOT EXISTS `achat_presta` (
  `idachatpresta` int(13) NOT NULL,
  `date_achat` varchar(255) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `total_achat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ayant_droit` (
  `idayantdroit` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `nom_ayant_droit` varchar(255) NOT NULL,
  `prenom_ayant_droit` varchar(255) NOT NULL,
  `date_naissance_ayant_droit` varchar(255) NOT NULL,
  `solde_ayant_droit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bilan`
--

CREATE TABLE IF NOT EXISTS `bilan` (
  `idcasebilan` int(13) NOT NULL,
  `type_bilan` int(1) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `billet_ayant_droit` (
  `idbilletayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billet_salarie`
--

CREATE TABLE IF NOT EXISTS `billet_salarie` (
  `idbilletsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `idtypetraitement` int(13) NOT NULL,
  `total_vente` varchar(255) NOT NULL,
  `etat_billet_salarie` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `charge_fixe`
--

CREATE TABLE IF NOT EXISTS `charge_fixe` (
  `idchargefixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_charge_fixe` varchar(255) NOT NULL,
  `montant_charge` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_balance`
--

CREATE TABLE IF NOT EXISTS `compta_balance` (
  `idcomptabalance` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_balance`
--

INSERT INTO `compta_balance` (`idcomptabalance`, `idcomptaplan`, `debit`, `credit`) VALUES
(80, 1, '', ''),
(81, 2, '', ''),
(82, 3, '', ''),
(83, 4, '', ''),
(84, 5, '', ''),
(85, 6, '', ''),
(86, 7, '', ''),
(87, 8, '', ''),
(88, 9, '', ''),
(89, 10, '', ''),
(90, 11, '', ''),
(91, 12, '', ''),
(92, 13, '', ''),
(93, 14, '', ''),
(94, 15, '', ''),
(95, 16, '', ''),
(96, 17, '', ''),
(97, 18, '', ''),
(98, 19, '', ''),
(99, 20, '', ''),
(100, 21, '', ''),
(101, 22, '', ''),
(102, 23, '', ''),
(103, 24, '', ''),
(104, 25, '', ''),
(105, 26, '', ''),
(106, 27, '', ''),
(107, 28, '', ''),
(108, 29, '', ''),
(109, 30, '', ''),
(110, 31, '', ''),
(111, 32, '', ''),
(112, 33, '', ''),
(113, 34, '', ''),
(114, 35, '', ''),
(115, 36, '', ''),
(116, 37, '', ''),
(117, 38, '', ''),
(118, 39, '', ''),
(119, 40, '', ''),
(120, 41, '', ''),
(121, 42, '', ''),
(122, 43, '', ''),
(123, 44, '', ''),
(124, 45, '', ''),
(125, 46, '', ''),
(126, 47, '', ''),
(127, 48, '', ''),
(128, 49, '', ''),
(129, 50, '', ''),
(130, 51, '', ''),
(131, 52, '', ''),
(132, 53, '', ''),
(133, 54, '', ''),
(134, 55, '', ''),
(135, 56, '', ''),
(136, 57, '', ''),
(137, 58, '', ''),
(138, 59, '', ''),
(139, 60, '', ''),
(140, 61, '', ''),
(141, 62, '', ''),
(142, 63, '', ''),
(143, 64, '', ''),
(144, 65, '', ''),
(145, 66, '', ''),
(146, 67, '', ''),
(147, 68, '', ''),
(148, 69, '', ''),
(149, 70, '', ''),
(150, 71, '', ''),
(151, 72, '', ''),
(152, 73, '', ''),
(153, 74, '', ''),
(154, 75, '', ''),
(155, 76, '', ''),
(156, 77, '', ''),
(157, 78, '', ''),
(158, 79, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_banque`
--

CREATE TABLE IF NOT EXISTS `compta_banque` (
  `idcomptabanque` int(13) NOT NULL,
  `date_bq` varchar(255) NOT NULL,
  `desc_bq` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_actif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_actif` (
  `idcptbilanactif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_bilan_passif`
--

CREATE TABLE IF NOT EXISTS `compta_bilan_passif` (
  `idcptbilanpassif` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `montant` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_caisse`
--

CREATE TABLE IF NOT EXISTS `compta_caisse` (
  `idcomptacaisse` int(13) NOT NULL,
  `date_caisse` varchar(255) NOT NULL,
  `desc_caisse` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_compte`
--

CREATE TABLE IF NOT EXISTS `compta_compte` (
  `idcomptacompte` int(13) NOT NULL,
  `idcomptaplan` int(11) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_livret`
--

CREATE TABLE IF NOT EXISTS `compta_livret` (
  `idcomptalivret` int(13) NOT NULL,
  `date_livret` varchar(255) NOT NULL,
  `desc_livret` varchar(25) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_mvm`
--

CREATE TABLE IF NOT EXISTS `compta_mvm` (
  `idcomptamvm` int(13) NOT NULL,
  `date_mvm` varchar(255) NOT NULL,
  `desc_mvm` varchar(255) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compta_plan`
--

CREATE TABLE IF NOT EXISTS `compta_plan` (
  `idcomptaplan` int(13) NOT NULL,
  `type_plan` int(1) NOT NULL,
  `nom_origine` varchar(255) NOT NULL,
  `nom_util` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compta_plan`
--

INSERT INTO `compta_plan` (`idcomptaplan`, `type_plan`, `nom_origine`, `nom_util`) VALUES
(1, 1, 'Caisse', 'Caisse'),
(2, 1, 'Poste', ''),
(3, 1, 'Banque', 'Banque'),
(4, 1, 'Cr&eacute;ances Clients', 'CrÃ©ances Client'),
(5, 1, 'Impots Pr&eacute;alable', ''),
(6, 1, 'Stock de Marchandises', ''),
(7, 1, 'Autre actif circulant 1', ''),
(8, 1, 'Autre actif circulant 2', 'Compte sur Livret'),
(9, 1, 'Autre actif circulant 3', ''),
(10, 1, 'Autre actif circulant  4', ''),
(11, 1, 'Machines et appareils', ''),
(12, 1, 'Mobiliers et installations', ''),
(13, 1, 'Infrastructure informatique', ''),
(14, 1, 'V&eacute;hicules', ''),
(15, 1, 'immeubles', ''),
(16, 1, 'Autre actif immobilis&eacute; 1', ''),
(17, 1, 'Autre actif immobilis&eacute; 2', ''),
(18, 1, 'Autre actif immobilis&eacute; 3', ''),
(19, 1, 'Autre actif immobilis&eacute; 4', ''),
(20, 2, 'Dettes Fournisseur', 'Dettes Fournisseur'),
(21, 2, 'TVA due', ''),
(22, 2, 'Dettes Hypoth&eacute;caire', ''),
(23, 2, 'Pr&ecirc;t Obtenue', ''),
(24, 2, 'Autre dette 1', 'Autres dettes'),
(25, 2, 'Autre dette 2', ''),
(26, 2, 'Autre dette 3', ''),
(27, 2, 'Autre dette 4', ''),
(28, 2, 'Capital', 'Capital'),
(29, 2, 'Priv&eacute;', ''),
(30, 2, 'Autre Capital 1', ''),
(31, 2, 'Autre Capital 2', ''),
(32, 3, 'Ventes de marchandises', 'Ventes de marchandises'),
(33, 3, 'D&eacute;ductions Obtenues', 'Gains divers'),
(34, 3, 'Commission (&agrave; des tiers)', ''),
(35, 3, 'Honoraires', 'Subvention de Fonctionnement'),
(36, 3, 'Prestations &agrave; soi-m&ecirc;me', 'Participation des salariÃ©s'),
(37, 3, 'Int&eacute;r&ecirc;t - Produits', 'IntÃ©rÃªts'),
(38, 3, 'Autre CA 1', 'Participation Entreprise'),
(39, 3, 'Autre CA 2', ''),
(40, 4, 'Achats de Marchandises', 'Achats de Marchandises'),
(41, 4, 'Frais d''Achats', ''),
(42, 4, 'Variations de Stocks', ''),
(43, 4, 'D&eacute;ductions Accord&eacute;es', ''),
(44, 4, 'Autre Charge 1', ''),
(45, 4, 'Autre Charge 2', ''),
(46, 5, 'Salaires', 'Salaires'),
(47, 5, 'Charges Sociales', 'Charges sociales'),
(48, 5, 'Autre charge de personnel 1', 'Honoraires'),
(49, 5, 'Autre charge de personnel 2', ''),
(50, 6, 'Loyer', 'Frais Postaux'),
(51, 6, 'Frais de V&eacute;hicules', 'Frais de dÃ©placements'),
(52, 6, 'Entretien et r&eacute;parations', 'Entretien et rÃ©parations'),
(53, 6, 'Frais d''exp&eacute;dition', 'Fournitures de bureaux'),
(54, 6, 'Assurances', 'Assurances'),
(55, 6, 'Electricit&eacute;, Gaz, etc...', 'Abonnements'),
(56, 6, 'Frais d''administration', 'Frais d''administration'),
(57, 6, 'T&eacute;l&eacute;phone, fax, internet', 'TÃ©lÃ©phone, fax, internet'),
(58, 6, 'Publicit&eacute;', 'Agios'),
(59, 6, 'Interet-charges, Frais Bancaires', 'Frais bancaires'),
(60, 6, 'Amortissements', 'Achat de matÃ©riel '),
(61, 6, 'Autre Charge d''exploitation 1', ''),
(62, 6, 'Autre Charge d''exploitation 2', ''),
(63, 6, 'Autre Charge d''exploitation 3', ''),
(64, 6, 'Autre Charge d''exploitation 4', ''),
(65, 7, 'Produits des titres', 'Produits Financiers'),
(66, 7, 'Produits d''immeubles', ''),
(67, 7, 'Autre r&eacute;sultat Annexe 1', ''),
(68, 7, 'Autre r&eacute;sultat Annexe 2', ''),
(69, 7, 'Charges d''immeubles', ''),
(70, 7, 'Autre Charge annexe 1', ''),
(71, 7, 'Autre Charge annexe 2', ''),
(72, 8, 'Produits Exeptionnels', 'Produits Exeptionnels'),
(73, 8, 'Autre r&eacute;sultat exeptionnel 1', ''),
(74, 8, 'Autre r&eacute;sultat exeptionnel 2', ''),
(75, 8, 'Charges Exeptionnelles', ''),
(76, 8, 'Impot sur le B&eacute;n&eacute;fice', ''),
(77, 8, 'Impots sur le Capital', ''),
(78, 8, 'Autre charge exeptionnelle 1', 'Charges Exceptionnelles'),
(79, 8, 'Autre charge exeptionnelle 2', '');

-- --------------------------------------------------------

--
-- Structure de la table `compta_resultat`
--

CREATE TABLE IF NOT EXISTS `compta_resultat` (
  `idresultat` int(13) NOT NULL,
  `idcomptaplan` int(13) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `config_etablissement`
--

CREATE TABLE IF NOT EXISTS `config_etablissement` (
  `idetablissement` int(13) NOT NULL,
  `nom_etablissement` varchar(255) NOT NULL,
  `remise_salarie` varchar(255) NOT NULL,
  `remise_ayant_droit` varchar(255) NOT NULL,
  `prefix_achat` varchar(255) NOT NULL,
  `prefix_vente` varchar(255) NOT NULL,
  `num_license` varchar(255) NOT NULL,
  `date_derniere_cloture` varchar(255) NOT NULL,
  `date_prochaine_cloture` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `config_etablissement`
--

INSERT INTO `config_etablissement` (`idetablissement`, `nom_etablissement`, `remise_salarie`, `remise_ayant_droit`, `prefix_achat`, `prefix_vente`, `num_license`, `date_derniere_cloture`, `date_prochaine_cloture`) VALUES
(1, 'COMITE D''ENTREPRISE BARILLA MALTERIE', '', '', 'FACTA000', 'FACVE000', 'F1A6E-62E69-1D508-10E25-1308B', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_resultat`
--

CREATE TABLE IF NOT EXISTS `cpt_resultat` (
  `idcptresultat` int(11) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `famille_prestation`
--

CREATE TABLE IF NOT EXISTS `famille_prestation` (
  `idfamilleprestation` int(13) NOT NULL,
  `designation_famille` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_ayant_droit` (
  `idlignebilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ligne_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `ligne_billet_salarie` (
  `idlignebilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `idprestation` int(13) NOT NULL,
  `qte` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_systeme`
--

CREATE TABLE IF NOT EXISTS `log_systeme` (
  `idlog` int(13) NOT NULL,
  `date_log` varchar(255) NOT NULL,
  `heure_log` varchar(255) NOT NULL,
  `libelle_log` varchar(255) NOT NULL,
  `etat_log` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `maj`
--

CREATE TABLE IF NOT EXISTS `maj` (
  `idmaj` int(13) NOT NULL,
  `version_latest` varchar(255) NOT NULL,
  `build` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `maj`
--

INSERT INTO `maj` (`idmaj`, `version_latest`, `build`) VALUES
(5, '1.6.1', '15315-PREM');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE IF NOT EXISTS `membre` (
  `iduser` int(13) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass_md5` varchar(255) NOT NULL,
  `groupe` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`iduser`, `login`, `pass_md5`, `groupe`) VALUES
(1, 'Administrateur', '25f9e794323b453885f5181f1b624d0b', 1);

-- --------------------------------------------------------

--
-- Structure de la table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `idmodule` int(13) NOT NULL,
  `designation_module` varchar(255) NOT NULL,
  `etat_module` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `module`
--

INSERT INTO `module` (`idmodule`, `designation_module`, `etat_module`) VALUES
(2, 'solde_salarie', '1'),
(3, 'vente_direct', '1');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

CREATE TABLE IF NOT EXISTS `prestation` (
  `idprestation` int(13) NOT NULL,
  `idfamilleprestation` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `debut_validite` varchar(255) NOT NULL,
  `fin_validite` varchar(255) NOT NULL,
  `part_salarie` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `cout_presta` varchar(255) NOT NULL,
  `nb_max_salarie` varchar(255) NOT NULL,
  `nb_stock` varchar(25) NOT NULL,
  `hors_quota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `produit_fixe`
--

CREATE TABLE IF NOT EXISTS `produit_fixe` (
  `idproduitfixe` int(13) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `date_produit_fixe` varchar(255) NOT NULL,
  `montant_produit` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `reg_billet_ayant_droit` (
  `idregbilletayantdroit` int(13) NOT NULL,
  `idbilletayantdroit` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_billet_salarie`
--

CREATE TABLE IF NOT EXISTS `reg_billet_salarie` (
  `idregbilletsalarie` int(13) NOT NULL,
  `idbilletsalarie` int(13) NOT NULL,
  `type_reglement` int(1) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `banque_chq` varchar(255) NOT NULL,
  `porteur_chq` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL,
  `pointe` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `reg_remb_ayant_droit` (
  `idregrembayantdroit` int(13) NOT NULL,
  `idrembayantdroit` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reg_remb_salarie`
--

CREATE TABLE IF NOT EXISTS `reg_remb_salarie` (
  `idregrembsalarie` int(13) NOT NULL,
  `idrembsalarie` int(13) NOT NULL,
  `montant_reglement` varchar(255) NOT NULL,
  `num_chq` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_ayant_droit`
--

CREATE TABLE IF NOT EXISTS `remb_ayant_droit` (
  `idrembayantdroit` int(13) NOT NULL,
  `idayantdroit` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remb_salarie`
--

CREATE TABLE IF NOT EXISTS `remb_salarie` (
  `idrembsalarie` int(13) NOT NULL,
  `idsalarie` int(13) NOT NULL,
  `prestation` varchar(255) NOT NULL,
  `date_vente` varchar(255) NOT NULL,
  `montant_prestation` varchar(255) NOT NULL,
  `part_ce` varchar(255) NOT NULL,
  `etat_facture` int(1) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque`
--

CREATE TABLE IF NOT EXISTS `remise_banque` (
  `idremisebanque` int(13) NOT NULL,
  `date_remise` varchar(255) NOT NULL,
  `type_remise` int(1) NOT NULL,
  `num_remise` varchar(255) NOT NULL,
  `montant_remise` varchar(255) NOT NULL,
  `valid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_chq`
--

CREATE TABLE IF NOT EXISTS `remise_banque_chq` (
  `idremisebanquechq` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `remise_banque_esp`
--

CREATE TABLE IF NOT EXISTS `remise_banque_esp` (
  `idremisebanqueesp` int(13) NOT NULL,
  `idremisebanque` int(13) NOT NULL,
  `idreglementventepresta` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

CREATE TABLE IF NOT EXISTS `salarie` (
  `idsalarie` int(13) NOT NULL,
  `matricule` varchar(255) NOT NULL,
  `civilite_salarie` int(1) NOT NULL,
  `nom_salarie` varchar(255) NOT NULL,
  `prenom_salarie` varchar(255) NOT NULL,
  `adresse1_salarie` varchar(255) NOT NULL,
  `adresse2_salarie` varchar(255) NOT NULL,
  `cp_salarie` varchar(255) NOT NULL,
  `ville_salarie` varchar(255) NOT NULL,
  `tel_salarie` varchar(255) NOT NULL,
  `port_salarie` varchar(255) NOT NULL,
  `mail_salarie` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `entre_salarie` varchar(255) NOT NULL,
  `sortie_salarie` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `poste_salarie` varchar(255) NOT NULL,
  `indice_salarie` varchar(255) NOT NULL,
  `commentaire` longtext NOT NULL,
  `contrat` varchar(255) NOT NULL,
  `etat_salarie` int(1) NOT NULL,
  `solde_salarie` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=326 DEFAULT CHARSET=latin1;

--
-- Contenu de la table `salarie`
--

INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(2, '', 0, 'ALI BEN HADJ', 'KARINE              ', 'LES PETITS GIRAUDONS', '', '36120', 'SAINT AOUT', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(3, '', 0, 'MATHEN', 'MARYSE', 'DES ETATS UNIS', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(4, '', 0, 'ANDRADE DE FREITAS', 'RUI MANUEL', 'DE LA CATICHE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(5, '', 0, 'ANGONIN', 'DELPHINE', 'DES LILAS', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(6, '', 0, 'ANTIN                         ', 'THIERRY             ', 'DU MONTET', 'APPT 31', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(7, '', 0, 'AUBRUN                        ', 'MARIE-CHRISTINE     ', 'DES PERRIERES', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(8, '', 0, 'AUGENDRE', 'DANIELLE', 'LES LOGES BERNARD L''AIGUILLON', '', '36230', 'NEUVY ST SEPULCHRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(9, '', 0, 'AUPETIT                       ', 'CLAUDE              ', 'PIERRE DE COUBERTIN', '                                ', '36120', 'ARDENTES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(10, '', 0, 'AUSSOURD                      ', 'RAPHAEL             ', 'LES PREAUX', '                                ', '36230', 'MONTIPOURET', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(11, '', 0, 'AUTIN                         ', 'JEAN MICHEL          ', 'DU COLONEL PICHENET    ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(12, '', 0, 'BABILLOT                      ', 'CHRISTOPHE          ', 'LES COTEAUX', '                                ', '36250', 'SAINT MAUR                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(13, '', 0, 'BABUCHON', 'JOCELYNE', 'LE CHAMP  DU PONT', '', '36330', 'ARTHON                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(14, '', 0, 'BALOUX', 'JOSETTE', 'DE SAINT AMAND', '', '18170', 'LE CHATELET', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(15, '', 0, 'BARBAT                        ', 'ALAIN               ', 'ROLAND GARROS         ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(16, '', 0, 'BARBOT                        ', 'DANIEL              ', 'CECILE SOREL          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(17, '', 0, 'BARNIER', 'JULIEN              ', 'DE PONTAULT', '', '77330', 'OZOIR LA FERRIERE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(18, '', 0, 'BARON                         ', 'PATRICK             ', 'DE LA CROIX DES BARRES', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(19, '', 0, 'BARRE', 'ANTHONY', 'LES THOMASSES', '', '36200', 'MOSNAY', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(20, '', 0, 'BARREAU                       ', 'JACQUES             ', 'DES BAUDICHONNES      ', '                                ', '36700', 'CHATILLON SUR INDRE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(21, '', 0, 'BARTHELEMY                    ', 'YANNICK             ', 'DES PRES DE DERRIERE', '                                ', '36250', 'VILLERS LES ORMES         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(22, '', 0, 'BATARD                        ', 'PASCAL              ', 'DE MARBAN', 'LE PRESSOIR', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(23, '', 0, 'BAUCHET                       ', 'FRANCK              ', 'DU SEQUOIA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(24, '', 0, 'BEAUCHENAT                    ', 'MICKAEL             ', 'DE LA GARE            ', '                                ', '36240', 'ECUEILLE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(25, '', 0, 'BEGUIN                        ', 'MARIE CHRISTINE          ', 'DU DOCTEUR LAMAZE     ', 'APPT 103                 ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(26, '', 0, 'BELLET                        ', 'THIERRY             ', 'HECTOR BERLIOZ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(27, '', 0, 'BEME                          ', 'CHANTAL             ', 'FONTAINE SAINT GERMAIN', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(28, '', 0, 'BENALI                        ', 'NOEL                ', 'DES PORNINS', ' ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(29, '', 0, 'BERGER', 'DIDIER              ', 'DE LA TOUCHE', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(30, '', 0, 'BERGER                        ', 'LAURENCE            ', 'DU RABROT             ', 'CREVANT                         ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(31, '', 0, 'BERGER                        ', 'JEAN LUC            ', 'DU RABROT             ', 'CREVANT                         ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(32, '', 0, 'BERNARD                       ', 'ALAIN               ', 'JACQUES PREVERT       ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(33, '', 0, 'BERNARD                       ', 'MICHEL              ', 'DU BLANC              ', 'BENAVENT', '36300', 'POULIGNY ST PIERRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(34, '', 0, 'BERNIER', 'RAYMONDE            ', 'DE LA GRANDE CROIX    ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(35, '', 0, 'BERTHON                       ', 'ERIC                ', 'DU PETIT PONT', 'LA TOUCHE PASQUIER              ', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(36, '', 0, 'BERTON                        ', 'DAMIEN              ', 'DES JONCS', ' ', '36110', 'SAINT MARTIN DE LAMPS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(37, '', 0, 'BIDRON                        ', 'NATHALIE            ', 'DE CHATEAUROUX        ', '                                ', '36500', 'VENDOEUVRES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(38, '', 0, 'BIGOT                         ', 'DOMINIQUE           ', 'DE LA PRAIRIE         ', '                                ', '36320', 'VILLEDIEU SUR INDRE ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(39, '', 0, 'BILLARD', 'SEBASTIEN           ', 'DE VENDOEUVRES        ', '', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(40, '', 0, 'BINOT                         ', 'JEAN MARC           ', 'DE LA GARE            ', '                                ', '36110', 'VINEUIL                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(41, '', 0, 'BLAZY                         ', 'DAVID               ', 'DU JARDIN', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(42, '', 0, 'BODIN                         ', 'GUY NOEL            ', 'ANDRE REULAND', '                                ', '36800', 'LE PONT CHRETIEN CHABENET', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(43, '', 0, 'BONJEAN', 'DAVID               ', 'DES SAULES', '', '36130', 'DIORS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(44, '', 0, 'BONNISSEAU                    ', 'JACKY               ', 'DU RUISSEAU', ' ', '36500', 'SAINT GENOU', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(45, '', 0, 'BOULIOL                       ', 'JEAN-MICHEL         ', 'DU 90 EME REGIMENT D''INFANTERIE', '                                ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(46, '', 0, 'BOURBON                       ', 'JOEL                ', 'DU CARROIR', 'BOISRAMIER', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(47, '', 0, 'BOURDEAU                      ', 'JEAN-PAUL           ', 'LE CHAMPS CADEAU', ' ', '36400', 'LA CHATRE                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(48, '', 0, 'BOUTARD                       ', 'JEAN-PIERRE         ', 'DES MAISONS BRULEES   ', '                                ', '36400', 'LA CHATRE                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(49, '', 0, 'BRILLAUD                      ', 'FRANCIS             ', 'FOSSE BELLOT          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(50, '', 0, 'BRISSAUD                      ', 'FREDERIC            ', 'DES CAPUCINES         ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(51, '', 0, 'BRISSAUD                      ', 'CHRISTELE', 'DES CAPUCINES', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(52, '', 0, 'BRISSET                       ', 'DIDIER              ', 'DES GROUAILLES        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(53, '', 0, 'BROUARD                       ', 'BRUNO               ', 'CAMILLE ST SAENS', ' ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(54, '', 0, 'BRUNEAU', 'JEAN MARY', 'DES AMANDIERS', '', '36130', 'DEOLS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(55, '', 0, 'BRUNET                        ', 'JEAN LUC            ', 'LES MARTINETS         ', 'LA PEROUILLE                    ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(56, '', 0, 'BRUNET                        ', 'MARIE THERESE       ', 'MARCEL CACHIN         ', 'APPT 70', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(57, '', 0, 'BURBAUD                       ', 'PHILIPPE            ', 'DE LA VOUIVRE         ', 'VILLIERS                        ', '36370', 'MAUVIERES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(58, '', 0, 'CAILLAULT                     ', 'THIERRY             ', 'DE CHAVANNE           ', '                                ', '36320', 'VILLEDIEU         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(59, '', 0, 'CAMUS                         ', 'PATRICK             ', 'DU TECQ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(60, '', 0, 'CAUMON                        ', 'LUDOVIC             ', 'DU LAVOIR             ', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(61, '', 0, 'CAZY                          ', 'JEAN CHRISTOPHE     ', 'DES AMANDIERS', '                                ', '36320', 'VILLEDIEU                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(62, '', 0, 'CHABOCHE                      ', 'STEPHANE            ', 'EDITH PIAF', 'APPT 198                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(63, '', 0, 'CHAILLER', 'SEBASTIEN           ', 'PAUL VALERY           ', 'APPT 145', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(64, '', 0, 'CHAMPIOT                      ', 'LAURENT             ', 'DU CLOU               ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(65, '', 0, 'CHANTRAINE                    ', 'DIDIER              ', 'LE CHAMP DU PONT', '                                ', '36330', 'ARTHON                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(66, '', 0, 'CHARBONNIER', 'YANNICK', 'DE REUILLY', '', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(67, '', 0, 'CHARDON                       ', 'JEAN LUC            ', 'ANNA DE NOAILLE       ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(68, '', 0, 'CHARLON                       ', 'PASCAL              ', 'BAUDELAIRE           ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(69, '', 0, 'CHASSEAU                      ', 'THIERRY             ', 'BASCOULARD            ', 'LE COUDRAY                      ', '18290', 'CIVRAY                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(70, '', 0, 'CHATONNET                     ', 'DOMINIQUE           ', 'DE LA CHAMPENOISE', '                                ', '36100', 'NEUVY- PAILLOUX            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(71, '', 0, 'CHAUVIN', 'ANGELINA', 'DE LA FLEURANDERIE', '', '36130', 'DEOLS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(72, '', 0, 'CHAUVIN                       ', 'MARIE-FRANCOISE          ', 'D''ARGENTON            ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(73, '', 0, 'CHEVALIER                     ', 'ELIAN               ', 'DU MARCHE', ' ', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(74, '', 0, 'CHIRON', 'JEAN MICHEL', 'MAURICE THOREZ        ', 'APPT 23', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(75, '', 0, 'CHOQUET                       ', 'THIERRY             ', 'DE PROVENCE           ', 'APPT 136', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(76, '', 0, 'CHUFFART                      ', 'CLAUDETTE           ', 'DES JARDINS', ' ', '36120', 'ARDENTES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(77, '', 0, 'CIMETIERE', 'NATHALIE            ', 'DU GENERAL DE GAULLE', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(78, '', 0, 'COANUS                        ', 'MARIANNE            ', 'DES DRYADES', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(79, '', 0, 'COCHEREAU                     ', 'ALEXANDRE           ', 'DE PROVENCE           ', 'APPT 134                      ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(80, '', 0, 'COCLIN', 'VIVIANE', 'DE VERDUN', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(81, '', 0, 'COLIN', 'JACKY               ', 'BLAISE PASCAL         ', 'APPT 3354', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(82, '', 0, 'COMBAUD                       ', 'THIERRY             ', 'DE CHATEAUNEUF', '                                ', '36200', 'ARGENTON SUR CREUSE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(83, '', 0, 'CORIAN                        ', 'MARIO               ', 'TERRES FORTES         ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(84, '', 0, 'COUET                         ', 'LUDOVIC             ', 'DES BOUVREUILS', '                                ', '36100', 'SAINT FAUSTE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(85, '', 0, 'COUNILLET                     ', 'BEATRICE            ', 'DE L''ECOLE   ', '                                ', '36130', 'DIORS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(86, '', 0, 'COUNILLET                     ', 'JEAN PHILIPPE       ', 'DE L''ECOLE   ', '                                ', '36130', 'DIORS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(87, '', 0, 'COUNILLET                     ', 'DAVID               ', 'DES ORANGERS', '                                ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(88, '', 0, 'CROUZY                        ', 'MICHEL              ', 'DES BAS               ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(89, '', 0, 'CRUVELLIER                    ', 'BERENGERE           ', 'DU GENERAL DE GAULLE  ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(90, '', 0, 'DA SILVA                      ', 'CARLOS              ', 'MARCEL CACHIN         ', 'APPT 68', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(91, '', 0, 'DAUGERON', 'ERIC', 'JEANNE DARC', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(92, '', 0, 'DAURIOL                       ', 'ERIC                ', 'DU GUE DE LA CHAPELLE    ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(93, '', 0, 'DAVAILLON                     ', 'DAMIEN              ', 'DE CHATEAUROUX        ', '                                ', '36500', 'VENDOEUVRES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(94, '', 0, 'DAVIER', 'CATHERINE           ', 'ANTOINE DE ST EXUPERY', '', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(95, '', 0, 'DAVIET', 'CHRISTOPHE          ', 'LA CHAUME NERAULT', '', '36230', 'NEUVY-SAINT SEPULCHRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(96, '', 0, 'DEBENEST', 'PATRICK             ', 'DE MONTLUCON', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(97, '', 0, 'DEBRIS                        ', 'CHRISTOPHE          ', 'DES COURS', ' ', '36250', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(98, '', 0, 'DECHENE                       ', 'PATRICK             ', 'DE NIHERNE            ', '                                ', '36250', 'VILLERS LES ORMES         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(99, '', 0, 'DECHENE                       ', 'DOMINIQUE           ', 'DES AMANDIERS', ' ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(100, '', 0, 'DEJOIE                        ', 'STEPHANE            ', 'DES GLYCINES', '', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(101, '', 0, 'DEJOIE                        ', 'LAURENT             ', 'JUST VEILLAT          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(102, '', 0, 'DELETANG                      ', 'FRANCOIS            ', 'D''AQUITAINE', 'APPT 207                         ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(103, '', 0, 'DEMELLIER                     ', 'DOMINIQUE           ', '                      ', 'LE BOULONNAIS                   ', '36320', 'VILLEDIEU         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(104, '', 0, 'DENAES                        ', 'JEAN PAUL           ', 'DES AUBRAYS', 'APPT 75', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(105, '', 0, 'DESRIER                       ', 'THIERRY             ', 'EISENHOWER            ', 'APPT 153', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(106, '', 0, 'DEVILLIERS                    ', 'PATRICK             ', 'DU CLERGE             ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(107, '', 0, 'DORANGEON', 'JACQUES             ', 'VASSON', '', '36120', 'JEU LES BOIS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(108, '', 0, 'DOUCHE                        ', 'CYRIL               ', 'GENERAL BERTRAND', ' ', '36100', 'SAINT VALENTIN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(109, '', 0, 'DUBREUIL', 'DENIS', 'PRINCIPALE', '', '36400', 'LE MAGNY', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(110, '', 0, 'DUCHEMIN', 'FLORENCE', 'LES VIGNES DE LA CHAUM', '', '36800', 'CHASSENEUIL', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(111, '', 0, 'DUPLAN                        ', 'PASCAL              ', 'DU ROTISSANT', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(112, '', 0, 'DURIS', 'FRANCK              ', 'ANDRE REULAND', ' ', '36800', 'LE PONT CHRETIEN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(113, '', 0, 'DUVAL                         ', 'ERICK                ', 'DE LA METAIRIE', '                                ', '36100', 'LA CHAMPENOISE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(114, '', 0, 'EL ALAMI                      ', 'DRISS               ', 'ANDRE LE NOTRE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(115, '', 0, 'EL MALKI                      ', 'ABDELHAMID          ', 'ANDRE GIDE            ', 'APPT 2839', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(116, '', 0, 'FADIL                         ', 'JAMAL               ', 'DES SAUNEES', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(117, '', 0, 'FANDRE', 'STEPHANE            ', 'LE FRESNE', '', '36320', 'VILLEDIEU SUR INDRE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(118, '', 0, 'FANDRE                        ', 'YANNICK             ', 'DE L''ABREUVOIR', '                                ', '36320', 'VILLEDIEU', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(119, '', 0, 'FAVEREAU                      ', 'YANNICK             ', 'DES ROSES', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(120, '', 0, 'FERRANDIERE', 'CAROLE              ', 'DU CH?TEAU ', '                                ', '36100', 'NEUVY- PAILLOUX            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(121, '', 0, 'FILLION                       ', 'JACKY               ', 'LOUIS BRAILLE', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(122, '', 0, 'FONTAINE                      ', 'MARIE-JEANNE        ', 'DU GENERAL DE GAULLE  ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(123, '', 0, 'FOREST                        ', 'PATRICK             ', 'EUGENE GRILLON        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(124, '', 0, 'FOREST                        ', 'HERVE               ', 'PAUL VALERY           ', 'APPT 34/56                      ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(125, '', 0, 'FOUCHER', 'PIERRE-YVES', 'DU SEQUOIA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(126, '', 0, 'FOUCRET                       ', 'JEAN CLAUDE          ', 'BLAISE PASCAL         ', 'APPT 462', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(127, '', 0, 'FOULATIER                     ', 'LAURENT             ', 'LES ETANGS BRISSE', '                                ', '36400', 'SAINT CHARTIER            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(128, '', 0, 'FRADET                        ', 'BERNARD             ', 'FLANDRES DUNKERQUE', 'APPT 1', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(129, '', 0, 'FRENAIZON                     ', 'MICHELINE           ', 'DE CHATELLERAULT      ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(130, '', 0, 'GABLIN                        ', 'ERIC                ', 'DU BLANC              ', '                                ', '36220', 'TOURNON ST MARTIN         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(131, '', 0, 'GAGNERAULT                    ', 'DIDIER              ', 'DES BRUYERES', 'BRASSIOUX                       ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(132, '', 0, 'GAILLOCHON                    ', 'CYRIL               ', 'DU QUARTIER LATIN     ', '                                ', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(133, '', 0, 'GARCEAULT', 'HERVE               ', 'PAUL VALERY           ', 'APPT 139', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(134, '', 0, 'GATEFOIN                      ', 'SILVINA             ', 'SAINT DENIS           ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(135, '', 0, 'GAUDAIS                       ', 'ALAIN               ', 'DES LUZERNES', ' ', '36250', 'VILLERS LES ORMES         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(136, '', 0, 'GAUTHIER                      ', 'LUDOVIC             ', 'LE LARREE', ' ', '36200', 'ARGENTON SUR CREUSE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(137, '', 0, 'GAUTHIER                      ', 'CLAUDE              ', 'CELON                 ', '                                ', '36320', 'VILLEDIEU                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(138, '', 0, 'GAUTIER', 'PASCAL', 'DE VERNEUIL', '', '36200', 'LE PECHEREAU', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(139, '', 0, 'GAUTRON                       ', 'FREDERIC            ', 'RATZ LA PEROUILLE     ', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(140, '', 0, 'GAUTRON                       ', 'MICHEL', 'LA PLAINE DES CHEZEAUX', '', '36800', 'SAINT GAULTIER            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(141, '', 0, 'GENDRON', 'FABIENNE ', 'DE ROSNAY', '', '36500', 'VENDOEUVRES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(142, '', 0, 'GODET                         ', 'SYLVIE              ', 'LOT LONGEROLLE       ', 'ARTHON                          ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(143, '', 0, 'GRASON                        ', 'ADRIEN              ', 'DU FOSSE ROUGE', '                                ', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(144, '', 0, 'GRIMAUD                       ', 'JEROME              ', 'DU GENERAL DE GAULLE  ', ' ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(145, '', 0, 'GUILLEMAIN                    ', 'JEAN YVES           ', '                      ', 'LE PETIT PLESSIS                ', '36330', 'VELLES                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(146, '', 0, 'GUILLOTON                     ', 'SEBASTIEN           ', 'DE LA BARONNERIE', 'CERE', '36130', 'COINGS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(147, '', 0, 'GUINCETRE                     ', 'CHRISTOPHE          ', 'LOUIS BLANC           ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(148, '', 0, 'GUYONNET                      ', 'LUDOVIC             ', 'DES ORANGERS', '                                ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(149, '', 0, 'HALLARY                       ', 'MAX                 ', 'DES CHAMPS            ', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(150, '', 0, 'HAMMOU OU ALI                 ', 'MOSTAFA             ', 'ARISTIDE BRIAND', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(151, '', 0, 'HEERWALD                      ', 'CLAUDE              ', 'EDOUARD RAMONET       ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(152, '', 0, 'HERAULT                       ', 'CHRISTOPHE          ', 'LINO VENTURA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(153, '', 0, 'HERAULT                       ', 'CHRISTOPHE          ', 'DE LA VRILLE', 'APPT 5', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(154, '', 0, 'HERGAULT                      ', 'PATRICE             ', 'D''ARPHEUILLES         ', 'LES CHIRONS                     ', '36290', 'SAULNAY                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(155, '', 0, 'HERMANN', 'MARIE JOSE', 'DU GENERAL LECLERC', '', '36200', 'ARGENTON SUR CREUSE       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(156, '', 0, 'HERMITE                       ', 'FREDERIC            ', 'GERARD PHILIPPE', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(157, '', 0, 'HIBOIS                        ', 'DIDIER              ', 'LE MOULIN NEUF', '                                ', '36200', 'LE MENOUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(158, '', 0, 'HILAIRE', 'CYRIL               ', 'CHARLES PERRAULT      ', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(159, '', 0, 'HOUVIEZ', 'DELPHINE', 'DES AUBRAYS', 'APPT 11', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(160, '', 0, 'JAEGER                        ', 'JEAN JACQUES          ', 'LOTISSEMENT LES ORMES ', '', '36110', 'VINEUIL                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(161, '', 0, 'JAMIN                         ', 'EDOUARD             ', 'DE FASLAY', ' ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(162, '', 0, 'JAMIN                         ', 'BERNADETTE          ', ' DE LA CROIX FASLEY', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(163, '', 0, 'JARDIN                        ', 'THIERRY             ', 'LA VERDURE', '                                ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(164, '', 0, 'JOLY', 'LAETITIA            ', 'JEAN MOULIN', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(165, '', 0, 'JOUBERT                       ', 'JEAN LUC            ', 'GRANDE                ', '                                ', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(166, '', 0, 'JOURNAULT                     ', 'JEAN RENE           ', 'DE BELLE ISLE         ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(167, '', 0, 'JOURNAUX                      ', 'PHILIPPE            ', 'DU LAVOIR             ', '                                ', '36700', 'ARPHEUILLES               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(168, '', 0, 'JOUSSE', 'MICKAEL             ', 'DE LA LIBERTE', '', '36150', 'VATAN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(169, '', 0, 'KABUL                         ', 'OMUR                ', 'GUSTAVE FLAUBERT', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(170, '', 0, 'KHATTAB', 'AHMED', 'DES Etats-Unis', 'APPT 5', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(171, '', 0, 'LABEL                         ', 'JEAN CLAUDE          ', 'DES TAUPINS', 'LUANT                           ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(172, '', 0, 'LABOULAIS', 'LAURENT', 'BEAU SITE', '', '18100', 'VIERZON', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(173, '', 0, 'LAMIREL', 'CORINNE             ', 'VICTOR HUGO', '', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(174, '', 0, 'LAMY                          ', 'KARINE              ', 'DE VERDUN', '                                ', '36250', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(175, '', 0, 'LANDILLON                     ', 'PAULETTE            ', 'DU PORTUGAL           ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(176, '', 0, 'LARMIGNAT                     ', 'MICHEL      ', 'DES CAPUCINES         ', 'BRASSIOUX                       ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(177, '', 0, 'LARRY                         ', 'PHILIPPE            ', 'DE SALLE', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(178, '', 0, 'LATHIERE', 'PHILIPPE            ', 'FONTBON', '', '36150', 'LA CHAPELLE ST LAURIAN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(179, '', 0, 'LE CLEAC''H                    ', 'PATRICK             ', 'POUSSE PENIL', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(180, '', 0, 'LE SAUX', 'JEROME              ', 'LE BOURG              ', '', '36290', 'SAULNAY                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(181, '', 0, 'LEBEAU                        ', 'CHANTAL             ', 'JEAN D''ALEMBERT', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(182, '', 0, 'LECHENE                       ', 'PATRICIA            ', 'DE LA GARE            ', 'MONTIERCHAUME                   ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(183, '', 0, 'LECHOWSKI                     ', 'FABIEN              ', 'DU VAL DE L''INDRE     ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(184, '', 0, 'LEGAGNEUX                     ', 'HERVE               ', 'DES ORMES             ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(185, '', 0, 'LEMOINE                       ', 'DIDIER              ', 'VILLEGINAIS', ' ', '36340', 'MALICORNAY                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(186, '', 0, 'LIMOUSIN                      ', 'CHRISTIAN           ', 'COSNAY', '', '36400', 'LACS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(187, '', 0, 'LIVERNETTE                    ', 'CHRISTOPHE          ', 'CHARLES PERRAULT      ', 'APPT 3502                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(188, '', 0, 'LLEDO                         ', 'BERNADETTE          ', 'DES AUBRAYS', 'APPART 1                       ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(189, '', 0, 'LLEDO                         ', 'RICHARD             ', 'DU PRESIDENT ALLENDE', '                                ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(190, '', 0, 'LLINARES', 'NADIA', 'PAUL VERLAINE', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(191, '', 0, 'LORIEAU                       ', 'JEAN LOUIS          ', 'LOTISSEMENT LES ORMES ', 'VINEUIL                         ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(192, '', 0, 'LORY                          ', 'CHANTAL             ', 'LE PETIT PLESSIS      ', 'LES GAYATS                      ', '36120', 'ST AOUT                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(193, '', 0, 'LOUIS                         ', 'FRANCK              ', 'MARCEL BOUILLON', ' ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(194, '', 0, 'LOUREIRO                      ', 'JOAQUIM             ', 'LOTISSEMENT LES ORMES ', 'VINEUIL                         ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(195, '', 0, 'MARANDON                      ', 'ISABELLE            ', 'DES PORNINS', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(196, '', 0, 'MARANDON                      ', 'MIREILLE            ', 'DE CHATEAUROUX        ', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(197, '', 0, 'MARINET                       ', 'BRIGITTE            ', 'DE L''EGLISE', '                                ', '36150', 'LINIEZ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(198, '', 0, 'MARSOLLIER                    ', 'JEROME              ', 'DES ORMES             ', 'PIOU', '36120', 'MARON                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(199, '', 0, 'MARTEAU                       ', 'CHRISTOPHE          ', 'DE LA BOETIE          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(200, '', 0, 'MARTELLO                      ', 'JEAN FRANCOIS          ', 'FRANCOIS FENELON      ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(201, '', 0, 'MARTELLO                      ', 'SYLVIE              ', 'FRANCOIS FENELON      ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(202, '', 0, 'MARTIN                        ', 'CHRISTOPHE          ', 'PTIT FAUBOURG CHAMPAGN', '                                ', '36110', 'LEVROUX                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(203, '', 0, 'MARTINAT', 'CYRIL               ', 'LES ROGEAIS', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(204, '', 0, 'MASSON                        ', 'MARIE CLAUDE          ', 'DU CHATEAU FORT / SURINS', 'NIHERNE                         ', '36250', 'SAINT MAUR                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(205, '', 0, 'MASSON                        ', 'PATRICK             ', 'DE LA GRANDE CROIX    ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(206, '', 0, 'MEDARD                        ', 'OLIVIER             ', 'DU CORBUSIER          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(207, '', 0, 'MERCIER                       ', 'SEBASTIEN           ', 'D''ISSOUDUN', '                                ', '36100', 'MEUNET-PLANCHES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(208, '', 0, 'MESNARD                       ', 'SEBASTIEN           ', 'DES ROCS', '                                ', '18570', 'LA CHAPELLE ST URSIN      ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(209, '', 0, 'METENIER                      ', 'SEBASTIEN           ', 'DE LA PETITE FADETTE', ' ', '36400', 'LA CHATRE                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(210, '', 0, 'MEUNIER                       ', 'ELISABETH           ', 'DE L''ECOLE   ', '                                ', '36100', 'LES BORDES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(211, '', 0, 'MEUNIER                       ', 'PATRICIA            ', 'GALLIENI              ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(212, '', 0, 'MEZIANI', 'MOHAMED', 'MARCEL PROUST', 'APPT 3345', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(213, '', 0, 'MICHENET                      ', 'PATRICK             ', 'BLAISE PASCAL         ', 'APPARTEMENT 559                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(214, '', 0, 'MICHENET                      ', 'FRANCK              ', 'DES PEPINIERES        ', 'APPARTEMENT 136                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(215, '', 0, 'MILLIET                       ', 'CLAIRE              ', 'CHATRE                ', 'SASSIERGE ST GERMAIN            ', '36120', 'ARDENTES                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(216, '', 0, 'MIRANDA                       ', 'THIERRY             ', 'J PATUREAU FRANCOEUR', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(217, '', 0, 'MONNIER                       ', 'JULIEN              ', 'DE LA CHATRE', ' ', '36230', 'NEUVY- ST  SEPULCHRE        ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(218, '', 0, 'MOREAU', 'SEBASTIEN', 'JACQUES MASSONNEAU', '', '36250', 'ST MAUR', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(219, '', 0, 'MOREAU                        ', 'ERIC                ', 'DE LA FOSSE BELO', '', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(220, '', 0, 'MOREAU                        ', 'MICKAEL             ', 'DES EGLANTIERS', ' ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(221, '', 0, 'MOREAU                        ', 'YANNICK             ', 'DES PETITS CHAMPS', ' ', '36120', 'MARON                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(222, '', 0, 'MORELET', 'CHANTAL             ', 'DES MESANGES', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(223, '', 0, 'MOSLE                         ', 'CHRISTIANE          ', 'DES EPRIS', ' ', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(224, '', 0, 'MOUAOUYA                      ', 'OMAR                ', 'JEAN JAURES', ' ', '36120', 'ARDENTES                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(225, '', 0, 'MYTHERBALE', 'BRICE', 'CROIX DE L''AUNAY', '', '36200', 'LE PECHEREAU', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(226, '', 0, 'NABINEAU                      ', 'PATRICK             ', 'AMPERE                ', 'BAT B', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(227, '', 0, 'NGUYEN                        ', 'JEAN-PASCAL         ', 'PIERRE FRESNAY        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(228, '', 0, 'NGUYEN                        ', 'VAN THANH           ', 'PIERRE FRESNAY        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(229, '', 0, 'NIVERT', 'JULIEN              ', 'JACQUES COPEAU', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(230, '', 0, 'NIVET                         ', 'KARIM               ', 'DE LA TUILERIE        ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(231, '', 0, 'OUZDI                         ', 'AHMED               ', 'CHATEAUBRIAND', 'APPT 86', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(232, '', 0, 'OVIDE                         ', 'MIREILLE            ', 'CHAMBLAY              ', '                                ', '36110', 'MOULINS SUR CEPHONS        ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(233, '', 0, 'PAGE                          ', 'SEBASTIEN           ', 'ALFRED DE MUSSET', ' ', '36800', 'LE PONT CHRETIEN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(234, '', 0, 'PAILLOUX                      ', 'LYDIE               ', 'DES MADRONS', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(235, '', 0, 'PAINCHAULT                    ', 'SYLVIE              ', 'ALFRED NOBEL          ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(236, '', 0, 'PAQUET                        ', 'TEDDY', 'DE LA VALLEE DE CHAMBON', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(237, '', 0, 'PAQUET                        ', 'JEAN PAUL           ', 'DES BERGERES          ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(238, '', 0, 'PASDELOUP                     ', 'PHILIPPE            ', 'DES GROUAILLES        ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(239, '', 0, 'PATTIER                       ', 'DIDIER              ', 'DE METZ               ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(240, '', 0, 'PAULET                        ', 'JOEL                ', 'FERDINAND DE LESSEPS', '', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(241, '', 0, 'PELTIER                       ', 'NICOLAS             ', 'DE LA PROCESSION', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(242, '', 0, 'PENAULT                       ', 'ERIC                ', 'DU CARROIR', 'LE GRAND VILLEMONGIN  ', '36120', 'MARON                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(243, '', 0, 'PERICAT                       ', 'ISABELLE            ', 'BASSET                ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(244, '', 0, 'PERICAT                       ', 'CORINNE             ', 'DU PORTUGAL           ', ' ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(245, '', 0, 'PERICAT                       ', 'STEPHANE            ', 'DU 3EME RAC', '                                ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(246, '', 0, 'PERIOLAT                      ', 'SEBASTIEN           ', 'SANGUILLES            ', '                                ', '36120', 'ARDENTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(247, '', 0, 'PERRIN                        ', 'JACKY               ', 'DE LA CHAUME', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(248, '', 0, 'PERRIOT                       ', 'CHRISTIAN           ', 'DE SAINT LACTENCIN', 'FOUILLEREAU', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(249, '', 0, 'PETIT', 'SYLVIE              ', 'AMABLE VIVIER', '                                ', '36110', 'MOULINS SUR CEPHONS       ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(250, '', 0, 'PICOT                         ', 'MICHEL              ', 'DU 19 MARS 1962', 'APPT 158', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(251, '', 0, 'PIERRE                        ', 'DIDIER              ', 'DE LA CONCORDE', ' ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000');
INSERT INTO `salarie` (`idsalarie`, `matricule`, `civilite_salarie`, `nom_salarie`, `prenom_salarie`, `adresse1_salarie`, `adresse2_salarie`, `cp_salarie`, `ville_salarie`, `tel_salarie`, `port_salarie`, `mail_salarie`, `date_naissance`, `entre_salarie`, `sortie_salarie`, `status`, `poste_salarie`, `indice_salarie`, `commentaire`, `contrat`, `etat_salarie`, `solde_salarie`) VALUES
(252, '', 0, 'PIERRY                        ', 'FREDERIC            ', 'DE LA GARE            ', 'MONTIERCHAUME                   ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(253, '', 0, 'PILLIOT', 'DELPHINE', 'DE LA SENECHALE', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(254, '', 0, 'PILLOT                        ', 'YVES                ', 'DES CHARMES           ', '                                ', '36130', 'DIORS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(255, '', 0, 'PILORGET                      ', 'JEAN MICHE          ', 'SARAH BERNHARDT       ', 'LA POINTERIE                    ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(256, '', 0, 'PINEAU                        ', 'WILLIAM             ', 'LE PETIT FOURCHAUD    ', '                                ', '36350', 'LUANT                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(257, '', 0, 'PINON', 'FRANCK              ', 'LE PRIEURE', '', '36240', 'JEU MALOCHES', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(258, '', 0, 'PIOT                          ', 'FABIEN              ', 'CARNOT                ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(259, '', 0, 'PIROT                         ', 'DANIEL              ', 'AMEDEE MARCHAND', 'ROSIERES', '18400', 'LUNERY', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(260, '', 0, 'PIROT                         ', 'STEPHANE            ', 'D''ARDENTES', ' ', '36100', 'VOUILLON', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(261, '', 0, 'PLANTEUR', 'AURELIE', 'DES GREDILLES', '', '36130', 'DEOLS', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(262, '', 0, 'POMMIER                       ', 'BERNARD             ', 'DE LA MANUFACTURE', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(263, '', 0, 'POMMIER                       ', 'HERVE               ', 'DU RABOT              ', 'CREVANT                         ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(264, '', 0, 'POQUEREAU                     ', 'SYLVIE              ', 'DE LA PAIX            ', '                                ', '36320', 'VILLEDIEU         ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(265, '', 0, 'POQUEREAU                     ', 'VALERIE             ', 'DU VAL DE L''INDRE     ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(266, '', 0, 'POULIQUEN', 'CATHERINE           ', 'DU GUE AUX CHEVAUX', '', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(267, '', 0, 'POURNIN                       ', 'EVELYNE             ', 'DU PORTUGAL           ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(268, '', 0, 'POURNIN                       ', 'DAVID               ', 'DU CENTRE', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(269, '', 0, 'PRAK                          ', 'BERNARD             ', 'DES NATIONS           ', 'APPT 31', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(270, '', 0, 'PUYBERTIER                    ', 'FABRICE             ', 'DES TILLEULS', ' ', '36160', 'POULIGNY NOTRE DAME', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(271, '', 0, 'RABILLE                       ', 'FRANCIS             ', 'LA SAIGNE             ', '                                ', '36400', 'BRIANTES                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(272, '', 0, 'RAGOT                         ', 'CATHERINE           ', 'DE L''ECOLE   ', 'APPT 51', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(273, '', 0, 'RAT                           ', 'ERIC                ', 'ROUGET DE L''ISLE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(274, '', 0, 'REICHMUTH                      ', 'WILLIAM             ', 'DE BUZANCAIS', 'LA BARRE                        ', '36500', 'BUZANCAIS                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(275, '', 0, 'RENARD', 'ANNE', 'ESPACE MENDES France', 'APPT 106', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(276, '', 0, 'RENAUD                        ', 'MICHELE             ', 'BEAUMONT DE LA PREUGNE', '                                ', '36400', 'SAINT CHARTIER            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(277, '', 0, 'RENAUD                        ', 'DANIEL              ', 'CHEMIN VERT           ', '                                ', '36110', 'VINEUIL                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(278, '', 0, 'RENAUD                        ', 'DOMINIQUE           ', 'DE LIGNIERES          ', '                                ', '36120', 'PRUNIERS                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(279, '', 0, 'RENAUD                        ', 'GILLES              ', 'DE CHATEAUROUX        ', '                                ', '36700', 'FLERE LA RIVIERE          ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(280, '', 0, 'ROCHER                        ', 'ALAIN               ', 'DU 19 MARS 1962', 'APPT 134', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(281, '', 0, 'ROGER                         ', 'SEBASTIEN           ', '                      ', 'SANGUILLES                      ', '36120', 'ETRECHET                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(282, '', 0, 'ROGER                         ', 'MARIE HELENE          ', 'DU BOIS RAVEAU        ', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(283, '', 0, 'ROGER                         ', 'RICHARD             ', 'DU PALIS', 'CHEZ MR ROGER MAURICE', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(284, '', 0, 'ROSIER                        ', 'NADINE              ', 'DE TOURS              ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(285, '', 0, 'ROUAN', 'PATRICIA', 'LA VALLEE DE CHAMBON', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(286, '', 0, 'ROUAN                         ', 'MICHEL              ', 'LA VALLEE DE CHAMBON  ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(287, '', 0, 'ROUX                          ', 'ALAIN               ', 'LT CL PICHENE         ', 'LOT. LE LYS                     ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(288, '', 0, 'SALLE                         ', 'MARIE-FRANCE          ', 'DES GREDILLES', 'CHEMIN DES MALGRAPPES', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(289, '', 0, 'SALLE                         ', 'FREDERIC            ', 'DE LA MEDIOLANE', ' ', '36110', 'MOULINS SUR CEPHONS        ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(290, '', 0, 'SALLE                         ', 'GUY                 ', 'DES GREDILLES', 'CHEMIN DES MALGRAPPES', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(291, '', 0, 'SALLE                         ', 'JEAN PIERRE          ', 'BORDESOULE            ', '                                ', '36330', 'VELLES                    ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(292, '', 0, 'SEGELLE                       ', 'FRANCK              ', 'CHATRE', '                                ', '36120', 'SASSIERGES SAINT GERMAIN', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(293, '', 0, 'SEGUIN                        ', 'CHRISTIAN           ', 'D''ARGENTON            ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(294, '', 0, 'SINOPLE                       ', 'HUBERT              ', 'DE VILLEGONGIS        ', 'ST CHRISTOPHE', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(295, '', 0, 'SOUPLET                       ', 'DAVID               ', 'DES CHAMPS DU PARE', '                                ', '36120', 'AMBRAULT                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(296, '', 0, 'STERN                         ', 'GEORGES             ', 'DE VARENNES', '', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(297, '', 0, 'SUBIRATS                      ', 'ALAIN               ', 'DU RETOUR', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(298, '', 0, 'TCHA', 'APOLO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(299, '', 0, 'TEIXEIRA                      ', 'ANTONIO             ', 'DES MARINS            ', '                                ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(300, '', 0, 'THEILLAUMAS                   ', 'PHILIPPE            ', 'VICTOR HUGO', ' ', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(301, '', 0, 'THERET                        ', 'PHILIPPE            ', 'SAINT PIERRE', 'RCS GEORGES SAND', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(302, '', 0, 'POMMIER                       ', 'ANGELIQUE', 'DE LA MANUFACTURE', ' ', '36110', 'BRION', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(303, '', 0, 'THIBESSARD                    ', 'MICHEL              ', 'DES LILAS', 'APPARTEMENT 37                  ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(304, '', 0, 'THIVET                        ', 'LAURENT             ', 'DE SAVOIE', 'APPT 17                         ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(305, '', 0, 'TIBOEUF                       ', 'HERVE               ', 'DE L''ORMELLE          ', '                                ', '36250', 'NIHERNE                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(306, '', 0, 'TIBOEUF                       ', 'SEVERINE            ', 'DU SEQUOIA', ' ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(307, '', 0, 'TIEURCELIN                    ', 'MURIELLE            ', 'POUSSE PENIL', '                                ', '36100', 'ISSOUDUN                  ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(308, '', 0, 'TOURNIER                      ', 'PATRICE             ', 'BLAISE PASCAL         ', 'APPT 374                 ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(309, '', 0, 'TOURTE                        ', 'PATRICK             ', 'LA POINTE DU JOUR     ', '                                ', '36110', 'VINEUIL                   ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(310, '', 0, 'TOUZET                        ', 'PATRICE             ', 'COMTESSE DE SEGUR     ', '                                ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(311, '', 0, 'VACHER', 'CYRIL               ', 'DU MARECHAL DE LATTRE', '', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(312, '', 0, 'VACHET                        ', 'BEATRICE            ', 'DE VILLERS            ', '                                ', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(313, '', 0, 'VERGER', 'ROBERT', 'PAUL ELUARD', '', '36130', 'DEOLS                     ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(314, '', 0, 'VERGNOLLE                     ', 'MARINETTE           ', 'DE LA ROCHETTE', 'APPT 7 ', '36000', 'CHATEAUROUX', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(315, '', 0, 'VERGNOLLE                     ', 'DOMINIQUE           ', 'DE L EGALITE          ', '                                ', '36250', 'SAINT MAUR                ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(316, '', 0, 'VERHELST                      ', 'JOEL                ', 'DU GRAND EPOT         ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(317, '', 0, 'VIEIRA DE ALMEDIA             ', 'ANTONIO             ', 'FOUILLEREAU           ', '                                ', '36500', 'CHEZELLES                 ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(318, '', 0, 'VIGNOLET                      ', 'PASCAL              ', 'DES MARINS            ', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(319, '', 0, 'VOLLEREAUX                    ', 'YVES                ', 'DE LA CROIX BLANCHE', 'CORNACAY', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(320, '', 0, 'VOLLEREAUX                    ', 'CHANTAL             ', 'DE LA CROIX BLANCHE', 'CORNACAY', '36130', 'MONTIERCHAUME             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(321, '', 0, 'WALTON                        ', 'WILLIAM             ', 'DE CORBILLY           ', '                                ', '36330', 'LE POINCONNET             ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(322, '', 0, 'WATISSEE                      ', 'FABRICE             ', 'GEORGE SAND', '                                ', '36200', 'SAINT MARCEL', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(323, '', 0, 'WATISSEE                      ', 'JEROME              ', 'DES JONQUILLES', '                                ', '36100', 'NEUVY- PAILLOUX            ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(324, '', 0, 'WATISSEE                      ', 'DAVID               ', 'DE LA METAIRIE', ' ', '36100', 'LA CHAMPENOISE', '', '', '', '', '', '', '', '', '', '', '', 1, '10000'),
(325, '', 0, 'YELALDI                       ', 'KEMAL               ', 'ESPACE MENDES FRANCE', ' ', '36000', 'CHATEAUROUX               ', '', '', '', '', '', '', '', '', '', '', '', 1, '10000');

-- --------------------------------------------------------

--
-- Structure de la table `solde_caisse`
--

CREATE TABLE IF NOT EXISTS `solde_caisse` (
  `idsoldecaisse` int(13) NOT NULL,
  `date_mouvement` varchar(255) NOT NULL,
  `num_mouvement` varchar(255) NOT NULL,
  `type_mouvement` varchar(255) NOT NULL,
  `type_solde` varchar(255) NOT NULL,
  `libelle_mouvement` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `point_caisse` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  ADD PRIMARY KEY (`idachatpresta`);

--
-- Index pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  ADD PRIMARY KEY (`idayantdroit`);

--
-- Index pour la table `bilan`
--
ALTER TABLE `bilan`
  ADD PRIMARY KEY (`idcasebilan`);

--
-- Index pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  ADD PRIMARY KEY (`idbilletayantdroit`);

--
-- Index pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  ADD PRIMARY KEY (`idbilletsalarie`);

--
-- Index pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  ADD PRIMARY KEY (`idchargefixe`);

--
-- Index pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  ADD PRIMARY KEY (`idcomptabalance`);

--
-- Index pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  ADD PRIMARY KEY (`idcomptabanque`);

--
-- Index pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  ADD PRIMARY KEY (`idcptbilanactif`);

--
-- Index pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  ADD PRIMARY KEY (`idcptbilanpassif`);

--
-- Index pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  ADD PRIMARY KEY (`idcomptacaisse`);

--
-- Index pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  ADD PRIMARY KEY (`idcomptacompte`);

--
-- Index pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  ADD PRIMARY KEY (`idcomptalivret`);

--
-- Index pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  ADD PRIMARY KEY (`idcomptamvm`),
  ADD KEY `date_mvm` (`date_mvm`);

--
-- Index pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  ADD PRIMARY KEY (`idcomptaplan`);

--
-- Index pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  ADD PRIMARY KEY (`idresultat`);

--
-- Index pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  ADD PRIMARY KEY (`idetablissement`);

--
-- Index pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  ADD PRIMARY KEY (`idcptresultat`);

--
-- Index pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  ADD PRIMARY KEY (`idfamilleprestation`);

--
-- Index pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  ADD PRIMARY KEY (`idlignebilletayantdroit`);

--
-- Index pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  ADD PRIMARY KEY (`idlignebilletsalarie`);

--
-- Index pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  ADD PRIMARY KEY (`idlog`);

--
-- Index pour la table `maj`
--
ALTER TABLE `maj`
  ADD PRIMARY KEY (`idmaj`);

--
-- Index pour la table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`idmodule`);

--
-- Index pour la table `prestation`
--
ALTER TABLE `prestation`
  ADD PRIMARY KEY (`idprestation`);

--
-- Index pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  ADD PRIMARY KEY (`idproduitfixe`);

--
-- Index pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  ADD PRIMARY KEY (`idregbilletayantdroit`);

--
-- Index pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  ADD PRIMARY KEY (`idregbilletsalarie`);

--
-- Index pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  ADD PRIMARY KEY (`idregrembayantdroit`);

--
-- Index pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  ADD PRIMARY KEY (`idregrembsalarie`);

--
-- Index pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  ADD PRIMARY KEY (`idrembayantdroit`);

--
-- Index pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  ADD PRIMARY KEY (`idrembsalarie`);

--
-- Index pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  ADD PRIMARY KEY (`idremisebanque`);

--
-- Index pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  ADD PRIMARY KEY (`idremisebanquechq`);

--
-- Index pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  ADD PRIMARY KEY (`idremisebanqueesp`);

--
-- Index pour la table `salarie`
--
ALTER TABLE `salarie`
  ADD PRIMARY KEY (`idsalarie`);

--
-- Index pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  ADD PRIMARY KEY (`idsoldecaisse`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `achat_presta`
--
ALTER TABLE `achat_presta`
  MODIFY `idachatpresta` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ayant_droit`
--
ALTER TABLE `ayant_droit`
  MODIFY `idayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `bilan`
--
ALTER TABLE `bilan`
  MODIFY `idcasebilan` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_ayant_droit`
--
ALTER TABLE `billet_ayant_droit`
  MODIFY `idbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `billet_salarie`
--
ALTER TABLE `billet_salarie`
  MODIFY `idbilletsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `charge_fixe`
--
ALTER TABLE `charge_fixe`
  MODIFY `idchargefixe` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_balance`
--
ALTER TABLE `compta_balance`
  MODIFY `idcomptabalance` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT pour la table `compta_banque`
--
ALTER TABLE `compta_banque`
  MODIFY `idcomptabanque` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_actif`
--
ALTER TABLE `compta_bilan_actif`
  MODIFY `idcptbilanactif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_bilan_passif`
--
ALTER TABLE `compta_bilan_passif`
  MODIFY `idcptbilanpassif` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_caisse`
--
ALTER TABLE `compta_caisse`
  MODIFY `idcomptacaisse` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_compte`
--
ALTER TABLE `compta_compte`
  MODIFY `idcomptacompte` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_livret`
--
ALTER TABLE `compta_livret`
  MODIFY `idcomptalivret` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_mvm`
--
ALTER TABLE `compta_mvm`
  MODIFY `idcomptamvm` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `compta_plan`
--
ALTER TABLE `compta_plan`
  MODIFY `idcomptaplan` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT pour la table `compta_resultat`
--
ALTER TABLE `compta_resultat`
  MODIFY `idresultat` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `config_etablissement`
--
ALTER TABLE `config_etablissement`
  MODIFY `idetablissement` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `cpt_resultat`
--
ALTER TABLE `cpt_resultat`
  MODIFY `idcptresultat` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `famille_prestation`
--
ALTER TABLE `famille_prestation`
  MODIFY `idfamilleprestation` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_ayant_droit`
--
ALTER TABLE `ligne_billet_ayant_droit`
  MODIFY `idlignebilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `ligne_billet_salarie`
--
ALTER TABLE `ligne_billet_salarie`
  MODIFY `idlignebilletsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `log_systeme`
--
ALTER TABLE `log_systeme`
  MODIFY `idlog` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `maj`
--
ALTER TABLE `maj`
  MODIFY `idmaj` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `membre`
--
ALTER TABLE `membre`
  MODIFY `iduser` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `module`
--
ALTER TABLE `module`
  MODIFY `idmodule` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `prestation`
--
ALTER TABLE `prestation`
  MODIFY `idprestation` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `produit_fixe`
--
ALTER TABLE `produit_fixe`
  MODIFY `idproduitfixe` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_ayant_droit`
--
ALTER TABLE `reg_billet_ayant_droit`
  MODIFY `idregbilletayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_billet_salarie`
--
ALTER TABLE `reg_billet_salarie`
  MODIFY `idregbilletsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_ayant_droit`
--
ALTER TABLE `reg_remb_ayant_droit`
  MODIFY `idregrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `reg_remb_salarie`
--
ALTER TABLE `reg_remb_salarie`
  MODIFY `idregrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_ayant_droit`
--
ALTER TABLE `remb_ayant_droit`
  MODIFY `idrembayantdroit` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remb_salarie`
--
ALTER TABLE `remb_salarie`
  MODIFY `idrembsalarie` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque`
--
ALTER TABLE `remise_banque`
  MODIFY `idremisebanque` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque_chq`
--
ALTER TABLE `remise_banque_chq`
  MODIFY `idremisebanquechq` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `remise_banque_esp`
--
ALTER TABLE `remise_banque_esp`
  MODIFY `idremisebanqueesp` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `salarie`
--
ALTER TABLE `salarie`
  MODIFY `idsalarie` int(13) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=326;
--
-- AUTO_INCREMENT pour la table `solde_caisse`
--
ALTER TABLE `solde_caisse`
  MODIFY `idsoldecaisse` int(13) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
